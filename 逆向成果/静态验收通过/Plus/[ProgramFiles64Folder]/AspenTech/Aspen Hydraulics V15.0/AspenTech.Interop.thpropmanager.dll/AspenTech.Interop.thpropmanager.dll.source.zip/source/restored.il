// IL code: AspenTech.Interop.thpropmanager
.class private auto ansi '<Module>'
{
} // end of class <Module>

.class public auto ansi import beforefieldinit AspenTech.Interop.ThPropManager.COTHPropertyManagerClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThPropManager.IThermoPropertyManager,
	           AspenTech.Interop.ThPropManager.COTHPropertyManager,
	           AspenTech.Interop.ThPropManager.IHysysCalc,
	           AspenTech.Interop.ThPropManager.IThermoProperty,
	           AspenTech.Interop.ThPropManager.IFlashProperties,
	           AspenTech.Interop.ThPropManager.IPersistStreamInit,
	           AspenTech.Interop.ThPropManager.IPersist,
	           AspenTech.Interop.ThPropManager.ISupportErrorInfo,
	           AspenTech.Interop.ThPropManager.IThermoPropertyManager1,
	           AspenTech.Interop.ThPropManager.XMLParserClient,
	           AspenTech.Interop.ThPropManager.IXMLStore,
	           AspenTech.Interop.ThPropManager.IThermoPropertyManager2,
	           AspenTech.Interop.ThPropManager.ICOMExtensionHandler,
	           AspenTech.Interop.ThPropManager.IPostProgress,
	           AspenTech.Interop.ThPropManager.IPostError,
	           AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry,
	           AspenTech.Interop.ThPropManager.INotifyChange,
	           AspenTech.Interop.ThPropManager.ICOTHHysysSecurity,
	           AspenTech.Interop.ThPropManager.ICOTHCompositionTransfer,
	           AspenTech.Interop.ThPropManager.IDerivativeHandler
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 31 43 41 30 38 39 35 2d 34 31 45 32
		2d 31 31 44 32 2d 42 38 43 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public hidebysig newslot virtual 
		instance void SetOverallFlash (
			[in] object marshal(idispatch) pFlashControl,
			[in] string marshal(bstr) strFlashFamily
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager::SetOverallFlash(object, string)
	} // end of method COTHPropertyManagerClass::SetOverallFlash

	.method public hidebysig newslot virtual 
		instance void SetFlash (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum eFlashType,
			[in] int32 nOrder,
			[in] object marshal(idispatch) pFlash
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager::SetFlash(valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum, int32, object)
	} // end of method COTHPropertyManagerClass::SetFlash

	.method public hidebysig newslot virtual 
		instance void SetPropertyModel (
			[in] string marshal(bstr) strModelName,
			[in] uint8 bReset
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager::SetPropertyModel(string, uint8)
	} // end of method COTHPropertyManagerClass::SetPropertyModel

	.method public hidebysig newslot virtual 
		instance void GetDefaultPropertiesMethods (
			[out] object& marshal(idispatch) pMethods
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager::GetDefaultPropertiesMethods(object&)
	} // end of method COTHPropertyManagerClass::GetDefaultPropertiesMethods

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) GetPropertyMethod (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance string AspenTech.Interop.ThPropManager.IThermoPropertyManager::GetPropertyMethod(int32, int32)
	} // end of method COTHPropertyManagerClass::GetPropertyMethod

	.method public hidebysig newslot virtual 
		instance void RemoveDefaultPropertyMethod (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager::RemoveDefaultPropertyMethod(int32, int32)
	} // end of method COTHPropertyManagerClass::RemoveDefaultPropertyMethod

	.method public hidebysig newslot virtual 
		instance void SetDefaultPropertyMethod (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType,
			[in] string marshal(bstr) strPropertyName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager::SetDefaultPropertyMethod(int32, int32, string)
	} // end of method COTHPropertyManagerClass::SetDefaultPropertyMethod

	.method public hidebysig newslot virtual 
		instance void SetPropertyEnumerationRegistry (
			[in] object marshal(idispatch) pPropEnumReg
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager::SetPropertyEnumerationRegistry(object)
	} // end of method COTHPropertyManagerClass::SetPropertyEnumerationRegistry

	.method public hidebysig newslot virtual 
		instance void SetCompList (
			[in] string marshal(bstr) DBPath,
			[in] int32 nc,
			[in] native int cmpinfo,
			[in] uint8 ReloadIP
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::SetCompList(string, int32, native int, uint8)
	} // end of method COTHPropertyManagerClass::SetCompList

	.method public hidebysig newslot virtual 
		instance void Execute (
			[in] [out] float64& Tdegk,
			[in] [out] float64& Pkpa,
			[in] [out] native int PhaseStr,
			[in] uint32 FeedIdx,
			[out] uint32& NumbPhase,
			[in] uint32 MaxLiquidPhase,
			[in] [out] int32& MyFlashType,
			[in] uint8 UseGFlash,
			[in] float64 lowerTkBound,
			[in] float64 upperTkBound
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::Execute(float64&, float64&, native int, uint32, uint32&, uint32, int32&, uint8, float64, float64)
	} // end of method COTHPropertyManagerClass::Execute

	.method public hidebysig newslot virtual 
		instance void GetIPInfo (
			[out] int32& nPanes,
			[out] int32& nComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::GetIPInfo(int32&, int32&)
	} // end of method COTHPropertyManagerClass::GetIPInfo

	.method public hidebysig newslot virtual 
		instance void GetIPValues (
			[in] int32 iPane,
			[out] string& marshal(bstr) name,
			[out] int32& nComp,
			[in] class AspenTech.Interop.ThPropManager.IRealMatrixDisp marshal(interface) pVal,
			[in] class AspenTech.Interop.ThPropManager.IIntegerMatrixDisp marshal(interface) p1Val
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::GetIPValues(int32, string&, int32&, class AspenTech.Interop.ThPropManager.IRealMatrixDisp, class AspenTech.Interop.ThPropManager.IIntegerMatrixDisp)
	} // end of method COTHPropertyManagerClass::GetIPValues

	.method public hidebysig newslot virtual 
		instance void PutIPValues (
			[in] int32 iPane,
			[in] string marshal(bstr) name,
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThPropManager.IRealMatrixDisp marshal(interface) pVal,
			[in] class AspenTech.Interop.ThPropManager.IIntegerMatrixDisp marshal(interface) p1Val
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::PutIPValues(int32, string, int32, class AspenTech.Interop.ThPropManager.IRealMatrixDisp, class AspenTech.Interop.ThPropManager.IIntegerMatrixDisp)
	} // end of method COTHPropertyManagerClass::PutIPValues

	.method public hidebysig newslot virtual 
		instance void AddComponent (
			[in] string marshal(bstr) DBPath,
			[in] int32 posn,
			[in] valuetype AspenTech.Interop.ThPropManager.thcmp_info& Comp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::AddComponent(string, int32, valuetype AspenTech.Interop.ThPropManager.thcmp_info&)
	} // end of method COTHPropertyManagerClass::AddComponent

	.method public hidebysig newslot virtual 
		instance void MoveComponent (
			[in] int32 compToMove,
			[in] int32 moveBeforeComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::MoveComponent(int32, int32)
	} // end of method COTHPropertyManagerClass::MoveComponent

	.method public hidebysig newslot virtual 
		instance void RemoveComponent (
			[in] int32 posn
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::RemoveComponent(int32)
	} // end of method COTHPropertyManagerClass::RemoveComponent

	.method public hidebysig newslot virtual 
		instance void RemoveLastComponent () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::RemoveLastComponent()
	} // end of method COTHPropertyManagerClass::RemoveLastComponent

	.method public hidebysig newslot virtual 
		instance void Viscosity (
			[in] float64 T,
			[in] float64 P,
			[in] float64& MoleFrac,
			[in] float64 MolarDensity,
			[in] valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType FluidBaseType,
			[out] float64& dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::Viscosity(float64, float64, float64&, float64, valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType, float64&)
	} // end of method COTHPropertyManagerClass::Viscosity

	.method public hidebysig newslot virtual 
		instance void ThermalConductivity (
			[in] float64 T,
			[in] float64 P,
			[in] float64& MoleFrac,
			[in] float64 MolarDensity,
			[in] valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType FluidBaseType,
			[out] float64& dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::ThermalConductivity(float64, float64, float64&, float64, valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType, float64&)
	} // end of method COTHPropertyManagerClass::ThermalConductivity

	.method public hidebysig newslot virtual 
		instance void LiquidDensity (
			[in] float64 T,
			[in] float64 P,
			[in] float64& MoleFrac,
			[out] float64& dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::LiquidDensity(float64, float64, float64&, float64&)
	} // end of method COTHPropertyManagerClass::LiquidDensity

	.method public hidebysig newslot virtual 
		instance void Enth (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] int32& phase,
			[in] float64& PhFrac,
			[in] float64& hi,
			[in] float64& si,
			[in] float64& cpl,
			[in] float64& vi
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::Enth(float64, float64, native int, int32&, float64&, float64&, float64&, float64&, float64&)
	} // end of method COTHPropertyManagerClass::Enth

	.method public hidebysig newslot virtual 
		instance void SurfaceTension (
			[in] float64 T,
			[in] float64& MoleFrac,
			[in] float64 press,
			[in] float64& vapComp,
			[in] float64 vapFrac,
			[out] float64& dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::SurfaceTension(float64, float64&, float64, float64&, float64, float64&)
	} // end of method COTHPropertyManagerClass::SurfaceTension

	.method public hidebysig newslot virtual 
		instance void HtDep (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& y,
			[in] float64& ahl,
			[in] float64& bhl,
			[in] float64& ahv,
			[in] float64& bhv
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::HtDep(float64, float64, float64&, float64&, float64&, float64&, float64&, float64&)
	} // end of method COTHPropertyManagerClass::HtDep

	.method public hidebysig newslot virtual 
		instance void GetLnK (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& y,
			[in] float64& zk,
			[in] float64& tzk,
			[in] int32 flag
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::GetLnK(float64, float64, float64&, float64&, float64&, float64&, int32)
	} // end of method COTHPropertyManagerClass::GetLnK

	.method public hidebysig newslot virtual 
		instance void HtDep1 (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& x2,
			[in] float64& ahl,
			[in] float64& bhl,
			[in] float64& ahv,
			[in] float64& bhv
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::HtDep1(float64, float64, float64&, float64&, float64&, float64&, float64&, float64&)
	} // end of method COTHPropertyManagerClass::HtDep1

	.method public hidebysig newslot virtual 
		instance void GetLnB (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& x2,
			[in] float64& kfact,
			[in] float64& dkfact,
			[in] int32 flag
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::GetLnB(float64, float64, float64&, float64&, float64&, float64&, int32)
	} // end of method COTHPropertyManagerClass::GetLnB

	.method public hidebysig newslot virtual 
		instance void KValue (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] native int kfact,
			[in] int32& phase
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::KValue(float64, float64, native int, native int, int32&)
	} // end of method COTHPropertyManagerClass::KValue

	.method public hidebysig newslot virtual 
		instance void LnK (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& y,
			[in] float64& zk
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::LnK(float64, float64, float64&, float64&, float64&)
	} // end of method COTHPropertyManagerClass::LnK

	.method public hidebysig newslot virtual 
		instance void Order (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] int32& phase,
			[in] float64& PhFrac
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::Order(float64, float64, native int, int32&, float64&)
	} // end of method COTHPropertyManagerClass::Order

	.method public hidebysig newslot virtual 
		instance void InitK (
			[in] int32 cmpno,
			[in] float64 T,
			[in] float64 P,
			[in] int32 phase,
			[out] float64& dVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::InitK(int32, float64, float64, int32, float64&)
	} // end of method COTHPropertyManagerClass::InitK

	.method public hidebysig newslot virtual 
		instance void PkgFug (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] native int fug,
			[in] int32& phase
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::PkgFug(float64, float64, native int, native int, int32&)
	} // end of method COTHPropertyManagerClass::PkgFug

	.method public hidebysig newslot virtual 
		instance void Prop3 (
			[in] float64& T,
			[in] float64& P,
			[in] native int Comp,
			[in] int32& phase,
			[in] float64& PhFrac,
			[in] float64& hi,
			[in] float64& si,
			[in] float64& cpi,
			[in] float64& vi,
			[in] uint8 tIsEstimate
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::Prop3(float64&, float64&, native int, int32&, float64&, float64&, float64&, float64&, float64&, uint8)
	} // end of method COTHPropertyManagerClass::Prop3

	.method public hidebysig newslot virtual 
		instance void FlasD (
			[in] float64& T,
			[in] float64 P,
			[in] float64 lfrc,
			[in] float64& z,
			[in] float64& x,
			[in] float64& y,
			[in] float64& LnK,
			[in] float64& dlnkdt
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::FlasD(float64&, float64, float64, float64&, float64&, float64&, float64&, float64&)
	} // end of method COTHPropertyManagerClass::FlasD

	.method public hidebysig newslot virtual 
		instance void Save (
			[out] string& marshal(bstr) data
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::Save(string&)
	} // end of method COTHPropertyManagerClass::Save

	.method public hidebysig newslot virtual 
		instance void Recall (
			[in] string marshal(bstr) data
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IHysysCalc::Recall(string)
	} // end of method COTHPropertyManagerClass::Recall

	.method public hidebysig newslot virtual 
		instance void EvaluateProperty (
			[in] int32 nPropertyID,
			[in] int32 ePhaseType,
			[in] object marshal(idispatch) pPhaseCollection
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoProperty::EvaluateProperty(int32, int32, object)
	} // end of method COTHPropertyManagerClass::EvaluateProperty

	.method public hidebysig newslot virtual 
		instance void EvaluatePhaseProperty (
			[in] int32 nPropertyID,
			[in] object marshal(idispatch) pPhase
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoProperty::EvaluatePhaseProperty(int32, object)
	} // end of method COTHPropertyManagerClass::EvaluatePhaseProperty

	.method public hidebysig newslot virtual 
		instance void EvaluatePropertyBy (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] string marshal(bstr) strMethod
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoProperty::EvaluatePropertyBy(object, string)
	} // end of method COTHPropertyManagerClass::EvaluatePropertyBy

	.method public hidebysig newslot virtual 
		instance void EvaluatePhasePropertyBy (
			[in] object marshal(idispatch) pPhase,
			[in] string marshal(bstr) strMethod
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoProperty::EvaluatePhasePropertyBy(object, string)
	} // end of method COTHPropertyManagerClass::EvaluatePhasePropertyBy

	.method public hidebysig newslot virtual 
		instance object marshal(idispatch) GetDefaultPropCalcMethodObjectForFlash (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType
		) runtime managed internalcall 
	{
		.override method instance object AspenTech.Interop.ThPropManager.IThermoProperty::GetDefaultPropCalcMethodObjectForFlash(int32, int32)
	} // end of method COTHPropertyManagerClass::GetDefaultPropCalcMethodObjectForFlash

	.method public hidebysig newslot virtual 
		instance void GetPropertyCallBackAndContextManager (
			[in] int32 ePropertyID,
			[in] object marshal(idispatch) pPhase,
			[out] object& marshal(idispatch) pPropCallBack,
			[out] object& marshal(idispatch) pContxMgr
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoProperty::GetPropertyCallBackAndContextManager(int32, object, object&, object&)
	} // end of method COTHPropertyManagerClass::GetPropertyCallBackAndContextManager

	.method public hidebysig newslot virtual 
		instance object marshal(idispatch) GetFlashControl () runtime managed internalcall 
	{
		.override method instance object AspenTech.Interop.ThPropManager.IFlashProperties::GetFlashControl()
	} // end of method COTHPropertyManagerClass::GetFlashControl

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) GetFlashFamily () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThPropManager.IFlashProperties::GetFlashFamily()
	} // end of method COTHPropertyManagerClass::GetFlashFamily

	.method public hidebysig newslot virtual 
		instance void CreateFlash (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum eFlashType,
			[in] int32 nOrder,
			[out] object& marshal(idispatch) ppFlash
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IFlashProperties::CreateFlash(valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum, int32, object&)
	} // end of method COTHPropertyManagerClass::CreateFlash

	.method public hidebysig newslot virtual 
		instance void CreateFlashByFamily (
			[in] string marshal(bstr) strFlashFamily,
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum eFlashType,
			[in] int32 nOrder,
			[out] object& marshal(idispatch) ppFlash
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IFlashProperties::CreateFlashByFamily(string, valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum, int32, object&)
	} // end of method COTHPropertyManagerClass::CreateFlashByFamily

	.method public hidebysig newslot virtual 
		instance void EvaluateFlashProperty (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType,
			[in] object marshal(idispatch) pPhaseCollection,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IFlashProperties::EvaluateFlashProperty(int32, int32, object, object, object&)
	} // end of method COTHPropertyManagerClass::EvaluateFlashProperty

	.method public hidebysig newslot virtual 
		instance void EvaluateFlashPhaseProperty (
			[in] int32 ePropertyID,
			[in] object marshal(idispatch) pPhase,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IFlashProperties::EvaluateFlashPhaseProperty(int32, object, object, object&)
	} // end of method COTHPropertyManagerClass::EvaluateFlashPhaseProperty

	.method public hidebysig newslot virtual 
		instance void EvaluateFlashPropertyBy (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] string marshal(bstr) strMethod,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IFlashProperties::EvaluateFlashPropertyBy(object, string, object, object&)
	} // end of method COTHPropertyManagerClass::EvaluateFlashPropertyBy

	.method public hidebysig newslot virtual 
		instance void EvaluateFlashPhasePropertyBy (
			[in] object marshal(idispatch) pPhase,
			[in] string marshal(bstr) strMethod,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IFlashProperties::EvaluateFlashPhasePropertyBy(object, string, object, object&)
	} // end of method COTHPropertyManagerClass::EvaluateFlashPhasePropertyBy

	.method public hidebysig newslot virtual 
		instance void GetClassID (
			[out] valuetype [mscorlib]System.Guid& pClassID
		) runtime managed internalcall 
	{
	} // end of method COTHPropertyManagerClass::GetClassID

	.method public hidebysig newslot virtual 
		instance void IsDirty () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPersistStreamInit::IsDirty()
	} // end of method COTHPropertyManagerClass::IsDirty

	.method public hidebysig newslot virtual 
		instance void Load (
			[in] class AspenTech.Interop.ThPropManager.IStream marshal(interface) pstm
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPersistStreamInit::Load(class AspenTech.Interop.ThPropManager.IStream)
	} // end of method COTHPropertyManagerClass::Load

	.method public hidebysig newslot virtual 
		instance void Save (
			[in] class AspenTech.Interop.ThPropManager.IStream marshal(interface) pstm,
			[in] int32 fClearDirty
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPersistStreamInit::Save(class AspenTech.Interop.ThPropManager.IStream, int32)
	} // end of method COTHPropertyManagerClass::Save

	.method public hidebysig newslot virtual 
		instance void GetSizeMax (
			[out] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER& pCbSize
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPersistStreamInit::GetSizeMax(valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER&)
	} // end of method COTHPropertyManagerClass::GetSizeMax

	.method public hidebysig newslot virtual 
		instance void InitNew () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPersistStreamInit::InitNew()
	} // end of method COTHPropertyManagerClass::InitNew

	.method public hidebysig newslot virtual 
		instance void InterfaceSupportsErrorInfo (
			[in] valuetype [mscorlib]System.Guid& riid
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISupportErrorInfo::InterfaceSupportsErrorInfo(valuetype [mscorlib]System.Guid&)
	} // end of method COTHPropertyManagerClass::InterfaceSupportsErrorInfo

	.method public hidebysig newslot virtual 
		instance void SetPropModelCreatePropObjects (
			[in] string marshal(bstr) strModelName,
			[in] uint8 bReset
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager1::SetPropModelCreatePropObjects(string, uint8)
	} // end of method COTHPropertyManagerClass::SetPropModelCreatePropObjects

	.method public hidebysig newslot virtual 
		instance void GetIPModelsInfo (
			[out] int32& numbIPs,
			[out] object& marshal(struct) modelnames,
			[out] object& marshal(struct) modelpanes
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager1::GetIPModelsInfo(int32&, object&, object&)
	} // end of method COTHPropertyManagerClass::GetIPModelsInfo

	.method public hidebysig newslot virtual 
		instance void SetDefaultPropertyMethodCreateObject (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType,
			[in] string marshal(bstr) strPropertyName,
			[in] object marshal(idispatch) pCC,
			[in] string marshal(bstr) defdbdir,
			[in] object marshal(idispatch) pIPManager
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager1::SetDefaultPropertyMethodCreateObject(int32, int32, string, object, string, object)
	} // end of method COTHPropertyManagerClass::SetDefaultPropertyMethodCreateObject

	.method public hidebysig newslot virtual 
		instance void GetModelType (
			[out] string& marshal(bstr) modeltype
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager1::GetModelType(string&)
	} // end of method COTHPropertyManagerClass::GetModelType

	.method public hidebysig newslot virtual 
		instance void SetCompoundCollection (
			[in] object marshal(idispatch) compcoll
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager1::SetCompoundCollection(object)
	} // end of method COTHPropertyManagerClass::SetCompoundCollection

	.method public hidebysig newslot virtual 
		instance void InitializeFlashes () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager1::InitializeFlashes()
	} // end of method COTHPropertyManagerClass::InitializeFlashes

	.method public hidebysig newslot virtual 
		instance void CharacterData (
			[in] string marshal(bstr) userData
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::CharacterData(string)
	} // end of method COTHPropertyManagerClass::CharacterData

	.method public hidebysig newslot virtual 
		instance void StartElement (
			[in] string marshal(bstr) name,
			[in] class AspenTech.Interop.ThPropManager.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::StartElement(string, class AspenTech.Interop.ThPropManager.TaggedAttributes)
	} // end of method COTHPropertyManagerClass::StartElement

	.method public hidebysig newslot virtual 
		instance void EndElement (
			[in] string marshal(bstr) name
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::EndElement(string)
	} // end of method COTHPropertyManagerClass::EndElement

	.method public hidebysig newslot virtual 
		instance void Comment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::Comment(string)
	} // end of method COTHPropertyManagerClass::Comment

	.method public hidebysig newslot virtual 
		instance void ProcessElement (
			[in] string marshal(bstr) name,
			[in] class AspenTech.Interop.ThPropManager.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::ProcessElement(string, class AspenTech.Interop.ThPropManager.TaggedAttributes)
	} // end of method COTHPropertyManagerClass::ProcessElement

	.method public hidebysig newslot virtual 
		instance void Error (
			[in] string marshal(bstr) Error
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::Error(string)
	} // end of method COTHPropertyManagerClass::Error

	.method public hidebysig newslot virtual 
		instance void StartDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::StartDocument()
	} // end of method COTHPropertyManagerClass::StartDocument

	.method public hidebysig newslot virtual 
		instance void EndDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::EndDocument()
	} // end of method COTHPropertyManagerClass::EndDocument

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) StoreAsXML () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThPropManager.IXMLStore::StoreAsXML()
	} // end of method COTHPropertyManagerClass::StoreAsXML

	.method public hidebysig newslot virtual 
		instance void SetIPModelsInfo (
			[in] object marshal(idispatch) pCC
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IThermoPropertyManager2::SetIPModelsInfo(object)
	} // end of method COTHPropertyManagerClass::SetIPModelsInfo

	.method public hidebysig newslot virtual 
		instance void GetPkgInfo (
			[in] [out] string& marshal(bstr) PkgName,
			[in] [out] string& marshal(bstr) PkgDescription,
			[in] [out] int32& nSetupFiles,
			[in] [out] string& marshal(bstr) SetupDescription
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::GetPkgInfo(string&, string&, int32&, string&)
	} // end of method COTHPropertyManagerClass::GetPkgInfo

	.method public hidebysig newslot virtual 
		instance void SetupExtendedPropPkg (
			[in] int32 nfiles,
			[in] object marshal(struct) filenames,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::SetupExtendedPropPkg(int32, object, int32&)
	} // end of method COTHPropertyManagerClass::SetupExtendedPropPkg

	.method public hidebysig newslot virtual 
		instance void UseExtendedPropPkg (
			[in] [out] uint8& IsUsed
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::UseExtendedPropPkg(uint8&)
	} // end of method COTHPropertyManagerClass::UseExtendedPropPkg

	.method public hidebysig newslot virtual 
		instance void GetExtendedPropPkg (
			[in] [out] object& marshal(idispatch) pPropPkg
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::GetExtendedPropPkg(object&)
	} // end of method COTHPropertyManagerClass::GetExtendedPropPkg

	.method public hidebysig newslot virtual 
		instance void GetPropCalcBase (
			[in] string marshal(bstr) PropName,
			[in] [out] int32& Base
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::GetPropCalcBase(string, int32&)
	} // end of method COTHPropertyManagerClass::GetPropCalcBase

	.method public hidebysig newslot virtual 
		instance void PreSetCompInfo (
			[in] [out] uint8& CanChange,
			[in] [out] int32& nComp,
			[in] [out] object& marshal(struct) HyprotechIDs,
			[in] [out] object& marshal(struct) names
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::PreSetCompInfo(uint8&, int32&, object&, object&)
	} // end of method COTHPropertyManagerClass::PreSetCompInfo

	.method public hidebysig newslot virtual 
		instance void GetPkgNumbComps (
			[in] [out] int32& nComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::GetPkgNumbComps(int32&)
	} // end of method COTHPropertyManagerClass::GetPkgNumbComps

	.method public hidebysig newslot virtual 
		instance void GetPkgCompInfo (
			[in] int32 iComp,
			[in] object marshal(idispatch) pCompoundi,
			[in] [out] int32& nProps,
			[in] [out] object& marshal(struct) propnames
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::GetPkgCompInfo(int32, object, int32&, object&)
	} // end of method COTHPropertyManagerClass::GetPkgCompInfo

	.method public hidebysig newslot virtual 
		instance void AddPkgLastComp (
			[in] object marshal(idispatch) pCompoundi
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::AddPkgLastComp(object)
	} // end of method COTHPropertyManagerClass::AddPkgLastComp

	.method public hidebysig newslot virtual 
		instance void RemovePkgComp (
			[in] int32 iComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::RemovePkgComp(int32)
	} // end of method COTHPropertyManagerClass::RemovePkgComp

	.method public hidebysig newslot virtual 
		instance void ExchangePkgComps (
			[in] int32 iComp,
			[in] int32 jComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::ExchangePkgComps(int32, int32)
	} // end of method COTHPropertyManagerClass::ExchangePkgComps

	.method public hidebysig newslot virtual 
		instance void PkgPhaseOrder (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] object marshal(idispatch) pThermoProperty
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::PkgPhaseOrder(object, object)
	} // end of method COTHPropertyManagerClass::PkgPhaseOrder

	.method public hidebysig newslot virtual 
		instance void PkgOnView (
			[in] [out] string& marshal(bstr) ViewName,
			[in] [out] bool& OpenView
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::PkgOnView(string&, bool&)
	} // end of method COTHPropertyManagerClass::PkgOnView

	.method public hidebysig newslot virtual 
		instance void PkgSave (
			[in] [out] string& marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::PkgSave(string&)
	} // end of method COTHPropertyManagerClass::PkgSave

	.method public hidebysig newslot virtual 
		instance void PkgRecall (
			[in] string marshal(bstr) saveinfo,
			[in] [out] bool& BaseChanged
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::PkgRecall(string, bool&)
	} // end of method COTHPropertyManagerClass::PkgRecall

	.method public hidebysig newslot virtual 
		instance void GetFlashInfo (
			[in] [out] string& marshal(bstr) FlashName,
			[in] [out] string& marshal(bstr) FlashDescription,
			[in] [out] int32& nSetupFiles,
			[in] [out] string& marshal(bstr) SetupDescription
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::GetFlashInfo(string&, string&, int32&, string&)
	} // end of method COTHPropertyManagerClass::GetFlashInfo

	.method public hidebysig newslot virtual 
		instance void SetupExtendedFlash (
			[in] int32 nfiles,
			[in] object marshal(struct) filenames,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::SetupExtendedFlash(int32, object, int32&)
	} // end of method COTHPropertyManagerClass::SetupExtendedFlash

	.method public hidebysig newslot virtual 
		instance void FlashTypesSupported (
			[in] [out] int32& nFlashes,
			[in] [out] object& marshal(struct) types
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::FlashTypesSupported(int32&, object&)
	} // end of method COTHPropertyManagerClass::FlashTypesSupported

	.method public hidebysig newslot virtual 
		instance void CanHandleFlashType (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum 'type',
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::CanHandleFlashType(valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum, int32&)
	} // end of method COTHPropertyManagerClass::CanHandleFlashType

	.method public hidebysig newslot virtual 
		instance void UseExtendedFlash (
			[in] [out] uint8& IsUsed
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::UseExtendedFlash(uint8&)
	} // end of method COTHPropertyManagerClass::UseExtendedFlash

	.method public hidebysig newslot virtual 
		instance void GetExtendedFlash (
			[in] [out] object& marshal(idispatch) pExtFlash
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::GetExtendedFlash(object&)
	} // end of method COTHPropertyManagerClass::GetExtendedFlash

	.method public hidebysig newslot virtual 
		instance void UseFlashControl (
			[in] [out] uint8& IsUsed
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::UseFlashControl(uint8&)
	} // end of method COTHPropertyManagerClass::UseFlashControl

	.method public hidebysig newslot virtual 
		instance void FlashSave (
			[in] [out] string& marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::FlashSave(string&)
	} // end of method COTHPropertyManagerClass::FlashSave

	.method public hidebysig newslot virtual 
		instance void FlashRecall (
			[in] string marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::FlashRecall(string)
	} // end of method COTHPropertyManagerClass::FlashRecall

	.method public hidebysig newslot virtual 
		instance void CalculateTwoPhaseProperty (
			[in] int32 propertyID,
			[in] object marshal(idispatch) pPhaseCollection,
			[in] int32 iphase,
			[in] int32 jphase
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::CalculateTwoPhaseProperty(int32, object, int32, int32)
	} // end of method COTHPropertyManagerClass::CalculateTwoPhaseProperty

	.method public hidebysig newslot virtual 
		instance void IsPkgSetup (
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::IsPkgSetup(int32&)
	} // end of method COTHPropertyManagerClass::IsPkgSetup

	.method public hidebysig newslot virtual 
		instance void IsFlashSetup (
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOMExtensionHandler::IsFlashSetup(int32&)
	} // end of method COTHPropertyManagerClass::IsFlashSetup

	.method public hidebysig newslot virtual 
		instance void PostProgress (
			[in] int32 ProgressCode,
			[in] string marshal(bstr) ProgressMessage
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPostProgress::PostProgress(int32, string)
	} // end of method COTHPropertyManagerClass::PostProgress

	.method public hidebysig newslot virtual 
		instance void SetProgressCallback (
			class AspenTech.Interop.ThPropManager.IThermoProgress marshal(interface) pProgressCallback
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPostProgress::SetProgressCallback(class AspenTech.Interop.ThPropManager.IThermoProgress)
	} // end of method COTHPropertyManagerClass::SetProgressCallback

	.method public hidebysig newslot virtual 
		instance void RemoveProgressCallback () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPostProgress::RemoveProgressCallback()
	} // end of method COTHPropertyManagerClass::RemoveProgressCallback

	.method public hidebysig newslot virtual 
		instance void PostError (
			[in] int32 ErrorCode,
			[in] string marshal(bstr) ErrorMessage,
			[in] bool ToUserDialog,
			[in] bool IsImportant
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPostError::PostError(int32, string, bool, bool)
	} // end of method COTHPropertyManagerClass::PostError

	.method public hidebysig newslot virtual 
		instance bool PostWarning (
			[in] int32 ErrorCode,
			[in] string marshal(bstr) ErrorMessage,
			[in] bool ToUserDialog,
			[in] bool IsImportant
		) runtime managed internalcall 
	{
		.override method instance bool AspenTech.Interop.ThPropManager.IPostError::PostWarning(int32, string, bool, bool)
	} // end of method COTHPropertyManagerClass::PostWarning

	.method public hidebysig newslot virtual 
		instance void SetErrorCallback (
			class AspenTech.Interop.ThPropManager.IThermoError marshal(interface) pErrorCallback
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPostError::SetErrorCallback(class AspenTech.Interop.ThPropManager.IThermoError)
	} // end of method COTHPropertyManagerClass::SetErrorCallback

	.method public hidebysig newslot virtual 
		instance void RemoveErrorCallback () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IPostError::RemoveErrorCallback()
	} // end of method COTHPropertyManagerClass::RemoveErrorCallback

	.method public hidebysig newslot virtual 
		instance int32 GetPropertyIDByName (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry::GetPropertyIDByName(string)
	} // end of method COTHPropertyManagerClass::GetPropertyIDByName

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) GetPropertyNameByID (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry::GetPropertyNameByID(int32)
	} // end of method COTHPropertyManagerClass::GetPropertyNameByID

	.method public hidebysig newslot virtual 
		instance int32 AddPropertyByName (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry::AddPropertyByName(string)
	} // end of method COTHPropertyManagerClass::AddPropertyByName

	.method public hidebysig newslot virtual 
		instance void UseNotifyChange (
			[in] uint8 Use
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.INotifyChange::UseNotifyChange(uint8)
	} // end of method COTHPropertyManagerClass::UseNotifyChange

	.method public hidebysig newslot virtual 
		instance void HasModified (
			[in] valuetype AspenTech.Interop.ThPropManager.NotifyChange whatchanged
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.INotifyChange::HasModified(valuetype AspenTech.Interop.ThPropManager.NotifyChange)
	} // end of method COTHPropertyManagerClass::HasModified

	.method public hidebysig newslot virtual 
		instance void PutApplicationInterface (
			[in] object marshal(iunknown) pIUnknown
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOTHHysysSecurity::PutApplicationInterface(object)
	} // end of method COTHPropertyManagerClass::PutApplicationInterface

	.method public hidebysig newslot virtual 
		instance void GetApplicationInterface (
			[in] [out] object& marshal(iunknown) pIUnknown
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOTHHysysSecurity::GetApplicationInterface(object&)
	} // end of method COTHPropertyManagerClass::GetApplicationInterface

	.method public hidebysig newslot virtual 
		instance void GetCompositionSource (
			[in] [out] string& marshal(bstr) sSource
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOTHCompositionTransfer::GetCompositionSource(string&)
	} // end of method COTHPropertyManagerClass::GetCompositionSource

	.method public hidebysig newslot virtual 
		instance void GetComposition (
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThPropManager.IRealArrayDisp marshal(interface) pComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ICOTHCompositionTransfer::GetComposition(int32, class AspenTech.Interop.ThPropManager.IRealArrayDisp)
	} // end of method COTHPropertyManagerClass::GetComposition

	.method public hidebysig newslot virtual 
		instance void TurnOnDerivative (
			[in] uint8 bOn
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IDerivativeHandler::TurnOnDerivative(uint8)
	} // end of method COTHPropertyManagerClass::TurnOnDerivative

	.method public hidebysig newslot virtual 
		instance void SetDerivativeType (
			[in] valuetype AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum eType
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IDerivativeHandler::SetDerivativeType(valuetype AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum)
	} // end of method COTHPropertyManagerClass::SetDerivativeType

	.method public hidebysig newslot virtual 
		instance void CanCalculateDerivative (
			[in] int32 nPropComID,
			[in] valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum ePhaseType,
			[in] int32 nPropID,
			[in] int32 nDerivativeID,
			[in] [out] uint8& bYes,
			[in] [out] valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum& ePropResultType,
			[in] [out] valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum& eDevResultType
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IDerivativeHandler::CanCalculateDerivative(int32, valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum, int32, int32, uint8&, valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum&, valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum&)
	} // end of method COTHPropertyManagerClass::CanCalculateDerivative

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHPropertyManagerClass::.ctor

} // end of class AspenTech.Interop.ThPropManager.COTHPropertyManagerClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.COTHPropertyManager
	implements AspenTech.Interop.ThPropManager.IThermoPropertyManager
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 38 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 50 72 6f 70 4d 61 6e 61 67
		65 72 2e 43 4f 54 48 50 72 6f 70 65 72 74 79 4d
		61 6e 61 67 65 72 43 6c 61 73 73 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 31 43 41 30 38 39 34 2d 34 31 45 32
		2d 31 31 44 32 2d 42 38 43 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
} // end of class AspenTech.Interop.ThPropManager.COTHPropertyManager

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IThermoPropertyManager
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 31 43 41 30 38 39 34 2d 34 31 45 32
		2d 31 31 44 32 2d 42 38 43 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetOverallFlash (
			[in] object marshal(idispatch) pFlashControl,
			[in] string marshal(bstr) strFlashFamily
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::SetOverallFlash

	.method public hidebysig newslot abstract virtual 
		instance void SetFlash (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum eFlashType,
			[in] int32 nOrder,
			[in] object marshal(idispatch) pFlash
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::SetFlash

	.method public hidebysig newslot abstract virtual 
		instance void SetPropertyModel (
			[in] string marshal(bstr) strModelName,
			[in] uint8 bReset
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::SetPropertyModel

	.method public hidebysig newslot abstract virtual 
		instance void GetDefaultPropertiesMethods (
			[out] object& marshal(idispatch) pMethods
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::GetDefaultPropertiesMethods

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetPropertyMethod (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::GetPropertyMethod

	.method public hidebysig newslot abstract virtual 
		instance void RemoveDefaultPropertyMethod (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::RemoveDefaultPropertyMethod

	.method public hidebysig newslot abstract virtual 
		instance void SetDefaultPropertyMethod (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType,
			[in] string marshal(bstr) strPropertyName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::SetDefaultPropertyMethod

	.method public hidebysig newslot abstract virtual 
		instance void SetPropertyEnumerationRegistry (
			[in] object marshal(idispatch) pPropEnumReg
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager::SetPropertyEnumerationRegistry

} // end of class AspenTech.Interop.ThPropManager.IThermoPropertyManager

.class public auto ansi sealed AspenTech.Interop.ThPropManager.tagFlashTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftUnknownFlash = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftPTFlash = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftPHFlash = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftPSFlash = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftPVFlash = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftTHFlash = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftTSFlash = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftTVFlash = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftHVFlash = int32(8)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftZPFlash = int32(9)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftZGorFlash = int32(10)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftHomotopyPTFlash = int32(11)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftHomotopyPVFlash = int32(12)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum xftLastFlash = int32(13)

} // end of class AspenTech.Interop.ThPropManager.tagFlashTypeEnum

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IHysysCalc
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = (
		01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 45 42 32 42 39 35 38 30 2d 44 31 32 39
		2d 31 31 44 34 2d 42 46 38 45 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 00 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetCompList (
			[in] string marshal(bstr) DBPath,
			[in] int32 nc,
			[in] native int cmpinfo,
			[in] uint8 ReloadIP
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::SetCompList

	.method public hidebysig newslot abstract virtual 
		instance void Execute (
			[in] [out] float64& Tdegk,
			[in] [out] float64& Pkpa,
			[in] [out] native int PhaseStr,
			[in] uint32 FeedIdx,
			[out] uint32& NumbPhase,
			[in] uint32 MaxLiquidPhase,
			[in] [out] int32& MyFlashType,
			[in] uint8 UseGFlash,
			[in] float64 lowerTkBound,
			[in] float64 upperTkBound
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::Execute

	.method public hidebysig newslot abstract virtual 
		instance void GetIPInfo (
			[out] int32& nPanes,
			[out] int32& nComp
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::GetIPInfo

	.method public hidebysig newslot abstract virtual 
		instance void GetIPValues (
			[in] int32 iPane,
			[out] string& marshal(bstr) name,
			[out] int32& nComp,
			[in] class AspenTech.Interop.ThPropManager.IRealMatrixDisp marshal(interface) pVal,
			[in] class AspenTech.Interop.ThPropManager.IIntegerMatrixDisp marshal(interface) p1Val
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::GetIPValues

	.method public hidebysig newslot abstract virtual 
		instance void PutIPValues (
			[in] int32 iPane,
			[in] string marshal(bstr) name,
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThPropManager.IRealMatrixDisp marshal(interface) pVal,
			[in] class AspenTech.Interop.ThPropManager.IIntegerMatrixDisp marshal(interface) p1Val
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::PutIPValues

	.method public hidebysig newslot abstract virtual 
		instance void AddComponent (
			[in] string marshal(bstr) DBPath,
			[in] int32 posn,
			[in] valuetype AspenTech.Interop.ThPropManager.thcmp_info& Comp
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::AddComponent

	.method public hidebysig newslot abstract virtual 
		instance void MoveComponent (
			[in] int32 compToMove,
			[in] int32 moveBeforeComp
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::MoveComponent

	.method public hidebysig newslot abstract virtual 
		instance void RemoveComponent (
			[in] int32 posn
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::RemoveComponent

	.method public hidebysig newslot abstract virtual 
		instance void RemoveLastComponent () runtime managed internalcall 
	{
	} // end of method IHysysCalc::RemoveLastComponent

	.method public hidebysig newslot abstract virtual 
		instance void Viscosity (
			[in] float64 T,
			[in] float64 P,
			[in] float64& MoleFrac,
			[in] float64 MolarDensity,
			[in] valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType FluidBaseType,
			[out] float64& dVal
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::Viscosity

	.method public hidebysig newslot abstract virtual 
		instance void ThermalConductivity (
			[in] float64 T,
			[in] float64 P,
			[in] float64& MoleFrac,
			[in] float64 MolarDensity,
			[in] valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType FluidBaseType,
			[out] float64& dVal
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::ThermalConductivity

	.method public hidebysig newslot abstract virtual 
		instance void LiquidDensity (
			[in] float64 T,
			[in] float64 P,
			[in] float64& MoleFrac,
			[out] float64& dVal
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::LiquidDensity

	.method public hidebysig newslot abstract virtual 
		instance void Enth (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] int32& phase,
			[in] float64& PhFrac,
			[in] float64& hi,
			[in] float64& si,
			[in] float64& cpl,
			[in] float64& vi
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::Enth

	.method public hidebysig newslot abstract virtual 
		instance void SurfaceTension (
			[in] float64 T,
			[in] float64& MoleFrac,
			[in] float64 press,
			[in] float64& vapComp,
			[in] float64 vapFrac,
			[out] float64& dVal
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::SurfaceTension

	.method public hidebysig newslot abstract virtual 
		instance void HtDep (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& y,
			[in] float64& ahl,
			[in] float64& bhl,
			[in] float64& ahv,
			[in] float64& bhv
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::HtDep

	.method public hidebysig newslot abstract virtual 
		instance void GetLnK (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& y,
			[in] float64& zk,
			[in] float64& tzk,
			[in] int32 flag
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::GetLnK

	.method public hidebysig newslot abstract virtual 
		instance void HtDep1 (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& x2,
			[in] float64& ahl,
			[in] float64& bhl,
			[in] float64& ahv,
			[in] float64& bhv
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::HtDep1

	.method public hidebysig newslot abstract virtual 
		instance void GetLnB (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& x2,
			[in] float64& kfact,
			[in] float64& dkfact,
			[in] int32 flag
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::GetLnB

	.method public hidebysig newslot abstract virtual 
		instance void KValue (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] native int kfact,
			[in] int32& phase
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::KValue

	.method public hidebysig newslot abstract virtual 
		instance void LnK (
			[in] float64 T,
			[in] float64 P,
			[in] float64& x,
			[in] float64& y,
			[in] float64& zk
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::LnK

	.method public hidebysig newslot abstract virtual 
		instance void Order (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] int32& phase,
			[in] float64& PhFrac
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::Order

	.method public hidebysig newslot abstract virtual 
		instance void InitK (
			[in] int32 cmpno,
			[in] float64 T,
			[in] float64 P,
			[in] int32 phase,
			[out] float64& dVal
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::InitK

	.method public hidebysig newslot abstract virtual 
		instance void PkgFug (
			[in] float64 temp,
			[in] float64 pres,
			[in] native int Comp,
			[in] native int fug,
			[in] int32& phase
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::PkgFug

	.method public hidebysig newslot abstract virtual 
		instance void Prop3 (
			[in] float64& T,
			[in] float64& P,
			[in] native int Comp,
			[in] int32& phase,
			[in] float64& PhFrac,
			[in] float64& hi,
			[in] float64& si,
			[in] float64& cpi,
			[in] float64& vi,
			[in] uint8 tIsEstimate
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::Prop3

	.method public hidebysig newslot abstract virtual 
		instance void FlasD (
			[in] float64& T,
			[in] float64 P,
			[in] float64 lfrc,
			[in] float64& z,
			[in] float64& x,
			[in] float64& y,
			[in] float64& LnK,
			[in] float64& dlnkdt
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::FlasD

	.method public hidebysig newslot abstract virtual 
		instance void Save (
			[out] string& marshal(bstr) data
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::Save

	.method public hidebysig newslot abstract virtual 
		instance void Recall (
			[in] string marshal(bstr) data
		) runtime managed internalcall 
	{
	} // end of method IHysysCalc::Recall

} // end of class AspenTech.Interop.ThPropManager.IHysysCalc

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager.thcmp_info
	extends [mscorlib]System.ValueType
{
	.pack 8
	.size 0

	// Fields
	.field public marshal(fixed array[13] ) int8[] cpnam
	.field public int32 numb
	.field public valuetype AspenTech.Interop.ThPropManager.thcmp_type 'type'
	.field public float64 tc
	.field public float64 pc
	.field public float64 vc
	.field public float64 w
	.field public float64 molw
	.field public float64 boil
	.field public float64 liqden
	.field public float64 htform
	.field public float64 Gibbs_A
	.field public float64 htcomb
	.field public float64 wsrk
	.field public float64 vchar
	.field public float64 theta_A
	.field public float64 theta_B
	.field public float64 dipole
	.field public marshal(fixed array[7] ) float64[] idlh
	.field public marshal(fixed array[6] ) float64[] antoine
	.field public float64 ant_tmax
	.field public float64 ant_tmin
	.field public float64 cavett
	.field public float64 Gibbs_B
	.field public float64 Gibbs_C
	.field public float64 rg
	.field public marshal(fixed array[14] ) int8[] form
	.field public marshal(fixed array[10] ) valuetype AspenTech.Interop.ThPropManager.thcmp_unifact[] unifac
	.field public float64 sqrttc
	.field public float64 Gibbs_D
	.field public float64 Gibbs_E

} // end of class AspenTech.Interop.ThPropManager.thcmp_info

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager.thcmp_type
	extends [mscorlib]System.ValueType
{
	.pack 4
	.size 0

	// Fields
	.field public uint32 hc
	.field public uint32 solid
	.field public uint32 misc
	.field public uint32 amine
	.field public uint32 alcohol
	.field public uint32 ketone
	.field public uint32 aldehyde
	.field public uint32 ester
	.field public uint32 carbacid
	.field public uint32 halogen
	.field public uint32 nitrile
	.field public uint32 phenol
	.field public uint32 ether
	.field public uint32 henry
	.field public uint32 blank2
	.field public uint32 blank3

} // end of class AspenTech.Interop.ThPropManager.thcmp_type

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager.thcmp_unifact
	extends [mscorlib]System.ValueType
{
	.pack 4
	.size 0

	// Fields
	.field public uint32 count
	.field public uint32 group

} // end of class AspenTech.Interop.ThPropManager.thcmp_unifact

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager.SPhaseStructure
	extends [mscorlib]System.ValueType
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = (
		01 00 00 00
	)
	.pack 8
	.size 0

	// Fields
	.field public valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType PhType
	.field public float64 PhFrac
	.field public native int Comp
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComConversionLossAttribute::.ctor() = (
		01 00 00 00
	)
	.field public float64 Sj
	.field public float64 Hj
	.field public float64 Cpj
	.field public float64 MolarVol

} // end of class AspenTech.Interop.ThPropManager.SPhaseStructure

.class public auto ansi sealed AspenTech.Interop.ThPropManager.tagHysysPhaseType
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysVapourPhase = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysLiquidPhase = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysAqueousPhase = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysCombinedLiquidPhase = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysSolidPhase = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysCombinedPhase = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysPolymerPhase = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysHeaviestLiqPhase = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagHysysPhaseType HysysUnknownPhase = int32(8)

} // end of class AspenTech.Interop.ThPropManager.tagHysysPhaseType

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IRealMatrixDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 36 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthRow (
			[in] int32 nRow
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthColumn (
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IthColumn

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IthColumn

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::Reset

	// Properties
	.property instance int32 NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.IRealMatrixDisp::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThPropManager.IRealMatrixDisp::set_NumberOfColumns(int32)
	}
	.property instance int32 NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.IRealMatrixDisp::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThPropManager.IRealMatrixDisp::set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThPropManager.IRealMatrixDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IIntegerMatrixDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 45 32 36 34 44 37 30 2d 46 37 42 30
		2d 31 31 44 34 2d 42 46 38 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthRow (
			[in] int32 nRow
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthColumn (
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_IthColumn

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_IthColumn

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::Reset

	// Properties
	.property instance int32 NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.IIntegerMatrixDisp::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThPropManager.IIntegerMatrixDisp::set_NumberOfColumns(int32)
	}
	.property instance int32 NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.IIntegerMatrixDisp::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThPropManager.IIntegerMatrixDisp::set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThPropManager.IIntegerMatrixDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IThermoProperty
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 31 43 46 44 44 35 42 30 2d 34 32 41 43
		2d 31 31 44 32 2d 42 38 43 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void EvaluateProperty (
			[in] int32 nPropertyID,
			[in] int32 ePhaseType,
			[in] object marshal(idispatch) pPhaseCollection
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IThermoProperty::EvaluateProperty

	.method public hidebysig newslot abstract virtual 
		instance void EvaluatePhaseProperty (
			[in] int32 nPropertyID,
			[in] object marshal(idispatch) pPhase
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IThermoProperty::EvaluatePhaseProperty

	.method public hidebysig newslot abstract virtual 
		instance void EvaluatePropertyBy (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] string marshal(bstr) strMethod
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IThermoProperty::EvaluatePropertyBy

	.method public hidebysig newslot abstract virtual 
		instance void EvaluatePhasePropertyBy (
			[in] object marshal(idispatch) pPhase,
			[in] string marshal(bstr) strMethod
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IThermoProperty::EvaluatePhasePropertyBy

	.method public hidebysig newslot abstract virtual 
		instance object marshal(idispatch) GetDefaultPropCalcMethodObjectForFlash (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IThermoProperty::GetDefaultPropCalcMethodObjectForFlash

	.method public hidebysig newslot abstract virtual 
		instance void GetPropertyCallBackAndContextManager (
			[in] int32 ePropertyID,
			[in] object marshal(idispatch) pPhase,
			[out] object& marshal(idispatch) pPropCallBack,
			[out] object& marshal(idispatch) pContxMgr
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IThermoProperty::GetPropertyCallBackAndContextManager

} // end of class AspenTech.Interop.ThPropManager.IThermoProperty

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IFlashProperties
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 45 46 36 31 36 46 34 30 2d 36 38 33 39
		2d 31 31 44 32 2d 42 38 45 30 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance object marshal(idispatch) GetFlashControl () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IFlashProperties::GetFlashControl

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetFlashFamily () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IFlashProperties::GetFlashFamily

	.method public hidebysig newslot abstract virtual 
		instance void CreateFlash (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum eFlashType,
			[in] int32 nOrder,
			[out] object& marshal(idispatch) ppFlash
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IFlashProperties::CreateFlash

	.method public hidebysig newslot abstract virtual 
		instance void CreateFlashByFamily (
			[in] string marshal(bstr) strFlashFamily,
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum eFlashType,
			[in] int32 nOrder,
			[out] object& marshal(idispatch) ppFlash
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IFlashProperties::CreateFlashByFamily

	.method public hidebysig newslot abstract virtual 
		instance void EvaluateFlashProperty (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType,
			[in] object marshal(idispatch) pPhaseCollection,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IFlashProperties::EvaluateFlashProperty

	.method public hidebysig newslot abstract virtual 
		instance void EvaluateFlashPhaseProperty (
			[in] int32 ePropertyID,
			[in] object marshal(idispatch) pPhase,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IFlashProperties::EvaluateFlashPhaseProperty

	.method public hidebysig newslot abstract virtual 
		instance void EvaluateFlashPropertyBy (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] string marshal(bstr) strMethod,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IFlashProperties::EvaluateFlashPropertyBy

	.method public hidebysig newslot abstract virtual 
		instance void EvaluateFlashPhasePropertyBy (
			[in] object marshal(idispatch) pPhase,
			[in] string marshal(bstr) strMethod,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] [out] object& marshal(idispatch) ppContext
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method IFlashProperties::EvaluateFlashPhasePropertyBy

} // end of class AspenTech.Interop.ThPropManager.IFlashProperties

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IPersistStreamInit
	implements AspenTech.Interop.ThPropManager.IPersist
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 37 46 44 35 32 33 38 30 2d 34 45 30 37
		2d 31 30 31 42 2d 41 45 32 44 2d 30 38 30 30 32
		42 32 45 43 37 31 33 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetClassID (
			[out] valuetype [mscorlib]System.Guid& pClassID
		) runtime managed internalcall 
	{
	} // end of method IPersistStreamInit::GetClassID

	.method public hidebysig newslot abstract virtual 
		instance void IsDirty () runtime managed internalcall 
	{
	} // end of method IPersistStreamInit::IsDirty

	.method public hidebysig newslot abstract virtual 
		instance void Load (
			[in] class AspenTech.Interop.ThPropManager.IStream marshal(interface) pstm
		) runtime managed internalcall 
	{
	} // end of method IPersistStreamInit::Load

	.method public hidebysig newslot abstract virtual 
		instance void Save (
			[in] class AspenTech.Interop.ThPropManager.IStream marshal(interface) pstm,
			[in] int32 fClearDirty
		) runtime managed internalcall 
	{
	} // end of method IPersistStreamInit::Save

	.method public hidebysig newslot abstract virtual 
		instance void GetSizeMax (
			[out] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER& pCbSize
		) runtime managed internalcall 
	{
	} // end of method IPersistStreamInit::GetSizeMax

	.method public hidebysig newslot abstract virtual 
		instance void InitNew () runtime managed internalcall 
	{
	} // end of method IPersistStreamInit::InitNew

} // end of class AspenTech.Interop.ThPropManager.IPersistStreamInit

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IPersist
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 30 30 30 30 30 31 30 43 2d 30 30 30 30
		2d 30 30 30 30 2d 43 30 30 30 2d 30 30 30 30 30
		30 30 30 30 30 34 36 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetClassID (
			[out] valuetype [mscorlib]System.Guid& pClassID
		) runtime managed internalcall 
	{
	} // end of method IPersist::GetClassID

} // end of class AspenTech.Interop.ThPropManager.IPersist

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IStream
	implements AspenTech.Interop.ThPropManager.ISequentialStream
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 30 30 30 30 30 30 30 43 2d 30 30 30 30
		2d 30 30 30 30 2d 43 30 30 30 2d 30 30 30 30 30
		30 30 30 30 30 34 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void RemoteRead (
			[out] uint8& pv,
			[in] uint32 cb,
			[out] uint32& pcbRead
		) runtime managed internalcall 
	{
	} // end of method IStream::RemoteRead

	.method public hidebysig newslot abstract virtual 
		instance void RemoteWrite (
			[in] uint8& pv,
			[in] uint32 cb,
			[out] uint32& pcbWritten
		) runtime managed internalcall 
	{
	} // end of method IStream::RemoteWrite

	.method public hidebysig newslot abstract virtual 
		instance void RemoteSeek (
			[in] valuetype AspenTech.Interop.ThPropManager._LARGE_INTEGER dlibMove,
			[in] uint32 dwOrigin,
			[out] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER& plibNewPosition
		) runtime managed internalcall 
	{
	} // end of method IStream::RemoteSeek

	.method public hidebysig newslot abstract virtual 
		instance void SetSize (
			[in] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER libNewSize
		) runtime managed internalcall 
	{
	} // end of method IStream::SetSize

	.method public hidebysig newslot abstract virtual 
		instance void RemoteCopyTo (
			[in] class AspenTech.Interop.ThPropManager.IStream marshal(interface) pstm,
			[in] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER cb,
			[out] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER& pcbRead,
			[out] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER& pcbWritten
		) runtime managed internalcall 
	{
	} // end of method IStream::RemoteCopyTo

	.method public hidebysig newslot abstract virtual 
		instance void Commit (
			[in] uint32 grfCommitFlags
		) runtime managed internalcall 
	{
	} // end of method IStream::Commit

	.method public hidebysig newslot abstract virtual 
		instance void Revert () runtime managed internalcall 
	{
	} // end of method IStream::Revert

	.method public hidebysig newslot abstract virtual 
		instance void LockRegion (
			[in] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER libOffset,
			[in] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER cb,
			[in] uint32 dwLockType
		) runtime managed internalcall 
	{
	} // end of method IStream::LockRegion

	.method public hidebysig newslot abstract virtual 
		instance void UnlockRegion (
			[in] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER libOffset,
			[in] valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER cb,
			[in] uint32 dwLockType
		) runtime managed internalcall 
	{
	} // end of method IStream::UnlockRegion

	.method public hidebysig newslot abstract virtual 
		instance void Stat (
			[out] valuetype AspenTech.Interop.ThPropManager.tagSTATSTG& pstatstg,
			[in] uint32 grfStatFlag
		) runtime managed internalcall 
	{
	} // end of method IStream::Stat

	.method public hidebysig newslot abstract virtual 
		instance void Clone (
			[out] class AspenTech.Interop.ThPropManager.IStream& marshal(interface) ppstm
		) runtime managed internalcall 
	{
	} // end of method IStream::Clone

} // end of class AspenTech.Interop.ThPropManager.IStream

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ISequentialStream
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 30 43 37 33 33 41 33 30 2d 32 41 31 43
		2d 31 31 43 45 2d 41 44 45 35 2d 30 30 41 41 30
		30 34 34 37 37 33 44 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void RemoteRead (
			[out] uint8& pv,
			[in] uint32 cb,
			[out] uint32& pcbRead
		) runtime managed internalcall 
	{
	} // end of method ISequentialStream::RemoteRead

	.method public hidebysig newslot abstract virtual 
		instance void RemoteWrite (
			[in] uint8& pv,
			[in] uint32 cb,
			[out] uint32& pcbWritten
		) runtime managed internalcall 
	{
	} // end of method ISequentialStream::RemoteWrite

} // end of class AspenTech.Interop.ThPropManager.ISequentialStream

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager._LARGE_INTEGER
	extends [mscorlib]System.ValueType
{
	.pack 8
	.size 0

	// Fields
	.field public int64 QuadPart

} // end of class AspenTech.Interop.ThPropManager._LARGE_INTEGER

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager._ULARGE_INTEGER
	extends [mscorlib]System.ValueType
{
	.pack 8
	.size 0

	// Fields
	.field public uint64 QuadPart

} // end of class AspenTech.Interop.ThPropManager._ULARGE_INTEGER

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager.tagSTATSTG
	extends [mscorlib]System.ValueType
{
	.pack 8
	.size 0

	// Fields
	.field public marshal(lpwstr) string pwcsName
	.field public uint32 'type'
	.field public valuetype AspenTech.Interop.ThPropManager._ULARGE_INTEGER cbSize
	.field public valuetype AspenTech.Interop.ThPropManager._FILETIME mtime
	.field public valuetype AspenTech.Interop.ThPropManager._FILETIME ctime
	.field public valuetype AspenTech.Interop.ThPropManager._FILETIME atime
	.field public uint32 grfMode
	.field public uint32 grfLocksSupported
	.field public valuetype [mscorlib]System.Guid 'clsid'
	.field public uint32 grfStateBits
	.field public uint32 reserved

} // end of class AspenTech.Interop.ThPropManager.tagSTATSTG

.class public sequential ansi sealed beforefieldinit AspenTech.Interop.ThPropManager._FILETIME
	extends [mscorlib]System.ValueType
{
	.pack 4
	.size 0

	// Fields
	.field public uint32 dwLowDateTime
	.field public uint32 dwHighDateTime

} // end of class AspenTech.Interop.ThPropManager._FILETIME

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ISupportErrorInfo
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 46 30 42 33 44 36 30 2d 35 34 38 46
		2d 31 30 31 42 2d 38 45 36 35 2d 30 38 30 30 32
		42 32 42 44 31 31 39 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void InterfaceSupportsErrorInfo (
			[in] valuetype [mscorlib]System.Guid& riid
		) runtime managed internalcall 
	{
	} // end of method ISupportErrorInfo::InterfaceSupportsErrorInfo

} // end of class AspenTech.Interop.ThPropManager.ISupportErrorInfo

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IThermoPropertyManager1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 41 43 32 44 33 33 31 2d 44 32 39 41
		2d 31 31 44 33 2d 41 36 30 46 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetPropModelCreatePropObjects (
			[in] string marshal(bstr) strModelName,
			[in] uint8 bReset
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager1::SetPropModelCreatePropObjects

	.method public hidebysig newslot abstract virtual 
		instance void GetIPModelsInfo (
			[out] int32& numbIPs,
			[out] object& marshal(struct) modelnames,
			[out] object& marshal(struct) modelpanes
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager1::GetIPModelsInfo

	.method public hidebysig newslot abstract virtual 
		instance void SetDefaultPropertyMethodCreateObject (
			[in] int32 ePropertyID,
			[in] int32 ePhaseType,
			[in] string marshal(bstr) strPropertyName,
			[in] object marshal(idispatch) pCC,
			[in] string marshal(bstr) defdbdir,
			[in] object marshal(idispatch) pIPManager
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager1::SetDefaultPropertyMethodCreateObject

	.method public hidebysig newslot abstract virtual 
		instance void GetModelType (
			[out] string& marshal(bstr) modeltype
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager1::GetModelType

	.method public hidebysig newslot abstract virtual 
		instance void SetCompoundCollection (
			[in] object marshal(idispatch) compcoll
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager1::SetCompoundCollection

	.method public hidebysig newslot abstract virtual 
		instance void InitializeFlashes () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager1::InitializeFlashes

} // end of class AspenTech.Interop.ThPropManager.IThermoPropertyManager1

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.XMLParserClient
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 35 46 37 38 39 39 34 2d 36 36 45 38
		2d 31 31 44 33 2d 38 45 42 33 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void CharacterData (
			[in] string marshal(bstr) userData
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method XMLParserClient::CharacterData

	.method public hidebysig newslot abstract virtual 
		instance void StartElement (
			[in] string marshal(bstr) name,
			[in] class AspenTech.Interop.ThPropManager.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method XMLParserClient::StartElement

	.method public hidebysig newslot abstract virtual 
		instance void EndElement (
			[in] string marshal(bstr) name
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method XMLParserClient::EndElement

	.method public hidebysig newslot abstract virtual 
		instance void Comment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method XMLParserClient::Comment

	.method public hidebysig newslot abstract virtual 
		instance void ProcessElement (
			[in] string marshal(bstr) name,
			[in] class AspenTech.Interop.ThPropManager.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method XMLParserClient::ProcessElement

	.method public hidebysig newslot abstract virtual 
		instance void Error (
			[in] string marshal(bstr) Error
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method XMLParserClient::Error

	.method public hidebysig newslot abstract virtual 
		instance void StartDocument () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method XMLParserClient::StartDocument

	.method public hidebysig newslot abstract virtual 
		instance void EndDocument () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
	} // end of method XMLParserClient::EndDocument

} // end of class AspenTech.Interop.ThPropManager.XMLParserClient

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.TaggedAttributes
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 37 37 45 44 42 42 30 2d 34 46 35 42
		2d 31 31 44 33 2d 38 45 41 45 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Add (
			[in] string marshal(bstr) tag,
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method TaggedAttributes::Add

	.method public hidebysig newslot abstract virtual 
		instance void AddMultiple (
			[in] object marshal(struct) tags,
			[in] object marshal(struct) values
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method TaggedAttributes::AddMultiple

	.method public hidebysig newslot abstract virtual 
		instance void Find (
			[in] string marshal(bstr) tag,
			[out] string& marshal(bstr) retValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method TaggedAttributes::Find

	.method public hidebysig newslot abstract virtual 
		instance void GetByIndex (
			[in] int32 index,
			[out] string& marshal(bstr) retTag,
			[out] string& marshal(bstr) retValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method TaggedAttributes::GetByIndex

	.method public hidebysig newslot abstract virtual 
		instance void GetMultiple (
			[out] object& marshal(struct) retTags,
			[out] object& marshal(struct) retValues
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method TaggedAttributes::GetMultiple

	.method public hidebysig newslot abstract virtual 
		instance void Size (
			[out] int32& Size
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method TaggedAttributes::Size

} // end of class AspenTech.Interop.ThPropManager.TaggedAttributes

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IXMLStore
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 36 46 43 46 44 34 30 2d 46 39 31 42
		2d 31 31 44 33 2d 42 46 34 36 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) StoreAsXML () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IXMLStore::StoreAsXML

} // end of class AspenTech.Interop.ThPropManager.IXMLStore

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IThermoPropertyManager2
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 39 46 42 45 46 46 39 31 2d 30 43 33 43
		2d 31 31 44 34 2d 41 36 33 33 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetIPModelsInfo (
			[in] object marshal(idispatch) pCC
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IThermoPropertyManager2::SetIPModelsInfo

} // end of class AspenTech.Interop.ThPropManager.IThermoPropertyManager2

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ICOMExtensionHandler
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 42 35 35 30 33 37 30 2d 33 32 39 38
		2d 31 31 44 35 2d 42 46 39 39 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetPkgInfo (
			[in] [out] string& marshal(bstr) PkgName,
			[in] [out] string& marshal(bstr) PkgDescription,
			[in] [out] int32& nSetupFiles,
			[in] [out] string& marshal(bstr) SetupDescription
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::GetPkgInfo

	.method public hidebysig newslot abstract virtual 
		instance void SetupExtendedPropPkg (
			[in] int32 nfiles,
			[in] object marshal(struct) filenames,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::SetupExtendedPropPkg

	.method public hidebysig newslot abstract virtual 
		instance void UseExtendedPropPkg (
			[in] [out] uint8& IsUsed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::UseExtendedPropPkg

	.method public hidebysig newslot abstract virtual 
		instance void GetExtendedPropPkg (
			[in] [out] object& marshal(idispatch) pPropPkg
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::GetExtendedPropPkg

	.method public hidebysig newslot abstract virtual 
		instance void GetPropCalcBase (
			[in] string marshal(bstr) PropName,
			[in] [out] int32& Base
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::GetPropCalcBase

	.method public hidebysig newslot abstract virtual 
		instance void PreSetCompInfo (
			[in] [out] uint8& CanChange,
			[in] [out] int32& nComp,
			[in] [out] object& marshal(struct) HyprotechIDs,
			[in] [out] object& marshal(struct) names
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::PreSetCompInfo

	.method public hidebysig newslot abstract virtual 
		instance void GetPkgNumbComps (
			[in] [out] int32& nComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::GetPkgNumbComps

	.method public hidebysig newslot abstract virtual 
		instance void GetPkgCompInfo (
			[in] int32 iComp,
			[in] object marshal(idispatch) pCompoundi,
			[in] [out] int32& nProps,
			[in] [out] object& marshal(struct) propnames
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::GetPkgCompInfo

	.method public hidebysig newslot abstract virtual 
		instance void AddPkgLastComp (
			[in] object marshal(idispatch) pCompoundi
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::AddPkgLastComp

	.method public hidebysig newslot abstract virtual 
		instance void RemovePkgComp (
			[in] int32 iComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::RemovePkgComp

	.method public hidebysig newslot abstract virtual 
		instance void ExchangePkgComps (
			[in] int32 iComp,
			[in] int32 jComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::ExchangePkgComps

	.method public hidebysig newslot abstract virtual 
		instance void PkgPhaseOrder (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] object marshal(idispatch) pThermoProperty
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::PkgPhaseOrder

	.method public hidebysig newslot abstract virtual 
		instance void PkgOnView (
			[in] [out] string& marshal(bstr) ViewName,
			[in] [out] bool& OpenView
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::PkgOnView

	.method public hidebysig newslot abstract virtual 
		instance void PkgSave (
			[in] [out] string& marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::PkgSave

	.method public hidebysig newslot abstract virtual 
		instance void PkgRecall (
			[in] string marshal(bstr) saveinfo,
			[in] [out] bool& BaseChanged
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::PkgRecall

	.method public hidebysig newslot abstract virtual 
		instance void GetFlashInfo (
			[in] [out] string& marshal(bstr) FlashName,
			[in] [out] string& marshal(bstr) FlashDescription,
			[in] [out] int32& nSetupFiles,
			[in] [out] string& marshal(bstr) SetupDescription
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::GetFlashInfo

	.method public hidebysig newslot abstract virtual 
		instance void SetupExtendedFlash (
			[in] int32 nfiles,
			[in] object marshal(struct) filenames,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::SetupExtendedFlash

	.method public hidebysig newslot abstract virtual 
		instance void FlashTypesSupported (
			[in] [out] int32& nFlashes,
			[in] [out] object& marshal(struct) types
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::FlashTypesSupported

	.method public hidebysig newslot abstract virtual 
		instance void CanHandleFlashType (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum 'type',
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 13 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::CanHandleFlashType

	.method public hidebysig newslot abstract virtual 
		instance void UseExtendedFlash (
			[in] [out] uint8& IsUsed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::UseExtendedFlash

	.method public hidebysig newslot abstract virtual 
		instance void GetExtendedFlash (
			[in] [out] object& marshal(idispatch) pExtFlash
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 15 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::GetExtendedFlash

	.method public hidebysig newslot abstract virtual 
		instance void UseFlashControl (
			[in] [out] uint8& IsUsed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 16 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::UseFlashControl

	.method public hidebysig newslot abstract virtual 
		instance void FlashSave (
			[in] [out] string& marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 17 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::FlashSave

	.method public hidebysig newslot abstract virtual 
		instance void FlashRecall (
			[in] string marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 18 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::FlashRecall

	.method public hidebysig newslot abstract virtual 
		instance void CalculateTwoPhaseProperty (
			[in] int32 propertyID,
			[in] object marshal(idispatch) pPhaseCollection,
			[in] int32 iphase,
			[in] int32 jphase
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 19 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::CalculateTwoPhaseProperty

	.method public hidebysig newslot abstract virtual 
		instance void IsPkgSetup (
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1a 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::IsPkgSetup

	.method public hidebysig newslot abstract virtual 
		instance void IsFlashSetup (
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 1b 00 00 00 00 00
		)
	} // end of method ICOMExtensionHandler::IsFlashSetup

} // end of class AspenTech.Interop.ThPropManager.ICOMExtensionHandler

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IPostProgress
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 33 42 44 38 38 43 31 2d 35 35 31 34
		2d 31 31 44 35 2d 41 36 31 34 2d 30 30 41 30 43
		39 44 46 34 45 45 32 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void PostProgress (
			[in] int32 ProgressCode,
			[in] string marshal(bstr) ProgressMessage
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IPostProgress::PostProgress

	.method public hidebysig newslot abstract virtual 
		instance void SetProgressCallback (
			class AspenTech.Interop.ThPropManager.IThermoProgress marshal(interface) pProgressCallback
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IPostProgress::SetProgressCallback

	.method public hidebysig newslot abstract virtual 
		instance void RemoveProgressCallback () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IPostProgress::RemoveProgressCallback

} // end of class AspenTech.Interop.ThPropManager.IPostProgress

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IThermoProgress
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 33 42 44 38 38 43 30 2d 35 35 31 34
		2d 31 31 44 35 2d 41 36 31 34 2d 30 30 41 30 43
		39 44 46 34 45 45 32 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 00 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Progress (
			[in] int32 ProgressCode,
			[in] string marshal(bstr) ProgressMessage
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IThermoProgress::Progress

} // end of class AspenTech.Interop.ThPropManager.IThermoProgress

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IPostError
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 34 32 46 46 30 38 30 2d 39 42 38 36
		2d 31 31 44 33 2d 42 46 45 35 2d 30 30 39 30 32
		37 31 43 45 41 30 31 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void PostError (
			[in] int32 ErrorCode,
			[in] string marshal(bstr) ErrorMessage,
			[in] bool ToUserDialog,
			[in] bool IsImportant
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IPostError::PostError

	.method public hidebysig newslot abstract virtual 
		instance bool PostWarning (
			[in] int32 ErrorCode,
			[in] string marshal(bstr) ErrorMessage,
			[in] bool ToUserDialog,
			[in] bool IsImportant
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IPostError::PostWarning

	.method public hidebysig newslot abstract virtual 
		instance void SetErrorCallback (
			class AspenTech.Interop.ThPropManager.IThermoError marshal(interface) pErrorCallback
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IPostError::SetErrorCallback

	.method public hidebysig newslot abstract virtual 
		instance void RemoveErrorCallback () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IPostError::RemoveErrorCallback

} // end of class AspenTech.Interop.ThPropManager.IPostError

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IThermoError
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 37 45 43 44 30 38 44 30 2d 38 41 46 37
		2d 31 31 44 33 2d 42 46 45 32 2d 30 30 39 30 32
		37 31 43 45 41 30 31 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Error (
			[in] int32 ErrorCode,
			[in] string marshal(bstr) ErrorMessage,
			[in] bool ToUserDialog,
			[in] bool IsImportant
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IThermoError::Error

	.method public hidebysig newslot abstract virtual 
		instance bool Warning (
			[in] int32 ErrorCode,
			[in] string marshal(bstr) ErrorMessage,
			[in] bool ToUserDialog,
			[in] bool IsImportant
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IThermoError::Warning

} // end of class AspenTech.Interop.ThPropManager.IThermoError

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 41 46 31 44 39 32 33 2d 33 37 41 41
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance int32 GetPropertyIDByName (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IPropertyEnumerationRegistry::GetPropertyIDByName

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetPropertyNameByID (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IPropertyEnumerationRegistry::GetPropertyNameByID

	.method public hidebysig newslot abstract virtual 
		instance int32 AddPropertyByName (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IPropertyEnumerationRegistry::AddPropertyByName

} // end of class AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.INotifyChange
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 37 38 36 36 34 30 30 2d 43 30 45 37
		2d 31 31 44 36 2d 42 38 39 36 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void UseNotifyChange (
			[in] uint8 Use
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method INotifyChange::UseNotifyChange

	.method public hidebysig newslot abstract virtual 
		instance void HasModified (
			[in] valuetype AspenTech.Interop.ThPropManager.NotifyChange whatchanged
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method INotifyChange::HasModified

} // end of class AspenTech.Interop.ThPropManager.INotifyChange

.class public auto ansi sealed AspenTech.Interop.ThPropManager.NotifyChange
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThPropManager.NotifyChange NothingChanged = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.NotifyChange CompColChanged = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.NotifyChange IPChanged = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.NotifyChange CompoundsChanged = int32(3)

} // end of class AspenTech.Interop.ThPropManager.NotifyChange

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ICOTHHysysSecurity
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 37 39 42 38 35 30 36 2d 36 34 34 31
		2d 34 34 32 33 2d 41 39 33 33 2d 42 37 34 44 32
		31 36 34 36 32 42 32 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void PutApplicationInterface (
			[in] object marshal(iunknown) pIUnknown
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICOTHHysysSecurity::PutApplicationInterface

	.method public hidebysig newslot abstract virtual 
		instance void GetApplicationInterface (
			[in] [out] object& marshal(iunknown) pIUnknown
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICOTHHysysSecurity::GetApplicationInterface

} // end of class AspenTech.Interop.ThPropManager.ICOTHHysysSecurity

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ICOTHCompositionTransfer
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 45 38 34 42 45 44 34 2d 44 36 45 41
		2d 34 36 30 31 2d 38 46 34 35 2d 42 34 41 32 41
		30 30 43 41 44 31 30 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetCompositionSource (
			[in] [out] string& marshal(bstr) sSource
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICOTHCompositionTransfer::GetCompositionSource

	.method public hidebysig newslot abstract virtual 
		instance void GetComposition (
			[in] int32 nComp,
			[in] class AspenTech.Interop.ThPropManager.IRealArrayDisp marshal(interface) pComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICOTHCompositionTransfer::GetComposition

} // end of class AspenTech.Interop.ThPropManager.ICOTHCompositionTransfer

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IRealArrayDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 34 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::get_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::set_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::get_IthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::set_IthValue

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::Reset

	.method public hidebysig newslot abstract virtual 
		instance void Copy (
			[in] class AspenTech.Interop.ThPropManager.IRealArrayDisp marshal(interface) pArray
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::Copy

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IRealArrayDisp::get_values

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_values (
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IRealArrayDisp::set_values

	// Properties
	.property instance int32 Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.IRealArrayDisp::get_Size()
		.set instance void AspenTech.Interop.ThPropManager.IRealArrayDisp::set_Size(int32)
	}

} // end of class AspenTech.Interop.ThPropManager.IRealArrayDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IDerivativeHandler
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 30 32 46 32 34 46 30 2d 35 45 32 30
		2d 31 31 44 37 2d 42 38 42 32 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void TurnOnDerivative (
			[in] uint8 bOn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IDerivativeHandler::TurnOnDerivative

	.method public hidebysig newslot abstract virtual 
		instance void SetDerivativeType (
			[in] valuetype AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum eType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IDerivativeHandler::SetDerivativeType

	.method public hidebysig newslot abstract virtual 
		instance void CanCalculateDerivative (
			[in] int32 nPropComID,
			[in] valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum ePhaseType,
			[in] int32 nPropID,
			[in] int32 nDerivativeID,
			[in] [out] uint8& bYes,
			[in] [out] valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum& ePropResultType,
			[in] [out] valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum& eDevResultType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IDerivativeHandler::CanCalculateDerivative

} // end of class AspenTech.Interop.ThPropManager.IDerivativeHandler

.class public auto ansi sealed AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum NoDerivativeType = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum AnalyticalOnly = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum NumericalOnly = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum NumericalBackup = int32(3)

} // end of class AspenTech.Interop.ThPropManager.tagDerivativeTypeEnum

.class public auto ansi sealed AspenTech.Interop.ThPropManager.tagPhaseTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptUnknownPhase = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptOverall = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptFeed = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptVapour = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptLiquid = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptAqueous = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptSolid = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptInsolubleSolid = int32(7)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptDensePhase = int32(8)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptHydrate = int32(9)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptWax = int32(10)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptUserType = int32(11)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptMultiPhase = int32(12)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum xptLastPhaseType = int32(13)

} // end of class AspenTech.Interop.ThPropManager.tagPhaseTypeEnum

.class public auto ansi sealed AspenTech.Interop.ThPropManager.tagResultTypeEnum
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum NoResultType = int32(0)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum RealPoint = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum RealArray = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum RealMatrix = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum IntPoint = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum IntArray = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum IntMatrix = int32(6)
	.field public static literal valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum VariantType = int32(7)

} // end of class AspenTech.Interop.ThPropManager.tagResultTypeEnum

.class public auto ansi import beforefieldinit AspenTech.Interop.ThPropManager.COTHInteractionParametersClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThPropManager.IExtractInteractionParameters,
	           AspenTech.Interop.ThPropManager.COTHInteractionParameters,
	           AspenTech.Interop.ThPropManager.ISetupInteractionParameters,
	           AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHypDB,
	           AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHYSYS,
	           AspenTech.Interop.ThPropManager.IInteractionParametersManipulate,
	           AspenTech.Interop.ThPropManager.ISetupInteractionParameters1,
	           AspenTech.Interop.ThPropManager.IExtractInteractionParameters1,
	           AspenTech.Interop.ThPropManager.IIPLoadingInfo,
	           AspenTech.Interop.ThPropManager.IIPLoad,
	           AspenTech.Interop.ThPropManager.XMLParserClient,
	           AspenTech.Interop.ThPropManager.IXMLStore,
	           AspenTech.Interop.ThPropManager.ISubIP
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 41 39 44 36 36 43 30 2d 35 31 41 37
		2d 31 31 44 32 2d 42 38 44 35 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance string marshal(bstr) get_ModelName () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method COTHInteractionParametersClass::get_ModelName

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfPanes () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method COTHInteractionParametersClass::get_NumberOfPanes

	.method public hidebysig specialname newslot virtual 
		instance int32 get_Dimension () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method COTHInteractionParametersClass::get_Dimension

	.method public hidebysig specialname newslot virtual 
		instance float64 get_value (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThPropManager.IExtractInteractionParameters::get_value(int32, int32, int32)
	} // end of method COTHInteractionParametersClass::get_value

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_values (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThPropManager.IExtractInteractionParameters::get_values(int32, int32)
	} // end of method COTHInteractionParametersClass::get_values

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_PaneValues (
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThPropManager.IExtractInteractionParameters::get_PaneValues(int32, int32)
	} // end of method COTHInteractionParametersClass::get_PaneValues

	.method public hidebysig specialname newslot virtual 
		instance void set_ModelName (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_ModelName(string)
	} // end of method COTHInteractionParametersClass::set_ModelName

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfPanes (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_NumberOfPanes(int32)
	} // end of method COTHInteractionParametersClass::set_NumberOfPanes

	.method public hidebysig specialname newslot virtual 
		instance void set_Dimension (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_Dimension(int32)
	} // end of method COTHInteractionParametersClass::set_Dimension

	.method public hidebysig specialname newslot virtual 
		instance void set_value (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_value(int32, int32, int32, float64)
	} // end of method COTHInteractionParametersClass::set_value

	.method public hidebysig specialname newslot virtual 
		instance void set_values (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_values(int32, int32, object)
	} // end of method COTHInteractionParametersClass::set_values

	.method public hidebysig specialname newslot virtual 
		instance void set_PaneValues (
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_PaneValues(int32, int32, object)
	} // end of method COTHInteractionParametersClass::set_PaneValues

	.method public hidebysig newslot virtual 
		instance void Init (
			[in] string marshal(bstr) strPath,
			[in] string marshal(bstr) strModel,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHypDB::Init(string, string, object)
	} // end of method COTHInteractionParametersClass::Init

	.method public hidebysig newslot virtual 
		instance void Init (
			[in] string marshal(bstr) strModel,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHYSYS::Init(string, object)
	} // end of method COTHInteractionParametersClass::Init

	.method public hidebysig newslot virtual 
		instance void LoadLastCompoundIPs (
			[in] string marshal(bstr) databasedir,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IInteractionParametersManipulate::LoadLastCompoundIPs(string, object)
	} // end of method COTHInteractionParametersClass::LoadLastCompoundIPs

	.method public hidebysig newslot virtual 
		instance void MoveIPs (
			[in] int32 compToMove,
			[in] int32 moveBeforeComp
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IInteractionParametersManipulate::MoveIPs(int32, int32)
	} // end of method COTHInteractionParametersClass::MoveIPs

	.method public hidebysig newslot virtual 
		instance void RemoveLastIPs (
			int32 nPaneSize
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IInteractionParametersManipulate::RemoveLastIPs(int32)
	} // end of method COTHInteractionParametersClass::RemoveLastIPs

	.method public hidebysig newslot virtual 
		instance void LoadIJPairIPsFromHypDB (
			[in] string marshal(bstr) strPath,
			[in] object marshal(idispatch) pCompList,
			[in] int32 comp1,
			[in] int32 comp2
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IInteractionParametersManipulate::LoadIJPairIPsFromHypDB(string, object, int32, int32)
	} // end of method COTHInteractionParametersClass::LoadIJPairIPsFromHypDB

	.method public hidebysig newslot virtual 
		instance void ReloadAllIPsFromHypDB (
			[in] string marshal(bstr) strPath,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IInteractionParametersManipulate::ReloadAllIPsFromHypDB(string, object)
	} // end of method COTHInteractionParametersClass::ReloadAllIPsFromHypDB

	.method public hidebysig newslot virtual 
		instance void PutSpecifiedValue (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] float64 dValue
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters1::PutSpecifiedValue(int32, int32, int32, float64)
	} // end of method COTHInteractionParametersClass::PutSpecifiedValue

	.method public hidebysig newslot virtual 
		instance void PutSpecMatrixValue (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] int32 iValue
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters1::PutSpecMatrixValue(int32, int32, int32, int32)
	} // end of method COTHInteractionParametersClass::PutSpecMatrixValue

	.method public hidebysig newslot virtual 
		instance void GetSpecMatrixValue (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[out] int32& pbValue
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IExtractInteractionParameters1::GetSpecMatrixValue(int32, int32, int32, int32&)
	} // end of method COTHInteractionParametersClass::GetSpecMatrixValue

	.method public hidebysig newslot virtual 
		instance void SetDefaultDatabaseDir (
			[in] string marshal(bstr) defaultatabasedir
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IIPLoadingInfo::SetDefaultDatabaseDir(string)
	} // end of method COTHInteractionParametersClass::SetDefaultDatabaseDir

	.method public hidebysig newslot virtual 
		instance void SetLoader (
			[in] object marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IIPLoadingInfo::SetLoader(object)
	} // end of method COTHInteractionParametersClass::SetLoader

	.method public hidebysig newslot virtual 
		instance void IPLoad (
			[in] object marshal(idispatch) pCC
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.IIPLoad::IPLoad(object)
	} // end of method COTHInteractionParametersClass::IPLoad

	.method public hidebysig newslot virtual 
		instance void CharacterData (
			[in] string marshal(bstr) userData
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::CharacterData(string)
	} // end of method COTHInteractionParametersClass::CharacterData

	.method public hidebysig newslot virtual 
		instance void StartElement (
			[in] string marshal(bstr) name,
			[in] class AspenTech.Interop.ThPropManager.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::StartElement(string, class AspenTech.Interop.ThPropManager.TaggedAttributes)
	} // end of method COTHInteractionParametersClass::StartElement

	.method public hidebysig newslot virtual 
		instance void EndElement (
			[in] string marshal(bstr) name
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::EndElement(string)
	} // end of method COTHInteractionParametersClass::EndElement

	.method public hidebysig newslot virtual 
		instance void Comment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::Comment(string)
	} // end of method COTHInteractionParametersClass::Comment

	.method public hidebysig newslot virtual 
		instance void ProcessElement (
			[in] string marshal(bstr) name,
			[in] class AspenTech.Interop.ThPropManager.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::ProcessElement(string, class AspenTech.Interop.ThPropManager.TaggedAttributes)
	} // end of method COTHInteractionParametersClass::ProcessElement

	.method public hidebysig newslot virtual 
		instance void Error (
			[in] string marshal(bstr) Error
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::Error(string)
	} // end of method COTHInteractionParametersClass::Error

	.method public hidebysig newslot virtual 
		instance void StartDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::StartDocument()
	} // end of method COTHInteractionParametersClass::StartDocument

	.method public hidebysig newslot virtual 
		instance void EndDocument () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.XMLParserClient::EndDocument()
	} // end of method COTHInteractionParametersClass::EndDocument

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) StoreAsXML () runtime managed internalcall 
	{
		.override method instance string AspenTech.Interop.ThPropManager.IXMLStore::StoreAsXML()
	} // end of method COTHInteractionParametersClass::StoreAsXML

	.method public hidebysig newslot virtual 
		instance void SetParent (
			[in] object marshal(idispatch) parent
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISubIP::SetParent(object)
	} // end of method COTHInteractionParametersClass::SetParent

	.method public hidebysig newslot virtual 
		instance void SetCompMapping (
			[in] int32 nComp,
			[in] int32& mapping
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThPropManager.ISubIP::SetCompMapping(int32, int32&)
	} // end of method COTHInteractionParametersClass::SetCompMapping

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHInteractionParametersClass::.ctor

	// Properties
	.property instance string ModelName()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThPropManager.COTHInteractionParametersClass::get_ModelName()
	}
	.property instance int32 NumberOfPanes()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.COTHInteractionParametersClass::get_NumberOfPanes()
	}
	.property instance int32 Dimension()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.COTHInteractionParametersClass::get_Dimension()
	}
	.property instance string AspenTech.Interop.ThPropManager.ISetupInteractionParameters.ModelName()
	{
		.set instance void AspenTech.Interop.ThPropManager.COTHInteractionParametersClass::set_ModelName(string)
	}
	.property instance int32 AspenTech.Interop.ThPropManager.ISetupInteractionParameters.NumberOfPanes()
	{
		.set instance void AspenTech.Interop.ThPropManager.COTHInteractionParametersClass::set_NumberOfPanes(int32)
	}
	.property instance int32 AspenTech.Interop.ThPropManager.ISetupInteractionParameters.Dimension()
	{
		.set instance void AspenTech.Interop.ThPropManager.COTHInteractionParametersClass::set_Dimension(int32)
	}

} // end of class AspenTech.Interop.ThPropManager.COTHInteractionParametersClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.COTHInteractionParameters
	implements AspenTech.Interop.ThPropManager.IExtractInteractionParameters
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 39 31 35 43 42 38 30 2d 33 37 41 39
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 3e 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 50 72 6f 70 4d 61 6e 61 67
		65 72 2e 43 4f 54 48 49 6e 74 65 72 61 63 74 69
		6f 6e 50 61 72 61 6d 65 74 65 72 73 43 6c 61 73
		73 00 00
	)
} // end of class AspenTech.Interop.ThPropManager.COTHInteractionParameters

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IExtractInteractionParameters
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 39 31 35 43 42 38 30 2d 33 37 41 39
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_ModelName () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IExtractInteractionParameters::get_ModelName

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfPanes () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IExtractInteractionParameters::get_NumberOfPanes

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Dimension () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IExtractInteractionParameters::get_Dimension

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_value (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IExtractInteractionParameters::get_value

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_values (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IExtractInteractionParameters::get_values

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_PaneValues (
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IExtractInteractionParameters::get_PaneValues

	// Properties
	.property instance string ModelName()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance string AspenTech.Interop.ThPropManager.IExtractInteractionParameters::get_ModelName()
	}
	.property instance int32 NumberOfPanes()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.IExtractInteractionParameters::get_NumberOfPanes()
	}
	.property instance int32 Dimension()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThPropManager.IExtractInteractionParameters::get_Dimension()
	}

} // end of class AspenTech.Interop.ThPropManager.IExtractInteractionParameters

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ISetupInteractionParameters
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 41 46 31 44 39 31 45 2d 33 37 41 41
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance void set_ModelName (
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters::set_ModelName

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfPanes (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters::set_NumberOfPanes

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Dimension (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters::set_Dimension

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_value (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] float64 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters::set_value

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_values (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters::set_values

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_PaneValues (
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] object marshal(idispatch) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters::set_PaneValues

	// Properties
	.property instance string ModelName()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_ModelName(string)
	}
	.property instance int32 NumberOfPanes()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_NumberOfPanes(int32)
	}
	.property instance int32 Dimension()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.set instance void AspenTech.Interop.ThPropManager.ISetupInteractionParameters::set_Dimension(int32)
	}

} // end of class AspenTech.Interop.ThPropManager.ISetupInteractionParameters

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHypDB
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 38 44 37 32 42 31 30 2d 35 43 37 44
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Init (
			[in] string marshal(bstr) strPath,
			[in] string marshal(bstr) strModel,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IInteractionParametersInitFromHypDB::Init

} // end of class AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHypDB

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHYSYS
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 44 46 36 46 36 41 30 2d 41 35 43 30
		2d 31 31 44 32 2d 39 44 33 44 2d 30 30 31 30 34
		42 32 32 32 34 31 36 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void Init (
			[in] string marshal(bstr) strModel,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IInteractionParametersInitFromHYSYS::Init

} // end of class AspenTech.Interop.ThPropManager.IInteractionParametersInitFromHYSYS

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IInteractionParametersManipulate
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 30 34 31 35 46 46 31 31 2d 36 43 38 33
		2d 31 31 44 33 2d 41 35 44 33 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void LoadLastCompoundIPs (
			[in] string marshal(bstr) databasedir,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IInteractionParametersManipulate::LoadLastCompoundIPs

	.method public hidebysig newslot abstract virtual 
		instance void MoveIPs (
			[in] int32 compToMove,
			[in] int32 moveBeforeComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IInteractionParametersManipulate::MoveIPs

	.method public hidebysig newslot abstract virtual 
		instance void RemoveLastIPs (
			int32 nPaneSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IInteractionParametersManipulate::RemoveLastIPs

	.method public hidebysig newslot abstract virtual 
		instance void LoadIJPairIPsFromHypDB (
			[in] string marshal(bstr) strPath,
			[in] object marshal(idispatch) pCompList,
			[in] int32 comp1,
			[in] int32 comp2
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IInteractionParametersManipulate::LoadIJPairIPsFromHypDB

	.method public hidebysig newslot abstract virtual 
		instance void ReloadAllIPsFromHypDB (
			[in] string marshal(bstr) strPath,
			[in] object marshal(idispatch) pCompList
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IInteractionParametersManipulate::ReloadAllIPsFromHypDB

} // end of class AspenTech.Interop.ThPropManager.IInteractionParametersManipulate

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ISetupInteractionParameters1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 46 39 36 46 33 35 31 2d 37 35 30 41
		2d 31 31 44 33 2d 41 35 44 37 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void PutSpecifiedValue (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] float64 dValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters1::PutSpecifiedValue

	.method public hidebysig newslot abstract virtual 
		instance void PutSpecMatrixValue (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[in] int32 iValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ISetupInteractionParameters1::PutSpecMatrixValue

} // end of class AspenTech.Interop.ThPropManager.ISetupInteractionParameters1

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IExtractInteractionParameters1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 46 39 36 46 33 35 33 2d 37 35 30 41
		2d 31 31 44 33 2d 41 35 44 37 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetSpecMatrixValue (
			[in] int32 nPaneIdx,
			[in] int32 nCompound1Idx,
			[in] int32 nCompound2Idx,
			[out] int32& pbValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IExtractInteractionParameters1::GetSpecMatrixValue

} // end of class AspenTech.Interop.ThPropManager.IExtractInteractionParameters1

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IIPLoadingInfo
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 35 38 44 34 42 30 31 2d 44 35 42 43
		2d 31 31 44 33 2d 41 36 31 30 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetDefaultDatabaseDir (
			[in] string marshal(bstr) defaultatabasedir
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIPLoadingInfo::SetDefaultDatabaseDir

	.method public hidebysig newslot abstract virtual 
		instance void SetLoader (
			[in] object marshal(idispatch) ploader
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIPLoadingInfo::SetLoader

} // end of class AspenTech.Interop.ThPropManager.IIPLoadingInfo

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IIPLoad
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 34 39 37 38 30 37 32 31 2d 44 35 44 30
		2d 31 31 44 33 2d 41 36 31 30 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void IPLoad (
			[in] object marshal(idispatch) pCC
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIPLoad::IPLoad

} // end of class AspenTech.Interop.ThPropManager.IIPLoad

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.ISubIP
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 31 44 44 37 44 37 41 31 2d 46 32 45 35
		2d 31 31 44 34 2d 41 36 44 38 2d 30 30 41 30 43
		39 44 46 34 32 32 42 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void SetParent (
			[in] object marshal(idispatch) parent
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ISubIP::SetParent

	.method public hidebysig newslot abstract virtual 
		instance void SetCompMapping (
			[in] int32 nComp,
			[in] int32& mapping
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ISubIP::SetCompMapping

} // end of class AspenTech.Interop.ThPropManager.ISubIP

.class public auto ansi import beforefieldinit AspenTech.Interop.ThPropManager.COTHPropertyEnumerationRegistryClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry,
	           AspenTech.Interop.ThPropManager.COTHPropertyEnumerationRegistry
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 34 38 31 34 43 45 30 2d 35 45 31 32
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public hidebysig newslot virtual 
		instance int32 GetPropertyIDByName (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry::GetPropertyIDByName(string)
	} // end of method COTHPropertyEnumerationRegistryClass::GetPropertyIDByName

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) GetPropertyNameByID (
			[in] int32 nPropID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance string AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry::GetPropertyNameByID(int32)
	} // end of method COTHPropertyEnumerationRegistryClass::GetPropertyNameByID

	.method public hidebysig newslot virtual 
		instance int32 AddPropertyByName (
			[in] string marshal(bstr) strName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry::AddPropertyByName(string)
	} // end of method COTHPropertyEnumerationRegistryClass::AddPropertyByName

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHPropertyEnumerationRegistryClass::.ctor

} // end of class AspenTech.Interop.ThPropManager.COTHPropertyEnumerationRegistryClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.COTHPropertyEnumerationRegistry
	implements AspenTech.Interop.ThPropManager.IPropertyEnumerationRegistry
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 41 46 31 44 39 32 33 2d 33 37 41 41
		2d 31 31 44 32 2d 42 38 43 36 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 44 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 50 72 6f 70 4d 61 6e 61 67
		65 72 2e 43 4f 54 48 50 72 6f 70 65 72 74 79 45
		6e 75 6d 65 72 61 74 69 6f 6e 52 65 67 69 73 74
		72 79 43 6c 61 73 73 00 00
	)
} // end of class AspenTech.Interop.ThPropManager.COTHPropertyEnumerationRegistry

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IExtendedPropPackage
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 45 41 43 45 46 31 30 2d 32 37 42 38
		2d 31 31 44 35 2d 42 46 39 36 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetPackageName (
			[in] [out] string& marshal(bstr) PkgName,
			[in] [out] string& marshal(bstr) description
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::GetPackageName

	.method public hidebysig newslot abstract virtual 
		instance void PkgFileNeeded (
			[in] [out] int32& nfiles,
			[in] [out] string& marshal(bstr) description
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::PkgFileNeeded

	.method public hidebysig newslot abstract virtual 
		instance void SetupPkg (
			[in] int32 nfiles,
			[in] object marshal(struct) filenames,
			[in] string marshal(bstr) setupinfo,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::SetupPkg

	.method public hidebysig newslot abstract virtual 
		instance void IsPkgSetup (
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::IsPkgSetup

	.method public hidebysig newslot abstract virtual 
		instance void InitializePropertyID (
			[in] object marshal(idispatch) lpPropertyRegistry
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::InitializePropertyID

	.method public hidebysig newslot abstract virtual 
		instance void CanCalculate (
			[in] int32 propertyID,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::CanCalculate

	.method public hidebysig newslot abstract virtual 
		instance void CalculateProperty (
			[in] int32 propertyID,
			[in] object marshal(idispatch) pPhase,
			[in] [out] object& marshal(idispatch) ppContext,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] object marshal(idispatch) errorLog,
			[in] object marshal(idispatch) progressMonitor
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::CalculateProperty

	.method public hidebysig newslot abstract virtual 
		instance void CalculateTwoPhaseProperty (
			[in] int32 propertyID,
			[in] object marshal(idispatch) pPhaseCollection,
			[in] int32 iphase,
			[in] int32 jphase,
			[in] [out] object& marshal(idispatch) ppContext,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] object marshal(idispatch) errorLog,
			[in] object marshal(idispatch) progressMonitor
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::CalculateTwoPhaseProperty

	.method public hidebysig newslot abstract virtual 
		instance void GetEnthalpyBase (
			[in] [out] int32& EnthBase
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::GetEnthalpyBase

	.method public hidebysig newslot abstract virtual 
		instance void GetGibbsBase (
			[in] [out] int32& GibbsBase
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::GetGibbsBase

	.method public hidebysig newslot abstract virtual 
		instance void CanNumbCompChange (
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::CanNumbCompChange

	.method public hidebysig newslot abstract virtual 
		instance void GetSupportedComps (
			[in] [out] int32& nComp,
			[in] [out] object& marshal(struct) HyprotechIDs,
			[in] [out] object& marshal(struct) names,
			[in] [out] string& marshal(bstr) identifiername,
			[in] [out] object& marshal(struct) identifiers
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::GetSupportedComps

	.method public hidebysig newslot abstract virtual 
		instance void GetNumbCompounds (
			[in] [out] int32& nComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::GetNumbCompounds

	.method public hidebysig newslot abstract virtual 
		instance void GetCompoundInfo (
			[in] int32 iComp,
			[in] object marshal(idispatch) pCompoundi,
			[in] [out] int32& nProps,
			[in] [out] object& marshal(struct) propnames
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::GetCompoundInfo

	.method public hidebysig newslot abstract virtual 
		instance void AddLastCompound (
			[in] object marshal(idispatch) pCompoundi
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::AddLastCompound

	.method public hidebysig newslot abstract virtual 
		instance void RemoveCompoundi (
			[in] int32 iComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::RemoveCompoundi

	.method public hidebysig newslot abstract virtual 
		instance void ExchangeCompounds (
			[in] int32 iComp,
			[in] int32 jComp
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::ExchangeCompounds

	.method public hidebysig newslot abstract virtual 
		instance void PhaseOrder (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] object marshal(idispatch) pThermoProperty
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 12 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::PhaseOrder

	.method public hidebysig newslot abstract virtual 
		instance void OnView (
			[in] [out] string& marshal(bstr) ViewName,
			[in] [out] bool& OpenView
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 13 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::OnView

	.method public hidebysig newslot abstract virtual 
		instance void PkgSave (
			[in] [out] string& marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 14 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::PkgSave

	.method public hidebysig newslot abstract virtual 
		instance void PkgRecall (
			[in] string marshal(bstr) saveinfo,
			[in] [out] bool& BaseChanged
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 15 00 00 00 00 00
		)
	} // end of method IExtendedPropPackage::PkgRecall

} // end of class AspenTech.Interop.ThPropManager.IExtendedPropPackage

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IExtendedFlash
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 39 38 32 46 46 46 30 2d 32 41 43 44
		2d 31 31 44 35 2d 42 46 39 36 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetFlashName (
			[in] [out] string& marshal(bstr) FlashName,
			[in] [out] string& marshal(bstr) description
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IExtendedFlash::GetFlashName

	.method public hidebysig newslot abstract virtual 
		instance void FlashFileNeeded (
			[in] [out] int32& nfiles,
			[in] [out] string& marshal(bstr) description
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IExtendedFlash::FlashFileNeeded

	.method public hidebysig newslot abstract virtual 
		instance void SetupFlash (
			[in] int32 nfiles,
			[in] object marshal(struct) filenames,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IExtendedFlash::SetupFlash

	.method public hidebysig newslot abstract virtual 
		instance void IsFlashSetup (
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IExtendedFlash::IsFlashSetup

	.method public hidebysig newslot abstract virtual 
		instance void SupportedFlashTypes (
			[in] [out] int32& nFlashes,
			[in] [out] object& marshal(struct) types
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IExtendedFlash::SupportedFlashTypes

	.method public hidebysig newslot abstract virtual 
		instance void CanHandleFlashType (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum 'type',
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IExtendedFlash::CanHandleFlashType

	.method public hidebysig newslot abstract virtual 
		instance void InitializePropertyID (
			[in] object marshal(idispatch) lpPropertyRegistry
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method IExtendedFlash::InitializePropertyID

	.method public hidebysig newslot abstract virtual 
		instance void IsFlashControlUsed (
			[in] [out] bool& IsUsed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 00 00 00 00
		)
	} // end of method IExtendedFlash::IsFlashControlUsed

	.method public hidebysig newslot abstract virtual 
		instance void Execute (
			[in] valuetype AspenTech.Interop.ThPropManager.tagFlashTypeEnum 'type',
			[in] object marshal(idispatch) pFlashControl,
			[in] object marshal(idispatch) pPhaseCollection,
			[in] object marshal(idispatch) pThermoProperty,
			[in] object marshal(idispatch) errorLog,
			[in] object marshal(idispatch) progressMonitor
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 00 00 00 00
		)
	} // end of method IExtendedFlash::Execute

	.method public hidebysig newslot abstract virtual 
		instance void FlashSave (
			[in] [out] string& marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 00 00 00 00
		)
	} // end of method IExtendedFlash::FlashSave

	.method public hidebysig newslot abstract virtual 
		instance void FlashRecall (
			[in] string marshal(bstr) saveinfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 00 00 00 00
		)
	} // end of method IExtendedFlash::FlashRecall

} // end of class AspenTech.Interop.ThPropManager.IExtendedFlash

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IPhaseCalculationMethod
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 30 37 30 30 36 30 39 30 2d 34 33 37 45
		2d 31 31 44 32 2d 42 38 43 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void InitializePropertyIDs (
			[in] object marshal(idispatch) pPropertyRegistry
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IPhaseCalculationMethod::InitializePropertyIDs

	.method public hidebysig newslot abstract virtual 
		instance void Calculate (
			[in] object marshal(idispatch) pPhase,
			[in] [out] object& marshal(idispatch) ppContext,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] object marshal(idispatch) errorLog,
			[in] object marshal(idispatch) progressMonitor
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IPhaseCalculationMethod::Calculate

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetPropertyMethodID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IPhaseCalculationMethod::GetPropertyMethodID

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetPropertyType () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IPhaseCalculationMethod::GetPropertyType

} // end of class AspenTech.Interop.ThPropManager.IPhaseCalculationMethod

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IInteractionParameterInfo
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 42 42 31 37 32 38 30 2d 37 30 33 42
		2d 31 31 44 33 2d 42 32 46 39 2d 30 30 41 30 43
		39 30 30 36 34 39 44 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetIPModelInformation (
			[out] object& marshal(struct) ipModelNames,
			[out] object& marshal(struct) ipNumbModelPanes,
			[out] object& marshal(struct) ipShapes,
			[out] object& marshal(struct) ipTypes,
			[out] int32& numbIPModels
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IInteractionParameterInfo::GetIPModelInformation

} // end of class AspenTech.Interop.ThPropManager.IInteractionParameterInfo

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IMultiPhaseCalculationMethod
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 45 42 45 34 43 38 36 30 2d 31 41 38 32
		2d 31 31 44 36 2d 42 38 36 42 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void InitializePropertyIDs (
			[in] object marshal(idispatch) pPropertyRegistry
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IMultiPhaseCalculationMethod::InitializePropertyIDs

	.method public hidebysig newslot abstract virtual 
		instance void CalculateMultiPhaseProp (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] int32 nPhases,
			[in] int32& PhaseIndexes,
			[in] [out] object& marshal(idispatch) ppContext,
			[in] object marshal(idispatch) pPropertyCallBack,
			[in] object marshal(idispatch) errorLog,
			[in] object marshal(idispatch) progressMonitor
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IMultiPhaseCalculationMethod::CalculateMultiPhaseProp

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetPropertyMethodID () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IMultiPhaseCalculationMethod::GetPropertyMethodID

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetPropertyType () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IMultiPhaseCalculationMethod::GetPropertyType

} // end of class AspenTech.Interop.ThPropManager.IMultiPhaseCalculationMethod

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IThermoProperty1
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 43 36 37 30 31 34 41 30 2d 31 43 42 45
		2d 31 31 44 36 2d 42 38 36 42 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void EvaluateMultiPhaseProperty (
			[in] int32 nPropertyID,
			[in] object marshal(idispatch) pPhaseCollection,
			[in] int32 nPhases,
			[in] int32& PhaseIndexes
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IThermoProperty1::EvaluateMultiPhaseProperty

	.method public hidebysig newslot abstract virtual 
		instance void EvaluateMultiPhasePropertyBy (
			[in] object marshal(idispatch) pPhaseCollection,
			[in] int32 nPhases,
			[in] int32& PhaseIndexes,
			[in] string marshal(bstr) strMethod
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IThermoProperty1::EvaluateMultiPhasePropertyBy

	.method public hidebysig newslot abstract virtual 
		instance object marshal(idispatch) GetDefaultMultiPhasePropObject (
			[in] int32 ePropertyID
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IThermoProperty1::GetDefaultMultiPhasePropObject

} // end of class AspenTech.Interop.ThPropManager.IThermoProperty1

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThPropManager.IDerivativeCalculation
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 38 42 32 46 39 46 30 2d 35 45 31 35
		2d 31 31 44 37 2d 42 38 42 32 2d 30 30 30 33 34
		37 41 37 34 36 36 30 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void TurnOnDerivative (
			[in] uint8 bOn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IDerivativeCalculation::TurnOnDerivative

	.method public hidebysig newslot abstract virtual 
		instance void CanCalculate (
			[in] int32 nPropID,
			[in] [out] int32& status
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IDerivativeCalculation::CanCalculate

	.method public hidebysig newslot abstract virtual 
		instance void CanCalculateDerivative (
			[in] valuetype AspenTech.Interop.ThPropManager.tagPhaseTypeEnum ePhaseType,
			[in] int32 nPropID,
			[in] int32 nDerivativeID,
			[in] [out] uint8& bYes,
			[in] [out] valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum& ePropResultType,
			[in] [out] valuetype AspenTech.Interop.ThPropManager.tagResultTypeEnum& eDevResultType
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IDerivativeCalculation::CanCalculateDerivative

} // end of class AspenTech.Interop.ThPropManager.IDerivativeCalculation

You are not using the latest version of the tool, please update.
Latest version is '11.2.0.10050' (yours is '9.1.0.7988')
