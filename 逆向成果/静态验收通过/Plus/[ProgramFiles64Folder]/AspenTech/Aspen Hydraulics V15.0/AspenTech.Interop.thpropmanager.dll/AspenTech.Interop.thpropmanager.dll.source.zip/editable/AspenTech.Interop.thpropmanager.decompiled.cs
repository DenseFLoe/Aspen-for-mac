using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: ImportedFromTypeLib("ThPropertyManagerLib")]
[assembly: Guid("8915f1f4-5707-11d2-b8d8-00a0c986f9f7")]
[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: AssemblyVersion("1.0.0.0")]
namespace AspenTech.Interop.ThPropManager;

[ComImport]
[Guid("C1CA0895-41E2-11D2-B8CF-00A0C986F9F7")]
[ClassInterface((short)0)]
[TypeLibType(2)]
public class COTHPropertyManagerClass : IThermoPropertyManager, COTHPropertyManager, IHysysCalc, IThermoProperty, IFlashProperties, IPersistStreamInit, ISupportErrorInfo, IThermoPropertyManager1, XMLParserClient, IXMLStore, IThermoPropertyManager2, ICOMExtensionHandler, IPostProgress, IPostError, IPropertyEnumerationRegistry, INotifyChange, ICOTHHysysSecurity, ICOTHCompositionTransfer, IDerivativeHandler
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern void IThermoPropertyManager.SetOverallFlash([In][MarshalAs(UnmanagedType.IDispatch)] object pFlashControl, [In][MarshalAs(UnmanagedType.BStr)] string strFlashFamily);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void IThermoPropertyManager.SetFlash([In] tagFlashTypeEnum eFlashType, [In] int nOrder, [In][MarshalAs(UnmanagedType.IDispatch)] object pFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IThermoPropertyManager.SetPropertyModel([In][MarshalAs(UnmanagedType.BStr)] string strModelName, [In] byte bReset);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IThermoPropertyManager.GetDefaultPropertiesMethods([MarshalAs(UnmanagedType.IDispatch)] out object pMethods);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IThermoPropertyManager.GetPropertyMethod([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void IThermoPropertyManager.RemoveDefaultPropertyMethod([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	extern void IThermoPropertyManager.SetDefaultPropertyMethod([In] int ePropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.BStr)] string strPropertyName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	extern void IThermoPropertyManager.SetPropertyEnumerationRegistry([In][MarshalAs(UnmanagedType.IDispatch)] object pPropEnumReg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.SetCompList([In][MarshalAs(UnmanagedType.BStr)] string DBPath, [In] int nc, [In] IntPtr cmpinfo, [In] byte ReloadIP);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.Execute([In][Out] ref double Tdegk, [In][Out] ref double Pkpa, [In][Out] IntPtr PhaseStr, [In] uint FeedIdx, out uint NumbPhase, [In] uint MaxLiquidPhase, [In][Out] ref int MyFlashType, [In] byte UseGFlash, [In] double lowerTkBound, [In] double upperTkBound);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.GetIPInfo(out int nPanes, out int nComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.GetIPValues([In] int iPane, [MarshalAs(UnmanagedType.BStr)] out string name, out int nComp, [In][MarshalAs(UnmanagedType.Interface)] IRealMatrixDisp pVal, [In][MarshalAs(UnmanagedType.Interface)] IIntegerMatrixDisp p1Val);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.PutIPValues([In] int iPane, [In][MarshalAs(UnmanagedType.BStr)] string name, [In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IRealMatrixDisp pVal, [In][MarshalAs(UnmanagedType.Interface)] IIntegerMatrixDisp p1Val);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.AddComponent([In][MarshalAs(UnmanagedType.BStr)] string DBPath, [In] int posn, [In] ref thcmp_info Comp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.MoveComponent([In] int compToMove, [In] int moveBeforeComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.RemoveComponent([In] int posn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.RemoveLastComponent();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.Viscosity([In] double T, [In] double P, [In] ref double MoleFrac, [In] double MolarDensity, [In] tagHysysPhaseType FluidBaseType, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.ThermalConductivity([In] double T, [In] double P, [In] ref double MoleFrac, [In] double MolarDensity, [In] tagHysysPhaseType FluidBaseType, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.LiquidDensity([In] double T, [In] double P, [In] ref double MoleFrac, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.Enth([In] double temp, [In] double pres, [In] IntPtr Comp, [In] ref int phase, [In] ref double PhFrac, [In] ref double hi, [In] ref double si, [In] ref double cpl, [In] ref double vi);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.SurfaceTension([In] double T, [In] ref double MoleFrac, [In] double press, [In] ref double vapComp, [In] double vapFrac, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.HtDep([In] double T, [In] double P, [In] ref double x, [In] ref double y, [In] ref double ahl, [In] ref double bhl, [In] ref double ahv, [In] ref double bhv);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.GetLnK([In] double T, [In] double P, [In] ref double x, [In] ref double y, [In] ref double zk, [In] ref double tzk, [In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.HtDep1([In] double T, [In] double P, [In] ref double x, [In] ref double x2, [In] ref double ahl, [In] ref double bhl, [In] ref double ahv, [In] ref double bhv);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.GetLnB([In] double T, [In] double P, [In] ref double x, [In] ref double x2, [In] ref double kfact, [In] ref double dkfact, [In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.KValue([In] double temp, [In] double pres, [In] IntPtr Comp, [In] IntPtr kfact, [In] ref int phase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.LnK([In] double T, [In] double P, [In] ref double x, [In] ref double y, [In] ref double zk);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.Order([In] double temp, [In] double pres, [In] IntPtr Comp, [In] ref int phase, [In] ref double PhFrac);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.InitK([In] int cmpno, [In] double T, [In] double P, [In] int phase, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.PkgFug([In] double temp, [In] double pres, [In] IntPtr Comp, [In] IntPtr fug, [In] ref int phase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.Prop3([In] ref double T, [In] ref double P, [In] IntPtr Comp, [In] ref int phase, [In] ref double PhFrac, [In] ref double hi, [In] ref double si, [In] ref double cpi, [In] ref double vi, [In] byte tIsEstimate);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.FlasD([In] ref double T, [In] double P, [In] double lfrc, [In] ref double z, [In] ref double x, [In] ref double y, [In] ref double LnK, [In] ref double dlnkdt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.Save([MarshalAs(UnmanagedType.BStr)] out string data);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IHysysCalc.Recall([In][MarshalAs(UnmanagedType.BStr)] string data);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluateProperty([In] int nPropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluatePhaseProperty([In] int nPropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluatePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluatePhasePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IThermoProperty.GetDefaultPropCalcMethodObjectForFlash([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.GetPropertyCallBackAndContextManager([In] int ePropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [MarshalAs(UnmanagedType.IDispatch)] out object pPropCallBack, [MarshalAs(UnmanagedType.IDispatch)] out object pContxMgr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IFlashProperties.GetFlashControl();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IFlashProperties.GetFlashFamily();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashProperties.CreateFlash([In] tagFlashTypeEnum eFlashType, [In] int nOrder, [MarshalAs(UnmanagedType.IDispatch)] out object ppFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashProperties.CreateFlashByFamily([In][MarshalAs(UnmanagedType.BStr)] string strFlashFamily, [In] tagFlashTypeEnum eFlashType, [In] int nOrder, [MarshalAs(UnmanagedType.IDispatch)] out object ppFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashProperties.EvaluateFlashProperty([In] int ePropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashProperties.EvaluateFlashPhaseProperty([In] int ePropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashProperties.EvaluateFlashPropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strMethod, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashProperties.EvaluateFlashPhasePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.BStr)] string strMethod, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void GetClassID(out Guid pClassID);
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPersistStreamInit.IsDirty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPersistStreamInit.Load([In][MarshalAs(UnmanagedType.Interface)] IStream pstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPersistStreamInit.Save([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] int fClearDirty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPersistStreamInit.GetSizeMax(out _ULARGE_INTEGER pCbSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPersistStreamInit.InitNew();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISupportErrorInfo.InterfaceSupportsErrorInfo([In] ref Guid riid);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoPropertyManager1.SetPropModelCreatePropObjects([In][MarshalAs(UnmanagedType.BStr)] string strModelName, [In] byte bReset);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoPropertyManager1.GetIPModelsInfo(out int numbIPs, [MarshalAs(UnmanagedType.Struct)] out object modelnames, [MarshalAs(UnmanagedType.Struct)] out object modelpanes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoPropertyManager1.SetDefaultPropertyMethodCreateObject([In] int ePropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.BStr)] string strPropertyName, [In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string defdbdir, [In][MarshalAs(UnmanagedType.IDispatch)] object pIPManager);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoPropertyManager1.GetModelType([MarshalAs(UnmanagedType.BStr)] out string modeltype);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoPropertyManager1.SetCompoundCollection([In][MarshalAs(UnmanagedType.IDispatch)] object compcoll);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoPropertyManager1.InitializeFlashes();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.CharacterData([In][MarshalAs(UnmanagedType.BStr)] string userData);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndElement([In][MarshalAs(UnmanagedType.BStr)] string name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Comment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.ProcessElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Error([In][MarshalAs(UnmanagedType.BStr)] string Error);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IXMLStore.StoreAsXML();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoPropertyManager2.SetIPModelsInfo([In][MarshalAs(UnmanagedType.IDispatch)] object pCC);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.GetPkgInfo([In][Out][MarshalAs(UnmanagedType.BStr)] ref string PkgName, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string PkgDescription, [In][Out] ref int nSetupFiles, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string SetupDescription);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.SetupExtendedPropPkg([In] int nfiles, [In][MarshalAs(UnmanagedType.Struct)] object filenames, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.UseExtendedPropPkg([In][Out] ref byte IsUsed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.GetExtendedPropPkg([In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object pPropPkg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.GetPropCalcBase([In][MarshalAs(UnmanagedType.BStr)] string PropName, [In][Out] ref int Base);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.PreSetCompInfo([In][Out] ref byte CanChange, [In][Out] ref int nComp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object HyprotechIDs, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object names);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.GetPkgNumbComps([In][Out] ref int nComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.GetPkgCompInfo([In] int iComp, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompoundi, [In][Out] ref int nProps, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object propnames);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.AddPkgLastComp([In][MarshalAs(UnmanagedType.IDispatch)] object pCompoundi);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.RemovePkgComp([In] int iComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.ExchangePkgComps([In] int iComp, [In] int jComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.PkgPhaseOrder([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pThermoProperty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.PkgOnView([In][Out][MarshalAs(UnmanagedType.BStr)] ref string ViewName, [In][Out] ref bool OpenView);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.PkgSave([In][Out][MarshalAs(UnmanagedType.BStr)] ref string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.PkgRecall([In][MarshalAs(UnmanagedType.BStr)] string saveinfo, [In][Out] ref bool BaseChanged);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.GetFlashInfo([In][Out][MarshalAs(UnmanagedType.BStr)] ref string FlashName, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string FlashDescription, [In][Out] ref int nSetupFiles, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string SetupDescription);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.SetupExtendedFlash([In] int nfiles, [In][MarshalAs(UnmanagedType.Struct)] object filenames, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.FlashTypesSupported([In][Out] ref int nFlashes, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object types);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.CanHandleFlashType([In] tagFlashTypeEnum type, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.UseExtendedFlash([In][Out] ref byte IsUsed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.GetExtendedFlash([In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object pExtFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.UseFlashControl([In][Out] ref byte IsUsed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.FlashSave([In][Out][MarshalAs(UnmanagedType.BStr)] ref string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.FlashRecall([In][MarshalAs(UnmanagedType.BStr)] string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.CalculateTwoPhaseProperty([In] int propertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In] int iphase, [In] int jphase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.IsPkgSetup([In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOMExtensionHandler.IsFlashSetup([In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPostProgress.PostProgress([In] int ProgressCode, [In][MarshalAs(UnmanagedType.BStr)] string ProgressMessage);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPostProgress.SetProgressCallback([MarshalAs(UnmanagedType.Interface)] IThermoProgress pProgressCallback);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPostProgress.RemoveProgressCallback();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPostError.PostError([In] int ErrorCode, [In][MarshalAs(UnmanagedType.BStr)] string ErrorMessage, [In] bool ToUserDialog, [In] bool IsImportant);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern bool IPostError.PostWarning([In] int ErrorCode, [In][MarshalAs(UnmanagedType.BStr)] string ErrorMessage, [In] bool ToUserDialog, [In] bool IsImportant);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPostError.SetErrorCallback([MarshalAs(UnmanagedType.Interface)] IThermoError pErrorCallback);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IPostError.RemoveErrorCallback();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IPropertyEnumerationRegistry.GetPropertyIDByName([In][MarshalAs(UnmanagedType.BStr)] string strName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IPropertyEnumerationRegistry.GetPropertyNameByID([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IPropertyEnumerationRegistry.AddPropertyByName([In][MarshalAs(UnmanagedType.BStr)] string strName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void INotifyChange.UseNotifyChange([In] byte Use);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void INotifyChange.HasModified([In] NotifyChange whatchanged);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOTHHysysSecurity.PutApplicationInterface([In][MarshalAs(UnmanagedType.IUnknown)] object pIUnknown);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOTHHysysSecurity.GetApplicationInterface([In][Out][MarshalAs(UnmanagedType.IUnknown)] ref object pIUnknown);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOTHCompositionTransfer.GetCompositionSource([In][Out][MarshalAs(UnmanagedType.BStr)] ref string sSource);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ICOTHCompositionTransfer.GetComposition([In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeHandler.TurnOnDerivative([In] byte bOn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeHandler.SetDerivativeType([In] tagDerivativeTypeEnum eType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IDerivativeHandler.CanCalculateDerivative([In] int nPropComID, [In] tagPhaseTypeEnum ePhaseType, [In] int nPropID, [In] int nDerivativeID, [In][Out] ref byte bYes, [In][Out] ref tagResultTypeEnum ePropResultType, [In][Out] ref tagResultTypeEnum eDevResultType);
}
[ComImport]
[CoClass(typeof(COTHPropertyManagerClass))]
[Guid("C1CA0894-41E2-11D2-B8CF-00A0C986F9F7")]
public interface COTHPropertyManager : IThermoPropertyManager
{
}
[ComImport]
[Guid("C1CA0894-41E2-11D2-B8CF-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IThermoPropertyManager
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetOverallFlash([In][MarshalAs(UnmanagedType.IDispatch)] object pFlashControl, [In][MarshalAs(UnmanagedType.BStr)] string strFlashFamily);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetFlash([In] tagFlashTypeEnum eFlashType, [In] int nOrder, [In][MarshalAs(UnmanagedType.IDispatch)] object pFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void SetPropertyModel([In][MarshalAs(UnmanagedType.BStr)] string strModelName, [In] byte bReset);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void GetDefaultPropertiesMethods([MarshalAs(UnmanagedType.IDispatch)] out object pMethods);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetPropertyMethod([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void RemoveDefaultPropertyMethod([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void SetDefaultPropertyMethod([In] int ePropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.BStr)] string strPropertyName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void SetPropertyEnumerationRegistry([In][MarshalAs(UnmanagedType.IDispatch)] object pPropEnumReg);
}
public enum tagFlashTypeEnum
{
	xftUnknownFlash,
	xftPTFlash,
	xftPHFlash,
	xftPSFlash,
	xftPVFlash,
	xftTHFlash,
	xftTSFlash,
	xftTVFlash,
	xftHVFlash,
	xftZPFlash,
	xftZGorFlash,
	xftHomotopyPTFlash,
	xftHomotopyPVFlash,
	xftLastFlash
}
[ComImport]
[ComConversionLoss]
[Guid("EB2B9580-D129-11D4-BF8E-00A0C9B465F6")]
[TypeLibType(4096)]
public interface IHysysCalc
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetCompList([In][MarshalAs(UnmanagedType.BStr)] string DBPath, [In] int nc, [In] IntPtr cmpinfo, [In] byte ReloadIP);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Execute([In][Out] ref double Tdegk, [In][Out] ref double Pkpa, [In][Out] IntPtr PhaseStr, [In] uint FeedIdx, out uint NumbPhase, [In] uint MaxLiquidPhase, [In][Out] ref int MyFlashType, [In] byte UseGFlash, [In] double lowerTkBound, [In] double upperTkBound);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetIPInfo(out int nPanes, out int nComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetIPValues([In] int iPane, [MarshalAs(UnmanagedType.BStr)] out string name, out int nComp, [In][MarshalAs(UnmanagedType.Interface)] IRealMatrixDisp pVal, [In][MarshalAs(UnmanagedType.Interface)] IIntegerMatrixDisp p1Val);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void PutIPValues([In] int iPane, [In][MarshalAs(UnmanagedType.BStr)] string name, [In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IRealMatrixDisp pVal, [In][MarshalAs(UnmanagedType.Interface)] IIntegerMatrixDisp p1Val);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void AddComponent([In][MarshalAs(UnmanagedType.BStr)] string DBPath, [In] int posn, [In] ref thcmp_info Comp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void MoveComponent([In] int compToMove, [In] int moveBeforeComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoveComponent([In] int posn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoveLastComponent();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Viscosity([In] double T, [In] double P, [In] ref double MoleFrac, [In] double MolarDensity, [In] tagHysysPhaseType FluidBaseType, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ThermalConductivity([In] double T, [In] double P, [In] ref double MoleFrac, [In] double MolarDensity, [In] tagHysysPhaseType FluidBaseType, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void LiquidDensity([In] double T, [In] double P, [In] ref double MoleFrac, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Enth([In] double temp, [In] double pres, [In] IntPtr Comp, [In] ref int phase, [In] ref double PhFrac, [In] ref double hi, [In] ref double si, [In] ref double cpl, [In] ref double vi);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SurfaceTension([In] double T, [In] ref double MoleFrac, [In] double press, [In] ref double vapComp, [In] double vapFrac, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void HtDep([In] double T, [In] double P, [In] ref double x, [In] ref double y, [In] ref double ahl, [In] ref double bhl, [In] ref double ahv, [In] ref double bhv);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetLnK([In] double T, [In] double P, [In] ref double x, [In] ref double y, [In] ref double zk, [In] ref double tzk, [In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void HtDep1([In] double T, [In] double P, [In] ref double x, [In] ref double x2, [In] ref double ahl, [In] ref double bhl, [In] ref double ahv, [In] ref double bhv);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetLnB([In] double T, [In] double P, [In] ref double x, [In] ref double x2, [In] ref double kfact, [In] ref double dkfact, [In] int flag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void KValue([In] double temp, [In] double pres, [In] IntPtr Comp, [In] IntPtr kfact, [In] ref int phase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void LnK([In] double T, [In] double P, [In] ref double x, [In] ref double y, [In] ref double zk);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Order([In] double temp, [In] double pres, [In] IntPtr Comp, [In] ref int phase, [In] ref double PhFrac);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InitK([In] int cmpno, [In] double T, [In] double P, [In] int phase, out double dVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void PkgFug([In] double temp, [In] double pres, [In] IntPtr Comp, [In] IntPtr fug, [In] ref int phase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Prop3([In] ref double T, [In] ref double P, [In] IntPtr Comp, [In] ref int phase, [In] ref double PhFrac, [In] ref double hi, [In] ref double si, [In] ref double cpi, [In] ref double vi, [In] byte tIsEstimate);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void FlasD([In] ref double T, [In] double P, [In] double lfrc, [In] ref double z, [In] ref double x, [In] ref double y, [In] ref double LnK, [In] ref double dlnkdt);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Save([MarshalAs(UnmanagedType.BStr)] out string data);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Recall([In][MarshalAs(UnmanagedType.BStr)] string data);
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct thcmp_info
{
	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 13, ArraySubType = (UnmanagedType)80)]
	public sbyte[] cpnam;

	public int numb;

	public thcmp_type type;

	public double tc;

	public double pc;

	public double vc;

	public double w;

	public double molw;

	public double boil;

	public double liqden;

	public double htform;

	public double Gibbs_A;

	public double htcomb;

	public double wsrk;

	public double vchar;

	public double theta_A;

	public double theta_B;

	public double dipole;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 7, ArraySubType = (UnmanagedType)80)]
	public double[] idlh;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = (UnmanagedType)80)]
	public double[] antoine;

	public double ant_tmax;

	public double ant_tmin;

	public double cavett;

	public double Gibbs_B;

	public double Gibbs_C;

	public double rg;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 14, ArraySubType = (UnmanagedType)80)]
	public sbyte[] form;

	[MarshalAs(UnmanagedType.ByValArray, SizeConst = 10, ArraySubType = (UnmanagedType)80)]
	public thcmp_unifact[] unifac;

	public double sqrttc;

	public double Gibbs_D;

	public double Gibbs_E;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct thcmp_type
{
	public uint hc;

	public uint solid;

	public uint misc;

	public uint amine;

	public uint alcohol;

	public uint ketone;

	public uint aldehyde;

	public uint ester;

	public uint carbacid;

	public uint halogen;

	public uint nitrile;

	public uint phenol;

	public uint ether;

	public uint henry;

	public uint blank2;

	public uint blank3;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct thcmp_unifact
{
	public uint count;

	public uint group;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
[ComConversionLoss]
public struct SPhaseStructure
{
	public tagHysysPhaseType PhType;

	public double PhFrac;

	[ComConversionLoss]
	public IntPtr Comp;

	public double Sj;

	public double Hj;

	public double Cpj;

	public double MolarVol;
}
public enum tagHysysPhaseType
{
	HysysVapourPhase,
	HysysLiquidPhase,
	HysysAqueousPhase,
	HysysCombinedLiquidPhase,
	HysysSolidPhase,
	HysysCombinedPhase,
	HysysPolymerPhase,
	HysysHeaviestLiqPhase,
	HysysUnknownPhase
}
[ComImport]
[Guid("5E58EFB6-3C34-11D2-B8CA-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IRealMatrixDisp
{
	[DispId(1)]
	int NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	int NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void set_IJthValue([In] int nRow, [In] int nColumn, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthRow([In] int nRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void set_IthRow([In] int nRow, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthColumn([In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void set_IthColumn([In] int nColumn, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Reset();
}
[ComImport]
[Guid("6E264D70-F7B0-11D4-BF8F-00A0C9B465F6")]
[TypeLibType(4160)]
public interface IIntegerMatrixDisp
{
	[DispId(1)]
	int NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	int NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	int get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void set_IJthValue([In] int nRow, [In] int nColumn, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthRow([In] int nRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void set_IthRow([In] int nRow, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthColumn([In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void set_IthColumn([In] int nColumn, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Reset();
}
[ComImport]
[Guid("1CFDD5B0-42AC-11D2-B8CF-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IThermoProperty
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void EvaluateProperty([In] int nPropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void EvaluatePhaseProperty([In] int nPropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void EvaluatePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void EvaluatePhasePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetDefaultPropCalcMethodObjectForFlash([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void GetPropertyCallBackAndContextManager([In] int ePropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [MarshalAs(UnmanagedType.IDispatch)] out object pPropCallBack, [MarshalAs(UnmanagedType.IDispatch)] out object pContxMgr);
}
[ComImport]
[Guid("EF616F40-6839-11D2-B8E0-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IFlashProperties
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetFlashControl();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetFlashFamily();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void CreateFlash([In] tagFlashTypeEnum eFlashType, [In] int nOrder, [MarshalAs(UnmanagedType.IDispatch)] out object ppFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void CreateFlashByFamily([In][MarshalAs(UnmanagedType.BStr)] string strFlashFamily, [In] tagFlashTypeEnum eFlashType, [In] int nOrder, [MarshalAs(UnmanagedType.IDispatch)] out object ppFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void EvaluateFlashProperty([In] int ePropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void EvaluateFlashPhaseProperty([In] int ePropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void EvaluateFlashPropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strMethod, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void EvaluateFlashPhasePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.BStr)] string strMethod, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext);
}
[ComImport]
[InterfaceType(1)]
[Guid("7FD52380-4E07-101B-AE2D-08002B2EC713")]
public interface IPersistStreamInit : IPersist
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void GetClassID(out Guid pClassID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void IsDirty();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Load([In][MarshalAs(UnmanagedType.Interface)] IStream pstm);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Save([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] int fClearDirty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetSizeMax(out _ULARGE_INTEGER pCbSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InitNew();
}
[ComImport]
[InterfaceType(1)]
[Guid("0000010C-0000-0000-C000-000000000046")]
public interface IPersist
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void GetClassID(out Guid pClassID);
}
[ComImport]
[Guid("0000000C-0000-0000-C000-000000000046")]
[InterfaceType(1)]
public interface IStream : ISequentialStream
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void RemoteRead(out byte pv, [In] uint cb, out uint pcbRead);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	new void RemoteWrite([In] ref byte pv, [In] uint cb, out uint pcbWritten);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteSeek([In] _LARGE_INTEGER dlibMove, [In] uint dwOrigin, out _ULARGE_INTEGER plibNewPosition);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void SetSize([In] _ULARGE_INTEGER libNewSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteCopyTo([In][MarshalAs(UnmanagedType.Interface)] IStream pstm, [In] _ULARGE_INTEGER cb, out _ULARGE_INTEGER pcbRead, out _ULARGE_INTEGER pcbWritten);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Commit([In] uint grfCommitFlags);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Revert();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void LockRegion([In] _ULARGE_INTEGER libOffset, [In] _ULARGE_INTEGER cb, [In] uint dwLockType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void UnlockRegion([In] _ULARGE_INTEGER libOffset, [In] _ULARGE_INTEGER cb, [In] uint dwLockType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Stat(out tagSTATSTG pstatstg, [In] uint grfStatFlag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Clone([MarshalAs(UnmanagedType.Interface)] out IStream ppstm);
}
[ComImport]
[InterfaceType(1)]
[Guid("0C733A30-2A1C-11CE-ADE5-00AA0044773D")]
public interface ISequentialStream
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteRead(out byte pv, [In] uint cb, out uint pcbRead);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void RemoteWrite([In] ref byte pv, [In] uint cb, out uint pcbWritten);
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct _LARGE_INTEGER
{
	public long QuadPart;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct _ULARGE_INTEGER
{
	public ulong QuadPart;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct tagSTATSTG
{
	[MarshalAs(UnmanagedType.LPWStr)]
	public string pwcsName;

	public uint type;

	public _ULARGE_INTEGER cbSize;

	public _FILETIME mtime;

	public _FILETIME ctime;

	public _FILETIME atime;

	public uint grfMode;

	public uint grfLocksSupported;

	public Guid clsid;

	public uint grfStateBits;

	public uint reserved;
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct _FILETIME
{
	public uint dwLowDateTime;

	public uint dwHighDateTime;
}
[ComImport]
[InterfaceType(1)]
[Guid("DF0B3D60-548F-101B-8E65-08002B2BD119")]
public interface ISupportErrorInfo
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InterfaceSupportsErrorInfo([In] ref Guid riid);
}
[ComImport]
[Guid("CAC2D331-D29A-11D3-A60F-00A0C9DF422B")]
[TypeLibType(4160)]
public interface IThermoPropertyManager1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetPropModelCreatePropObjects([In][MarshalAs(UnmanagedType.BStr)] string strModelName, [In] byte bReset);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetIPModelsInfo(out int numbIPs, [MarshalAs(UnmanagedType.Struct)] out object modelnames, [MarshalAs(UnmanagedType.Struct)] out object modelpanes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void SetDefaultPropertyMethodCreateObject([In] int ePropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.BStr)] string strPropertyName, [In][MarshalAs(UnmanagedType.IDispatch)] object pCC, [In][MarshalAs(UnmanagedType.BStr)] string defdbdir, [In][MarshalAs(UnmanagedType.IDispatch)] object pIPManager);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void GetModelType([MarshalAs(UnmanagedType.BStr)] out string modeltype);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void SetCompoundCollection([In][MarshalAs(UnmanagedType.IDispatch)] object compcoll);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void InitializeFlashes();
}
[ComImport]
[Guid("55F78994-66E8-11D3-8EB3-00A0C9DF3D2C")]
[TypeLibType(4160)]
public interface XMLParserClient
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void CharacterData([In][MarshalAs(UnmanagedType.BStr)] string userData);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void StartElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void EndElement([In][MarshalAs(UnmanagedType.BStr)] string name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void Comment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void ProcessElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void Error([In][MarshalAs(UnmanagedType.BStr)] string Error);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void StartDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void EndDocument();
}
[ComImport]
[Guid("577EDBB0-4F5B-11D3-8EAE-00A0C9DF3D2C")]
[TypeLibType(4160)]
public interface TaggedAttributes
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void Add([In][MarshalAs(UnmanagedType.BStr)] string tag, [In][MarshalAs(UnmanagedType.BStr)] string value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void AddMultiple([In][MarshalAs(UnmanagedType.Struct)] object tags, [In][MarshalAs(UnmanagedType.Struct)] object values);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Find([In][MarshalAs(UnmanagedType.BStr)] string tag, [MarshalAs(UnmanagedType.BStr)] out string retValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void GetByIndex([In] int index, [MarshalAs(UnmanagedType.BStr)] out string retTag, [MarshalAs(UnmanagedType.BStr)] out string retValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void GetMultiple([MarshalAs(UnmanagedType.Struct)] out object retTags, [MarshalAs(UnmanagedType.Struct)] out object retValues);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void Size(out int Size);
}
[ComImport]
[Guid("F6FCFD40-F91B-11D3-BF46-00A0C9B465F6")]
[TypeLibType(4160)]
public interface IXMLStore
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string StoreAsXML();
}
[ComImport]
[Guid("9FBEFF91-0C3C-11D4-A633-00A0C9DF422B")]
[TypeLibType(4160)]
public interface IThermoPropertyManager2
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetIPModelsInfo([In][MarshalAs(UnmanagedType.IDispatch)] object pCC);
}
[ComImport]
[Guid("BB550370-3298-11D5-BF99-00A0C9B465F6")]
[TypeLibType(4160)]
public interface ICOMExtensionHandler
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetPkgInfo([In][Out][MarshalAs(UnmanagedType.BStr)] ref string PkgName, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string PkgDescription, [In][Out] ref int nSetupFiles, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string SetupDescription);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetupExtendedPropPkg([In] int nfiles, [In][MarshalAs(UnmanagedType.Struct)] object filenames, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void UseExtendedPropPkg([In][Out] ref byte IsUsed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void GetExtendedPropPkg([In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object pPropPkg);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void GetPropCalcBase([In][MarshalAs(UnmanagedType.BStr)] string PropName, [In][Out] ref int Base);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void PreSetCompInfo([In][Out] ref byte CanChange, [In][Out] ref int nComp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object HyprotechIDs, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object names);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void GetPkgNumbComps([In][Out] ref int nComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void GetPkgCompInfo([In] int iComp, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompoundi, [In][Out] ref int nProps, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object propnames);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void AddPkgLastComp([In][MarshalAs(UnmanagedType.IDispatch)] object pCompoundi);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void RemovePkgComp([In] int iComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	void ExchangePkgComps([In] int iComp, [In] int jComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void PkgPhaseOrder([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pThermoProperty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	void PkgOnView([In][Out][MarshalAs(UnmanagedType.BStr)] ref string ViewName, [In][Out] ref bool OpenView);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	void PkgSave([In][Out][MarshalAs(UnmanagedType.BStr)] ref string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	void PkgRecall([In][MarshalAs(UnmanagedType.BStr)] string saveinfo, [In][Out] ref bool BaseChanged);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	void GetFlashInfo([In][Out][MarshalAs(UnmanagedType.BStr)] ref string FlashName, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string FlashDescription, [In][Out] ref int nSetupFiles, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string SetupDescription);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(17)]
	void SetupExtendedFlash([In] int nfiles, [In][MarshalAs(UnmanagedType.Struct)] object filenames, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(18)]
	void FlashTypesSupported([In][Out] ref int nFlashes, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object types);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(19)]
	void CanHandleFlashType([In] tagFlashTypeEnum type, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(20)]
	void UseExtendedFlash([In][Out] ref byte IsUsed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(21)]
	void GetExtendedFlash([In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object pExtFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(22)]
	void UseFlashControl([In][Out] ref byte IsUsed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(23)]
	void FlashSave([In][Out][MarshalAs(UnmanagedType.BStr)] ref string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(24)]
	void FlashRecall([In][MarshalAs(UnmanagedType.BStr)] string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(25)]
	void CalculateTwoPhaseProperty([In] int propertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In] int iphase, [In] int jphase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(26)]
	void IsPkgSetup([In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(27)]
	void IsFlashSetup([In][Out] ref int status);
}
[ComImport]
[Guid("53BD88C1-5514-11D5-A614-00A0C9DF4EE2")]
[TypeLibType(4160)]
public interface IPostProgress
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void PostProgress([In] int ProgressCode, [In][MarshalAs(UnmanagedType.BStr)] string ProgressMessage);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetProgressCallback([MarshalAs(UnmanagedType.Interface)] IThermoProgress pProgressCallback);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void RemoveProgressCallback();
}
[ComImport]
[InterfaceType(1)]
[Guid("53BD88C0-5514-11D5-A614-00A0C9DF4EE2")]
[TypeLibType(64)]
public interface IThermoProgress
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Progress([In] int ProgressCode, [In][MarshalAs(UnmanagedType.BStr)] string ProgressMessage);
}
[ComImport]
[TypeLibType(4160)]
[Guid("C42FF080-9B86-11D3-BFE5-0090271CEA01")]
public interface IPostError
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void PostError([In] int ErrorCode, [In][MarshalAs(UnmanagedType.BStr)] string ErrorMessage, [In] bool ToUserDialog, [In] bool IsImportant);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	bool PostWarning([In] int ErrorCode, [In][MarshalAs(UnmanagedType.BStr)] string ErrorMessage, [In] bool ToUserDialog, [In] bool IsImportant);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void SetErrorCallback([MarshalAs(UnmanagedType.Interface)] IThermoError pErrorCallback);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void RemoveErrorCallback();
}
[ComImport]
[Guid("7ECD08D0-8AF7-11D3-BFE2-0090271CEA01")]
[TypeLibType(64)]
[InterfaceType(1)]
public interface IThermoError
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Error([In] int ErrorCode, [In][MarshalAs(UnmanagedType.BStr)] string ErrorMessage, [In] bool ToUserDialog, [In] bool IsImportant);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	bool Warning([In] int ErrorCode, [In][MarshalAs(UnmanagedType.BStr)] string ErrorMessage, [In] bool ToUserDialog, [In] bool IsImportant);
}
[ComImport]
[TypeLibType(4160)]
[Guid("6AF1D923-37AA-11D2-B8C6-00A0C986F9F7")]
public interface IPropertyEnumerationRegistry
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	int GetPropertyIDByName([In][MarshalAs(UnmanagedType.BStr)] string strName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetPropertyNameByID([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	int AddPropertyByName([In][MarshalAs(UnmanagedType.BStr)] string strName);
}
[ComImport]
[Guid("A7866400-C0E7-11D6-B896-000347A74660")]
[TypeLibType(4160)]
public interface INotifyChange
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void UseNotifyChange([In] byte Use);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void HasModified([In] NotifyChange whatchanged);
}
public enum NotifyChange
{
	NothingChanged,
	CompColChanged,
	IPChanged,
	CompoundsChanged
}
[ComImport]
[TypeLibType(4160)]
[Guid("C79B8506-6441-4423-A933-B74D216462B2")]
public interface ICOTHHysysSecurity
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void PutApplicationInterface([In][MarshalAs(UnmanagedType.IUnknown)] object pIUnknown);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetApplicationInterface([In][Out][MarshalAs(UnmanagedType.IUnknown)] ref object pIUnknown);
}
[ComImport]
[TypeLibType(4160)]
[Guid("6E84BED4-D6EA-4601-8F45-B4A2A00CAD10")]
public interface ICOTHCompositionTransfer
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetCompositionSource([In][Out][MarshalAs(UnmanagedType.BStr)] ref string sSource);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void GetComposition([In] int nComp, [In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pComp);
}
[ComImport]
[Guid("5E58EFB4-3C34-11D2-B8CA-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IRealArrayDisp
{
	[DispId(1)]
	int Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	double get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void set_IthValue([In] int i, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void Copy([In][MarshalAs(UnmanagedType.Interface)] IRealArrayDisp pArray);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	double get_values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void set_values([In] int nSize, [In] ref double pVal);
}
[ComImport]
[Guid("D02F24F0-5E20-11D7-B8B2-000347A74660")]
[TypeLibType(4160)]
public interface IDerivativeHandler
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void TurnOnDerivative([In] byte bOn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetDerivativeType([In] tagDerivativeTypeEnum eType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void CanCalculateDerivative([In] int nPropComID, [In] tagPhaseTypeEnum ePhaseType, [In] int nPropID, [In] int nDerivativeID, [In][Out] ref byte bYes, [In][Out] ref tagResultTypeEnum ePropResultType, [In][Out] ref tagResultTypeEnum eDevResultType);
}
public enum tagDerivativeTypeEnum
{
	NoDerivativeType,
	AnalyticalOnly,
	NumericalOnly,
	NumericalBackup
}
public enum tagPhaseTypeEnum
{
	xptUnknownPhase,
	xptOverall,
	xptFeed,
	xptVapour,
	xptLiquid,
	xptAqueous,
	xptSolid,
	xptInsolubleSolid,
	xptDensePhase,
	xptHydrate,
	xptWax,
	xptUserType,
	xptMultiPhase,
	xptLastPhaseType
}
public enum tagResultTypeEnum
{
	NoResultType,
	RealPoint,
	RealArray,
	RealMatrix,
	IntPoint,
	IntArray,
	IntMatrix,
	VariantType
}
[ComImport]
[TypeLibType(2)]
[ClassInterface((short)0)]
[Guid("BA9D66C0-51A7-11D2-B8D5-00A0C986F9F7")]
public class COTHInteractionParametersClass : IExtractInteractionParameters, COTHInteractionParameters, ISetupInteractionParameters, IInteractionParametersInitFromHypDB, IInteractionParametersInitFromHYSYS, IInteractionParametersManipulate, ISetupInteractionParameters1, IExtractInteractionParameters1, IIPLoadingInfo, IIPLoad, XMLParserClient, IXMLStore, ISubIP
{
	[DispId(1)]
	public virtual extern string ModelName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(2)]
	public virtual extern int NumberOfPanes
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
	}

	[DispId(3)]
	public virtual extern int Dimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(3)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern double IExtractInteractionParameters.get_value([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IExtractInteractionParameters.get_values([In] int nPaneIdx, [In] int nCompound1Idx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IExtractInteractionParameters.get_PaneValues([In] int nCompound1Idx, [In] int nCompound2Idx);

	extern string ISetupInteractionParameters.ModelName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	extern int ISetupInteractionParameters.NumberOfPanes
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int ISetupInteractionParameters.Dimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISetupInteractionParameters.set_value([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, [In] double value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISetupInteractionParameters.set_values([In] int nPaneIdx, [In] int nCompound1Idx, [In] [MarshalAs(UnmanagedType.IDispatch)] object value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISetupInteractionParameters.set_PaneValues([In] int nCompound1Idx, [In] int nCompound2Idx, [In] [MarshalAs(UnmanagedType.IDispatch)] object value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IInteractionParametersInitFromHypDB.Init([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In][MarshalAs(UnmanagedType.BStr)] string strModel, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IInteractionParametersInitFromHYSYS.Init([In][MarshalAs(UnmanagedType.BStr)] string strModel, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IInteractionParametersManipulate.LoadLastCompoundIPs([In][MarshalAs(UnmanagedType.BStr)] string databasedir, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IInteractionParametersManipulate.MoveIPs([In] int compToMove, [In] int moveBeforeComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IInteractionParametersManipulate.RemoveLastIPs(int nPaneSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IInteractionParametersManipulate.LoadIJPairIPsFromHypDB([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList, [In] int comp1, [In] int comp2);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IInteractionParametersManipulate.ReloadAllIPsFromHypDB([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISetupInteractionParameters1.PutSpecifiedValue([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, [In] double dValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISetupInteractionParameters1.PutSpecMatrixValue([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, [In] int iValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IExtractInteractionParameters1.GetSpecMatrixValue([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, out int pbValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIPLoadingInfo.SetDefaultDatabaseDir([In][MarshalAs(UnmanagedType.BStr)] string defaultatabasedir);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIPLoadingInfo.SetLoader([In][MarshalAs(UnmanagedType.IDispatch)] object ploader);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIPLoad.IPLoad([In][MarshalAs(UnmanagedType.IDispatch)] object pCC);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.CharacterData([In][MarshalAs(UnmanagedType.BStr)] string userData);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndElement([In][MarshalAs(UnmanagedType.BStr)] string name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Comment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.ProcessElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.Error([In][MarshalAs(UnmanagedType.BStr)] string Error);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.StartDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void XMLParserClient.EndDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IXMLStore.StoreAsXML();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISubIP.SetParent([In][MarshalAs(UnmanagedType.IDispatch)] object parent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void ISubIP.SetCompMapping([In] int nComp, [In] ref int mapping);
}
[ComImport]
[Guid("F915CB80-37A9-11D2-B8C6-00A0C986F9F7")]
[CoClass(typeof(COTHInteractionParametersClass))]
public interface COTHInteractionParameters : IExtractInteractionParameters
{
}
[ComImport]
[Guid("F915CB80-37A9-11D2-B8C6-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IExtractInteractionParameters
{
	[DispId(1)]
	string ModelName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
	}

	[DispId(2)]
	int NumberOfPanes
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
	}

	[DispId(3)]
	int Dimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(3)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	double get_value([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_values([In] int nPaneIdx, [In] int nCompound1Idx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_PaneValues([In] int nCompound1Idx, [In] int nCompound2Idx);
}
[ComImport]
[TypeLibType(4160)]
[Guid("6AF1D91E-37AA-11D2-B8C6-00A0C986F9F7")]
public interface ISetupInteractionParameters
{
	[DispId(1)]
	string ModelName
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(2)]
	int NumberOfPanes
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[DispId(3)]
	int Dimension
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(3)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void set_value([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, [In] double value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void set_values([In] int nPaneIdx, [In] int nCompound1Idx, [In] [MarshalAs(UnmanagedType.IDispatch)] object value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void set_PaneValues([In] int nCompound1Idx, [In] int nCompound2Idx, [In] [MarshalAs(UnmanagedType.IDispatch)] object value);
}
[ComImport]
[Guid("D8D72B10-5C7D-11D2-B8DF-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IInteractionParametersInitFromHypDB
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Init([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In][MarshalAs(UnmanagedType.BStr)] string strModel, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);
}
[ComImport]
[TypeLibType(4160)]
[Guid("5DF6F6A0-A5C0-11D2-9D3D-00104B222416")]
public interface IInteractionParametersInitFromHYSYS
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Init([In][MarshalAs(UnmanagedType.BStr)] string strModel, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);
}
[ComImport]
[TypeLibType(4160)]
[Guid("0415FF11-6C83-11D3-A5D3-00A0C9DF422B")]
public interface IInteractionParametersManipulate
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void LoadLastCompoundIPs([In][MarshalAs(UnmanagedType.BStr)] string databasedir, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void MoveIPs([In] int compToMove, [In] int moveBeforeComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void RemoveLastIPs(int nPaneSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void LoadIJPairIPsFromHypDB([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList, [In] int comp1, [In] int comp2);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void ReloadAllIPsFromHypDB([In][MarshalAs(UnmanagedType.BStr)] string strPath, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompList);
}
[ComImport]
[Guid("6F96F351-750A-11D3-A5D7-00A0C9DF422B")]
[TypeLibType(4160)]
public interface ISetupInteractionParameters1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void PutSpecifiedValue([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, [In] double dValue);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void PutSpecMatrixValue([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, [In] int iValue);
}
[ComImport]
[TypeLibType(4160)]
[Guid("6F96F353-750A-11D3-A5D7-00A0C9DF422B")]
public interface IExtractInteractionParameters1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetSpecMatrixValue([In] int nPaneIdx, [In] int nCompound1Idx, [In] int nCompound2Idx, out int pbValue);
}
[ComImport]
[Guid("558D4B01-D5BC-11D3-A610-00A0C9DF422B")]
[TypeLibType(4160)]
public interface IIPLoadingInfo
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetDefaultDatabaseDir([In][MarshalAs(UnmanagedType.BStr)] string defaultatabasedir);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetLoader([In][MarshalAs(UnmanagedType.IDispatch)] object ploader);
}
[ComImport]
[Guid("49780721-D5D0-11D3-A610-00A0C9DF422B")]
[TypeLibType(4160)]
public interface IIPLoad
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void IPLoad([In][MarshalAs(UnmanagedType.IDispatch)] object pCC);
}
[ComImport]
[Guid("1DD7D7A1-F2E5-11D4-A6D8-00A0C9DF422B")]
[TypeLibType(4160)]
public interface ISubIP
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void SetParent([In][MarshalAs(UnmanagedType.IDispatch)] object parent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void SetCompMapping([In] int nComp, [In] ref int mapping);
}
[ComImport]
[Guid("D4814CE0-5E12-11D2-B8DF-00A0C986F9F7")]
[ClassInterface((short)0)]
[TypeLibType(2)]
public class COTHPropertyEnumerationRegistryClass : IPropertyEnumerationRegistry, COTHPropertyEnumerationRegistry
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern int IPropertyEnumerationRegistry.GetPropertyIDByName([In][MarshalAs(UnmanagedType.BStr)] string strName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string IPropertyEnumerationRegistry.GetPropertyNameByID([In] int nPropID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern int IPropertyEnumerationRegistry.AddPropertyByName([In][MarshalAs(UnmanagedType.BStr)] string strName);
}
[ComImport]
[Guid("6AF1D923-37AA-11D2-B8C6-00A0C986F9F7")]
[CoClass(typeof(COTHPropertyEnumerationRegistryClass))]
public interface COTHPropertyEnumerationRegistry : IPropertyEnumerationRegistry
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("AEACEF10-27B8-11D5-BF96-00A0C9B465F6")]
public interface IExtendedPropPackage
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetPackageName([In][Out][MarshalAs(UnmanagedType.BStr)] ref string PkgName, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string description);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void PkgFileNeeded([In][Out] ref int nfiles, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string description);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void SetupPkg([In] int nfiles, [In][MarshalAs(UnmanagedType.Struct)] object filenames, [In][MarshalAs(UnmanagedType.BStr)] string setupinfo, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void IsPkgSetup([In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void InitializePropertyID([In][MarshalAs(UnmanagedType.IDispatch)] object lpPropertyRegistry);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void CanCalculate([In] int propertyID, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void CalculateProperty([In] int propertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][MarshalAs(UnmanagedType.IDispatch)] object progressMonitor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void CalculateTwoPhaseProperty([In] int propertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In] int iphase, [In] int jphase, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][MarshalAs(UnmanagedType.IDispatch)] object progressMonitor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void GetEnthalpyBase([In][Out] ref int EnthBase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void GetGibbsBase([In][Out] ref int GibbsBase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	void CanNumbCompChange([In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	void GetSupportedComps([In][Out] ref int nComp, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object HyprotechIDs, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object names, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string identifiername, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object identifiers);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	void GetNumbCompounds([In][Out] ref int nComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	void GetCompoundInfo([In] int iComp, [In][MarshalAs(UnmanagedType.IDispatch)] object pCompoundi, [In][Out] ref int nProps, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object propnames);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	void AddLastCompound([In][MarshalAs(UnmanagedType.IDispatch)] object pCompoundi);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	void RemoveCompoundi([In] int iComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(17)]
	void ExchangeCompounds([In] int iComp, [In] int jComp);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(18)]
	void PhaseOrder([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pThermoProperty);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(19)]
	void OnView([In][Out][MarshalAs(UnmanagedType.BStr)] ref string ViewName, [In][Out] ref bool OpenView);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(20)]
	void PkgSave([In][Out][MarshalAs(UnmanagedType.BStr)] ref string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(21)]
	void PkgRecall([In][MarshalAs(UnmanagedType.BStr)] string saveinfo, [In][Out] ref bool BaseChanged);
}
[ComImport]
[Guid("6982FFF0-2ACD-11D5-BF96-00A0C9B465F6")]
[TypeLibType(4160)]
public interface IExtendedFlash
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetFlashName([In][Out][MarshalAs(UnmanagedType.BStr)] ref string FlashName, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string description);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void FlashFileNeeded([In][Out] ref int nfiles, [In][Out][MarshalAs(UnmanagedType.BStr)] ref string description);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void SetupFlash([In] int nfiles, [In][MarshalAs(UnmanagedType.Struct)] object filenames, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void IsFlashSetup([In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void SupportedFlashTypes([In][Out] ref int nFlashes, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object types);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void CanHandleFlashType([In] tagFlashTypeEnum type, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void InitializePropertyID([In][MarshalAs(UnmanagedType.IDispatch)] object lpPropertyRegistry);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void IsFlashControlUsed([In][Out] ref bool IsUsed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void Execute([In] tagFlashTypeEnum type, [In][MarshalAs(UnmanagedType.IDispatch)] object pFlashControl, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pThermoProperty, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][MarshalAs(UnmanagedType.IDispatch)] object progressMonitor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void FlashSave([In][Out][MarshalAs(UnmanagedType.BStr)] ref string saveinfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	void FlashRecall([In][MarshalAs(UnmanagedType.BStr)] string saveinfo);
}
[ComImport]
[TypeLibType(4160)]
[Guid("07006090-437E-11D2-B8CF-00A0C986F9F7")]
public interface IPhaseCalculationMethod
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void InitializePropertyIDs([In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyRegistry);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void Calculate([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][MarshalAs(UnmanagedType.IDispatch)] object progressMonitor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetPropertyMethodID();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetPropertyType();
}
[ComImport]
[Guid("DBB17280-703B-11D3-B2F9-00A0C900649D")]
[TypeLibType(4160)]
public interface IInteractionParameterInfo
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetIPModelInformation([MarshalAs(UnmanagedType.Struct)] out object ipModelNames, [MarshalAs(UnmanagedType.Struct)] out object ipNumbModelPanes, [MarshalAs(UnmanagedType.Struct)] out object ipShapes, [MarshalAs(UnmanagedType.Struct)] out object ipTypes, out int numbIPModels);
}
[ComImport]
[Guid("EBE4C860-1A82-11D6-B86B-000347A74660")]
[TypeLibType(4160)]
public interface IMultiPhaseCalculationMethod
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void InitializePropertyIDs([In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyRegistry);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void CalculateMultiPhaseProp([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In] int nPhases, [In] ref int PhaseIndexes, [In][Out][MarshalAs(UnmanagedType.IDispatch)] ref object ppContext, [In][MarshalAs(UnmanagedType.IDispatch)] object pPropertyCallBack, [In][MarshalAs(UnmanagedType.IDispatch)] object errorLog, [In][MarshalAs(UnmanagedType.IDispatch)] object progressMonitor);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetPropertyMethodID();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetPropertyType();
}
[ComImport]
[TypeLibType(4160)]
[Guid("C67014A0-1CBE-11D6-B86B-000347A74660")]
public interface IThermoProperty1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void EvaluateMultiPhaseProperty([In] int nPropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In] int nPhases, [In] ref int PhaseIndexes);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void EvaluateMultiPhasePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In] int nPhases, [In] ref int PhaseIndexes, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetDefaultMultiPhasePropObject([In] int ePropertyID);
}
[ComImport]
[Guid("68B2F9F0-5E15-11D7-B8B2-000347A74660")]
[TypeLibType(4160)]
public interface IDerivativeCalculation
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void TurnOnDerivative([In] byte bOn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void CanCalculate([In] int nPropID, [In][Out] ref int status);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void CanCalculateDerivative([In] tagPhaseTypeEnum ePhaseType, [In] int nPropID, [In] int nDerivativeID, [In][Out] ref byte bYes, [In][Out] ref tagResultTypeEnum ePropResultType, [In][Out] ref tagResultTypeEnum eDevResultType);
}
