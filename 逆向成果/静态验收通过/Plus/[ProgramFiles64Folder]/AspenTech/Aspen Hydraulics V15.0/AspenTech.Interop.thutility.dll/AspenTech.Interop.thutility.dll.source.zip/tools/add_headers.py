#!/usr/bin/env python3
"""Add the original PE header block to a replay package (local extension).

The .NET 1.1 linker writes optional-header counters and section characteristics
that Roslyn computes differently (SizeOfInitializedData, section flags).
Replaying the original header bytes verbatim, instead of patching individual
fields, keeps the reconstructed image exact.

Usage: add_headers.py <package.zip> <original.dll> <out.zip>
"""
import json
import struct
import sys
import zipfile
from hashlib import sha256
from pathlib import Path


def main(package, original, out):
    data = Path(original).read_bytes()
    with zipfile.ZipFile(package) as z:
        members = {n: z.read(n) for n in z.namelist()}
    # SizeOfHeaders is at optional header offset 60 (PE32 / PE32+)
    pe_off = struct.unpack_from("<I", data, 0x3C)[0]
    opt = pe_off + 24
    magic = struct.unpack_from("<H", data, opt)[0]
    size_of_headers = struct.unpack_from("<I", data, opt + 60)[0]
    header = data[:size_of_headers]
    members["original-build/pe-headers.bin"] = header
    recipe = json.loads(members["layout-recipe.json"])
    recipe["original_headers_sha256"] = sha256(header).hexdigest()
    recipe["original_headers_bytes"] = len(header)
    members["layout-recipe.json"] = (json.dumps(recipe, ensure_ascii=False, indent=1) + "\n").encode()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    print(json.dumps({"headers_bytes": len(header), "magic": hex(magic),
                      "sha256": sha256(Path(out).read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main(*sys.argv[1:4])
