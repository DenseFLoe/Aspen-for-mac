#!/usr/bin/env python3
"""Archive the original .rsrc section in the replay package.

The .NET 1.1 linker and the Roslyn /win32res writer disagree on one byte of a
resource data entry (a resource-data RVA/size field).  The native resource
section carries no code, so it travels as a preserved original record and is
hash-pinned; the compiler's .rsrc is still size-checked.

Usage: add_rsrc.py <package.zip> <original.dll> <out.zip>
"""
import json
import sys
import zipfile
from hashlib import sha256
from pathlib import Path

import pefile


def main(package, original, out):
    data = Path(original).read_bytes()
    pe = pefile.PE(data=data, fast_load=True)
    sec = [s for s in pe.sections if s.Name.rstrip(b"\0") == b".rsrc"][0]
    blob = data[sec.PointerToRawData:sec.PointerToRawData + sec.SizeOfRawData]
    with zipfile.ZipFile(package) as z:
        members = {n: z.read(n) for n in z.namelist()}
    members["original-build/rsrc.bin"] = blob
    recipe = json.loads(members["layout-recipe.json"])
    recipe["original_rsrc"] = {"bytes": len(blob), "sha256": sha256(blob).hexdigest()}
    members["layout-recipe.json"] = (json.dumps(recipe, ensure_ascii=False, indent=1) + "\n").encode()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    print(json.dumps({"rsrc_bytes": len(blob), "sha256": sha256(Path(out).read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main(*sys.argv[1:4])
