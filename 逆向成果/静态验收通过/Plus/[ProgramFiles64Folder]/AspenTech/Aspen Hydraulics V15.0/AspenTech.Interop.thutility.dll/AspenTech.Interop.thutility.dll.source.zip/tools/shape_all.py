#!/usr/bin/env python3
"""Reshape ILSpy tlbimp class members into explicit interface implementations,
driven by the original IL's `.override` rows.

Usage: shape_all.py <source.cs> <original.il> <out.cs> <namespace>

For every `public virtual extern` member of every `public class` the original
MethodDef's `.override` target decides the interface to implement explicitly.
Members without an override stay public (tlbimp implicit mapping).
"""
import json
import re
import sys
from pathlib import Path

PRIM = {"int32": "int", "uint32": "uint", "int16": "short", "uint16": "ushort",
        "int64": "long", "uint64": "ulong", "float32": "float", "float64": "double",
        "bool": "bool", "char": "char", "string": "string", "object": "object",
        "void": "void", "int8": "sbyte", "uint8": "byte", "native int": "IntPtr",
        "native unsigned int": "UIntPtr"}


def il_type(text):
    text = re.sub(r"\bmarshal\([^)]*\)", "", text)
    text = re.sub(r"\b(valuetype|class)\s+", "", text)
    text = text.replace("&", "").strip()
    return PRIM.get(text, text.split(".")[-1])


def parse_il(path):
    il = Path(path).read_text(encoding="utf-8", errors="replace")
    out = {}
    for part in re.split(r"(?m)^\.class ", il)[1:]:
        head = part[:part.find("\n")]
        m = re.search(r"\b([A-Za-z_][\w.]*)\s+extends\s", part[:300], re.S)
        if m:
            cls = m.group(1)
        else:
            mm = re.match(r".*?([A-Za-z_][\w.]*)\s*$", head)
            if not mm:
                continue
            cls = mm.group(1)
        methods = []
        for mm in re.finditer(r"(?m)^\t\.method\b", part):
            st = mm.start()
            e = re.search(r"\} // end of method (\S+)::(\S+)", part[st:])
            if not e:
                continue
            blk = part[st:st + e.end()]
            hdr = blk[:blk.find("{")]
            params = []
            params_raw = []
            flat = re.sub(r"\s+", " ", hdr)
            mname = e.group(2)
            rt_end = flat.find(" " + mname + " (")
            ret_raw = flat[flat.find("instance ") + len("instance "):rt_end].strip() if rt_end > 0 else "void"
            ret_tok = [t for t in ret_raw.split() if not t.startswith("marshal(")]
            ret = il_type(ret_tok[0]) if ret_tok else "void"
            ret_m = re.search(r"marshal\((\w+)\)", ret_raw)
            return_marshal = {"bstr": "BStr", "struct": "Struct", "interface": "Interface",
                              "idispatch": "IDispatch", "iunknown": "IUnknown",
                              "lpstr": "LPStr", "lpwstr": "LPWStr", "bool": "Bool"}.get(
                                  ret_m.group(1)) if ret_m else None
            if rt_end > 0:
                pstart = flat.find("(", rt_end)
                pend = flat.rfind(") runtime managed")
                if pend > pstart:
                    for p in csv_params(flat[pstart + 1:pend]):
                        params_raw.append(p)
                        toks = [t for t in p.split() if not t.startswith("[") and not t.startswith("marshal(")]
                        if not toks:
                            continue
                        ttype = toks[1] if toks[0] in ("class", "valuetype") and len(toks) > 1 else toks[0]
                        params.append(il_type(ttype))
            ov = re.findall(r"\.override method \S+ ([^\(]+)\(([^)]*)\)", blk)
            methods.append({"name": e.group(2), "params": params, "ret": ret,
                            "params_raw": params_raw, "ret_il": ret,
                            "return_marshal": return_marshal,
                            "overrides": [(o[0].split("::")[0].split(".")[-1],
                                           o[0].split("::")[-1]) for o in ov],
                            "override_full": [o[0] for o in ov]})
        out[cls] = methods
    return out


def csv_params(text):
    parts, depth, cur = [], 0, ""
    for ch in text:
        if ch in "([":
            depth += 1
        elif ch in ")]":
            depth -= 1
        if ch == "," and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    if cur.strip():
        parts.append(cur)
    return [p.strip() for p in parts if p.strip()]


def cs_type(text):
    text = re.sub(r"\[[^\]]*\]", "", text)
    text = re.sub(r"\b(params|out|ref|in)\b", "", text).strip()
    base = text.split()[0] if text.split() else text
    return PRIM.get(base, base.split(".")[-1])


def cs_params(text):
    return [cs_type(p.split()[0] if " " in p.strip() else p) for p in csv_params(text)]


MEMBER = re.compile(r"^(\t+)public virtual extern (.+?) ([A-Za-z_][A-Za-z0-9_]*)(\s*)$")
METHOD = re.compile(r"^(\t+)public virtual extern (.+?) ([A-Za-z_][A-Za-z0-9_]*)(\(.*)$")


def main(src, orig_il, out, ns):
    lines = Path(src).read_text(encoding="utf-8").splitlines(keepends=True)
    ilmap = parse_il(orig_il)
    edits, skipped = [], []
    i = 0
    while i < len(lines):
        m = re.match(r"public class ([A-Za-z_][A-Za-z0-9_]*)", lines[i])
        if not m:
            i += 1
            continue
        cls = m.group(1)
        full = ns + "." + cls
        methods = ilmap.get(full)
        j = i + 1
        while j < len(lines) and lines[j].rstrip("\r\n") != "}":
            body = lines[j].rstrip("\r\n")
            eol = lines[j][len(body):]
            mm = MEMBER.match(body) or METHOD.match(body)
            if not mm:
                j += 1
                continue
            indent, typ, name, tail = mm.groups()
            is_method = tail.startswith("(")
            if methods is None:
                skipped.append({"class": full, "member": name, "why": "class missing in IL"})
                j += 1
                continue
            want = cs_type(typ)
            acc_get = acc_set = True
            if not is_method:
                acc_get, acc_set = False, False
                k2 = j
                while k2 < len(lines):
                    t2 = lines[k2].rstrip("\r\n")
                    if t2 == "\t}":
                        break
                    if t2.strip() == "get;":
                        acc_get = True
                    if t2.strip() == "set;":
                        acc_set = True
                    k2 += 1
            if is_method:
                cand = [x for x in methods if x["name"] == name
                        and len(x["params"]) == len(cs_params(tail[1:tail.rfind(")")]))
                        and il_type(x["ret"]) == want]
                member = name
            else:
                member = None
                cand = []
                exact = [x for x in methods
                         if x["name"] in ("get_" + name, "set_" + name) and x["overrides"]
                         and ((x["name"].startswith("set_") and x["params"]
                               and il_type(x["params"][-1]) == want)
                              or il_type(x["ret"]) == want)]
                if exact:
                    cand = exact
                    member = name
                elif "_" in name:
                    for k in range(1, len(name)):
                        if name[k] != "_":
                            continue
                        short, rest = name[:k], name[k + 1:]
                        pref = (short + "_get_" + rest, short + "_set_" + rest)
                        plain = ("get_" + rest, "set_" + rest)
                        ok = lambda x: (((x["name"].startswith("set_") or "_set_" in x["name"])
                                         and x["params"] and il_type(x["params"][-1]) == want)
                                        or il_type(x["ret"]) == want)
                        hits = [x for x in methods if x["name"] in pref
                                and x["overrides"] and ok(x)
                                and (x["overrides"][0][0] == short or short in x["name"])]
                        if not hits:
                            hits = [x for x in methods if x["name"] in plain
                                    and x["overrides"] and ok(x)
                                    and x["overrides"][0][0] == short]
                        if not hits:
                            hits = [x for x in methods if x["name"] in pref or x["name"] in plain
                                    if x["overrides"] and ok(x)]
                        if hits:
                            cand = hits
                            member = rest
                            break
                if not cand:
                    cand = [x for x in methods
                            if x["name"] in ("get_" + name, "set_" + name) and x["overrides"]
                            and ((x["name"].startswith("set_") and x["params"]
                                  and il_type(x["params"][-1]) == want)
                                 or il_type(x["ret"]) == want)]
                    member = name
            if not is_method:
                cand = [x for x in cand
                        if (acc_get and "get_" in x["name"]) or (acc_set and "set_" in x["name"])]
            ovs = [(i, mm) for x in cand for i, mm in x["overrides"]]
            ifaces = {i for i, _ in ovs}
            targets = sorted(ifaces)
            if len(ifaces) == 1 and cand:
                iface = targets[0]
                raw_names = {mm for _, mm in ovs}
                names = {mm[4:] if mm.startswith(("get_", "set_")) else mm for _, mm in ovs}
                if is_method:
                    member = next(iter(raw_names)) if len(raw_names) == 1 else name
                elif member is None or len(names) == 1:
                    member = next(iter(names))
                edits.append({"line": j + 1, "class": cls, "member": name,
                              "iface": iface, "target": member,
                              "orig": body.strip(), "via": "override"})
                newline = "%sextern %s %s.%s%s%s" % (indent, typ, iface, member, tail, eol)
            elif not targets and not any(x["overrides"] for x in
                                        [y for y in methods if y["name"] in
                                         ((name,) if is_method else ("get_" + name, "set_" + name))]):
                j += 1
                continue
            else:
                skipped.append({"class": full, "member": name, "targets": targets})
                j += 1
                continue
            lines[j] = newline
            j += 1
        i = j + 1
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text("".join(lines), encoding="utf-8", newline="")
    Path(out + ".shape-report.json").write_text(
        json.dumps({"edits": edits, "skipped": skipped}, ensure_ascii=False, indent=1),
        encoding="utf-8")
    print("reshaped %d members; skipped %d" % (len(edits), len(skipped)))
    for s in skipped[:20]:
        print("  SKIP", s)


if __name__ == "__main__":
    main(*sys.argv[1:5])
