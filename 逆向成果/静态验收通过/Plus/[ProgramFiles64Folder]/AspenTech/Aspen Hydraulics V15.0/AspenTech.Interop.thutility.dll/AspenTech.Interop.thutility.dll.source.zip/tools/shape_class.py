#!/usr/bin/env python3
"""Turn the public virtual extern members of one tlbimp class into explicit
interface implementations of a given interface.

Original IL shape: `public hidebysig newslot virtual ... Name` + `.override
IFace::Name`.  C# can emit the `.override` row only through an explicit
interface implementation; declaration flags/names are restored afterwards.

Usage: shape_class.py <source.cs> <out.cs> <ClassName> <Interface> [--dry]
"""
import re
import sys
from pathlib import Path

MEMBER = re.compile(r"^(\t+)public virtual extern (.+?) ([A-Za-z_][A-Za-z0-9_]*)(\s*)$")
METHOD = re.compile(r"^(\t+)public virtual extern (.+?) ([A-Za-z_][A-Za-z0-9_]*)(\(.*)$")


def main(src, out, cls, iface, dry=False):
    lines = Path(src).read_text(encoding="utf-8").splitlines(keepends=True)
    start = None
    for i, line in enumerate(lines):
        if re.match(r"public class %s\b" % re.escape(cls), line):
            start = i
            break
    if start is None:
        raise SystemExit("class not found: " + cls)
    end = None
    for j in range(start + 1, len(lines)):
        if lines[j].rstrip("\r\n") == "}":
            end = j
            break
    if end is None:
        raise SystemExit("class end not found: " + cls)
    n = 0
    for i in range(start + 1, end):
        body = lines[i].rstrip("\r\n")
        eol = lines[i][len(body):]
        m = MEMBER.match(body) or METHOD.match(body)
        if not m:
            continue
        indent, typ, name, tail = m.groups()
        new = "%sextern %s %s.%s%s%s" % (indent, typ, iface, name, tail, eol)
        if dry:
            print("line %-5d %s" % (i + 1, new.strip()))
        lines[i] = new
        n += 1
    if not dry:
        Path(out).parent.mkdir(parents=True, exist_ok=True)
        Path(out).write_text("".join(lines), encoding="utf-8", newline="")
    print("%s: %d members -> explicit %s" % (cls, n, iface))


if __name__ == "__main__":
    main(*sys.argv[1:5], dry="--dry" in sys.argv)
