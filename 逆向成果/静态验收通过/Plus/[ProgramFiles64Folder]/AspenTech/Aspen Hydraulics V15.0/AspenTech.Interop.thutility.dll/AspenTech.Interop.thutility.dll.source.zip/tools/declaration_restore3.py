#!/usr/bin/env python3
"""Restore MethodDef declaration names/flags that C# cannot express.  Local variant: a rule may carry the paired candidate MethodDef row (_candidate_row) so same-suffix accessors in one TypeDef stay unambiguous.

An explicit interface implementation in C# always emits
private final hidebysig newslot virtual instance void I.M() plus an
.override I::M row.  The original tlbimp-shaped assembly declares the same
body as public hidebysig newslot virtual instance void M() with the same
.override row.  The .override row IS expressible in C# (explicit
implementation); the public non-final name is not.  This module renames the
MethodDef and restores its accessibility flags in place, which keeps every
metadata table, heap and RVA at its original size.
"""
import json
import struct
import sys
from hashlib import sha256
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "managed"))
import clr_meta

MD_TABLE = 0x06


def _string_map(pe, cli, root):
    heap = root["streams"]["#Strings"]
    file_start = pe.get_offset_from_rva(cli["metadata_rva"] + heap["offset"])
    data = pe.get_data(cli["metadata_rva"] + heap["offset"], heap["size"])
    out = {}
    at = 0
    while at < len(data):
        if not data[at]:
            at += 1
            continue
        end = data.index(b"\0", at)
        out.setdefault(data[at:end].decode("utf-8", "replace"), at)
        at = end + 1
    return out, file_start


def _owner_typedef(content, tables, method_row):
    """Return the sibling MethodDef rows of the TypeDef that owns method_row."""
    if 0x02 not in tables["layout"]:
        return None
    type_rows = tables["layout"][0x02]["rows"]
    method_rows = tables["layout"][MD_TABLE]["rows"]
    owner = None
    for index in range(1, type_rows + 1):
        row = clr_meta.read_row(content, tables, 0x02, index)
        first = row[5]
        if first and first <= method_row:
            owner = index
    if owner is None:
        return None
    first = clr_meta.read_row(content, tables, 0x02, owner)[5]
    last = (clr_meta.read_row(content, tables, 0x02, owner + 1)[5]
            if owner < type_rows else method_rows + 1)
    return list(range(first, last))


def restore(image_bytes, rules):
    """Apply target_name/expected_flags/target_flags rules in place."""
    pe, cli, root = clr_meta.read_image(image_bytes)
    tables = root["tables"]
    layout = tables["layout"][MD_TABLE]
    content = bytearray(root["bytes"])
    md_file = pe.get_offset_from_rva(cli["metadata_rva"])
    heap_width = 4 if tables["heap_sizes"] & 1 else 2
    strings_map, _ = _string_map(pe, cli, root)
    report = []
    touched = set()
    for rule in rules:
        target = rule["target_name"]
        # Local extension over work/override-fix/declaration_restore.py:
        # an exact-name row (e.g. the .ctor flag-only rule) is also accepted, and
        # the candidate's recorded flags disambiguate the bare interface member
        # (abstract, different flags) from the explicit implementation.
        matched = []
        row_hint = rule.get("_candidate_row")
        for index in range(1, layout["rows"] + 1):
            if row_hint and index != row_hint:
                continue
            row = clr_meta.read_row(content, tables, MD_TABLE, index)
            name = clr_meta.strings(pe, cli, root, row[3])
            if ((name == target or name.endswith("." + target)) and row[2] == rule["expected_flags"]
                    and index not in touched):
                matched.append((index, row, name))
        want_owner = rule.get("owner_type")
        if want_owner:
            def owner_name(row_index):
                type_rows = tables["layout"][0x02]["rows"]
                method_rows = tables["layout"][MD_TABLE]["rows"]
                for t in range(1, type_rows + 1):
                    first = clr_meta.read_row(content, tables, 0x02, t)[5]
                    last = (clr_meta.read_row(content, tables, 0x02, t + 1)[5]
                            if t < type_rows else method_rows + 1)
                    if first <= row_index < last:
                        trow = clr_meta.read_row(content, tables, 0x02, t)
                        name = clr_meta.strings(pe, cli, root, trow[1])
                        ns = clr_meta.strings(pe, cli, root, trow[2])
                        return (ns + "." if ns else "") + name
                return None
            matched = [m for m in matched if owner_name(m[0]) == want_owner]
        if len(matched) != 1:
            raise ValueError("MethodDef for %r matched %d rows" % (target, len(matched)))
        index, row, old_name = matched[0]
        touched.add(index)
        # The compiler stores the explicit-impl name as <interface>.<method> and
        # lets the bare name share its suffix inside the #Strings heap, so the
        # target index is the explicit name index plus the prefix length.
        new_index = row[3] + (len(old_name) - len(target))
        heap = root["streams"]["#Strings"]
        if not 0 <= new_index < heap["size"]:
            raise ValueError("suffix name of %r falls outside #Strings" % target)
        probe = pe.get_data(cli["metadata_rva"] + heap["offset"] + new_index,
                            min(len(target) + 1, heap["size"] - new_index))
        if probe != target.encode("utf-8") + b"\0":
            raise ValueError("%r is not the suffix of the explicit-impl name" % target)
        strings_map[target] = new_index
        owner = _owner_typedef(content, tables, index)
        if owner is None:
            raise ValueError("%s has no owning TypeDef" % target)
        for j in owner:
            if j == index:
                continue
            other = clr_meta.read_row(content, tables, MD_TABLE, j)
            if (clr_meta.strings(pe, cli, root, other[3]) == target
                    and other[4] == row[4]):
                raise ValueError("renaming %s would collide inside its TypeDef (row %d)" % (target, j))
        base = layout["offset"] + (index - 1) * layout["row_size"]
        # MethodDef row: RVA(4) ImplFlags(2) Flags(2) Name(2) Signature(2) ParamList(2)
        content[base + 6:base + 8] = struct.pack("<H", rule["target_flags"])
        content[base + 8:base + 8 + heap_width] = strings_map[target].to_bytes(heap_width, "little")
        report.append({"methoddef_row": index, "token": 0x06000000 | index,
                       "old_name": old_name, "new_name": target,
                       "old_flags": row[2], "new_flags": rule["target_flags"],
                       "name_string_index": strings_map[target]})
    result = bytearray(image_bytes)
    result[md_file:md_file + len(content)] = content
    return bytes(result), report


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True, type=Path)
    ap.add_argument("--rules", required=True, type=Path)
    ap.add_argument("--out", required=True, type=Path)
    a = ap.parse_args()
    rules = json.loads(a.rules.read_text("utf-8"))
    data, report = restore(a.image.read_bytes(), rules)
    a.out.write_bytes(data)
    print(json.dumps({"in": sha256(a.image.read_bytes()).hexdigest(),
                      "out": sha256(data).hexdigest(), "edits": report},
                     ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main()