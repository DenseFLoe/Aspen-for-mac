#!/usr/bin/env python3
"""Convert explicit interface implementations that C# cannot satisfy back to
implicit public members, driven by CS0535 diagnostics.

When an interface hides (`new`) a base-interface member with the same
signature, one explicit implementation only maps to one of them; the original
tlbimp image maps a single MethodDef to both (implicit name match plus one
.override row).  C# cannot express that, so emit the implicit public member.

Usage: fix_implicit.py <source.cs> <compile.log> <out.cs> <namespace>
"""
import re
import sys
from pathlib import Path

ERR = re.compile(r"error CS0535: .*?[“\"]([A-Za-z_][\w]*(?:\.[A-Za-z_]\w*)*)[”\"]"
                 r".*?[“\"]([A-Za-z_][\w]*)\.([A-Za-z_][\w]*)(?:\([^)]*\))?[”\"]")


def main(src, log, out, ns):
    src, log, out = Path(src), Path(log), Path(out)
    text = src.read_text(encoding="utf-8")
    data = log.read_bytes().decode("utf-8", "replace")
    missing = set()
    for m in re.finditer(r"CS0535: .*?[“\"]([\w.]+)[”\"].*?[“\"]([\w.]+)\.(\w+)(?:\([^)]*\))?[”\"]", data):
        missing.add((m.group(1).split(".")[-1], m.group(2).split(".")[-1], m.group(3)))
    fixed = []
    lines = text.splitlines(keepends=True)
    current = None
    for i, line in enumerate(lines):
        mm = re.match(r"public class (\w+)", line)
        if mm:
            current = mm.group(1)
        if current is None:
            continue
        for cls, iface, member in missing:
            if cls != current:
                continue
            m2 = re.match(r"(\t)(?:public virtual extern )?(?:extern )?(.+?) "
                          r"[A-Za-z_]\w*\." + re.escape(member) + r"(\s*\(.*)$", line)
            if not m2:
                continue
            indent, typ, tail = m2.groups()
            lines[i] = "%spublic virtual extern %s %s%s" % (indent, typ, member, tail)
            fixed.append({"class": cls, "member": member, "line": i + 1})
    out.write_text("".join(lines), encoding="utf-8", newline="")
    print("implicit-restored %d members" % len(fixed))
    for f in fixed:
        print("  ", f)


if __name__ == "__main__":
    main(*sys.argv[1:5])
