#!/usr/bin/env python3
"""Append the local replay tools to a recipe package so it is self-contained."""
import sys, zipfile
from hashlib import sha256
from pathlib import Path

def main(src, out, tool_dir):
    src, out, tool_dir = Path(src), Path(out), Path(tool_dir)
    with zipfile.ZipFile(src) as z:
        members = {n: z.read(n) for n in z.namelist()}
    for name in ("token_replay2.py", "pe_layout2.py", "replay2.py", "build_recipe2.py",
                 "make_source.py", "derive_rules.py", "declaration_restore2.py",
                 "compare_methods.py", "make_pkg.py"):
        members["tools/" + name] = (tool_dir / name).read_bytes()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    print(sha256(out.read_bytes()).hexdigest(), out)

if __name__ == "__main__":
    main(*sys.argv[1:4])
