#!/usr/bin/env python3
"""Reshape ILSpy tlbimp output so C# can express the original declarations.

ILSpy disambiguates colliding interface members as `public virtual extern T
IFace_Member`.  The original MethodDef is `public hidebysig newslot virtual ...
Member` with `.override IFace::Member`.  C# can only emit the `.override` row via
an explicit interface implementation, so rewrite those members to
`extern T IFace.Member`.  Flags/names are restored later by
declaration_restore2.py.

Usage: reshape.py <source.cs> <out.cs>
"""
import re
import sys
from pathlib import Path

MEMBER = re.compile(r"^(\t+)public virtual extern (.+?) (I[A-Za-z0-9]+)_([A-Za-z0-9]+)(\s*)$")
METHOD = re.compile(r"^(\t+)public virtual extern (.+?) (I[A-Za-z0-9]+)_([A-Za-z0-9]+)(\(.*)$")


def main(src, out):
    text = Path(src).read_text(encoding="utf-8")
    lines = text.splitlines(keepends=True)
    changed = []
    for i, line in enumerate(lines):
        body = line.rstrip("\r\n")
        eol = line[len(body):]
        m = MEMBER.match(body) or METHOD.match(body)
        if not m:
            continue
        indent, typ, iface, member, tail = m.groups()
        lines[i] = "%sextern %s %s.%s%s%s" % (indent, typ, iface, member, tail, eol)
        changed.append({"line": i + 1, "from": body.strip(), "to": lines[i].strip()})
    Path(out).parent.mkdir(parents=True, exist_ok=True)
    Path(out).write_text("".join(lines), encoding="utf-8", newline="")
    for c in changed:
        print("line %-5d %s" % (c["line"], c["to"]))
    print("reshaped %d members" % len(changed))


if __name__ == "__main__":
    main(*sys.argv[1:3])
