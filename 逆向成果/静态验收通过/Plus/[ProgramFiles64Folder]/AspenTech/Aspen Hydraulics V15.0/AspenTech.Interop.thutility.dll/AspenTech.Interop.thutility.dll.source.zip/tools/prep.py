#!/usr/bin/env python3
"""Assemble a build package (build-plan + editable source + resources + snk +
original-build records) for one tlbimp-shape interop item.

Usage: prep.py <sha8> <pkg-base-dir> <original-dll>
"""
import json
import struct
import sys
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROUTER = HERE.parents[1]
TOOL = ROUTER / "work" / "managed-override-1"
sys.path.insert(0, str(TOOL))
sys.path.insert(0, str(ROUTER / "managed"))
DEPS = ROUTER.parents[1] / "aspen-acceptance-work" / "deps"
if DEPS.is_dir():
    sys.path.insert(0, str(DEPS))

import pefile  # noqa: E402
import build_recipe2 as br  # noqa: E402


def digest(b):
    return sha256(b).hexdigest()


def main(sha8, pkg_base, original):
    pkg_base, original = Path(pkg_base).resolve(), Path(original)
    work = HERE / sha8
    pkg = work / "pkg"
    (pkg / "editable").mkdir(parents=True, exist_ok=True)
    (pkg / "resources").mkdir(parents=True, exist_ok=True)
    (pkg / "build").mkdir(parents=True, exist_ok=True)
    (pkg / "original-build").mkdir(parents=True, exist_ok=True)

    inputs = json.loads((pkg_base / "build-inputs.json").read_text(encoding="utf-8"))
    src_name = next(iter(inputs["repaired_source_sha256"]))
    source = pkg_base / "editable" / src_name
    data = original.read_bytes()
    pe = pefile.PE(data=data, fast_load=True)

    # Managed resources: none expected for this family; refuse silently dropping any.
    cli_off = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress)
    cli = data[cli_off:cli_off + 72]
    res_rva, res_size = struct.unpack_from("<II", cli, 24)
    if res_size:
        raise SystemExit("original has managed resources (%d bytes); handle separately" % res_size)

    (pkg / "editable" / src_name).write_bytes(source.read_bytes())
    (pkg / "resources" / "original.res").write_bytes((pkg_base / "resources" / "original.res").read_bytes())

    # Public key from Assembly.PublicKey blob -> assembly-public-key.snk
    pe_i, root_i = br.identified_image(data)
    cli_i = br.cli_header(pe_i)
    pub = br.public_key_blob(pe_i, cli_i, br.metadata_root(pe_i, cli_i))
    if not pub["present"]:
        raise SystemExit("original has no assembly public key")
    (pkg / "build" / "assembly-public-key.snk").write_bytes(pub["bytes"])

    # debug record / strong-name / certificate table
    boot = br.bootstrap(pe_i)
    debug = br.debug_tail(data, pe_i) or b""
    sec = pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    cert = data[sec.VirtualAddress:sec.VirtualAddress + sec.Size] if sec.Size else b""
    strong = b""
    if root_i.get("strong_name_bytes"):
        slot = pe.get_offset_from_rva(root_i["strong_name_rva"])
        strong = data[slot:slot + root_i["strong_name_bytes"]]
        (pkg / "original-build" / "strong-name.bin").write_bytes(strong)
    (pkg / "original-build" / "debug-record.bin").write_bytes(debug)
    (pkg / "original-build" / "certificate-table.bin").write_bytes(cert)

    plan = {
        "assembly_name": original.name,
        "original_sha256": digest(data),
        "tool_path": {
            "dotnet": str(ROUTER.parents[1] / "patrol-0857/review340/net9/dotnet.exe"),
            "csc": str(ROUTER.parents[1] / "patrol-0857/review340/net9/sdk/9.0.321/Roslyn/bincore/csc.dll"),
        },
        "references": inputs["references"],
        "fixed_flags": ["/nologo", "/utf8output", "/nostdlib+", "/deterministic+",
                        "/langversion:10", "/optimize+", "/target:library",
                        "/baseaddress:0x400000", "/filealign:512",
                        "/subsystemversion:4.00", "/publicsign+"],
        "managed_resources": [],
        "build_input_sha256": {
            "editable/" + src_name: digest(source.read_bytes()),
            "resources/original.res": digest((pkg_base / "resources" / "original.res").read_bytes()),
            "build/assembly-public-key.snk": digest((pkg / "build" / "assembly-public-key.snk").read_bytes()),
        },
        "source_edits": inputs.get("source_edits", []),
    }
    (pkg / "build-plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(json.dumps({"pkg": str(pkg), "source": str(pkg / "editable" / src_name),
                      "snk_bytes": len(pub["bytes"]),
                      "debug_bytes": len(debug), "cert_bytes": len(cert),
                      "strong_bytes": len(strong),
                      "refs": len(plan["references"])}, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    main(*sys.argv[1:4])
