#!/usr/bin/env python3
"""Add the original x86 import/bootstrap tail to a replay package.

Roslyn's import directory differs from the .NET 1.1 linker's in hint/name
padding and total length (the original can be longer than the compiler block).
For byte-exact replay the original tail is archived and hash-pinned.

Usage: add_import.py <package.zip> <original.dll> <out.zip>
"""
import json
import sys
import zipfile
from hashlib import sha256
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "local-tools"))
import pe_layout2 as pl  # noqa: E402
import pefile  # noqa: E402


def main(package, original, out):
    data = Path(original).read_bytes()
    pe = pefile.PE(data=data, fast_load=True)
    boot = pl.bootstrap(pe)
    if not boot:
        raise SystemExit("no x86 bootstrap")
    start = pe.get_offset_from_rva(boot["start"])
    end = pe.get_offset_from_rva(boot["entry"]) + 6
    tail = data[start:end]
    with zipfile.ZipFile(package) as z:
        members = {n: z.read(n) for n in z.namelist()}
    members["original-build/import-tail.bin"] = tail
    recipe = json.loads(members["layout-recipe.json"])
    recipe["original_import_tail"] = {"rva": boot["start"], "bytes": len(tail),
                                      "sha256": sha256(tail).hexdigest(),
                                      "entry": boot["entry"]}
    members["layout-recipe.json"] = (json.dumps(recipe, ensure_ascii=False, indent=1) + "\n").encode()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    print(json.dumps({"import_tail_bytes": len(tail), "sha256":
                      sha256(Path(out).read_bytes()).hexdigest()}))


if __name__ == "__main__":
    main(*sys.argv[1:4])
