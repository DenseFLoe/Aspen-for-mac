#!/usr/bin/env python3
"""Append replay tools, helper scripts and local reference shims to a package.

Usage: finalize_pkg2.py <src.zip> <out.zip> <extra_json>
extra_json: {"tools": [...paths...], "members": {archive_name: local_path}}
"""
import json
import sys
import zipfile
from hashlib import sha256
from pathlib import Path


def main(src, out, extra_json):
    src, out = Path(src), Path(out)
    extra = json.loads(Path(extra_json).read_text(encoding="utf-8"))
    with zipfile.ZipFile(src) as z:
        members = {n: z.read(n) for n in z.namelist()}
    for path in extra.get("tools", []):
        p = Path(path)
        members["tools/" + p.name] = p.read_bytes()
    for name, path in extra.get("members", {}).items():
        members[name] = Path(path).read_bytes()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    print(sha256(out.read_bytes()).hexdigest(), out)


if __name__ == "__main__":
    main(*sys.argv[1:4])
