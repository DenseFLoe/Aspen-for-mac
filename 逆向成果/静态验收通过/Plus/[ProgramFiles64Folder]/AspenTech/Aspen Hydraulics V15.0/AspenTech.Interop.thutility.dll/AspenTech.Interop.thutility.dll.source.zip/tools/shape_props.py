#!/usr/bin/env python3
"""Rewrite parameterized COM properties as get_/set_ method declarations.

ILSpy renders IDL indexed properties as plain C# properties and drops the index
parameters, so the compiled signature can never match the original MethodDef.
This pass replaces every such property (interface or class) with the `get_X` /
`set_X` declarations the original metadata actually contains.  Class members are
emitted as explicit interface implementations (the `.override` row requires it);
MethodDef flags/names are restored later by declaration_restore2.py.

Usage: shape_props.py <source.cs> <original.il> <out.cs> <namespace>
"""
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import shape_all as sh  # noqa: E402

PROP = re.compile(r"(?m)^(\t)((?:public virtual extern )?)([A-Za-z_][\w\.\<\>\[\]]*(?: [A-Za-z_]\w*)?) ([A-Za-z_]\w*)[ \t]*\r?\n\t\{")


def cs_param(raw):
    toks = [t for t in raw.split() if not t.startswith("[") and not t.startswith("marshal(")]
    if not toks:
        return None
    ttype = toks[1] if toks[0] in ("class", "valuetype") and len(toks) > 1 else toks[0]
    name = toks[-1].strip("'")
    if not name:
        name = "value"
    byref = ttype.endswith("&")
    base = sh.il_type(ttype)
    attrs = []
    if "[in]" in raw:
        attrs.append("[In]")
    if "[out]" in raw:
        attrs.append("[Out]")
    ms = re.search(r"marshal\((\w+)\)", raw)
    if ms:
        attrs.append("[MarshalAs(UnmanagedType.%s)]" %
                     {"bstr": "BStr", "struct": "Struct", "interface": "Interface",
                      "idispatch": "IDispatch", "iunknown": "IUnknown",
                      "lpstr": "LPStr", "lpwstr": "LPWStr", "bool": "Bool"}.get(ms.group(1), "Struct"))
    mode = "out " if ("[out]" in raw and byref) else ("ref " if byref else "")
    return " ".join(attrs + [mode + base, name])


def pick(cand, prop_type, kind, iface=None):
    out = []
    for x in cand:
        if iface and x.get("overrides") and x["overrides"][0][0] != iface:
            continue
        if kind == "get":
            if sh.il_type(x["ret"]) == prop_type:
                out.append(x)
        else:
            if x["params"] and sh.il_type(x["params"][-1]) == prop_type:
                out.append(x)
    return out


def main(src, orig_il, out, ns):
    text = Path(src).read_text(encoding="utf-8")
    ilmap = sh.parse_il(orig_il)
    edits = []
    pos = 0
    while True:
        m = PROP.search(text, pos)
        if not m:
            break
        indent, mod, typ, name = m.group(1), m.group(2).strip(), m.group(3).strip(), m.group(4)
        eol = text.find("\n\t}", m.end())
        if eol < 0:
            break
        block_end = eol + len("\n\t}")
        line_start = text.count("\n", 0, m.start())
        owner = None
        kind_of = "class"
        for k in range(line_start, -1, -1):
            mm = re.match(r"public (interface|class) ([A-Za-z_]\w*)", text.splitlines()[k])
            if mm:
                kind_of = mm.group(1)
                owner = ns + "." + mm.group(2)
                break
        methods = (ilmap.get(owner) or []) if owner else []
        if not methods:
            pos = block_end
            continue
        want = sh.cs_type(typ.split()[-1])
        # candidate accessor sets, source-name-exact first
        names = [("get_" + name, "set_" + name)]
        if "_" in name:
            for k in range(1, len(name)):
                if name[k] != "_":
                    continue
                short, rest = name[:k], name[k + 1:]
                names.append((short + "_get_" + rest, short + "_set_" + rest))
                names.append(("get_" + rest, "set_" + rest))
        getter = setter = None
        want_iface = None
        if "_" in name:
            for k in range(1, len(name)):
                if name[k] == "_" and any(x["overrides"] and x["overrides"][0][0] == name[:k]
                                          for x in methods if "_" in x["name"]):
                    want_iface = name[:k]
                    break
        for gname, sname in names:
            g = pick([x for x in methods if x["name"] == gname], want, "get", want_iface)
            s = pick([x for x in methods if x["name"] == sname], want, "set", want_iface)
            if g or s:
                getter, setter = (g[0] if g else None), (s[0] if s else None)
                break
        get_params = getter.get("params_raw") or [] if getter else []
        set_params = setter.get("params_raw") or [] if setter else []
        if not (len(get_params) or len(set_params) > 1):
            pos = block_end
            continue
        # leading attribute lines
        pre = m.start()
        lead = []
        while True:
            prev_end = pre - 1
            prev_start = text.rfind("\n", 0, prev_end)
            prev = text[prev_start + 1:prev_end]
            if prev.strip().startswith("["):
                lead.insert(0, prev)
                pre = prev_start + 1
            else:
                break
        def acc_iface(x):
            return x["overrides"][0][0] if (x and x.get("overrides")) else None
        target_iface = want_iface or acc_iface(getter) or acc_iface(setter)
        if target_iface:
            if getter and acc_iface(getter) != target_iface:
                getter = None
            if setter and acc_iface(setter) != target_iface:
                setter = None
        iface = target_iface
        g_iface = acc_iface(getter)
        s_iface = acc_iface(setter)
        prefix = "public virtual extern " if (mod and kind_of == "class") else ""
        decls = []
        if getter:
            ps = [cs_param(p) for p in get_params]
            ps = [p for p in ps if p]
            gname2 = getter["name"]
            if g_iface and gname2.startswith(g_iface + "_"):
                gname2 = gname2[len(g_iface) + 1:]
            explicit = bool(g_iface and prefix)
            qn = "%s.%s" % (g_iface, gname2) if explicit else getter["name"]
            pf = "extern " if explicit else prefix
            attrs = ["	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]"] + list(lead)
            if getter.get("return_marshal"):
                attrs.append("\t[return: MarshalAs(UnmanagedType.%s)]" % getter["return_marshal"])
            decls.append("\n".join(attrs) + "\n\t%s%s %s(%s);" % (pf, getter["ret_il"], qn, ", ".join(ps)))
        if setter:
            ps = [cs_param(p) for p in set_params]
            ps = [p for p in ps if p]
            sname2 = setter["name"]
            if s_iface and sname2.startswith(s_iface + "_"):
                sname2 = sname2[len(s_iface) + 1:]
            explicit = bool(s_iface and prefix)
            qn = "%s.%s" % (s_iface, sname2) if explicit else setter["name"]
            pf = "extern " if explicit else prefix
            attrs = ["\t[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]"] + list(lead)
            decls.append("\n".join(attrs) + "\n\t%svoid %s(%s);" % (pf, qn, ", ".join(ps)))
        text = text[:pre] + "\n\n".join(decls) + text[block_end:]
        pos = pre + len("\n\n".join(decls))
        edits.append({"owner": owner, "property": name, "kind": kind_of,
                      "decls": [d.replace("\n", " ") for d in decls]})
    Path(out).write_text(text, encoding="utf-8", newline="")
    print("deparameterized %d properties" % len(edits))
    for e in edits:
        print("  ", e["owner"].split(".")[-1], e["property"], "->", e["decls"][0][:130])


if __name__ == "__main__":
    main(*sys.argv[1:5])
