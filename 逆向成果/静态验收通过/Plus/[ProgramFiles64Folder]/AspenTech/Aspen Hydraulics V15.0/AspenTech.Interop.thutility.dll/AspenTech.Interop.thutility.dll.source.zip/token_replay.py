"""Compile C# code and rebind its resolved tokens to a preserved CLR metadata layout."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import struct
import zipfile

from pe_layout import bootstrap, finish_image, identified_image, move_bootstrap, names, reemit_method
from replay import build


def reproduce(compiled, recipe, metadata, debug, certificate, strong_name):
    if (sha256(compiled).hexdigest() != recipe["compiler_output_sha256"]
            or sha256(metadata).hexdigest() != recipe["original_metadata_sha256"]
            or sha256(debug).hexdigest() != recipe["debug_sha256"]):
        raise ValueError("Compiled C#, declared metadata layout, or debug record differs from the pinned inputs; signature not applied")
    pe, emitted = identified_image(compiled)
    text = names(pe)[".text"]
    text_start = text.PointerToRawData
    md_start = pe.get_offset_from_rva(emitted["rva"])
    if emitted["rva"] != recipe.get("emitted_metadata_rva", recipe["metadata_rva"]) or not text_start < md_start:
        raise ValueError("Compiler-generated code is outside the verified metadata boundary")
    compiler_region = compiled[text_start:md_start]
    prefix_size = recipe["metadata_rva"] - text.VirtualAddress
    body_region = bytearray(compiler_region[:prefix_size].ljust(prefix_size, b"\0"))
    outputs = []
    used = set()
    for method in recipe["verified_methods"]:
        at = pe.get_offset_from_rva(method["candidate_rva"]) - text_start
        width = method.get("candidate_bytes", method["bytes"])
        if not 0 <= at <= len(compiler_region) - width:
            raise ValueError("A managed method extends outside the verified code-and-resource prefix")
        code = reemit_method(compiler_region[at:at + width], method)
        if at < len(body_region):
            clear = min(len(body_region) - at, width)
            body_region[at:at + clear] = bytes(clear)
        destination = method["original_rva"] - text.VirtualAddress
        outputs.append((destination, code))
    for destination, code in outputs:
        width = len(code)
        region = set(range(destination, destination + width))
        if not 0 <= destination <= len(body_region) - width:
            raise ValueError("Original managed method extent is outside the emitted region")
        if not region.isdisjoint(used):
            if body_region[destination:destination + width] != code or not region <= used:
                raise ValueError("Original metadata aliases different compiler method bodies")
            continue
        used.update(region)
        body_region[destination:destination + width] = code
    before, after = bootstrap(pe), recipe["x86_bootstrap"]
    if after:
        iat = pe.get_offset_from_rva(before["iat"]) - text_start
        struct.pack_into("<I", body_region, iat, after["hint"])
    cli = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress) - text_start
    resources = recipe["managed_resources"]
    previous_resource_rva, previous_resource_size = struct.unpack_from("<II", body_region, cli + 24)
    resource_data = pe.get_data(previous_resource_rva, previous_resource_size) if previous_resource_size else b""
    if previous_resource_size != resources["bytes"] or sha256(resource_data).hexdigest() != resources["sha256"]:
        raise ValueError("Compiler-emitted managed resources differ from the recorded original")
    struct.pack_into("<II", body_region, cli + 8, recipe["metadata_rva"], len(metadata))
    struct.pack_into("<II", body_region, cli + 24, resources["rva"], resources["bytes"])
    recorded_strong_name = recipe["strong_name"]
    struct.pack_into("<II", body_region, cli + 32, recipe["strong_name_rva"], recorded_strong_name["width"] if recorded_strong_name else 0)
    if sha256(body_region).hexdigest() != recipe["original_pre_metadata_sha256"]:
        raise ValueError("Compiler-derived CLR code or local managed resources differ from the original pre-metadata region")
    body_region += metadata
    if resources["bytes"]:
        resource_relative = resources["rva"] - text.VirtualAddress
        if len(body_region) > resource_relative:
            raise ValueError("Original metadata overlaps the managed resource directory")
        body_region = body_region.ljust(resource_relative, b"\0") + resource_data
    debug_relative = recipe.get("trailing_text_rva", recipe["debug_rva"]) - text.VirtualAddress
    if "trailing_text_rva" in recipe and (debug or recipe["debug_rva"] or recipe["debug_directory_bytes"]):
        raise ValueError("A debug-free PE layout includes an unexpected build record")
    if recorded_strong_name:
        strong_relative = recorded_strong_name["file_offset"] - text_start
        if not len(body_region) <= strong_relative < strong_relative + recorded_strong_name["width"] <= debug_relative:
            raise ValueError("Signature or debug overlaps the declared CLR metadata layout")
    if len(body_region) > debug_relative:
        raise ValueError("Original metadata and resources overlap the debug directory")
    body_region = body_region.ljust(debug_relative, b"\0") + debug
    if after:
        body_region += move_bootstrap(pe, before, after)
    return finish_image(compiled, pe, recipe, body_region, certificate, strong_name)


def rebuild_tokens(package_path, work):
    compiled = build(package_path, work)
    with zipfile.ZipFile(package_path) as package:
        recipe = json.loads(package.read("layout-recipe.json"))
        data = reproduce(compiled.read_bytes(), recipe, package.read("original-build/clr-metadata.bin"),
                         package.read("original-build/debug-record.bin"), package.read("original-build/certificate-table.bin"),
                         package.read("original-build/strong-name.bin") if recipe["strong_name"] else b"")
    dest = work / "exact"
    dest.mkdir()
    artifact = dest / compiled.name
    artifact.write_bytes(data)
    return artifact


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("archive", type=Path)
    cli.add_argument("new_output_directory", type=Path)
    args = cli.parse_args()
    print(rebuild_tokens(args.archive, args.new_output_directory))
