#!/usr/bin/env python3
"""Per-method IL comparison (declaration type + signature pairing).

Method blocks are delimited by "} // end of method <Type>::<Name>".
The pairing key is the normalized declaration header (access/flags/return type/
name/signature).  Two levels are reported:
  full  - normalized block including .override rows and custom attributes
  body  - block minus declaration header and minus .override rows
"""
import json
import re
import sys
import difflib
from pathlib import Path

def norm(text):
    lines = []
    for ln in text.splitlines():
        ln = re.sub(r"IL_[0-9A-Fa-f]{4}:", "IL_:", ln)
        ln = re.sub(r"/\*\s*[0-9A-Fa-f]{8}\s*\*/", "/*tok*/", ln)
        ln = re.sub(r"//.*$", "", ln)
        ln = ln.rstrip()
        if ln:
            lines.append(ln)
    return "\n".join(lines)

def norm_header(h):
    h = re.sub(r"/\*\s*[0-9A-Fa-f]{8}\s*\*/", "", h)
    h = re.sub(r"//.*$", "", h, flags=re.M)
    h = h.replace("{", " ").replace("\n", " ")
    return re.sub(r"\s+", " ", h).strip()

def split(il):
    out = {}
    starts = [m.start() for m in re.finditer(r"(?m)^\t\.method\b", il)]
    for i, start in enumerate(starts):
        endm = re.search(r"\} // end of method (\S+)::(\S+)", il[start:])
        if not endm:
            continue
        block = il[start:start + endm.end()]
        header_end = block.find("{")
        header = block[:header_end] if header_end >= 0 else block
        key = norm_header(header)
        n = 2
        while key in out:
            key2 = key + "#" + str(n)
            n += 1
            if key2 not in out:
                key = key2
                break
        out[key] = {"block": norm(block), "name": endm.group(2), "type": endm.group(1),
                    "header": key}
    return out

def body_of(block):
    lines = block.splitlines()
    at = next((i for i, l in enumerate(lines) if l.strip().startswith("{")), 0)
    body = [l for l in lines[at + 1:] if not l.strip().startswith(".override")]
    return "\n".join(body)

def main(orig, cand, out):
    o = split(Path(orig).read_text(encoding="utf-8", errors="replace"))
    c = split(Path(cand).read_text(encoding="utf-8", errors="replace"))
    full_eq, body_eq, differ, only_o, only_c = [], [], [], [], []
    for k in o:
        if k not in c:
            only_o.append(o[k]["name"])
            continue
        if o[k]["block"] == c[k]["block"]:
            full_eq.append(o[k]["name"])
        else:
            differ.append({"method": o[k]["name"], "type": o[k]["type"],
                           "body_equal": body_of(o[k]["block"]) == body_of(c[k]["block"]),
                           "diff": list(difflib.unified_diff(o[k]["block"].splitlines(),
                                                             c[k]["block"].splitlines(),
                                                             lineterm="", n=0))[:16]})
        if body_of(o[k]["block"]) == body_of(c[k]["block"]):
            body_eq.append(o[k]["name"])
    only_c = [c[k]["name"] for k in c if k not in o]
    res = {"original_methods": len(o), "candidate_methods": len(c),
           "full_equal": len(full_eq), "body_equal": len(body_eq),
           "differ": len(differ), "only_original": len(only_o), "only_candidate": len(only_c),
           "only_original_list": only_o, "only_candidate_list": only_c,
           "differ_list": differ}
    Path(out).write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({k: v for k, v in res.items() if k != "differ_list"}, ensure_ascii=False))
    for d in differ:
        print("  DIFF", d["method"], "body_equal=", d["body_equal"])
        for line in d["diff"][:8]:
            print("    ", line)

if __name__ == "__main__":
    main(*sys.argv[1:4])
