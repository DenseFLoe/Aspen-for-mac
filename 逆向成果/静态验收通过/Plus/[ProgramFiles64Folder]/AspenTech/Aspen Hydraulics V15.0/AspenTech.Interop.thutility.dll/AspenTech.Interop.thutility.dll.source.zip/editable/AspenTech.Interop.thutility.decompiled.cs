using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: ImportedFromTypeLib("ThUtilityLib")]
[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: Guid("8915f1f1-5707-11d2-b8d8-00a0c986f9f7")]
[assembly: AssemblyVersion("1.0.0.0")]
namespace AspenTech.Interop.ThUtility;

[ComImport]
[Guid("5E58EFBA-3C34-11D2-B8CA-00A0C986F9F7")]
[TypeLibType(2)]
[ClassInterface((short)0)]
public class COTHRealArrayClass : IRealArrayDisp, COTHRealArray, IRealArray
{
	[DispId(1)]
	extern int IRealArrayDisp.Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern double IRealArrayDisp.get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void IRealArrayDisp.set_IthValue([In] int i, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	extern double IRealArrayDisp.get_Values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	extern void IRealArrayDisp.set_Values([In] int nSize, [In] ref double pVal);

	extern int IRealArray.Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double IRealArray.get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRealArray.set_IthValue([In] int i, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double IRealArray.get_Values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRealArray.set_Values([In] int nSize, [In] ref double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IRealArrayDisp.Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IRealArrayDisp.Copy([In][MarshalAs(UnmanagedType.Interface)] COTHRealArray pArray);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRealArray.Reset();
}
[ComImport]
[Guid("5E58EFB4-3C34-11D2-B8CA-00A0C986F9F7")]
[CoClass(typeof(COTHRealArrayClass))]
public interface COTHRealArray : IRealArrayDisp
{
}
[ComImport]
[Guid("5E58EFB4-3C34-11D2-B8CA-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IRealArrayDisp
{
	[DispId(1)]
	int Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	double get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void set_IthValue([In] int i, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void Copy([In][MarshalAs(UnmanagedType.Interface)] COTHRealArray pArray);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	double get_Values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void set_Values([In] int nSize, [In] ref double pVal);
}
[ComImport]
[Guid("5E58EFB9-3C34-11D2-B8CA-00A0C986F9F7")]
[InterfaceType(1)]
public interface IRealArray
{
	[DispId(1610678272)]
	int Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678274)]
	double get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678274)]
	void set_IthValue([In] int i, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678277)]
	double get_Values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678277)]
	void set_Values([In] int nSize, [In] ref double pVal);
}
[ComImport]
[Guid("5E58EFBC-3C34-11D2-B8CA-00A0C986F9F7")]
[ClassInterface((short)0)]
[TypeLibType(2)]
public class COTHRealMatrixClass : IRealMatrixDisp, COTHRealMatrix, IRealMatrix
{
	[DispId(1)]
	extern int IRealMatrixDisp.NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	extern int IRealMatrixDisp.NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern double IRealMatrixDisp.get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IRealMatrixDisp.set_IJthValue([In] int nRow, [In] int nColumn, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IRealMatrixDisp.get_IthRow([In] int nRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IRealMatrixDisp.set_IthRow([In] int nRow, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IRealMatrixDisp.get_IthColumn([In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	extern void IRealMatrixDisp.set_IthColumn([In] int nColumn, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	extern int IRealMatrix.NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int IRealMatrix.NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double IRealMatrix.get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRealMatrix.set_IJthValue([In] int nRow, [In] int nColumn, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double IRealMatrix.get_IthRow([In] int nRow, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRealMatrix.set_IthRow([In] int nRow, [In] int nSize, [In] ref double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern double IRealMatrix.get_IthColumn([In] int nColumn, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRealMatrix.set_IthColumn([In] int nColumn, [In] int nSize, [In] ref double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void IRealMatrixDisp.Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IRealMatrix.Reset();
}
[ComImport]
[Guid("5E58EFB6-3C34-11D2-B8CA-00A0C986F9F7")]
[CoClass(typeof(COTHRealMatrixClass))]
public interface COTHRealMatrix : IRealMatrixDisp
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("5E58EFB6-3C34-11D2-B8CA-00A0C986F9F7")]
public interface IRealMatrixDisp
{
	[DispId(1)]
	int NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	int NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	double get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void set_IJthValue([In] int nRow, [In] int nColumn, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthRow([In] int nRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void set_IthRow([In] int nRow, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthColumn([In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void set_IthColumn([In] int nColumn, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Reset();
}
[ComImport]
[Guid("5E58EFBB-3C34-11D2-B8CA-00A0C986F9F7")]
[InterfaceType(1)]
public interface IRealMatrix
{
	[DispId(1610678272)]
	int NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[DispId(1610678274)]
	int NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678276)]
	double get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678276)]
	void set_IJthValue([In] int nRow, [In] int nColumn, [In] double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678278)]
	double get_IthRow([In] int nRow, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678278)]
	void set_IthRow([In] int nRow, [In] int nSize, [In] ref double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678280)]
	double get_IthColumn([In] int nColumn, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678280)]
	void set_IthColumn([In] int nColumn, [In] int nSize, [In] ref double pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();
}
[ComImport]
[Guid("FD44DAA0-F7AF-11D4-BF8F-00A0C9B465F6")]
[ClassInterface((short)0)]
[TypeLibType(2)]
public class COTHIntegerMatrixClass : IIntegerMatrixDisp, COTHIntegerMatrix, IIntegerMatrix
{
	[DispId(1)]
	extern int IIntegerMatrixDisp.NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	extern int IIntegerMatrixDisp.NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern int IIntegerMatrixDisp.get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IIntegerMatrixDisp.set_IJthValue([In] int nRow, [In] int nColumn, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IIntegerMatrixDisp.get_IthRow([In] int nRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IIntegerMatrixDisp.set_IthRow([In] int nRow, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IIntegerMatrixDisp.get_IthColumn([In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	extern void IIntegerMatrixDisp.set_IthColumn([In] int nColumn, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	extern int IIntegerMatrix.NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	extern int IIntegerMatrix.NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IIntegerMatrix.get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIntegerMatrix.set_IJthValue([In] int nRow, [In] int nColumn, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IIntegerMatrix.get_IthRow([In] int nRow, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIntegerMatrix.set_IthRow([In] int nRow, [In] int nSize, [In] ref int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IIntegerMatrix.get_IthColumn([In] int nColumn, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIntegerMatrix.set_IthColumn([In] int nColumn, [In] int nSize, [In] ref int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void IIntegerMatrixDisp.Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIntegerMatrix.Reset();
}
[ComImport]
[Guid("6E264D70-F7B0-11D4-BF8F-00A0C9B465F6")]
[CoClass(typeof(COTHIntegerMatrixClass))]
public interface COTHIntegerMatrix : IIntegerMatrixDisp
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("6E264D70-F7B0-11D4-BF8F-00A0C9B465F6")]
public interface IIntegerMatrixDisp
{
	[DispId(1)]
	int NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[DispId(2)]
	int NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	int get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void set_IJthValue([In] int nRow, [In] int nColumn, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthRow([In] int nRow);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void set_IthRow([In] int nRow, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object get_IthColumn([In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void set_IthColumn([In] int nColumn, [In] [MarshalAs(UnmanagedType.IDispatch)] object pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Reset();
}
[ComImport]
[Guid("56EAE630-F7AF-11D4-BF8F-00A0C9B465F6")]
[InterfaceType(1)]
public interface IIntegerMatrix
{
	[DispId(1610678272)]
	int NumberOfColumns
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[DispId(1610678274)]
	int NumberOfRows
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678276)]
	int get_IJthValue([In] int nRow, [In] int nColumn);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678276)]
	void set_IJthValue([In] int nRow, [In] int nColumn, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678278)]
	int get_IthRow([In] int nRow, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678278)]
	void set_IthRow([In] int nRow, [In] int nSize, [In] ref int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678280)]
	int get_IthColumn([In] int nColumn, [In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678280)]
	void set_IthColumn([In] int nColumn, [In] int nSize, [In] ref int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();
}
[ComImport]
[ClassInterface((short)0)]
[TypeLibType(2)]
[Guid("A4BC2B72-5D6F-11D2-B8DF-00A0C986F9F7")]
public class COTHIntegerArrayClass : IIntegerArrayDisp, COTHIntegerArray, IIntegerArray
{
	[DispId(1)]
	extern int IIntegerArrayDisp.Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern int IIntegerArrayDisp.get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void IIntegerArrayDisp.set_IthValue([In] int i, [In] int pVal);

	extern int IIntegerArray.Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IIntegerArray.get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIntegerArray.set_IthValue([In] int i, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern int IIntegerArray.get_Values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIntegerArray.set_Values([In] int nSize, [In] ref int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IIntegerArrayDisp.Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IIntegerArray.Reset();
}
[ComImport]
[Guid("A4BC2B71-5D6F-11D2-B8DF-00A0C986F9F7")]
[CoClass(typeof(COTHIntegerArrayClass))]
public interface COTHIntegerArray : IIntegerArrayDisp
{
}
[ComImport]
[Guid("A4BC2B71-5D6F-11D2-B8DF-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IIntegerArrayDisp
{
	[DispId(1)]
	int Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	int get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void set_IthValue([In] int i, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void Reset();
}
[ComImport]
[InterfaceType(1)]
[Guid("A4BC2B70-5D6F-11D2-B8DF-00A0C986F9F7")]
public interface IIntegerArray
{
	[DispId(1610678272)]
	int Size
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678274)]
	int get_IthValue([In] int i);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678274)]
	void set_IthValue([In] int i, [In] int pVal);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Reset();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678277)]
	int get_Values([In] int nSize);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678277)]
	void set_Values([In] int nSize, [In] ref int pVal);
}
[ComImport]
[Guid("F4D05D1B-1DE6-46EB-BC02-B9EF55D73D07")]
[ClassInterface((short)0)]
[TypeLibType(2)]
public class COTHOptionClass : ICOTHOption, COTHOption
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern void ICOTHOption.GetNumbOptions([In][Out] ref int nOptions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void ICOTHOption.FindOption([In][Out][MarshalAs(UnmanagedType.BStr)] string sName, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void ICOTHOption.AddOption([In][MarshalAs(UnmanagedType.BStr)] string sName, [In] tagCOTHOptionType eType, [In] byte bHasSubOption, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void ICOTHOption.GetOption([In] int nIdx, [In][Out] ref tagCOTHOptionType eType, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object vValues, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object vNames, [In][Out] ref int nNames, [In][Out] ref byte bMultipleAllowed, [In][Out] ref int nMaxAllowed, [In][Out][MarshalAs(UnmanagedType.Interface)] ref COTHOption pSubOption);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	extern void ICOTHOption.SetOption([In] int nIdx, [In][MarshalAs(UnmanagedType.Struct)] object vValues, [In][MarshalAs(UnmanagedType.Struct)] object vNames, [In] int nNames, [In] byte bMultipleAllowed, [In] int nMaxAllowed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	extern void ICOTHOption.Save([In][Out][MarshalAs(UnmanagedType.BStr)] ref string sSaveInfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	extern void ICOTHOption.Recall([In][Out][MarshalAs(UnmanagedType.BStr)] string sSaveInfo);
}
[ComImport]
[CoClass(typeof(COTHOptionClass))]
[Guid("DED45C25-05C7-4FCD-8A3C-29BFF8B98E9F")]
public interface COTHOption : ICOTHOption
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("DED45C25-05C7-4FCD-8A3C-29BFF8B98E9F")]
public interface ICOTHOption
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void GetNumbOptions([In][Out] ref int nOptions);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void FindOption([In][Out][MarshalAs(UnmanagedType.BStr)] string sName, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void AddOption([In][MarshalAs(UnmanagedType.BStr)] string sName, [In] tagCOTHOptionType eType, [In] byte bHasSubOption, [In][Out] ref int nIdx);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void GetOption([In] int nIdx, [In][Out] ref tagCOTHOptionType eType, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object vValues, [In][Out][MarshalAs(UnmanagedType.Struct)] ref object vNames, [In][Out] ref int nNames, [In][Out] ref byte bMultipleAllowed, [In][Out] ref int nMaxAllowed, [In][Out][MarshalAs(UnmanagedType.Interface)] ref COTHOption pSubOption);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void SetOption([In] int nIdx, [In][MarshalAs(UnmanagedType.Struct)] object vValues, [In][MarshalAs(UnmanagedType.Struct)] object vNames, [In] int nNames, [In] byte bMultipleAllowed, [In] int nMaxAllowed);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void Save([In][Out][MarshalAs(UnmanagedType.BStr)] ref string sSaveInfo);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void Recall([In][Out][MarshalAs(UnmanagedType.BStr)] string sSaveInfo);
}
public enum tagCOTHOptionType
{
	BooleanOptionType = 1,
	RealValueOptionType,
	IntValueOptionType,
	MultiChoiceOptionType,
	MultiRealValueOptionType,
	MultiIntValueOptionType
}
