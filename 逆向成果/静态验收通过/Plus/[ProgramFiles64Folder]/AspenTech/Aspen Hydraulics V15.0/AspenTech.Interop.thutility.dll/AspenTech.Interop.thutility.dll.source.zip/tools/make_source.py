#!/usr/bin/env python3
"""Rewrite the decompiled C# so class methods are explicit interface implementations.

Why: the original is a tlbimp-shaped assembly: each class MethodDef is
`public hidebysig newslot virtual` *and* carries a MethodImpl (`.override I::M`)
row.  C# can only emit that MethodImpl row when the source uses explicit
interface implementation (`void I.M()`), which the compiler emits as
`private final hidebysig newslot virtual`.  declaration_restore.py then restores
the accessibility/name; together the pair reproduces the original declaration.
"""
import json
import re
import sys
from pathlib import Path

def overrides_from_il(il_text):
    """Return {method_name: [interface_full_name, ...]} from an ILSpy -il dump."""
    out = {}
    ends = list(re.finditer(r"\} // end of method (\S+)::(\S+)", il_text))
    start = 0
    for end in ends:
        block = il_text[start:end.start()]
        start = end.end()
        name = end.group(2)
        for m in re.finditer(r"\.override\s+method\s+.*?\s(\S+?)::(\S+?)\(", block):
            iface, oname = m.group(1), m.group(2)
            if oname != name:
                raise SystemExit("override name %s != enclosing method %s" % (oname, name))
            out.setdefault(name, []).append(iface)
    return out

def transform(source, mapping, namespace):
    lines = source.splitlines(keepends=True)
    out = []
    done = set()
    for line in lines:
        m = re.match(r"^(\t)public virtual extern (.+?) (\w+)\((.*)\);\s*$", line)
        if m and m.group(3) in mapping:
            name = m.group(3)
            ifaces = mapping[name]
            if len(ifaces) != 1:
                raise SystemExit("method %s has %d override targets" % (name, len(ifaces)))
            iface = ifaces[0].split(".")[-1]
            out.append("\textern %s %s.%s(%s);\n" % (m.group(2), iface, name, m.group(4)))
            done.add(name)
        else:
            out.append(line)
    missing = set(mapping) - done
    if missing:
        raise SystemExit("source methods not transformed: %s" % sorted(missing))
    return "".join(out)

def main():
    sha8, src, il, dst = sys.argv[1:5]
    source = Path(src).read_text(encoding="utf-8-sig")
    mapping = overrides_from_il(Path(il).read_text(encoding="utf-8", errors="replace"))
    ns = re.search(r"^namespace\s+(\S+);", source, re.M).group(1)
    result = transform(source, mapping, ns)
    Path(dst).parent.mkdir(parents=True, exist_ok=True)
    Path(dst).write_text(result, encoding="utf-8")
    print(json.dumps({"sha8": sha8, "overrides": mapping,
                      "transformed": sorted(mapping), "count": len(mapping)}, ensure_ascii=False, indent=1))

if __name__ == "__main__":
    main()
