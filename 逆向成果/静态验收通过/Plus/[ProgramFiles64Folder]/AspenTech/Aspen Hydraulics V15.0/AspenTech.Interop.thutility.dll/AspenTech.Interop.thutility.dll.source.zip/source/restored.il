// IL code: AspenTech.Interop.thutility
.class private auto ansi '<Module>'
{
} // end of class <Module>

.class public auto ansi import beforefieldinit AspenTech.Interop.ThUtility.COTHRealArrayClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThUtility.IRealArrayDisp,
	           AspenTech.Interop.ThUtility.COTHRealArray,
	           AspenTech.Interop.ThUtility.IRealArray
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 41 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IRealArrayDisp::get_Size()
	} // end of method COTHRealArrayClass::get_Size

	.method public hidebysig specialname newslot virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealArrayDisp::set_Size(int32)
	} // end of method COTHRealArrayClass::set_Size

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThUtility.IRealArrayDisp::get_IthValue(int32)
	} // end of method COTHRealArrayClass::get_IthValue

	.method public hidebysig specialname newslot virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealArrayDisp::set_IthValue(int32, float64)
	} // end of method COTHRealArrayClass::set_IthValue

	.method public hidebysig specialname newslot virtual 
		instance float64 get_Values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.override method instance float64 AspenTech.Interop.ThUtility.IRealArrayDisp::get_Values(int32)
	} // end of method COTHRealArrayClass::get_Values

	.method public hidebysig specialname newslot virtual 
		instance void set_Values (
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealArrayDisp::set_Values(int32, float64&)
	} // end of method COTHRealArrayClass::set_Values

	.method private final hidebysig specialname newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IRealArray.get_Size () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IRealArray::get_Size()
	} // end of method COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.get_Size

	.method private final hidebysig specialname newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealArray.set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealArray::set_Size(int32)
	} // end of method COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.set_Size

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThUtility.IRealArray.get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThUtility.IRealArray::get_IthValue(int32)
	} // end of method COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.get_IthValue

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealArray.set_IthValue (
			[in] int32 i,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealArray::set_IthValue(int32, float64)
	} // end of method COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.set_IthValue

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThUtility.IRealArray.get_Values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThUtility.IRealArray::get_Values(int32)
	} // end of method COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.get_Values

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealArray.set_Values (
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealArray::set_Values(int32, float64&)
	} // end of method COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.set_Values

	.method public hidebysig newslot virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealArrayDisp::Reset()
	} // end of method COTHRealArrayClass::Reset

	.method public hidebysig newslot virtual 
		instance void Copy (
			[in] class AspenTech.Interop.ThUtility.COTHRealArray marshal(interface) pArray
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealArrayDisp::Copy(class AspenTech.Interop.ThUtility.COTHRealArray)
	} // end of method COTHRealArrayClass::Copy

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealArray.Reset () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealArray::Reset()
	} // end of method COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.Reset

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHRealArrayClass::.ctor

	// Properties
	.property instance int32 AspenTech.Interop.ThUtility.IRealArrayDisp.Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.COTHRealArrayClass::get_Size()
		.set instance void AspenTech.Interop.ThUtility.COTHRealArrayClass::set_Size(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IRealArray.Size()
	{
		.get instance int32 AspenTech.Interop.ThUtility.COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.get_Size()
		.set instance void AspenTech.Interop.ThUtility.COTHRealArrayClass::AspenTech.Interop.ThUtility.IRealArray.set_Size(int32)
	}

} // end of class AspenTech.Interop.ThUtility.COTHRealArrayClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.COTHRealArray
	implements AspenTech.Interop.ThUtility.IRealArrayDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 34 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 2e 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 55 74 69 6c 69 74 79 2e 43
		4f 54 48 52 65 61 6c 41 72 72 61 79 43 6c 61 73
		73 00 00
	)
} // end of class AspenTech.Interop.ThUtility.COTHRealArray

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IRealArrayDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 34 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::get_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::set_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::get_IthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::set_IthValue

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::Reset

	.method public hidebysig newslot abstract virtual 
		instance void Copy (
			[in] class AspenTech.Interop.ThUtility.COTHRealArray marshal(interface) pArray
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealArrayDisp::Copy

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IRealArrayDisp::get_Values

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Values (
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method IRealArrayDisp::set_Values

	// Properties
	.property instance int32 Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IRealArrayDisp::get_Size()
		.set instance void AspenTech.Interop.ThUtility.IRealArrayDisp::set_Size(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IRealArrayDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IRealArray
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 39 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
	} // end of method IRealArray::get_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
	} // end of method IRealArray::set_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
	} // end of method IRealArray::get_IthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
	} // end of method IRealArray::set_IthValue

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
	} // end of method IRealArray::Reset

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_Values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 01 60 00 00
		)
	} // end of method IRealArray::get_Values

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Values (
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 01 60 00 00
		)
	} // end of method IRealArray::set_Values

	// Properties
	.property instance int32 Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 01 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IRealArray::get_Size()
		.set instance void AspenTech.Interop.ThUtility.IRealArray::set_Size(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IRealArray

.class public auto ansi import beforefieldinit AspenTech.Interop.ThUtility.COTHRealMatrixClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThUtility.IRealMatrixDisp,
	           AspenTech.Interop.ThUtility.COTHRealMatrix,
	           AspenTech.Interop.ThUtility.IRealMatrix
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 43 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IRealMatrixDisp::get_NumberOfColumns()
	} // end of method COTHRealMatrixClass::get_NumberOfColumns

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::set_NumberOfColumns(int32)
	} // end of method COTHRealMatrixClass::set_NumberOfColumns

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IRealMatrixDisp::get_NumberOfRows()
	} // end of method COTHRealMatrixClass::get_NumberOfRows

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::set_NumberOfRows(int32)
	} // end of method COTHRealMatrixClass::set_NumberOfRows

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance float64 AspenTech.Interop.ThUtility.IRealMatrixDisp::get_IJthValue(int32, int32)
	} // end of method COTHRealMatrixClass::get_IJthValue

	.method public hidebysig specialname newslot virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::set_IJthValue(int32, int32, float64)
	} // end of method COTHRealMatrixClass::set_IJthValue

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_IthRow (
			[in] int32 nRow
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThUtility.IRealMatrixDisp::get_IthRow(int32)
	} // end of method COTHRealMatrixClass::get_IthRow

	.method public hidebysig specialname newslot virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::set_IthRow(int32, object)
	} // end of method COTHRealMatrixClass::set_IthRow

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_IthColumn (
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThUtility.IRealMatrixDisp::get_IthColumn(int32)
	} // end of method COTHRealMatrixClass::get_IthColumn

	.method public hidebysig specialname newslot virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::set_IthColumn(int32, object)
	} // end of method COTHRealMatrixClass::set_IthColumn

	.method private final hidebysig specialname newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IRealMatrix.get_NumberOfColumns () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IRealMatrix::get_NumberOfColumns()
	} // end of method COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.get_NumberOfColumns

	.method private final hidebysig specialname newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealMatrix.set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrix::set_NumberOfColumns(int32)
	} // end of method COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.set_NumberOfColumns

	.method private final hidebysig specialname newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IRealMatrix.get_NumberOfRows () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IRealMatrix::get_NumberOfRows()
	} // end of method COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.get_NumberOfRows

	.method private final hidebysig specialname newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealMatrix.set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrix::set_NumberOfRows(int32)
	} // end of method COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.set_NumberOfRows

	.method private final hidebysig newslot virtual 
		instance float64 AspenTech.Interop.ThUtility.IRealMatrix.get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThUtility.IRealMatrix::get_IJthValue(int32, int32)
	} // end of method COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.get_IJthValue

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealMatrix.set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrix::set_IJthValue(int32, int32, float64)
	} // end of method COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.set_IJthValue

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IthRow (
			[in] int32 nRow,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThUtility.IRealMatrix::get_IthRow(int32, int32)
	} // end of method COTHRealMatrixClass::get_IthRow

	.method public hidebysig specialname newslot virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrix::set_IthRow(int32, int32, float64&)
	} // end of method COTHRealMatrixClass::set_IthRow

	.method public hidebysig specialname newslot virtual 
		instance float64 get_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.override method instance float64 AspenTech.Interop.ThUtility.IRealMatrix::get_IthColumn(int32, int32)
	} // end of method COTHRealMatrixClass::get_IthColumn

	.method public hidebysig specialname newslot virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrix::set_IthColumn(int32, int32, float64&)
	} // end of method COTHRealMatrixClass::set_IthColumn

	.method public hidebysig newslot virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::Reset()
	} // end of method COTHRealMatrixClass::Reset

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IRealMatrix.Reset () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IRealMatrix::Reset()
	} // end of method COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.Reset

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHRealMatrixClass::.ctor

	// Properties
	.property instance int32 AspenTech.Interop.ThUtility.IRealMatrixDisp.NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.COTHRealMatrixClass::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.COTHRealMatrixClass::set_NumberOfColumns(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IRealMatrixDisp.NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.COTHRealMatrixClass::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.COTHRealMatrixClass::set_NumberOfRows(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IRealMatrix.NumberOfColumns()
	{
		.get instance int32 AspenTech.Interop.ThUtility.COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.set_NumberOfColumns(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IRealMatrix.NumberOfRows()
	{
		.get instance int32 AspenTech.Interop.ThUtility.COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.COTHRealMatrixClass::AspenTech.Interop.ThUtility.IRealMatrix.set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThUtility.COTHRealMatrixClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.COTHRealMatrix
	implements AspenTech.Interop.ThUtility.IRealMatrixDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 36 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 2f 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 55 74 69 6c 69 74 79 2e 43
		4f 54 48 52 65 61 6c 4d 61 74 72 69 78 43 6c 61
		73 73 00 00
	)
} // end of class AspenTech.Interop.ThUtility.COTHRealMatrix

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IRealMatrixDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 36 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthRow (
			[in] int32 nRow
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthColumn (
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::get_IthColumn

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::set_IthColumn

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IRealMatrixDisp::Reset

	// Properties
	.property instance int32 NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IRealMatrixDisp::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::set_NumberOfColumns(int32)
	}
	.property instance int32 NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IRealMatrixDisp::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.IRealMatrixDisp::set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IRealMatrixDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IRealMatrix
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 45 35 38 45 46 42 42 2d 33 43 33 34
		2d 31 31 44 32 2d 42 38 43 41 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
	} // end of method IRealMatrix::get_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
	} // end of method IRealMatrix::set_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
	} // end of method IRealMatrix::get_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
	} // end of method IRealMatrix::set_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 01 60 00 00
		)
	} // end of method IRealMatrix::get_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] float64 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 01 60 00 00
		)
	} // end of method IRealMatrix::set_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IthRow (
			[in] int32 nRow,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 01 60 00 00
		)
	} // end of method IRealMatrix::get_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 01 60 00 00
		)
	} // end of method IRealMatrix::set_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance float64 get_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 01 60 00 00
		)
	} // end of method IRealMatrix::get_IthColumn

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize,
			[in] float64& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 01 60 00 00
		)
	} // end of method IRealMatrix::set_IthColumn

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
	} // end of method IRealMatrix::Reset

	// Properties
	.property instance int32 NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 01 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IRealMatrix::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.IRealMatrix::set_NumberOfColumns(int32)
	}
	.property instance int32 NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IRealMatrix::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.IRealMatrix::set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IRealMatrix

.class public auto ansi import beforefieldinit AspenTech.Interop.ThUtility.COTHIntegerMatrixClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThUtility.IIntegerMatrixDisp,
	           AspenTech.Interop.ThUtility.COTHIntegerMatrix,
	           AspenTech.Interop.ThUtility.IIntegerMatrix
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 44 34 34 44 41 41 30 2d 46 37 41 46
		2d 31 31 44 34 2d 42 46 38 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrixDisp::get_NumberOfColumns()
	} // end of method COTHIntegerMatrixClass::get_NumberOfColumns

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::set_NumberOfColumns(int32)
	} // end of method COTHIntegerMatrixClass::set_NumberOfColumns

	.method public hidebysig specialname newslot virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrixDisp::get_NumberOfRows()
	} // end of method COTHIntegerMatrixClass::get_NumberOfRows

	.method public hidebysig specialname newslot virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::set_NumberOfRows(int32)
	} // end of method COTHIntegerMatrixClass::set_NumberOfRows

	.method public hidebysig specialname newslot virtual 
		instance int32 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrixDisp::get_IJthValue(int32, int32)
	} // end of method COTHIntegerMatrixClass::get_IJthValue

	.method public hidebysig specialname newslot virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::set_IJthValue(int32, int32, int32)
	} // end of method COTHIntegerMatrixClass::set_IJthValue

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_IthRow (
			[in] int32 nRow
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThUtility.IIntegerMatrixDisp::get_IthRow(int32)
	} // end of method COTHIntegerMatrixClass::get_IthRow

	.method public hidebysig specialname newslot virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::set_IthRow(int32, object)
	} // end of method COTHIntegerMatrixClass::set_IthRow

	.method public hidebysig specialname newslot virtual 
		instance object marshal(idispatch) get_IthColumn (
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance object AspenTech.Interop.ThUtility.IIntegerMatrixDisp::get_IthColumn(int32)
	} // end of method COTHIntegerMatrixClass::get_IthColumn

	.method public hidebysig specialname newslot virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::set_IthColumn(int32, object)
	} // end of method COTHIntegerMatrixClass::set_IthColumn

	.method private final hidebysig specialname newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix.get_NumberOfColumns () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix::get_NumberOfColumns()
	} // end of method COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.get_NumberOfColumns

	.method private final hidebysig specialname newslot virtual 
		instance void AspenTech.Interop.ThUtility.IIntegerMatrix.set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrix::set_NumberOfColumns(int32)
	} // end of method COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.set_NumberOfColumns

	.method private final hidebysig specialname newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix.get_NumberOfRows () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix::get_NumberOfRows()
	} // end of method COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.get_NumberOfRows

	.method private final hidebysig specialname newslot virtual 
		instance void AspenTech.Interop.ThUtility.IIntegerMatrix.set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrix::set_NumberOfRows(int32)
	} // end of method COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.set_NumberOfRows

	.method private final hidebysig newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix.get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix::get_IJthValue(int32, int32)
	} // end of method COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.get_IJthValue

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IIntegerMatrix.set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrix::set_IJthValue(int32, int32, int32)
	} // end of method COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.set_IJthValue

	.method public hidebysig specialname newslot virtual 
		instance int32 get_IthRow (
			[in] int32 nRow,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix::get_IthRow(int32, int32)
	} // end of method COTHIntegerMatrixClass::get_IthRow

	.method public hidebysig specialname newslot virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] int32 nSize,
			[in] int32& pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrix::set_IthRow(int32, int32, int32&)
	} // end of method COTHIntegerMatrixClass::set_IthRow

	.method public hidebysig specialname newslot virtual 
		instance int32 get_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix::get_IthColumn(int32, int32)
	} // end of method COTHIntegerMatrixClass::get_IthColumn

	.method public hidebysig specialname newslot virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize,
			[in] int32& pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrix::set_IthColumn(int32, int32, int32&)
	} // end of method COTHIntegerMatrixClass::set_IthColumn

	.method public hidebysig newslot virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::Reset()
	} // end of method COTHIntegerMatrixClass::Reset

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IIntegerMatrix.Reset () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerMatrix::Reset()
	} // end of method COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.Reset

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHIntegerMatrixClass::.ctor

	// Properties
	.property instance int32 AspenTech.Interop.ThUtility.IIntegerMatrixDisp.NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::set_NumberOfColumns(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IIntegerMatrixDisp.NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::set_NumberOfRows(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix.NumberOfColumns()
	{
		.get instance int32 AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.set_NumberOfColumns(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix.NumberOfRows()
	{
		.get instance int32 AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.COTHIntegerMatrixClass::AspenTech.Interop.ThUtility.IIntegerMatrix.set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThUtility.COTHIntegerMatrixClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.COTHIntegerMatrix
	implements AspenTech.Interop.ThUtility.IIntegerMatrixDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 45 32 36 34 44 37 30 2d 46 37 42 30
		2d 31 31 44 34 2d 42 46 38 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 32 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 55 74 69 6c 69 74 79 2e 43
		4f 54 48 49 6e 74 65 67 65 72 4d 61 74 72 69 78
		43 6c 61 73 73 00 00
	)
} // end of class AspenTech.Interop.ThUtility.COTHIntegerMatrix

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IIntegerMatrixDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 45 32 36 34 44 37 30 2d 46 37 42 30
		2d 31 31 44 34 2d 42 46 38 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthRow (
			[in] int32 nRow
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance object marshal(idispatch) get_IthColumn (
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::get_IthColumn

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] object marshal(idispatch) pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::set_IthColumn

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method IIntegerMatrixDisp::Reset

	// Properties
	.property instance int32 NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IIntegerMatrixDisp::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::set_NumberOfColumns(int32)
	}
	.property instance int32 NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IIntegerMatrixDisp::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.IIntegerMatrixDisp::set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IIntegerMatrixDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IIntegerMatrix
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 36 45 41 45 36 33 30 2d 46 37 41 46
		2d 31 31 44 34 2d 42 46 38 46 2d 30 30 41 30 43
		39 42 34 36 35 46 36 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfColumns () runtime managed internalcall 
	{
	} // end of method IIntegerMatrix::get_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfColumns (
			[in] int32 'value'
		) runtime managed internalcall 
	{
	} // end of method IIntegerMatrix::set_NumberOfColumns

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NumberOfRows () runtime managed internalcall 
	{
	} // end of method IIntegerMatrix::get_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_NumberOfRows (
			[in] int32 'value'
		) runtime managed internalcall 
	{
	} // end of method IIntegerMatrix::set_NumberOfRows

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 01 60 00 00
		)
	} // end of method IIntegerMatrix::get_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IJthValue (
			[in] int32 nRow,
			[in] int32 nColumn,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 01 60 00 00
		)
	} // end of method IIntegerMatrix::set_IJthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IthRow (
			[in] int32 nRow,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 01 60 00 00
		)
	} // end of method IIntegerMatrix::get_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthRow (
			[in] int32 nRow,
			[in] int32 nSize,
			[in] int32& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 01 60 00 00
		)
	} // end of method IIntegerMatrix::set_IthRow

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 01 60 00 00
		)
	} // end of method IIntegerMatrix::get_IthColumn

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthColumn (
			[in] int32 nColumn,
			[in] int32 nSize,
			[in] int32& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 01 60 00 00
		)
	} // end of method IIntegerMatrix::set_IthColumn

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
	} // end of method IIntegerMatrix::Reset

	// Properties
	.property instance int32 NumberOfColumns()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 01 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix::get_NumberOfColumns()
		.set instance void AspenTech.Interop.ThUtility.IIntegerMatrix::set_NumberOfColumns(int32)
	}
	.property instance int32 NumberOfRows()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IIntegerMatrix::get_NumberOfRows()
		.set instance void AspenTech.Interop.ThUtility.IIntegerMatrix::set_NumberOfRows(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IIntegerMatrix

.class public auto ansi import beforefieldinit AspenTech.Interop.ThUtility.COTHIntegerArrayClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThUtility.IIntegerArrayDisp,
	           AspenTech.Interop.ThUtility.COTHIntegerArray,
	           AspenTech.Interop.ThUtility.IIntegerArray
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 34 42 43 32 42 37 32 2d 35 44 36 46
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerArrayDisp::get_Size()
	} // end of method COTHIntegerArrayClass::get_Size

	.method public hidebysig specialname newslot virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerArrayDisp::set_Size(int32)
	} // end of method COTHIntegerArrayClass::set_Size

	.method public hidebysig specialname newslot virtual 
		instance int32 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerArrayDisp::get_IthValue(int32)
	} // end of method COTHIntegerArrayClass::get_IthValue

	.method public hidebysig specialname newslot virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerArrayDisp::set_IthValue(int32, int32)
	} // end of method COTHIntegerArrayClass::set_IthValue

	.method private final hidebysig specialname newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IIntegerArray.get_Size () runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerArray::get_Size()
	} // end of method COTHIntegerArrayClass::AspenTech.Interop.ThUtility.IIntegerArray.get_Size

	.method private final hidebysig specialname newslot virtual 
		instance void AspenTech.Interop.ThUtility.IIntegerArray.set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerArray::set_Size(int32)
	} // end of method COTHIntegerArrayClass::AspenTech.Interop.ThUtility.IIntegerArray.set_Size

	.method private final hidebysig newslot virtual 
		instance int32 AspenTech.Interop.ThUtility.IIntegerArray.get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerArray::get_IthValue(int32)
	} // end of method COTHIntegerArrayClass::AspenTech.Interop.ThUtility.IIntegerArray.get_IthValue

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IIntegerArray.set_IthValue (
			[in] int32 i,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerArray::set_IthValue(int32, int32)
	} // end of method COTHIntegerArrayClass::AspenTech.Interop.ThUtility.IIntegerArray.set_IthValue

	.method public hidebysig specialname newslot virtual 
		instance int32 get_Values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.override method instance int32 AspenTech.Interop.ThUtility.IIntegerArray::get_Values(int32)
	} // end of method COTHIntegerArrayClass::get_Values

	.method public hidebysig specialname newslot virtual 
		instance void set_Values (
			[in] int32 nSize,
			[in] int32& pVal
		) runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerArray::set_Values(int32, int32&)
	} // end of method COTHIntegerArrayClass::set_Values

	.method public hidebysig newslot virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.IIntegerArrayDisp::Reset()
	} // end of method COTHIntegerArrayClass::Reset

	.method private final hidebysig newslot virtual 
		instance void AspenTech.Interop.ThUtility.IIntegerArray.Reset () runtime managed internalcall 
	{
		.override method instance void AspenTech.Interop.ThUtility.IIntegerArray::Reset()
	} // end of method COTHIntegerArrayClass::AspenTech.Interop.ThUtility.IIntegerArray.Reset

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHIntegerArrayClass::.ctor

	// Properties
	.property instance int32 AspenTech.Interop.ThUtility.IIntegerArrayDisp.Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.COTHIntegerArrayClass::get_Size()
		.set instance void AspenTech.Interop.ThUtility.COTHIntegerArrayClass::set_Size(int32)
	}
	.property instance int32 AspenTech.Interop.ThUtility.IIntegerArray.Size()
	{
		.get instance int32 AspenTech.Interop.ThUtility.COTHIntegerArrayClass::AspenTech.Interop.ThUtility.IIntegerArray.get_Size()
		.set instance void AspenTech.Interop.ThUtility.COTHIntegerArrayClass::AspenTech.Interop.ThUtility.IIntegerArray.set_Size(int32)
	}

} // end of class AspenTech.Interop.ThUtility.COTHIntegerArrayClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.COTHIntegerArray
	implements AspenTech.Interop.ThUtility.IIntegerArrayDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 34 42 43 32 42 37 31 2d 35 44 36 46
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 31 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 55 74 69 6c 69 74 79 2e 43
		4f 54 48 49 6e 74 65 67 65 72 41 72 72 61 79 43
		6c 61 73 73 00 00
	)
} // end of class AspenTech.Interop.ThUtility.COTHIntegerArray

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IIntegerArrayDisp
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 34 42 43 32 42 37 31 2d 35 44 36 46
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::get_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::set_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::get_IthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::set_IthValue

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method IIntegerArrayDisp::Reset

	// Properties
	.property instance int32 Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IIntegerArrayDisp::get_Size()
		.set instance void AspenTech.Interop.ThUtility.IIntegerArrayDisp::set_Size(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IIntegerArrayDisp

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.IIntegerArray
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 34 42 43 32 42 37 30 2d 35 44 36 46
		2d 31 31 44 32 2d 42 38 44 46 2d 30 30 41 30 43
		39 38 36 46 39 46 37 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Size () runtime managed internalcall 
	{
	} // end of method IIntegerArray::get_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Size (
			[in] int32 'value'
		) runtime managed internalcall 
	{
	} // end of method IIntegerArray::set_Size

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_IthValue (
			[in] int32 i
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
	} // end of method IIntegerArray::get_IthValue

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_IthValue (
			[in] int32 i,
			[in] int32 pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
	} // end of method IIntegerArray::set_IthValue

	.method public hidebysig newslot abstract virtual 
		instance void Reset () runtime managed internalcall 
	{
	} // end of method IIntegerArray::Reset

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_Values (
			[in] int32 nSize
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 01 60 00 00
		)
	} // end of method IIntegerArray::get_Values

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Values (
			[in] int32 nSize,
			[in] int32& pVal
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 01 60 00 00
		)
	} // end of method IIntegerArray::set_Values

	// Properties
	.property instance int32 Size()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 01 60 00 00
		)
		.get instance int32 AspenTech.Interop.ThUtility.IIntegerArray::get_Size()
		.set instance void AspenTech.Interop.ThUtility.IIntegerArray::set_Size(int32)
	}

} // end of class AspenTech.Interop.ThUtility.IIntegerArray

.class public auto ansi import beforefieldinit AspenTech.Interop.ThUtility.COTHOptionClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.ThUtility.ICOTHOption,
	           AspenTech.Interop.ThUtility.COTHOption
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 46 34 44 30 35 44 31 42 2d 31 44 45 36
		2d 34 36 45 42 2d 42 43 30 32 2d 42 39 45 46 35
		35 44 37 33 44 30 37 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public hidebysig newslot virtual 
		instance void GetNumbOptions (
			[in] [out] int32& nOptions
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.ICOTHOption::GetNumbOptions(int32&)
	} // end of method COTHOptionClass::GetNumbOptions

	.method public hidebysig newslot virtual 
		instance void FindOption (
			[in] [out] string marshal(bstr) sName,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.ICOTHOption::FindOption(string, int32&)
	} // end of method COTHOptionClass::FindOption

	.method public hidebysig newslot virtual 
		instance void AddOption (
			[in] string marshal(bstr) sName,
			[in] valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType eType,
			[in] uint8 bHasSubOption,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.ICOTHOption::AddOption(string, valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType, uint8, int32&)
	} // end of method COTHOptionClass::AddOption

	.method public hidebysig newslot virtual 
		instance void GetOption (
			[in] int32 nIdx,
			[in] [out] valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType& eType,
			[in] [out] object& marshal(struct) vValues,
			[in] [out] object& marshal(struct) vNames,
			[in] [out] int32& nNames,
			[in] [out] uint8& bMultipleAllowed,
			[in] [out] int32& nMaxAllowed,
			[in] [out] class AspenTech.Interop.ThUtility.COTHOption& marshal(interface) pSubOption
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.ICOTHOption::GetOption(int32, valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType&, object&, object&, int32&, uint8&, int32&, class AspenTech.Interop.ThUtility.COTHOption&)
	} // end of method COTHOptionClass::GetOption

	.method public hidebysig newslot virtual 
		instance void SetOption (
			[in] int32 nIdx,
			[in] object marshal(struct) vValues,
			[in] object marshal(struct) vNames,
			[in] int32 nNames,
			[in] uint8 bMultipleAllowed,
			[in] int32 nMaxAllowed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.ICOTHOption::SetOption(int32, object, object, int32, uint8, int32)
	} // end of method COTHOptionClass::SetOption

	.method public hidebysig newslot virtual 
		instance void Save (
			[in] [out] string& marshal(bstr) sSaveInfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.ICOTHOption::Save(string&)
	} // end of method COTHOptionClass::Save

	.method public hidebysig newslot virtual 
		instance void Recall (
			[in] [out] string marshal(bstr) sSaveInfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
		.override method instance void AspenTech.Interop.ThUtility.ICOTHOption::Recall(string)
	} // end of method COTHOptionClass::Recall

	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method COTHOptionClass::.ctor

} // end of class AspenTech.Interop.ThUtility.COTHOptionClass

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.COTHOption
	implements AspenTech.Interop.ThUtility.ICOTHOption
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 2b 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 54 68 55 74 69 6c 69 74 79 2e 43
		4f 54 48 4f 70 74 69 6f 6e 43 6c 61 73 73 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 45 44 34 35 43 32 35 2d 30 35 43 37
		2d 34 46 43 44 2d 38 41 33 43 2d 32 39 42 46 46
		38 42 39 38 45 39 46 00 00
	)
} // end of class AspenTech.Interop.ThUtility.COTHOption

.class interface public auto ansi abstract import beforefieldinit AspenTech.Interop.ThUtility.ICOTHOption
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 45 44 34 35 43 32 35 2d 30 35 43 37
		2d 34 46 43 44 2d 38 41 33 43 2d 32 39 42 46 46
		38 42 39 38 45 39 46 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void GetNumbOptions (
			[in] [out] int32& nOptions
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 00 00 00 00
		)
	} // end of method ICOTHOption::GetNumbOptions

	.method public hidebysig newslot abstract virtual 
		instance void FindOption (
			[in] [out] string marshal(bstr) sName,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 00 00 00 00
		)
	} // end of method ICOTHOption::FindOption

	.method public hidebysig newslot abstract virtual 
		instance void AddOption (
			[in] string marshal(bstr) sName,
			[in] valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType eType,
			[in] uint8 bHasSubOption,
			[in] [out] int32& nIdx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 00 00 00 00
		)
	} // end of method ICOTHOption::AddOption

	.method public hidebysig newslot abstract virtual 
		instance void GetOption (
			[in] int32 nIdx,
			[in] [out] valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType& eType,
			[in] [out] object& marshal(struct) vValues,
			[in] [out] object& marshal(struct) vNames,
			[in] [out] int32& nNames,
			[in] [out] uint8& bMultipleAllowed,
			[in] [out] int32& nMaxAllowed,
			[in] [out] class AspenTech.Interop.ThUtility.COTHOption& marshal(interface) pSubOption
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 00 00 00 00
		)
	} // end of method ICOTHOption::GetOption

	.method public hidebysig newslot abstract virtual 
		instance void SetOption (
			[in] int32 nIdx,
			[in] object marshal(struct) vValues,
			[in] object marshal(struct) vNames,
			[in] int32 nNames,
			[in] uint8 bMultipleAllowed,
			[in] int32 nMaxAllowed
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 00 00 00 00
		)
	} // end of method ICOTHOption::SetOption

	.method public hidebysig newslot abstract virtual 
		instance void Save (
			[in] [out] string& marshal(bstr) sSaveInfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 00 00 00 00
		)
	} // end of method ICOTHOption::Save

	.method public hidebysig newslot abstract virtual 
		instance void Recall (
			[in] [out] string marshal(bstr) sSaveInfo
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 00 00 00 00
		)
	} // end of method ICOTHOption::Recall

} // end of class AspenTech.Interop.ThUtility.ICOTHOption

.class public auto ansi sealed AspenTech.Interop.ThUtility.tagCOTHOptionType
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType BooleanOptionType = int32(1)
	.field public static literal valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType RealValueOptionType = int32(2)
	.field public static literal valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType IntValueOptionType = int32(3)
	.field public static literal valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType MultiChoiceOptionType = int32(4)
	.field public static literal valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType MultiRealValueOptionType = int32(5)
	.field public static literal valuetype AspenTech.Interop.ThUtility.tagCOTHOptionType MultiIntValueOptionType = int32(6)

} // end of class AspenTech.Interop.ThUtility.tagCOTHOptionType

You are not using the latest version of the tool, please update.
Latest version is '11.2.0.10050' (yours is '9.1.0.7988')
