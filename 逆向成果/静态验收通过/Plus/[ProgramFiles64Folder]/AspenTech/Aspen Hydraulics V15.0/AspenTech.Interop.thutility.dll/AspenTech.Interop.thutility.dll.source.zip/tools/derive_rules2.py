#!/usr/bin/env python3
"""Derive declaration_restore rules (name-preferred pairing).

Local extension of work/managed-override-1/derive_rules.py: within a bucket of
(owning TypeDef full name + signature blob), candidates are matched by exact or
suffix name first and only then by occurrence order.  This keeps `.ctor` from
being mispaired with an explicit interface member that has the same `void()`
signature, and keeps same-name property accessors stable when a sibling method
signature differs because a dependent assembly is absent.

Usage: derive_rules2.py <original> <candidate> <out.json>
"""
import json
import sys
from pathlib import Path

ROUTER = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROUTER / "managed"))
sys.path.insert(0, str(ROUTER.parents[1] / "aspen-acceptance-work" / "deps"))
import clr_meta  # noqa: E402


def rows(path):
    data = Path(path).read_bytes()
    pe, cli, root = clr_meta.read_image(data)
    methods = clr_meta.method_defs(pe, cli, root)
    owner = {}
    trows = root["tables"]["layout"].get(0x02, {}).get("rows", 0)
    for index in range(1, trows + 1):
        row = clr_meta.read_row(root["bytes"], root["tables"], 0x02, index)
        name = clr_meta.strings(pe, cli, root, row[1])
        ns = clr_meta.strings(pe, cli, root, row[2])
        full = (ns + "." if ns else "") + name
        first = row[5]
        last = (clr_meta.read_row(root["bytes"], root["tables"], 0x02, index + 1)[5]
                if index < trows else len(methods) + 1)
        for m in range(first, last):
            owner[m] = full
    out = []
    for r in methods:
        out.append({"row": r["row"], "token": r["token"],
                    "name": clr_meta.strings(pe, cli, root, r["name_index"]),
                    "flags": r["flags"],
                    "sig": clr_meta.blob(pe, cli, root, r["signature_index"]),
                    "owner": owner.get(r["row"], "?")})
    return out


def main(orig_path, cand_path, out_path):
    o, c = rows(orig_path), rows(cand_path)
    buckets = {}
    for row in c:
        buckets.setdefault((row["owner"], row["sig"]), []).append(row)
    rules, pairs, problems = [], [], []
    used = {}
    for a in o:
        key = (a["owner"], a["sig"])
        pool = buckets.get(key, [])
        taken = used.setdefault(key, set())
        free = [x for x in pool if x["row"] not in taken]
        def name_match(cn, on):
            if cn == on or cn.endswith("." + on):
                return True
            return cn.replace(".", "_").endswith(on)
        named = [x for x in free if name_match(x["name"], a["name"])]
        pool_n = named or free
        if not pool_n:
            # Same owner only: a signature blob may differ solely because a
            # TypeRef coded index points at a different row when a dependent
            # assembly is referenced through a local reference shim.  Fall back
            # to the exact/suffix method name inside the SAME TypeDef, never
            # across types.
            owner_bucket = [x for x in c
                            if x["owner"] == a["owner"] and x["row"] not in taken
                            and name_match(x["name"], a["name"])
                            and x["sig"][0:2] == a["sig"][0:2]]
            pool_n = owner_bucket
        if not pool_n:
            problems.append({"original": a["name"], "owner": a["owner"]})
            continue
        b = pool_n[0]
        taken.add(b["row"])
        name_ok = name_match(b["name"], a["name"])
        pair = {"owner": a["owner"], "original_row": a["row"], "candidate_row": b["row"],
                "original_name": a["name"], "candidate_name": b["name"],
                "original_flags": a["flags"], "candidate_flags": b["flags"],
                "flags_equal": a["flags"] == b["flags"], "name_shape_ok": name_ok}
        pairs.append(pair)
        if not name_ok:
            problems.append({"original": a["name"], "candidate": b["name"], "owner": a["owner"],
                             "reason": "name suffix mismatch"})
        if a["flags"] != b["flags"]:
            rules.append({"target_name": a["name"], "expected_flags": b["flags"],
                          "target_flags": a["flags"], "_candidate_row": b["row"],
                          "_candidate_name": b["name"], "_owner": a["owner"],
                          "owner_type": a["owner"]})
    result = {"rules": rules, "pairs": pairs, "problems": problems,
              "counts": {"original": len(o), "candidate": len(c),
                         "paired": len(pairs), "rule_count": len(rules),
                         "flags_diff": sum(1 for p in pairs if not p["flags_equal"])}}
    Path(out_path).write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps(result["counts"], ensure_ascii=False))
    for r in rules:
        print("  rule %-28s %-38s %#06x -> %#06x" % (r["target_name"], r["_candidate_name"],
                                                     r["expected_flags"], r["target_flags"]))
    for p in problems:
        print("  PROBLEM", p)


if __name__ == "__main__":
    main(*sys.argv[1:4])
