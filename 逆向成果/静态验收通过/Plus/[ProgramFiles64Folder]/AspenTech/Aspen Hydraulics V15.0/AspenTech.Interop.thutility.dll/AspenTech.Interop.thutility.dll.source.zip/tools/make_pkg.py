#!/usr/bin/env python3
"""Assemble a replay package zip for one item (build-plan + source + assets)."""
import json, sys, zipfile
from hashlib import sha256
from pathlib import Path
import pefile

def digest(b): return sha256(b).hexdigest()

def main(pkg_dir, source, original, out_zip):
    pkg, source, original = Path(pkg_dir), Path(source), Path(original)
    plan = json.loads((pkg / "build-plan.json").read_text(encoding="utf-8"))
    src_member = "editable/" + source.name
    plan["build_input_sha256"][src_member] = digest(source.read_bytes())
    members = {}
    for name in plan["build_input_sha256"]:
        if name == src_member:
            members[name] = source.read_bytes()
        elif (pkg / name).is_file():
            members[name] = (pkg / name).read_bytes()
        else:
            raise SystemExit("missing build input: " + name)
    for name in ("original-build/debug-record.bin", "original-build/certificate-table.bin",
                 "original-build/strong-name.bin"):
        members[name] = (pkg / name).read_bytes()
    data = original.read_bytes()
    pe = pefile.PE(data=data, fast_load=True)
    clr = pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    clr_off = pe.get_offset_from_rva(clr.VirtualAddress)
    header = data[clr_off:clr_off + 72]
    import struct
    md_rva, md_size = struct.unpack_from("<II", header, 8)
    members["original-build/clr-metadata.bin"] = pe.get_data(md_rva, md_size)
    members["original-build/clr-header.bin"] = header
    plan["x86_layout_extension"] = {
        "why": ".NET 1.1 tlbimp originals place the strong-name signature between the "
               "CLR header and the metadata root; Roslyn places it after metadata.",
        "clr_header_member": "original-build/clr-header.bin",
        "clr_header_sha256": digest(header),
        "strong_name_before_metadata": True,
    }
    members["build-plan.json"] = (json.dumps(plan, ensure_ascii=False, indent=1) + "\n").encode()
    out_zip = Path(out_zip)
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(members):
            z.writestr(name, members[name])
    print(json.dumps({"package": str(out_zip), "sha256": digest(out_zip.read_bytes()),
                      "members": sorted(members), "source_sha256": digest(source.read_bytes()),
                      "plan": {k: plan[k] for k in ("assembly_name", "original_sha256")}},
                     ensure_ascii=False, indent=1))

if __name__ == "__main__":
    main(*sys.argv[1:5])
