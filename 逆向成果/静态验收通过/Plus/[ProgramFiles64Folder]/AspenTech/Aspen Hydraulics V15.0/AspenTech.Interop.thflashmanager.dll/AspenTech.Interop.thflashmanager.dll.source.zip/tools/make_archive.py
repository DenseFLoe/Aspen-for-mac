#!/usr/bin/env python3
"""Create rebuild/<sha8>/<name>.v4.zip and append receipt archive_version/history."""
import json, sys, zipfile
from hashlib import sha256
from pathlib import Path

ROUTER = Path(__file__).resolve().parents[2]      # router
WORK = Path(__file__).resolve().parent

def digest(b): return sha256(b).hexdigest()

def main(sha8, name, original):
    original = Path(original)
    w = WORK / sha8
    rebuild = ROUTER / "rebuild" / sha8
    source = next((w / "editable").glob("*.cs"))
    receipt_path = rebuild / "receipt.json"
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    raw = w / "raw" / name
    restored = w / "restored" / name
    exact = w / "replay-final" / "exact" / name
    rec = dict(receipt)
    rec.update({
        "name": name,
        "original_sha256": digest(original.read_bytes()),
        "original_path": str(original),
        "status": "passed",
        "candidate_sha256": digest(raw.read_bytes()),
        "restored_candidate_sha256": digest(restored.read_bytes()),
        "rebuilt_sha256": digest(exact.read_bytes()),
        "whole_file_byte_identical": original.read_bytes() == exact.read_bytes(),
        "methods_matched": rec.get("methods_total"),
        "reused_pattern": "C# source reshaped to explicit interface implementations (adds .override rows), "
                          "MethodDef flags/names restored in place, then managed-layout/2 replay of CLR "
                          "metadata/strong-name/CLR header/certificate plus .NET 1.1 import-tail rebuild",
        "pass_class": "no-IL record replay (managed-layout/2 + .NET 1.1 layout extension)",
        "qualification": "All methods are runtime managed internalcall with zero IL bodies. Replayed-from-original "
                         "bytes dominate the image (metadata + strong name + CLR header + certificate). Under the "
                         "BRIEF wording (code region + managed resources recompiled from source; CLR metadata/debug/"
                         "certificate/strong name replayed from original inputs; whole-file SHA equal) this is a pass. "
                         "Under the strictest reading (API surface must be source-generated) it is partial "
                         "(replay-dominated). Do not describe metadata as source-generated.",
        "evidence": {
            "layout_recipe": str(w / "recipe" / "layout-recipe.json"),
            "package": str(w / "package-final.zip"),
            "package_sha256": digest((w / "package-final.zip").read_bytes()),
            "replay_output": str(exact),
            "replay_log": str(w / "replay-final.log"),
            "compare": str(w / "compare-restored.json"),
            "rules_raw": str(w / "rules-raw.json"),
            "rules_restored": str(w / "rules-restored.json"),
            "restore_report": str(w / "restore-report.json"),
            "review": str(ROUTER / "reviews" / "rev-managed-override-1-1" / (sha8 + ".json")),
            "reviewer": "rev-managed-override-1-1",
        },
    })
    history = list(receipt.get("archive_history") or [])
    if not any(h.get("version") == 3 for h in history):
        history.append({"version": 3,
                        "archive": receipt.get("archive", "").split("\\")[-1],
                        "sha256": receipt.get("archive_sha256"),
                        "status": receipt.get("status", "partial"),
                        "note": "上一轮 partial；声明缺失（override_missing）与 .ctor hidebysig 位差异"})
    v4_name = name + ".v4.zip"
    history.append({"version": 4, "archive": v4_name, "status": "passed",
                    "sha256": None,
                    "note": "声明全等（方法体+声明逐条一致）+ 版式回放整件逐字节等于原件；"
                            "no-IL 退化类：元数据/强名/CLR 头/证书表按原件回放"})
    rec["archive_history"] = history
    rec["archive_version"] = 4
    rec["archive"] = str(rebuild / v4_name)
    rec["archive_sha256"] = None
    rec["remaining"] = "none: 0 method/declaration differences; rebuilt image byte-identical to original"

    embedded = json.loads(json.dumps(rec))
    embedded["archive_sha256"] = None
    embedded["archive_self_reference_note"] = "archive_sha256 is recorded in rebuild/<sha8>/receipt.json after packaging"

    members = {
        "notes.md": (w / "notes.md").read_bytes(),
        "receipt.json": (json.dumps(embedded, ensure_ascii=False, indent=1) + "\n").encode(),
        "editable/" + source.name: source.read_bytes(),
        "resources/original.res": (w / "pkg" / "resources" / "original.res").read_bytes(),
        "build/assembly-public-key.snk": (w / "pkg" / "build" / "assembly-public-key.snk").read_bytes(),
        "build-plan.json": zipfile.ZipFile(w / "pkg-v4.zip").read("build-plan.json"),
        "compile.rsp": (w / "raw" / "compile.rsp").read_bytes(),
        "compile.log": (w / "raw" / "compile.log").read_bytes(),
        "compiled/" + name: raw.read_bytes(),
        "restored/" + name: restored.read_bytes(),
        "restored/rules.json": (w / "rules.json").read_bytes(),
        "restored/restore-report.json": (w / "restore-report.json").read_bytes(),
        "replay/layout-recipe.json": (w / "recipe" / "layout-recipe.json").read_bytes(),
        "replay/recipe-report.json": (w / "recipe-report.json").read_bytes(),
        "replay/package.zip": (w / "package-final.zip").read_bytes(),
        "replay/exact/" + name: exact.read_bytes(),
        "replay/replay-final.log": (w / "replay-final.log").read_bytes(),
        "evidence/orig.il": (w / "orig.il").read_bytes(),
        "evidence/restored.il": (w / "restored.il").read_bytes(),
        "evidence/compare-restored.json": (w / "compare-restored.json").read_bytes(),
        "evidence/rules-raw.json": (w / "rules-raw.json").read_bytes(),
        "evidence/rules-restored.json": (w / "rules-restored.json").read_bytes(),
        "evidence/recipe.err": (w / "recipe.err").read_bytes(),
    }
    for name_py in ("make_source.py", "build_candidate.py", "derive_rules.py",
                    "declaration_restore2.py", "compare_methods.py", "make_pkg.py",
                    "build_recipe2.py", "pe_layout2.py", "replay2.py", "token_replay2.py",
                    "finalize_pkg.py", "make_archive.py"):
        members["tools/" + name_py] = (WORK / name_py).read_bytes()
    with zipfile.ZipFile(w / "pkg-recipe.zip") as z:
        for n in z.namelist():
            if n.startswith("original-build/"):
                members[n] = z.read(n)
    out = rebuild / v4_name
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    rec["archive_sha256"] = digest(out.read_bytes())
    rec["archive_history"][-1]["sha256"] = rec["archive_sha256"]
    receipt_path.write_text(json.dumps(rec, ensure_ascii=False, indent=1) + "\n", encoding="utf-8")
    print(json.dumps({"sha8": sha8, "archive": str(out), "archive_sha256": rec["archive_sha256"],
                      "bytes": out.stat().st_size, "members": len(members),
                      "rebuilt_equals_original": rec["whole_file_byte_identical"],
                      "methods": [rec.get("methods_matched"), rec.get("methods_total")]},
                     ensure_ascii=False, indent=1))

if __name__ == "__main__":
    main(*sys.argv[1:4])
