#!/usr/bin/env python3
"""Compile a package's C# source with the package-pinned toolchain.

Usage: build_candidate.py <pkg-dir> <source.cs> <out-dll> <log>
Mirrors replay.build()/pipeline.compile_item(): fixed_flags + /out + /win32res
+ /publicsign+/keyfile + /reference:* + /resource:* + source.
"""
import os, subprocess, sys, json
from hashlib import sha256
from pathlib import Path

def q(p): return '"' + str(p) + '"'

def main():
    pkg, src, out, log = (Path(x).resolve() for x in sys.argv[1:5])
    plan = json.loads((pkg / "build-plan.json").read_text(encoding="utf-8"))
    flags = list(plan["fixed_flags"])
    flags += ["/out:" + q(out.resolve()), "/win32res:" + q((pkg / "resources/original.res").resolve())]
    snk = pkg / "build/assembly-public-key.snk"
    if snk.exists():
        flags += ["/publicsign+", "/keyfile:" + q(snk.resolve())]
    flags += ["/reference:" + q(p) for p in plan["references"]]
    flags += ["/resource:" + q((pkg / row["member"]).resolve()) + "," + q(row["manifest_name"]) + "," + row["visibility"]
              for row in plan.get("managed_resources", ())]
    flags.append(q(src.resolve()))
    rsp = out.parent / "compile.rsp"
    rsp.write_text("\n".join(flags) + "\n", encoding="utf-8")
    env = dict(os.environ)
    env.update({"DOTNET_CLI_HOME": str(out.parent), "DOTNET_CLI_TELEMETRY_OPTOUT": "1", "DOTNET_NOLOGO": "1"})
    p = subprocess.run([plan["tool_path"]["dotnet"], plan["tool_path"]["csc"], "/noconfig", "@" + str(rsp)],
                       cwd=str(out.parent), capture_output=True, env=env, timeout=900)
    log.write_bytes(p.stdout + p.stderr)
    rec = {"exit": p.returncode, "out": str(out), "exists": out.is_file(),
           "sha256": sha256(out.read_bytes()).hexdigest() if out.is_file() else None,
           "log_tail": (p.stdout + p.stderr).decode("utf-8", "replace")[-1200:]}
    print(json.dumps(rec, ensure_ascii=False, indent=1))
    return 0 if p.returncode == 0 and out.is_file() else 1

if __name__ == "__main__":
    sys.exit(main())
