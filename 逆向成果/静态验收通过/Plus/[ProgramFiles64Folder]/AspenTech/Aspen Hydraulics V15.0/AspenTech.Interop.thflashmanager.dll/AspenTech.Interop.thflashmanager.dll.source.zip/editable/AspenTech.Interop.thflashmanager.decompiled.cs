using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: Guid("81a15441-733e-11d2-b8f4-00a0c986f9f7")]
[assembly: ImportedFromTypeLib("ThFlashManagerLib")]
[assembly: AssemblyVersion("1.0.0.0")]
namespace AspenTech.Interop.ThFlashManager;

[ComImport]
[TypeLibType(2)]
[ClassInterface((short)0)]
[Guid("81A15440-733E-11D2-B8F4-00A0C986F9F7")]
public class COTHFlashManagerClass : IFlashManager, COTHFlashManager, IThermoProperty, IFlashManager1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	extern void IFlashManager.Initialize([In][MarshalAs(UnmanagedType.IDispatch)] object pPropManager);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	extern void IFlashManager.Flash([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	extern void IFlashManager.FlashBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	extern void IFlashManager.FlashByFamily([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strFlashFamily);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluateProperty([In] int nPropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluatePhaseProperty([In] int nPropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluatePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.EvaluatePhasePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	extern object IThermoProperty.GetDefaultPropCalcMethodObjectForFlash([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IThermoProperty.GetPropertyCallBackAndContextManager([In] int ePropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [MarshalAs(UnmanagedType.IDispatch)] out object pPropCallBack, [MarshalAs(UnmanagedType.IDispatch)] out object pContxMgr);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void IFlashManager1.GetPropmanager([MarshalAs(UnmanagedType.IDispatch)] out object pTempDisp);
}
[ComImport]
[CoClass(typeof(COTHFlashManagerClass))]
[Guid("A6C75B00-6844-11D2-B8E0-00A0C986F9F7")]
public interface COTHFlashManager : IFlashManager
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("A6C75B00-6844-11D2-B8E0-00A0C986F9F7")]
public interface IFlashManager
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void Initialize([In][MarshalAs(UnmanagedType.IDispatch)] object pPropManager);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void Flash([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void FlashBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.IDispatch)] object pFlash);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void FlashByFamily([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strFlashFamily);
}
[ComImport]
[Guid("1CFDD5B0-42AC-11D2-B8CF-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IThermoProperty
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void EvaluateProperty([In] int nPropertyID, [In] int ePhaseType, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void EvaluatePhaseProperty([In] int nPropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void EvaluatePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhaseCollection, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void EvaluatePhasePropertyBy([In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [In][MarshalAs(UnmanagedType.BStr)] string strMethod);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	[return: MarshalAs(UnmanagedType.IDispatch)]
	object GetDefaultPropCalcMethodObjectForFlash([In] int ePropertyID, [In] int ePhaseType);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void GetPropertyCallBackAndContextManager([In] int ePropertyID, [In][MarshalAs(UnmanagedType.IDispatch)] object pPhase, [MarshalAs(UnmanagedType.IDispatch)] out object pPropCallBack, [MarshalAs(UnmanagedType.IDispatch)] out object pContxMgr);
}
[ComImport]
[TypeLibType(4160)]
[Guid("2F6ADAD3-5CFA-11D4-A685-00A0C9DF422B")]
public interface IFlashManager1
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void GetPropmanager([MarshalAs(UnmanagedType.IDispatch)] out object pTempDisp);
}
[ComImport]
[TypeLibType(2)]
[ClassInterface((short)0)]
[Guid("BE1FA7B3-CCF6-11D2-B93E-00A0C986F9F7")]
public class COTHContextManagerClass : IContextManager, COTHContextManager, INewContextManager
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	extern void IContextManager.AddContext([In] int lContextID, [In][MarshalAs(UnmanagedType.IUnknown)] object pContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	extern void IContextManager.GetContext([In] int lContextID, [MarshalAs(UnmanagedType.IUnknown)] out object pContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	extern void IContextManager.RemoveContext([In] int lContextID);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	extern void INewContextManager.InvalidatePhase([In][MarshalAs(UnmanagedType.IUnknown)] object pPhase);
}
[ComImport]
[CoClass(typeof(COTHContextManagerClass))]
[Guid("BE1FA7B0-CCF6-11D2-B93E-00A0C986F9F7")]
public interface COTHContextManager : IContextManager
{
}
[ComImport]
[Guid("BE1FA7B0-CCF6-11D2-B93E-00A0C986F9F7")]
[TypeLibType(4160)]
public interface IContextManager
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void AddContext([In] int lContextID, [In][MarshalAs(UnmanagedType.IUnknown)] object pContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void GetContext([In] int lContextID, [MarshalAs(UnmanagedType.IUnknown)] out object pContext);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void RemoveContext([In] int lContextID);
}
[ComImport]
[Guid("BE1FA7B1-CCF6-11D2-B93E-00A0C986F9F7")]
[TypeLibType(4096)]
public interface INewContextManager
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void InvalidatePhase([In][MarshalAs(UnmanagedType.IUnknown)] object pPhase);
}
