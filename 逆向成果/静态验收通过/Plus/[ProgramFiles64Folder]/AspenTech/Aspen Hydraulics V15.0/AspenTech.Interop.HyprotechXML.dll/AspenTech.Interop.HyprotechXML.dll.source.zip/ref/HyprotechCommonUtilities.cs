namespace HyprotechCommonUtilities
{
    // Reference-only shim: the original HyprotechCommonUtilities v1.0.0.0
    // (public key token 0D78107A74F71EF2) is not installed.  Compiling against
    // this assembly keeps the TypeRef shape of the original signatures; the
    // final image uses the original metadata replayed verbatim.
    public interface TaggedAttributes
    {
    }

    public interface DataTransfer
    {
    }
}
