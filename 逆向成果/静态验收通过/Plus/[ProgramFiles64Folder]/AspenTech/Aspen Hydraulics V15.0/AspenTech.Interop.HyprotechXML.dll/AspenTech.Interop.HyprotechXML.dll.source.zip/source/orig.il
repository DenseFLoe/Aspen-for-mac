// IL code: AspenTech.Interop.HyprotechXML
.class private auto ansi '<Module>'
{
} // end of class <Module>

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.XMLWriter
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(int16) = (
		01 00 01 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 37 34 42 42 46 33 30 2d 39 32 45 39
		2d 31 31 44 33 2d 39 45 32 37 2d 30 30 41 30 43
		39 42 34 35 45 34 44 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void WriteHeader (
			[in] string marshal(bstr) bstrName,
			[in] string marshal(bstr) bstrAttNames,
			[in] string marshal(bstr) bstrAtts
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 01 60 00 00
		)
	} // end of method XMLWriter::WriteHeader

	.method public hidebysig newslot abstract virtual 
		instance void StartTag (
			[in] string marshal(bstr) bstrTagName,
			[in] string marshal(bstr) bstrAttribNames,
			[in] string marshal(bstr) bstrAttribs,
			[in] string marshal(bstr) bstrContent
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 01 60 00 00
		)
	} // end of method XMLWriter::StartTag

	.method public hidebysig newslot abstract virtual 
		instance void Element (
			[in] string marshal(bstr) bstrElementName,
			[in] string marshal(bstr) bstrAttribNames,
			[in] string marshal(bstr) bstrAttribs,
			[in] string marshal(bstr) bstrSubTagNames,
			[in] string marshal(bstr) bstrSubTagContent,
			[in] string marshal(bstr) bstrContent
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
	} // end of method XMLWriter::Element

	.method public hidebysig newslot abstract virtual 
		instance void SimpleTag (
			[in] string marshal(bstr) bstrTagName,
			[in] string marshal(bstr) bstrAttribNames,
			[in] string marshal(bstr) bstrAttribs,
			[in] string marshal(bstr) bstrContent
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 01 60 00 00
		)
	} // end of method XMLWriter::SimpleTag

	.method public hidebysig newslot abstract virtual 
		instance void EndTag () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 01 60 00 00
		)
	} // end of method XMLWriter::EndTag

	.method public hidebysig newslot abstract virtual 
		instance void WriteComment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 01 60 00 00
		)
	} // end of method XMLWriter::WriteComment

	.method public hidebysig newslot abstract virtual 
		instance void SetWhitespaceFormat (
			[in] string marshal(bstr) bstrElement,
			[in] string marshal(bstr) bstrStatus
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 01 60 00 00
		)
	} // end of method XMLWriter::SetWhitespaceFormat

	.method public hidebysig newslot abstract virtual 
		instance void SetDataTransfer (
			[in] object marshal(iunknown) tx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 01 60 00 00
		)
	} // end of method XMLWriter::SetDataTransfer

} // end of class AspenTech.Interop.HyprotechXML.XMLWriter

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.XMLParserClient
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 35 46 37 38 39 39 34 2d 36 36 45 38
		2d 31 31 44 33 2d 38 45 42 33 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void CharacterData (
			[in] string marshal(bstr) userData
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method XMLParserClient::CharacterData

	.method public hidebysig newslot abstract virtual 
		instance void StartElement (
			[in] string marshal(bstr) name,
			[in] class [HyprotechCommonUtilities]HyprotechCommonUtilities.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method XMLParserClient::StartElement

	.method public hidebysig newslot abstract virtual 
		instance void EndElement (
			[in] string marshal(bstr) name
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method XMLParserClient::EndElement

	.method public hidebysig newslot abstract virtual 
		instance void Comment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method XMLParserClient::Comment

	.method public hidebysig newslot abstract virtual 
		instance void ProcessElement (
			[in] string marshal(bstr) name,
			[in] class [HyprotechCommonUtilities]HyprotechCommonUtilities.TaggedAttributes marshal(interface) attribs
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method XMLParserClient::ProcessElement

	.method public hidebysig newslot abstract virtual 
		instance void Error (
			[in] string marshal(bstr) Error
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method XMLParserClient::Error

	.method public hidebysig newslot abstract virtual 
		instance void StartDocument () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method XMLParserClient::StartDocument

	.method public hidebysig newslot abstract virtual 
		instance void EndDocument () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
	} // end of method XMLParserClient::EndDocument

} // end of class AspenTech.Interop.HyprotechXML.XMLParserClient

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.XMLParser
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 35 46 37 38 39 39 33 2d 36 36 45 38
		2d 31 31 44 33 2d 38 45 42 33 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void ReadFile (
			[in] string marshal(bstr) bstrFilePath,
			[in] class AspenTech.Interop.HyprotechXML.XMLParserClient marshal(interface) client,
			[in] bool includeWhitespace,
			[in] bool includeComments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method XMLParser::ReadFile

	.method public hidebysig newslot abstract virtual 
		instance void ReadText (
			[in] string marshal(bstr) FileText,
			[in] class AspenTech.Interop.HyprotechXML.XMLParserClient marshal(interface) client,
			[in] bool includeWhitespace,
			[in] bool includeComments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method XMLParser::ReadText

	.method public hidebysig newslot abstract virtual 
		instance void Read (
			[in] class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer marshal(interface) tx,
			[in] class AspenTech.Interop.HyprotechXML.XMLParserClient marshal(interface) client,
			[in] bool includeWhitespace,
			[in] bool includeComments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method XMLParser::Read

} // end of class AspenTech.Interop.HyprotechXML.XMLParser

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.XMLModelNode
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 33 46 41 30 41 36 30 2d 38 33 31 36
		2d 31 31 44 33 2d 38 45 42 43 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance void set_Attribute (
			[in] object& marshal(struct) varIndex,
			[in] object marshal(struct) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method XMLModelNode::set_Attribute

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_Attribute (
			[in] object& marshal(struct) varIndex
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method XMLModelNode::get_Attribute

	.method public hidebysig newslot abstract virtual 
		instance void SetAttribute (
			[in] string marshal(bstr) name,
			[in] string marshal(bstr) 'value'
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method XMLModelNode::SetAttribute

	.method public hidebysig newslot abstract virtual 
		instance class AspenTech.Interop.HyprotechXML.XMLModelNode marshal(interface) CreateNode (
			[in] string marshal(bstr) name
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method XMLModelNode::CreateNode

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_TagName (
			[in] string marshal(bstr) tag
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method XMLModelNode::set_TagName

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_TagName () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method XMLModelNode::get_TagName

	.method public hidebysig specialname newslot abstract virtual 
		instance void set_CharacterData (
			[in] object marshal(struct) charData
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method XMLModelNode::set_CharacterData

	.method public hidebysig specialname newslot abstract virtual 
		instance string marshal(bstr) get_CharacterData () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method XMLModelNode::get_CharacterData

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_NodeCount () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
	} // end of method XMLModelNode::get_NodeCount

	.method public hidebysig newslot abstract virtual 
		instance class AspenTech.Interop.HyprotechXML.XMLModelNode marshal(interface) GetContainedNode (
			[in] object& marshal(struct) varIndex
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 02 60 00 00
		)
	} // end of method XMLModelNode::GetContainedNode

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetAttribute (
			[in] int32 Index
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0a 00 02 60 00 00
		)
	} // end of method XMLModelNode::GetAttribute

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) GetAttributeName (
			[in] int32 Index
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0b 00 02 60 00 00
		)
	} // end of method XMLModelNode::GetAttributeName

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) FindAttribute (
			[in] string marshal(bstr) AttributeName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0c 00 02 60 00 00
		)
	} // end of method XMLModelNode::FindAttribute

	.method public hidebysig specialname newslot abstract virtual 
		instance int32 get_AttributeCount () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 02 60 00 00
		)
	} // end of method XMLModelNode::get_AttributeCount

	.method public hidebysig newslot abstract virtual 
		instance void Write (
			[in] class AspenTech.Interop.HyprotechXML.HyprotechXMLWriter marshal(interface) writer
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0e 00 02 60 00 00
		)
	} // end of method XMLModelNode::Write

	.method public hidebysig specialname newslot abstract virtual 
		instance class AspenTech.Interop.HyprotechXML.XMLModelNode marshal(interface) get_Parent () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 02 60 00 00
		)
	} // end of method XMLModelNode::get_Parent

	.method public hidebysig specialname newslot abstract virtual 
		instance bool get_AttributeExists (
			[in] string marshal(bstr) AttributeName
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
	} // end of method XMLModelNode::get_AttributeExists

	.method public hidebysig newslot abstract virtual 
		instance void ReplaceAttribute (
			[in] string marshal(bstr) AttributeName,
			[in] string marshal(bstr) attributeValue
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 11 00 02 60 00 00
		)
	} // end of method XMLModelNode::ReplaceAttribute

	// Properties
	.property string Attribute(
		[in] object& marshal(struct) varIndex
	)
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.get instance string AspenTech.Interop.HyprotechXML.XMLModelNode::get_Attribute(object&)
		.set instance void AspenTech.Interop.HyprotechXML.XMLModelNode::set_Attribute(object&, object)
	}
	.property string TagName()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.get instance string AspenTech.Interop.HyprotechXML.XMLModelNode::get_TagName()
		.set instance void AspenTech.Interop.HyprotechXML.XMLModelNode::set_TagName(string)
	}
	.property string CharacterData()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.get instance string AspenTech.Interop.HyprotechXML.XMLModelNode::get_CharacterData()
		.set instance void AspenTech.Interop.HyprotechXML.XMLModelNode::set_CharacterData(object)
	}
	.property int32 NodeCount()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.HyprotechXML.XMLModelNode::get_NodeCount()
	}
	.property int32 AttributeCount()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0d 00 02 60 00 00
		)
		.get instance int32 AspenTech.Interop.HyprotechXML.XMLModelNode::get_AttributeCount()
	}
	.property class AspenTech.Interop.HyprotechXML.XMLModelNode Parent()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 0f 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.HyprotechXML.XMLModelNode AspenTech.Interop.HyprotechXML.XMLModelNode::get_Parent()
	}
	.property bool AttributeExists(
		[in] string marshal(bstr) AttributeName
	)
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 10 00 02 60 00 00
		)
		.get instance bool AspenTech.Interop.HyprotechXML.XMLModelNode::get_AttributeExists(string)
	}

} // end of class AspenTech.Interop.HyprotechXML.XMLModelNode

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.XMLModel
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 33 46 41 30 41 36 31 2d 38 33 31 36
		2d 31 31 44 33 2d 38 45 42 43 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 40 10 00 00
	)
	// Methods
	.method public hidebysig newslot abstract virtual 
		instance void ReadFromFile (
			[in] string marshal(bstr) filePath,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
	} // end of method XMLModel::ReadFromFile

	.method public hidebysig newslot abstract virtual 
		instance void WriteToFile (
			[in] string marshal(bstr) filePath
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
	} // end of method XMLModel::WriteToFile

	.method public hidebysig newslot abstract virtual 
		instance void ReadFromText (
			[in] string marshal(bstr) FileText,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
	} // end of method XMLModel::ReadFromText

	.method public hidebysig newslot abstract virtual 
		instance string marshal(bstr) WriteToText () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
	} // end of method XMLModel::WriteToText

	.method public hidebysig newslot abstract virtual 
		instance void Read (
			[in] class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer marshal(interface) tx,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
	} // end of method XMLModel::Read

	.method public hidebysig newslot abstract virtual 
		instance class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer marshal(interface) Write () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
	} // end of method XMLModel::Write

	.method public hidebysig specialname newslot abstract virtual 
		instance class AspenTech.Interop.HyprotechXML.XMLModelNode marshal(interface) get_RootNode () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
	} // end of method XMLModel::get_RootNode

	.method public hidebysig newslot abstract virtual 
		instance void Clear () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
	} // end of method XMLModel::Clear

	.method public hidebysig newslot abstract virtual 
		instance void ReadFromCompressedFile (
			[in] string marshal(bstr) filePath,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
	} // end of method XMLModel::ReadFromCompressedFile

	.method public hidebysig newslot abstract virtual 
		instance void WriteToCompressedFile (
			[in] string marshal(bstr) filePath
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 02 60 00 00
		)
	} // end of method XMLModel::WriteToCompressedFile

	// Properties
	.property class AspenTech.Interop.HyprotechXML.XMLModelNode RootNode()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.HyprotechXML.XMLModelNode AspenTech.Interop.HyprotechXML.XMLModel::get_RootNode()
	}

} // end of class AspenTech.Interop.HyprotechXML.XMLModel

.class public auto ansi import AspenTech.Interop.HyprotechXML.HyprotechXMLWriterClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.HyprotechXML.XMLWriter,
	           AspenTech.Interop.HyprotechXML.HyprotechXMLWriter
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 36 34 37 33 32 30 43 30 2d 39 36 33 42
		2d 31 31 44 33 2d 39 45 32 39 2d 30 30 41 30 43
		39 42 34 35 45 34 44 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method HyprotechXMLWriterClass::.ctor

	.method public hidebysig newslot virtual 
		instance void WriteHeader (
			[in] string marshal(bstr) bstrName,
			[in] string marshal(bstr) bstrAttNames,
			[in] string marshal(bstr) bstrAtts
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::WriteHeader(string, string, string)
	} // end of method HyprotechXMLWriterClass::WriteHeader

	.method public hidebysig newslot virtual 
		instance void StartTag (
			[in] string marshal(bstr) bstrTagName,
			[in] string marshal(bstr) bstrAttribNames,
			[in] string marshal(bstr) bstrAttribs,
			[in] string marshal(bstr) bstrContent
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::StartTag(string, string, string, string)
	} // end of method HyprotechXMLWriterClass::StartTag

	.method public hidebysig newslot virtual 
		instance void Element (
			[in] string marshal(bstr) bstrElementName,
			[in] string marshal(bstr) bstrAttribNames,
			[in] string marshal(bstr) bstrAttribs,
			[in] string marshal(bstr) bstrSubTagNames,
			[in] string marshal(bstr) bstrSubTagContent,
			[in] string marshal(bstr) bstrContent
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::Element(string, string, string, string, string, string)
	} // end of method HyprotechXMLWriterClass::Element

	.method public hidebysig newslot virtual 
		instance void SimpleTag (
			[in] string marshal(bstr) bstrTagName,
			[in] string marshal(bstr) bstrAttribNames,
			[in] string marshal(bstr) bstrAttribs,
			[in] string marshal(bstr) bstrContent
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::SimpleTag(string, string, string, string)
	} // end of method HyprotechXMLWriterClass::SimpleTag

	.method public hidebysig newslot virtual 
		instance void EndTag () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::EndTag()
	} // end of method HyprotechXMLWriterClass::EndTag

	.method public hidebysig newslot virtual 
		instance void WriteComment (
			[in] string marshal(bstr) bstrComment
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::WriteComment(string)
	} // end of method HyprotechXMLWriterClass::WriteComment

	.method public hidebysig newslot virtual 
		instance void SetWhitespaceFormat (
			[in] string marshal(bstr) bstrElement,
			[in] string marshal(bstr) bstrStatus
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::SetWhitespaceFormat(string, string)
	} // end of method HyprotechXMLWriterClass::SetWhitespaceFormat

	.method public hidebysig newslot virtual 
		instance void SetDataTransfer (
			[in] object marshal(iunknown) tx
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 01 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLWriter::SetDataTransfer(object)
	} // end of method HyprotechXMLWriterClass::SetDataTransfer

} // end of class AspenTech.Interop.HyprotechXML.HyprotechXMLWriterClass

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.HyprotechXMLWriter
	implements AspenTech.Interop.HyprotechXML.XMLWriter
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 41 37 34 42 42 46 33 30 2d 39 32 45 39
		2d 31 31 44 33 2d 39 45 32 37 2d 30 30 41 30 43
		39 42 34 35 45 34 44 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 36 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 48 79 70 72 6f 74 65 63 68 58 4d
		4c 2e 48 79 70 72 6f 74 65 63 68 58 4d 4c 57 72
		69 74 65 72 43 6c 61 73 73 00 00
	)
} // end of class AspenTech.Interop.HyprotechXML.HyprotechXMLWriter

.class public auto ansi import AspenTech.Interop.HyprotechXML.HyprotechStreamingXMLParserClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.HyprotechXML.XMLParser,
	           AspenTech.Interop.HyprotechXML.HyprotechStreamingXMLParser
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 35 46 37 38 39 39 32 2d 36 36 45 38
		2d 31 31 44 33 2d 38 45 42 33 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	// Methods
	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method HyprotechStreamingXMLParserClass::.ctor

	.method public hidebysig newslot virtual 
		instance void ReadFile (
			[in] string marshal(bstr) bstrFilePath,
			[in] class AspenTech.Interop.HyprotechXML.XMLParserClient marshal(interface) client,
			[in] bool includeWhitespace,
			[in] bool includeComments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLParser::ReadFile(string, class AspenTech.Interop.HyprotechXML.XMLParserClient, bool, bool)
	} // end of method HyprotechStreamingXMLParserClass::ReadFile

	.method public hidebysig newslot virtual 
		instance void ReadText (
			[in] string marshal(bstr) FileText,
			[in] class AspenTech.Interop.HyprotechXML.XMLParserClient marshal(interface) client,
			[in] bool includeWhitespace,
			[in] bool includeComments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLParser::ReadText(string, class AspenTech.Interop.HyprotechXML.XMLParserClient, bool, bool)
	} // end of method HyprotechStreamingXMLParserClass::ReadText

	.method public hidebysig newslot virtual 
		instance void Read (
			[in] class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer marshal(interface) tx,
			[in] class AspenTech.Interop.HyprotechXML.XMLParserClient marshal(interface) client,
			[in] bool includeWhitespace,
			[in] bool includeComments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLParser::Read(class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer, class AspenTech.Interop.HyprotechXML.XMLParserClient, bool, bool)
	} // end of method HyprotechStreamingXMLParserClass::Read

} // end of class AspenTech.Interop.HyprotechXML.HyprotechStreamingXMLParserClass

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.HyprotechStreamingXMLParser
	implements AspenTech.Interop.HyprotechXML.XMLParser
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 35 35 46 37 38 39 39 33 2d 36 36 45 38
		2d 31 31 44 33 2d 38 45 42 33 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 3f 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 48 79 70 72 6f 74 65 63 68 58 4d
		4c 2e 48 79 70 72 6f 74 65 63 68 53 74 72 65 61
		6d 69 6e 67 58 4d 4c 50 61 72 73 65 72 43 6c 61
		73 73 00 00
	)
} // end of class AspenTech.Interop.HyprotechXML.HyprotechStreamingXMLParser

.class public auto ansi import AspenTech.Interop.HyprotechXML.HyprotechXMLModelClass
	extends [mscorlib]System.Object
	implements AspenTech.Interop.HyprotechXML.XMLModel,
	           AspenTech.Interop.HyprotechXML.HyprotechXMLModel
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(int16) = (
		01 00 00 00 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 31 39 44 39 32 32 45 31 2d 38 35 41 35
		2d 31 31 44 33 2d 38 45 42 44 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(int16) = (
		01 00 02 00 00 00
	)
	// Methods
	.method public specialname rtspecialname 
		instance void .ctor () runtime managed internalcall 
	{
	} // end of method HyprotechXMLModelClass::.ctor

	.method public hidebysig newslot virtual 
		instance void ReadFromFile (
			[in] string marshal(bstr) filePath,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLModel::ReadFromFile(string, bool, bool)
	} // end of method HyprotechXMLModelClass::ReadFromFile

	.method public hidebysig newslot virtual 
		instance void WriteToFile (
			[in] string marshal(bstr) filePath
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 01 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLModel::WriteToFile(string)
	} // end of method HyprotechXMLModelClass::WriteToFile

	.method public hidebysig newslot virtual 
		instance void ReadFromText (
			[in] string marshal(bstr) FileText,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 02 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLModel::ReadFromText(string, bool, bool)
	} // end of method HyprotechXMLModelClass::ReadFromText

	.method public hidebysig newslot virtual 
		instance string marshal(bstr) WriteToText () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 03 00 02 60 00 00
		)
		.override method instance string AspenTech.Interop.HyprotechXML.XMLModel::WriteToText()
	} // end of method HyprotechXMLModelClass::WriteToText

	.method public hidebysig newslot virtual 
		instance void Read (
			[in] class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer marshal(interface) tx,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 04 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLModel::Read(class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer, bool, bool)
	} // end of method HyprotechXMLModelClass::Read

	.method public hidebysig newslot virtual 
		instance class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer marshal(interface) Write () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 05 00 02 60 00 00
		)
		.override method instance class [HyprotechCommonUtilities]HyprotechCommonUtilities.DataTransfer AspenTech.Interop.HyprotechXML.XMLModel::Write()
	} // end of method HyprotechXMLModelClass::Write

	.method public hidebysig specialname newslot virtual 
		instance class AspenTech.Interop.HyprotechXML.XMLModelNode marshal(interface) get_RootNode () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.override method instance class AspenTech.Interop.HyprotechXML.XMLModelNode AspenTech.Interop.HyprotechXML.XMLModel::get_RootNode()
	} // end of method HyprotechXMLModelClass::get_RootNode

	.method public hidebysig newslot virtual 
		instance void Clear () runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 07 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLModel::Clear()
	} // end of method HyprotechXMLModelClass::Clear

	.method public hidebysig newslot virtual 
		instance void ReadFromCompressedFile (
			[in] string marshal(bstr) filePath,
			[in] bool whitespace,
			[in] bool comments
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 08 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLModel::ReadFromCompressedFile(string, bool, bool)
	} // end of method HyprotechXMLModelClass::ReadFromCompressedFile

	.method public hidebysig newslot virtual 
		instance void WriteToCompressedFile (
			[in] string marshal(bstr) filePath
		) runtime managed internalcall 
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 09 00 02 60 00 00
		)
		.override method instance void AspenTech.Interop.HyprotechXML.XMLModel::WriteToCompressedFile(string)
	} // end of method HyprotechXMLModelClass::WriteToCompressedFile

	// Properties
	.property class AspenTech.Interop.HyprotechXML.XMLModelNode RootNode()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 06 00 02 60 00 00
		)
		.get instance class AspenTech.Interop.HyprotechXML.XMLModelNode AspenTech.Interop.HyprotechXML.HyprotechXMLModelClass::get_RootNode()
	}

} // end of class AspenTech.Interop.HyprotechXML.HyprotechXMLModelClass

.class interface public auto ansi abstract import AspenTech.Interop.HyprotechXML.HyprotechXMLModel
	implements AspenTech.Interop.HyprotechXML.XMLModel
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = (
		01 00 35 41 73 70 65 6e 54 65 63 68 2e 49 6e 74
		65 72 6f 70 2e 48 79 70 72 6f 74 65 63 68 58 4d
		4c 2e 48 79 70 72 6f 74 65 63 68 58 4d 4c 4d 6f
		64 65 6c 43 6c 61 73 73 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 44 33 46 41 30 41 36 31 2d 38 33 31 36
		2d 31 31 44 33 2d 38 45 42 43 2d 30 30 41 30 43
		39 44 46 33 44 32 43 00 00
	)
} // end of class AspenTech.Interop.HyprotechXML.HyprotechXMLModel

You are not using the latest version of the tool, please update.
Latest version is '11.2.0.10050' (yours is '9.1.0.7988')
