using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using HyprotechCommonUtilities;

[assembly: Guid("55f78991-66e8-11d3-8eb3-00a0c9df3d2c")]
[assembly: ImportedFromTypeLib("HyprotechXML")]
[assembly: AssemblyVersion("1.2.0.0")]
namespace AspenTech.Interop.HyprotechXML
{

[ComImport]
[TypeLibType(64)]
[InterfaceType(1)]
[Guid("A74BBF30-92E9-11D3-9E27-00A0C9B45E4D")]
public interface XMLWriter
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678272)]
	void WriteHeader([In][MarshalAs(UnmanagedType.BStr)] string bstrName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAtts);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678273)]
	void StartTag([In][MarshalAs(UnmanagedType.BStr)] string bstrTagName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribs, [In][MarshalAs(UnmanagedType.BStr)] string bstrContent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678274)]
	void Element([In][MarshalAs(UnmanagedType.BStr)] string bstrElementName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribs, [In][MarshalAs(UnmanagedType.BStr)] string bstrSubTagNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrSubTagContent, [In][MarshalAs(UnmanagedType.BStr)] string bstrContent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678275)]
	void SimpleTag([In][MarshalAs(UnmanagedType.BStr)] string bstrTagName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribs, [In][MarshalAs(UnmanagedType.BStr)] string bstrContent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678276)]
	void EndTag();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678277)]
	void WriteComment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678278)]
	void SetWhitespaceFormat([In][MarshalAs(UnmanagedType.BStr)] string bstrElement, [In][MarshalAs(UnmanagedType.BStr)] string bstrStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678279)]
	void SetDataTransfer([In][MarshalAs(UnmanagedType.IUnknown)] object tx);
}
[ComImport]
[Guid("55F78994-66E8-11D3-8EB3-00A0C9DF3D2C")]
[TypeLibType(4160)]
public interface XMLParserClient
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void CharacterData([In][MarshalAs(UnmanagedType.BStr)] string userData);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void StartElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void EndElement([In][MarshalAs(UnmanagedType.BStr)] string name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	void Comment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void ProcessElement([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.Interface)] TaggedAttributes attribs);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	void Error([In][MarshalAs(UnmanagedType.BStr)] string Error);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void StartDocument();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void EndDocument();
}
[ComImport]
[TypeLibType(4160)]
[Guid("55F78993-66E8-11D3-8EB3-00A0C9DF3D2C")]
public interface XMLParser
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void ReadFile([In][MarshalAs(UnmanagedType.BStr)] string bstrFilePath, [In][MarshalAs(UnmanagedType.Interface)] XMLParserClient client, [In] bool includeWhitespace, [In] bool includeComments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void ReadText([In][MarshalAs(UnmanagedType.BStr)] string FileText, [In][MarshalAs(UnmanagedType.Interface)] XMLParserClient client, [In] bool includeWhitespace, [In] bool includeComments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void Read([In][MarshalAs(UnmanagedType.Interface)] DataTransfer tx, [In][MarshalAs(UnmanagedType.Interface)] XMLParserClient client, [In] bool includeWhitespace, [In] bool includeComments);
}
[ComImport]
[Guid("D3FA0A60-8316-11D3-8EBC-00A0C9DF3D2C")]
[TypeLibType(4160)]
public interface XMLModelNode
{
	// ILSpy collapsed the parameterized COM accessors below into plain C#
	// properties and silently dropped the index parameter.  The original
	// MethodDefs are specialname accessors with real parameters, so they are
	// declared here as methods named get_/set_ (the way tlbimp emits them);
	// the specialname flag is restored by declaration_restore2.
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string get_Attribute([In][MarshalAs(UnmanagedType.Struct)] ref object varIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void set_Attribute([In][MarshalAs(UnmanagedType.Struct)] ref object varIndex, [In][MarshalAs(UnmanagedType.Struct)] object value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void SetAttribute([In][MarshalAs(UnmanagedType.BStr)] string name, [In][MarshalAs(UnmanagedType.BStr)] string value);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.Interface)]
	XMLModelNode CreateNode([In][MarshalAs(UnmanagedType.BStr)] string name);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string get_TagName();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void set_TagName([In][MarshalAs(UnmanagedType.BStr)] string tag);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string get_CharacterData();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743814)]
	void set_CharacterData([In][MarshalAs(UnmanagedType.Struct)] object charData);

	[DispId(1610743816)]
	int NodeCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743816)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	[return: MarshalAs(UnmanagedType.Interface)]
	XMLModelNode GetContainedNode([In][MarshalAs(UnmanagedType.Struct)] ref object varIndex);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743818)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetAttribute([In] int Index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743819)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetAttributeName([In] int Index);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743820)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string FindAttribute([In][MarshalAs(UnmanagedType.BStr)] string AttributeName);

	[DispId(1610743821)]
	int AttributeCount
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743821)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743822)]
	void Write([In][MarshalAs(UnmanagedType.Interface)] HyprotechXMLWriter writer);

	[DispId(1610743823)]
	XMLModelNode Parent
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743823)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743824)]
	bool get_AttributeExists([In][MarshalAs(UnmanagedType.BStr)] string AttributeName);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743825)]
	void ReplaceAttribute([In][MarshalAs(UnmanagedType.BStr)] string AttributeName, [In][MarshalAs(UnmanagedType.BStr)] string attributeValue);
}
[ComImport]
[Guid("D3FA0A61-8316-11D3-8EBC-00A0C9DF3D2C")]
[TypeLibType(4160)]
public interface XMLModel
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	void ReadFromFile([In][MarshalAs(UnmanagedType.BStr)] string filePath, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	void WriteToFile([In][MarshalAs(UnmanagedType.BStr)] string filePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	void ReadFromText([In][MarshalAs(UnmanagedType.BStr)] string FileText, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string WriteToText();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	void Read([In][MarshalAs(UnmanagedType.Interface)] DataTransfer tx, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.Interface)]
	DataTransfer Write();

	[DispId(1610743814)]
	XMLModelNode RootNode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	void Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	void ReadFromCompressedFile([In][MarshalAs(UnmanagedType.BStr)] string filePath, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	void WriteToCompressedFile([In][MarshalAs(UnmanagedType.BStr)] string filePath);
}
[ComImport]
[Guid("647320C0-963B-11D3-9E29-00A0C9B45E4D")]
[ClassInterface((short)0)]
[TypeLibType(2)]
public class HyprotechXMLWriterClass : XMLWriter, HyprotechXMLWriter
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678272)]
	extern void XMLWriter.WriteHeader([In][MarshalAs(UnmanagedType.BStr)] string bstrName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAtts);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678273)]
	extern void XMLWriter.StartTag([In][MarshalAs(UnmanagedType.BStr)] string bstrTagName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribs, [In][MarshalAs(UnmanagedType.BStr)] string bstrContent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678274)]
	extern void XMLWriter.Element([In][MarshalAs(UnmanagedType.BStr)] string bstrElementName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribs, [In][MarshalAs(UnmanagedType.BStr)] string bstrSubTagNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrSubTagContent, [In][MarshalAs(UnmanagedType.BStr)] string bstrContent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678275)]
	extern void XMLWriter.SimpleTag([In][MarshalAs(UnmanagedType.BStr)] string bstrTagName, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribNames, [In][MarshalAs(UnmanagedType.BStr)] string bstrAttribs, [In][MarshalAs(UnmanagedType.BStr)] string bstrContent);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678276)]
	extern void XMLWriter.EndTag();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678277)]
	extern void XMLWriter.WriteComment([In][MarshalAs(UnmanagedType.BStr)] string bstrComment);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678278)]
	extern void XMLWriter.SetWhitespaceFormat([In][MarshalAs(UnmanagedType.BStr)] string bstrElement, [In][MarshalAs(UnmanagedType.BStr)] string bstrStatus);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610678279)]
	extern void XMLWriter.SetDataTransfer([In][MarshalAs(UnmanagedType.IUnknown)] object tx);
}
[ComImport]
[Guid("A74BBF30-92E9-11D3-9E27-00A0C9B45E4D")]
[CoClass(typeof(HyprotechXMLWriterClass))]
public interface HyprotechXMLWriter : XMLWriter
{
}
[ComImport]
[Guid("55F78992-66E8-11D3-8EB3-00A0C9DF3D2C")]
[TypeLibType(2)]
[ClassInterface((short)0)]
public class HyprotechStreamingXMLParserClass : XMLParser, HyprotechStreamingXMLParser
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	extern void XMLParser.ReadFile([In][MarshalAs(UnmanagedType.BStr)] string bstrFilePath, [In][MarshalAs(UnmanagedType.Interface)] XMLParserClient client, [In] bool includeWhitespace, [In] bool includeComments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	extern void XMLParser.ReadText([In][MarshalAs(UnmanagedType.BStr)] string FileText, [In][MarshalAs(UnmanagedType.Interface)] XMLParserClient client, [In] bool includeWhitespace, [In] bool includeComments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	extern void XMLParser.Read([In][MarshalAs(UnmanagedType.Interface)] DataTransfer tx, [In][MarshalAs(UnmanagedType.Interface)] XMLParserClient client, [In] bool includeWhitespace, [In] bool includeComments);
}
[ComImport]
[Guid("55F78993-66E8-11D3-8EB3-00A0C9DF3D2C")]
[CoClass(typeof(HyprotechStreamingXMLParserClass))]
public interface HyprotechStreamingXMLParser : XMLParser
{
}
[ComImport]
[ClassInterface((short)0)]
[Guid("19D922E1-85A5-11D3-8EBD-00A0C9DF3D2C")]
[TypeLibType(2)]
public class HyprotechXMLModelClass : XMLModel, HyprotechXMLModel
{
	[DispId(1610743814)]
	extern XMLModelNode XMLModel.RootNode
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1610743814)]
		[return: MarshalAs(UnmanagedType.Interface)]
		get;
	}

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743808)]
	extern void XMLModel.ReadFromFile([In][MarshalAs(UnmanagedType.BStr)] string filePath, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743809)]
	extern void XMLModel.WriteToFile([In][MarshalAs(UnmanagedType.BStr)] string filePath);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743810)]
	extern void XMLModel.ReadFromText([In][MarshalAs(UnmanagedType.BStr)] string FileText, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743811)]
	[return: MarshalAs(UnmanagedType.BStr)]
	extern string XMLModel.WriteToText();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743812)]
	extern void XMLModel.Read([In][MarshalAs(UnmanagedType.Interface)] DataTransfer tx, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743813)]
	[return: MarshalAs(UnmanagedType.Interface)]
	extern DataTransfer XMLModel.Write();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743815)]
	extern void XMLModel.Clear();

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743816)]
	extern void XMLModel.ReadFromCompressedFile([In][MarshalAs(UnmanagedType.BStr)] string filePath, [In] bool whitespace, [In] bool comments);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1610743817)]
	extern void XMLModel.WriteToCompressedFile([In][MarshalAs(UnmanagedType.BStr)] string filePath);
}
[ComImport]
[CoClass(typeof(HyprotechXMLModelClass))]
[Guid("D3FA0A61-8316-11D3-8EBC-00A0C9DF3D2C")]
public interface HyprotechXMLModel : XMLModel
{
}
}
