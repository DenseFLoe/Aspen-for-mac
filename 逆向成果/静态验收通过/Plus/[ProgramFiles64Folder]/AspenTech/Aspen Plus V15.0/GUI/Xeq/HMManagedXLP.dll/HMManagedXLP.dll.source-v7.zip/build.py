"""Compile the editable C# assembly directly. The original DLL is not a build input."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--dotnet", required=True, type=Path)
    parser.add_argument("--csc", required=True, type=Path)
    parser.add_argument("--netstandard-ref", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    args = parser.parse_args()

    package = Path(__file__).resolve().parent
    source = package / "HMManagedXLP.dll.cs"
    key = package / "build" / "assembly-public-key.snk"
    dotnet, csc, reference = (
        p.resolve(strict=True) for p in (args.dotnet, args.csc, args.netstandard_ref)
    )
    csc_hash, ref_hash = digest(csc), digest(reference)
    if csc_hash != "be4ed221693245e985c11ebc433d3bb197b443196aff2f02f1b01b67feaa2ff9":
        parser.error("--csc must be the netcoreapp3.1 csc.dll from Microsoft.Net.Compilers.Toolset 3.8.0")
    if ref_hash != "1799854d01a89d141fecc4c4548b01e51fa57118c9b18eac66a752f3bbe98c02":
        parser.error("--netstandard-ref must be netstandard.dll from NETStandard.Library 2.0.3")

    output_dir = args.out_dir.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        parser.error("--out-dir must be empty")
    work = output_dir / "scratch"
    work.mkdir()
    output = output_dir / "HMManagedXLP.dll"
    env = {
        **os.environ,
        "DOTNET_ROOT": str(dotnet.parent),
        "DOTNET_CLI_HOME": str(work),
        "DOTNET_SKIP_FIRST_TIME_EXPERIENCE": "1",
        "DOTNET_ROLL_FORWARD": "LatestMajor",
        "DOTNET_CLI_TELEMETRY_OPTOUT": "1",
        "TEMP": str(work),
        "TMP": str(work),
        "TMPDIR": str(work),
    }
    command = [
        str(dotnet), str(csc), "/noconfig", "/nologo", "/utf8output", "/nostdlib+",
        "/deterministic+", "/optimize+", "/target:library", "/platform:anycpu",
        "/baseaddress:0x10000000", "/filealign:512", "/subsystemversion:4.00",
        "/langversion:9", "/highentropyva+", "/publicsign+",
        f"/keyfile:{key}", f"/reference:{reference}", f"/out:{output}", str(source),
    ]
    subprocess.run(command, cwd=work, env=env, check=True)
    report = {
        "command": command,
        "source_sha256": digest(source),
        "public_key_sha256": digest(key),
        "csc_sha256": csc_hash,
        "netstandard_ref_sha256": ref_hash,
        "dotnet_host_sha256": digest(dotnet),
        "output_sha256": digest(output),
        "output_bytes": output.stat().st_size,
    }
    (output_dir / "build.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(report["output_sha256"], output)


if __name__ == "__main__":
    main()
