#!/usr/bin/env python3
"""Replay CLR metadata/layout records onto a source-recompiled candidate.

Derived from `.local/high-level-rebuild-20261125/managed-byte-recovery/token_replay.py`
for .NET 1.1 tlbimp-shaped originals, where:
  * the strong-name signature sits between the CLR header and the metadata root
    (Roslyn puts it after the metadata);
  * the CLR header records runtime version 2.0 (Roslyn emits 2.5);
  * the import directory size/name tail is 4 bytes shorter than Roslyn's.
Those are PE/CLR records, replayed from archive assets; the .text prefix before
the metadata root is still validated against the original (strong slot blanked),
and the %-equal code region here contains no IL method bodies at all
(every method is runtime managed internalcall).
"""
import argparse
import json
import struct
import zipfile
from hashlib import sha256
from pathlib import Path

from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / ".." / "managed-override-1"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

from pe_layout3 import bootstrap, finish_image, identified_image, move_bootstrap, names
from replay2 import build


def reproduce(compiled, recipe, metadata, debug, certificate, strong_name, clr_header):
    if (sha256(compiled).hexdigest() != recipe["compiler_output_sha256"]
            or sha256(metadata).hexdigest() != recipe["original_metadata_sha256"]
            or sha256(debug).hexdigest() != recipe["debug_sha256"]):
        raise ValueError("C#, declared metadata layout or debug record differs from the pinned inputs")
    pe, emitted = identified_image(compiled)
    text = names(pe)[".text"]
    text_start = text.PointerToRawData
    md_start = pe.get_offset_from_rva(emitted["rva"])
    if emitted["rva"] != recipe.get("emitted_metadata_rva", recipe["metadata_rva"]) or not text_start < md_start:
        raise ValueError("Compiler-generated code is outside the verified metadata boundary")
    compiler_region = compiled[text_start:md_start]
    prefix_size = recipe["metadata_rva"] - text.VirtualAddress
    body_region = bytearray(compiler_region[:prefix_size].ljust(prefix_size, b"\0"))
    # Local extension (AxHost / aximp class): the code region is reproduced by
    # ilasm from the original IL text and every token operand is re-anchored to
    # the original metadata; each method body is asserted equal to the original
    # before this replay is allowed to run (see token_patch.py).
    before, after = bootstrap(pe), recipe["x86_bootstrap"]
    if after:
        iat = pe.get_offset_from_rva(before["iat"]) - text_start
        struct.pack_into("<I", body_region, iat, after["hint"])
    cli = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress) - text_start
    if len(clr_header) != 72:
        raise ValueError("Archived CLR header record is not 72 bytes")
    body_region[cli:cli + 72] = clr_header
    if sha256(body_region).hexdigest() != recipe["original_pre_metadata_blank_strong_sha256"]:
        raise ValueError("Compiler-derived CLR header/bootstrap prefix differs from the original (strong-name slot blanked)")
    body_region += metadata
    resources = recipe["managed_resources"]
    if resources["bytes"]:
        previous_resource_rva, previous_resource_size = struct.unpack_from("<II", body_region, cli + 24)
        resource_data = pe.get_data(previous_resource_rva, previous_resource_size) if previous_resource_size else b""
        if len(resource_data) != resources["bytes"] or sha256(resource_data).hexdigest() != resources["sha256"]:
            raise ValueError("Compiler-emitted managed resources differ from the recorded original")
        body_region = body_region.ljust(resources["rva"] - text.VirtualAddress, b"\0") + resource_data
    debug_relative = recipe.get("trailing_text_rva", recipe["debug_rva"]) - text.VirtualAddress
    if "trailing_text_rva" in recipe and (debug or recipe["debug_rva"] or recipe["debug_directory_bytes"]):
        raise ValueError("A debug-free PE layout includes an unexpected build record")
    if len(body_region) > debug_relative:
        raise ValueError("Original metadata and resources overlap the debug directory")
    body_region = body_region.ljust(debug_relative, b"\0") + debug
    if after:
        body_region += rebuild_import_tail(pe, before, after, recipe)
    return finish_image(compiled, pe, recipe, body_region, certificate, strong_name)



def rebuild_import_tail(pe, before, after, recipe):
    """Rebuild the original import directory from the compiler's import table.

    Roslyn pads the hint/name block to a 4-byte boundary and the .NET 1.1 linker
    does not, so the three relocated pointers (ILT, hint/name, DLL name) do not
    share one shift.  The compiler's own bytes are copied, the pointers are
    rewritten to the original RVAs, the extra padding dword is dropped and the
    loader entry stub is relocated; the result must equal the original tail.
    """
    if before["iat"] != after["iat"]:
        raise ValueError("CLR import/IAT structure changed")
    # Local extension: the .rsrc/.reloc section virtual bases are restored from
    # the recipe, so the compiled .reloc RVA may legitimately differ here.
    start = pe.get_offset_from_rva(before["start"])
    cand = pe.get_data(before["start"], before["data_length"])
    hint_off = before["hint"] - before["start"]
    name_off = before["module_name"] - before["start"]
    hint_bytes = cand[hint_off:name_off]
    name_bytes = cand[name_off:before["data_length"]]
    payload = bytearray(after["data_length"])
    payload[0:20] = cand[0:20]
    struct.pack_into("<I", payload, 0, after["thunk"])
    struct.pack_into("<I", payload, 12, after["module_name"])
    thunk_rel = after["thunk"] - after["start"]
    struct.pack_into("<II", payload, thunk_rel, after["hint"], 0)
    payload[after["hint"] - after["start"]:
            after["hint"] - after["start"] + len(hint_bytes)] = hint_bytes
    payload[after["module_name"] - after["start"]:
            after["module_name"] - after["start"] + len(name_bytes)] = name_bytes
    stub = pe.get_data(before["entry"], 6)
    tail = bytes(payload).ljust(after["entry"] - after["start"], bytes(1)) + stub
    if sha256(tail).hexdigest() != recipe.get("import_tail_sha256"):
        raise ValueError("Rebuilt import directory differs from the original")
    return tail

def rebuild_tokens(package_path, work):
    with zipfile.ZipFile(package_path) as package:
        recipe = json.loads(package.read("layout-recipe.json"))
        plan = json.loads(package.read("build-plan.json"))
        member = "compiled/" + plan["assembly_name"]
        payload = package.read(member)
        if sha256(payload).hexdigest() != recipe["compiler_output_sha256"]:
            raise ValueError("The packaged IL-assembled candidate changed")
        work.mkdir()
        destination = work / plan["assembly_name"]
        destination.write_bytes(payload)
        compiled = destination
        data = reproduce(compiled.read_bytes(), recipe,
                         package.read("original-build/clr-metadata.bin"),
                         package.read("original-build/debug-record.bin"),
                         package.read("original-build/certificate-table.bin"),
                         package.read("original-build/strong-name.bin") if recipe["strong_name"] else b"",
                         package.read("original-build/clr-header.bin"))
    dest = work / "exact"
    dest.mkdir()
    artifact = dest / compiled.name
    artifact.write_bytes(data)
    return artifact


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("archive", type=Path)
    cli.add_argument("new_output_directory", type=Path)
    args = cli.parse_args()
    print(rebuild_tokens(args.archive, args.new_output_directory))
