"""Read the CLR metadata tables a managed layout recipe needs.

Only the parts required to build a layout recipe are implemented: the #~ table
stream (row layout, MethodDef RVA table), the #Strings/#Blob/#GUID/#US heaps, the
CLI header, and exact method-body extents (header + code + exception sections).
All indexes follow ECMA-335 II.22 / II.24.
"""

import struct

import pefile

# ---------------------------------------------------------------- row schemas
# ("u", width) fixed integer, ("s", table) simple index, ("c", coded) coded index.
SCHEMA = {
    0x00: [("u", 2), ("s", "Strings"), ("s", "GUID"), ("s", "GUID"), ("s", "GUID")],
    0x01: [("c", "ResolutionScope"), ("s", "Strings"), ("s", "Strings")],
    0x02: [("u", 4), ("s", "Strings"), ("s", "Strings"), ("c", "TypeDefOrRef"), ("s", 0x04), ("s", 0x06)],
    0x03: [("s", 0x04)],
    0x04: [("u", 2), ("s", "Strings"), ("s", "Blob")],
    0x05: [("s", 0x06)],
    0x06: [("u", 4), ("u", 2), ("u", 2), ("s", "Strings"), ("s", "Blob"), ("s", 0x08)],
    0x07: [("s", 0x08)],
    0x08: [("u", 2), ("u", 2), ("s", "Strings")],
    0x09: [("s", 0x02), ("c", "TypeDefOrRef")],
    0x0A: [("c", "MemberRefParent"), ("s", "Strings"), ("s", "Blob")],
    0x0B: [("u", 1), ("u", 1), ("c", "HasConstant"), ("s", "Blob")],
    0x0C: [("c", "HasCustomAttribute"), ("c", "CustomAttributeType"), ("s", "Blob")],
    0x0D: [("c", "HasFieldMarshal"), ("s", "Blob")],
    0x0E: [("u", 2), ("c", "HasDeclSecurity"), ("s", "Blob")],
    0x0F: [("u", 2), ("u", 4), ("s", 0x02)],
    0x10: [("u", 4), ("s", 0x04)],
    0x11: [("s", "Blob")],
    0x12: [("s", 0x02), ("s", 0x14)],
    0x13: [("s", 0x14)],
    0x14: [("u", 2), ("s", "Strings"), ("c", "TypeDefOrRef")],
    0x15: [("s", 0x02), ("s", 0x17)],
    0x16: [("s", 0x17)],
    0x17: [("u", 2), ("s", "Strings"), ("s", "Blob")],
    0x18: [("u", 2), ("s", 0x06), ("c", "HasSemantics")],
    0x19: [("s", 0x02), ("c", "MethodDefOrRef"), ("c", "MethodDefOrRef")],
    0x1A: [("s", "Strings")],
    0x1B: [("s", "Blob")],
    0x1C: [("u", 2), ("c", "MemberForwarded"), ("s", "Strings"), ("s", 0x1A)],
    0x1D: [("u", 4), ("s", 0x04)],
    0x1E: [("u", 4), ("u", 4)],
    0x1F: [("u", 4)],
    0x20: [("u", 4), ("u", 2), ("u", 2), ("u", 2), ("u", 2), ("u", 4),
           ("s", "Blob"), ("s", "Strings"), ("s", "Strings")],
    0x21: [("u", 4)],
    0x22: [("u", 4), ("u", 4), ("u", 4)],
    0x23: [("u", 2), ("u", 2), ("u", 2), ("u", 2), ("u", 4), ("s", "Blob"),
           ("s", "Strings"), ("s", "Strings"), ("s", "Blob")],
    0x24: [("u", 4), ("s", 0x23)],
    0x25: [("u", 4), ("u", 4), ("u", 4), ("s", 0x23)],
    0x26: [("u", 4), ("s", "Strings"), ("s", "Blob")],
    0x27: [("u", 4), ("u", 4), ("s", "Strings"), ("s", "Strings"), ("c", "Implementation")],
    0x28: [("u", 4), ("u", 4), ("s", "Strings"), ("c", "Implementation")],
    0x29: [("s", 0x02), ("s", 0x02)],
    0x2A: [("u", 2), ("u", 2), ("c", "TypeOrMethodDef"), ("s", "Strings")],
    0x2B: [("c", "MethodDefOrRef"), ("s", "Blob")],
    0x2C: [("s", 0x2A), ("c", "TypeDefOrRef")],
}

CODED = {
    "TypeDefOrRef": (2, [0x02, 0x01, 0x1B]),
    "HasConstant": (2, [0x04, 0x08, 0x17]),
    "HasCustomAttribute": (5, [0x06, 0x04, 0x01, 0x02, 0x08, 0x09, 0x0A, 0x00, 0x0E,
                               0x17, 0x14, 0x11, 0x1A, 0x1B, 0x20, 0x23, 0x26, 0x27,
                               0x28, 0x2A, 0x2C, 0x2B]),
    "HasFieldMarshal": (1, [0x04, 0x08]),
    "HasDeclSecurity": (2, [0x02, 0x06, 0x20]),
    "MemberRefParent": (3, [0x02, 0x01, 0x1A, 0x06, 0x1B]),
    "HasSemantics": (1, [0x14, 0x17]),
    "MethodDefOrRef": (1, [0x06, 0x0A]),
    "MemberForwarded": (1, [0x04, 0x06]),
    "Implementation": (2, [0x26, 0x23, 0x27]),
    "CustomAttributeType": (3, [None, None, 0x06, 0x0A, None]),
    "ResolutionScope": (2, [0x00, 0x1A, 0x23, 0x01]),
    "TypeOrMethodDef": (1, [0x02, 0x06]),
}

TABLE_NAMES = {
    0x00: "Module", 0x01: "TypeRef", 0x02: "TypeDef", 0x04: "Field", 0x06: "MethodDef",
    0x08: "Param", 0x0A: "MemberRef", 0x11: "StandAloneSig", 0x14: "Event",
    0x17: "Property", 0x1A: "ModuleRef", 0x1B: "TypeSpec", 0x20: "Assembly",
    0x23: "AssemblyRef", 0x27: "ExportedType", 0x28: "ManifestResource",
    0x2A: "GenericParam", 0x2B: "MethodSpec",
}


class MetadataError(ValueError):
    """The CLR metadata layout is outside what this reader accepts."""


def _u16(data, at):
    return struct.unpack_from("<H", data, at)[0]


def _u32(data, at):
    return struct.unpack_from("<I", data, at)[0]


def cli_header(pe):
    directory = pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    raw = pe.get_data(directory.VirtualAddress, directory.Size)
    if len(raw) != 72 or _u32(raw, 0) != 72:
        raise MetadataError("Expected a pure IL assembly with a standard CLR header")
    (flags,) = struct.unpack_from("<I", raw, 16)
    metadata_rva, metadata_size = struct.unpack_from("<II", raw, 8)
    resource_rva, resource_size = struct.unpack_from("<II", raw, 24)
    strong_rva, strong_size = struct.unpack_from("<II", raw, 32)
    return {"flags": flags, "metadata_rva": metadata_rva, "metadata_size": metadata_size,
            "resource_rva": resource_rva, "resource_size": resource_size,
            "strong_name_rva": strong_rva, "strong_name_size": strong_size,
            "entry_point": _u32(raw, 20), "vtable_rva": _u32(raw, 28)}


def metadata_root(pe, cli):
    content = pe.get_data(cli["metadata_rva"], cli["metadata_size"])
    if len(content) != cli["metadata_size"] or content[:4] != b"BSJB":
        raise MetadataError("Unreadable CLR metadata root")
    version_length = _u32(content, 12)
    at = 16 + version_length
    count = _u16(content, at + 2)
    at += 4
    streams = {}
    for _ in range(count):
        offset, length = struct.unpack_from("<II", content, at)
        end = content.index(b"\0", at + 8)
        name = content[at + 8:end].decode("ascii")
        if name in streams or offset + length > len(content):
            raise MetadataError("Invalid CLR metadata stream span")
        streams[name] = {"offset": offset, "size": length}
        at = (end + 4) & ~3
    if "#~" not in streams or "#Strings" not in streams or "#Blob" not in streams or "#GUID" not in streams:
        raise MetadataError("CLR metadata streams are incomplete for a layout recipe")
    root = {"bytes": content, "streams": streams, "version_length": version_length}
    root["tables"] = table_layout(content, streams["#~"])
    return root


def table_layout(content, stream):
    start = stream["offset"]
    heap_sizes = content[start + 6]
    valid = struct.unpack_from("<Q", content, start + 8)[0]
    sorted_mask = struct.unpack_from("<Q", content, start + 16)[0]
    at = start + 24
    rows = {}
    for table in range(64):
        if valid >> table & 1:
            rows[table] = _u32(content, at)
            at += 4
    heap_width = {"Strings": 4 if heap_sizes & 1 else 2, "GUID": 4 if heap_sizes & 2 else 2,
                  "Blob": 4 if heap_sizes & 4 else 2}
    simple_width = {table: 4 if count >= 0x10000 else 2 for table, count in rows.items()}

    def coded_width(name):
        bits, tables = CODED[name]
        highest = max((rows.get(t, 0) for t in tables if t is not None), default=0)
        return 2 if highest < (1 << (16 - bits)) else 4

    layout = {}
    for table in sorted(rows):
        size = 0
        for kind, spec in SCHEMA[table]:
            if kind == "u":
                size += spec
            elif kind == "s":
                size += heap_width[spec] if isinstance(spec, str) else simple_width.get(spec, 2)
            else:
                size += coded_width(spec)
        layout[table] = {"row_size": size, "rows": rows[table], "offset": at}
        at += size * rows[table]
    if at > start + stream["size"]:
        raise MetadataError("CLR table stream overruns its declared extent")
    return {"stream_offset": start, "heap_sizes": heap_sizes, "valid": valid, "sorted": sorted_mask,
            "rows": rows, "layout": layout, "end": at}


def read_row(content, tables, table, index):
    """Return the row fields as a dict keyed by ECMA names."""
    if table not in tables["layout"] or not 1 <= index <= tables["layout"][table]["rows"]:
        raise MetadataError("CLR table row out of range")
    heap_width = {"Strings": 4 if tables["heap_sizes"] & 1 else 2,
                  "GUID": 4 if tables["heap_sizes"] & 2 else 2,
                  "Blob": 4 if tables["heap_sizes"] & 4 else 2}
    simple_width = {t: 4 if n >= 0x10000 else 2 for t, n in tables["rows"].items()}

    def coded_width(name):
        bits, targets = CODED[name]
        highest = max((tables["rows"].get(t, 0) for t in targets if t is not None), default=0)
        return 2 if highest < (1 << (16 - bits)) else 4

    at = tables["layout"][table]["offset"] + (index - 1) * tables["layout"][table]["row_size"]
    out = {}
    for position, (kind, spec) in enumerate(SCHEMA[table]):
        if kind == "u":
            out[position] = int.from_bytes(content[at:at + spec], "little")
            at += spec
        elif kind == "s":
            width = heap_width[spec] if isinstance(spec, str) else simple_width.get(spec, 2)
            out[position] = int.from_bytes(content[at:at + width], "little")
            at += width
        else:
            width = coded_width(spec)
            out[position] = int.from_bytes(content[at:at + width], "little")
            at += width
    return out


def strings(pe, cli, root, index):
    heap = root["streams"]["#Strings"]
    base = cli["metadata_rva"] + heap["offset"]
    if index >= heap["size"]:
        raise MetadataError("#Strings index out of range")
    end = pe.get_data(base + index, heap["size"] - index).index(b"\0")
    return pe.get_data(base + index, end).decode("utf-8", "replace")


def blob(pe, cli, root, index):
    heap = root["streams"]["#Blob"]
    if index >= heap["size"]:
        raise MetadataError("#Blob index out of range")
    base = cli["metadata_rva"] + heap["offset"]
    first = pe.get_data(base + index, 1)[0]
    if first & 0x80 == 0:
        length, width = first, 1
    elif first & 0xC0 == 0x80:
        length, width = ((first & 0x3F) << 8) | pe.get_data(base + index + 1, 1)[0], 2
    else:
        raw = pe.get_data(base + index + 1, 3)
        length, width = ((first & 0x1F) << 24) | int.from_bytes(raw, "big"), 4
    return pe.get_data(base + index + width, length)


def method_extent(pe, rva):
    """Return (total_bytes, header_bytes, code_bytes, flags) of one CLI method."""
    if not rva:
        return 0, 0, 0, 0
    first = pe.get_data(rva, 1)[0]
    if first & 3 == 2:
        head, code, flags = 1, first >> 2, 2
    elif first & 3 == 3:
        raw = struct.unpack_from("<H", pe.get_data(rva, 2))[0]
        head = (raw >> 12) * 4
        flags = raw & 0xFFF
        if head != 12:
            raise MetadataError("Nonstandard fat CLI method header")
        code = _u32(pe.get_data(rva + 4, 4), 0)
    else:
        raise MetadataError("Unknown CLI method-header encoding")
    size = head + code
    if flags & 8:
        at = (size + 3) & ~3
        kind = pe.get_data(rva + at, 1)[0]
        if kind & 0x40:
            chunk = int.from_bytes(pe.get_data(rva + at + 1, 3), "little")
        else:
            chunk = pe.get_data(rva + at + 1, 1)[0]
        size = at + chunk
    if size > 0x100000:
        raise MetadataError("Implausible CLI method extent")
    return size, head, code, flags


def method_defs(pe, cli, root):
    """Return the MethodDef RVA table: token, RVA and registered name."""
    if 0x06 not in root["tables"]["layout"]:
        raise MetadataError("CLR metadata has no MethodDef table")
    count = root["tables"]["layout"][0x06]["rows"]
    rows = []
    for index in range(1, count + 1):
        row = read_row(root["bytes"], root["tables"], 0x06, index)
        rva = row[0]
        total, head, code, flags = method_extent(pe, rva)
        rows.append({"row": index, "token": 0x06000000 | index, "rva": rva,
                     "impl_flags": row[1], "flags": row[2],
                     "name_index": row[3], "signature_index": row[4], "param_list": row[5],
                     "code_size": code, "header_bytes": head, "body_bytes": total,
                     "method_flags": flags})
    return rows


def assembly_public_key(pe, cli, root):
    """Return the Assembly.PublicKey blob (empty for unsigned assemblies)."""
    if 0x20 not in root["tables"]["layout"] or not root["tables"]["layout"][0x20]["rows"]:
        return b""
    row = read_row(root["bytes"], root["tables"], 0x20, 1)
    index = row[6]
    return blob(pe, cli, root, index) if index else b""


def read_image(data):
    pe = pefile.PE(data=data, fast_load=True)
    cli = cli_header(pe)
    root = metadata_root(pe, cli)
    return pe, cli, root
