﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AxEditorCtrlLib.AxEditorCtrl
  AxEditorCtrlLib.AxEditorCtrlEventMulticaster
}

// Metadata version: v4.0.30319
.assembly extern System.Windows.Forms
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern EditorCtrlLib
{
  .publickeytoken = (B0 56 89 B3 9D EE FB CD )                         // .V......
  .ver 1:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly AxEditorCtrlLib
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/TypeLibraryTimeStampAttribute::.ctor(string) = ( 01 00 13 30 34 2F 31 34 2F 32 30 32 35 20 30 39   // ...04/14/2025 09
                                                                                                                           3A 30 35 3A 35 36 00 00 )                         // :05:56..
  .custom instance void [mscorlib]System.Reflection.AssemblyKeyFileAttribute::.ctor(string) = ( 01 00 0D 41 73 70 65 6E 74 65 63 68 2E 73 6E 6B   // ...Aspentech.snk
                                                                                                00 00 ) 
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                31 CE F7 DF 85 4A 51 60 93 9C 58 8A 09 81 30 D8   // 1....JQ`..X...0.
                3B 58 C6 41 43 FE 98 DE 4F EA 84 44 85 EE C0 F8   // ;X.AC...O..D....
                BF 75 0A 6A 39 BA 8A 55 2E 37 20 73 B6 95 3A 09   // .u.j9..U.7 s..:.
                53 17 FB FB A3 6E B8 37 F2 D0 14 D6 2D 52 2D 2C   // S....n.7....-R-,
                B2 4F 39 B6 12 E0 DA 27 6D BF 15 4A 5D 0F 84 0D   // .O9....'m..J]...
                59 7F 81 E6 0E 83 1D 25 B6 EB C3 47 9D 69 C3 A6   // Y......%...G.i..
                6A 21 E7 D3 A8 62 09 D1 D3 50 BB 90 86 82 98 3C   // j!...b...P.....<
                80 C0 F7 D4 3B 60 C3 48 79 73 35 A7 33 B2 61 C8 ) // ....;`.Hys5.3.a.
  .hash algorithm 0x00008004
  .ver 1:0:0:0
}
.module AxEditorCtrlLib.dll
// MVID: {756d5d66-04b7-4d10-99ea-527f3db8e73a}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x000002262F2E0000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi beforefieldinit AxEditorCtrlLib.AxEditorCtrl
       extends [System.Windows.Forms]System.Windows.Forms.AxHost
{
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ClsidAttribute::.ctor(string) = ( 01 00 26 7B 64 62 30 31 36 38 34 64 2D 62 31 38   // ..&{db01684d-b18
                                                                                                            66 2D 34 31 30 30 2D 38 66 39 35 2D 38 37 64 64   // f-4100-8f95-87dd
                                                                                                            34 39 63 30 66 36 63 39 7D 00 00 )                // 49c0f6c9}..
  .custom instance void [System]System.ComponentModel.DesignTimeVisibleAttribute::.ctor(bool) = ( 01 00 01 00 00 ) 
  .custom instance void [System]System.ComponentModel.DefaultEventAttribute::.ctor(string) = ( 01 00 12 43 6F 6E 74 65 78 74 4D 65 6E 75 4F 70   // ...ContextMenuOp
                                                                                               65 6E 69 6E 67 00 00 )                            // ening..
  .field private class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl ocx
  .field private class AxEditorCtrlLib.AxEditorCtrlEventMulticaster eventMulticaster
  .field private class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie cookie
  .field private class [mscorlib]System.EventHandler ContextMenuOpening
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       31 (0x1f)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "db01684d-b18f-4100-8f95-87dd49c0f6c9"
    IL_0006:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::.ctor(string)
    IL_000b:  ldarg.0
    IL_000c:  ldarg.0
    IL_000d:  dup
    IL_000e:  ldvirtftn  instance void AxEditorCtrlLib.AxEditorCtrl::AboutBox()
    IL_0014:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/AboutBoxDelegate::.ctor(object,
                                                                                                                 native int)
    IL_0019:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::SetAboutBoxDelegate(class [System.Windows.Forms]System.Windows.Forms.AxHost/AboutBoxDelegate)
    IL_001e:  ret
  } // end of method AxEditorCtrl::.ctor

  .method public hidebysig newslot specialname virtual 
          instance bool  get_IsReadOnly() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IsReadOnly"
    IL_000d:  ldc.i4.1
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::get_IsReadOnly()
    IL_001f:  ret
  } // end of method AxEditorCtrl::get_IsReadOnly

  .method public hidebysig newslot specialname virtual 
          instance void  set_IsReadOnly(bool 'value') cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IsReadOnly"
    IL_000d:  ldc.i4.2
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::set_IsReadOnly(bool)
    IL_0020:  ret
  } // end of method AxEditorCtrl::set_IsReadOnly

  .method public hidebysig specialname instance void 
          add_ContextMenuOpening(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxEditorCtrlLib.AxEditorCtrl::ContextMenuOpening
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxEditorCtrlLib.AxEditorCtrl::ContextMenuOpening
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxEditorCtrl::add_ContextMenuOpening

  .method public hidebysig specialname instance void 
          remove_ContextMenuOpening(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxEditorCtrlLib.AxEditorCtrl::ContextMenuOpening
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxEditorCtrlLib.AxEditorCtrl::ContextMenuOpening
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxEditorCtrl::remove_ContextMenuOpening

  .method public hidebysig newslot virtual 
          instance void  AboutBox() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "AboutBox"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::AboutBox()
    IL_001f:  ret
  } // end of method AxEditorCtrl::AboutBox

  .method public hidebysig newslot virtual 
          instance int32  CreateEditor(int32 lWidth,
                                       int32 lHeght) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CreateEditor"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::CreateEditor(int32,
                                                                                                int32)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxEditorCtrl::CreateEditor

  .method public hidebysig newslot virtual 
          instance int32  CreateEditorWithText(int32 lWidth,
                                               int32 lHeight,
                                               string sText,
                                               bool bScript) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  5
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CreateEditorWithText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    bScript
    IL_001f:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::CreateEditorWithText(int32,
                                                                                                        int32,
                                                                                                        string,
                                                                                                        bool)
    IL_0024:  stloc.0
    IL_0025:  ldloc.0
    IL_0026:  ret
  } // end of method AxEditorCtrl::CreateEditorWithText

  .method public hidebysig newslot virtual 
          instance int32  LoadText(string sText,
                                   bool bScript) cil managed
  {
    // Code size       36 (0x24)
    .maxstack  3
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "LoadText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::LoadText(string,
                                                                                            bool)
    IL_0021:  stloc.0
    IL_0022:  ldloc.0
    IL_0023:  ret
  } // end of method AxEditorCtrl::LoadText

  .method public hidebysig newslot virtual 
          instance string  GetEditorText() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetEditorText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance string [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetEditorText()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetEditorText

  .method public hidebysig newslot virtual 
          instance void  Undo() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Undo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::Undo()
    IL_001f:  ret
  } // end of method AxEditorCtrl::Undo

  .method public hidebysig newslot virtual 
          instance void  Redo() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Redo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::Redo()
    IL_001f:  ret
  } // end of method AxEditorCtrl::Redo

  .method public hidebysig newslot virtual 
          instance bool  CanUndo() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CanUndo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::CanUndo()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::CanUndo

  .method public hidebysig newslot virtual 
          instance bool  CanRedo() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CanRedo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::CanRedo()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::CanRedo

  .method public hidebysig newslot virtual 
          instance void  SetDisplayLineNumbers(int32 nLineNumberChars) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetDisplayLineNumbers"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetDisplayLineNumbers(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetDisplayLineNumbers

  .method public hidebysig newslot virtual 
          instance void  Copy() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Copy"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::Copy()
    IL_001f:  ret
  } // end of method AxEditorCtrl::Copy

  .method public hidebysig newslot virtual 
          instance void  Paste() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Paste"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::Paste()
    IL_001f:  ret
  } // end of method AxEditorCtrl::Paste

  .method public hidebysig newslot virtual 
          instance void  Cut() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Cut"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::Cut()
    IL_001f:  ret
  } // end of method AxEditorCtrl::Cut

  .method public hidebysig newslot virtual 
          instance void  SetDisplayBookmarks(bool bFlag) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetDisplayBookmarks"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetDisplayBookmarks(bool)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetDisplayBookmarks

  .method public hidebysig newslot virtual 
          instance void  SetDisplayFolding(bool bFlag) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetDisplayFolding"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetDisplayFolding(bool)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetDisplayFolding

  .method public hidebysig newslot virtual 
          instance void  GotoLine(int32 line) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GotoLine"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GotoLine(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::GotoLine

  .method public hidebysig newslot virtual 
          instance void  InsertText(string text) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "InsertText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::InsertText(string)
    IL_0020:  ret
  } // end of method AxEditorCtrl::InsertText

  .method public hidebysig newslot virtual 
          instance void  Print(string header) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Print"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::Print(string)
    IL_0020:  ret
  } // end of method AxEditorCtrl::Print

  .method public hidebysig newslot virtual 
          instance string  GetSelectedText() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelectedText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance string [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetSelectedText()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetSelectedText

  .method public hidebysig newslot virtual 
          instance bool  CanPaste() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CanPaste"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::CanPaste()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::CanPaste

  .method public hidebysig newslot virtual 
          instance bool  IsModified() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IsModified"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::IsModified()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::IsModified

  .method public hidebysig newslot virtual 
          instance void  ToggleBookmark() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ToggleBookmark"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::ToggleBookmark()
    IL_001f:  ret
  } // end of method AxEditorCtrl::ToggleBookmark

  .method public hidebysig newslot virtual 
          instance void  PreviousBookmark() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "PreviousBookmark"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::PreviousBookmark()
    IL_001f:  ret
  } // end of method AxEditorCtrl::PreviousBookmark

  .method public hidebysig newslot virtual 
          instance void  NextBookmark() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "NextBookmark"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::NextBookmark()
    IL_001f:  ret
  } // end of method AxEditorCtrl::NextBookmark

  .method public hidebysig newslot virtual 
          instance int32  FindNextBookmark() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FindNextBookmark"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::FindNextBookmark()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::FindNextBookmark

  .method public hidebysig newslot virtual 
          instance int32  FindPreviousBookmark() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FindPreviousBookmark"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::FindPreviousBookmark()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::FindPreviousBookmark

  .method public hidebysig newslot virtual 
          instance void  DeleteAllBookmarks() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DeleteAllBookmarks"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::DeleteAllBookmarks()
    IL_001f:  ret
  } // end of method AxEditorCtrl::DeleteAllBookmarks

  .method public hidebysig newslot virtual 
          instance bool  HasAnyBookmarks() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "HasAnyBookmarks"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::HasAnyBookmarks()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::HasAnyBookmarks

  .method public hidebysig newslot virtual 
          instance int32  GetCurrentLine() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetCurrentLine"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetCurrentLine()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetCurrentLine

  .method public hidebysig newslot virtual 
          instance int32  GetLineCount() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetLineCount"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetLineCount()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetLineCount

  .method public hidebysig newslot virtual 
          instance void  SetSearchFlags(int32 searchFlags) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSearchFlags"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetSearchFlags(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetSearchFlags

  .method public hidebysig newslot virtual 
          instance bool  SearchNext(string szText) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SearchNext"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SearchNext(string)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::SearchNext

  .method public hidebysig newslot virtual 
          instance bool  SearchPrevious(string szText) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SearchPrevious"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SearchPrevious(string)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::SearchPrevious

  .method public hidebysig newslot virtual 
          instance int32  GetSelectionStart() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelectionStart"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetSelectionStart()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetSelectionStart

  .method public hidebysig newslot virtual 
          instance int32  GetSelectionEnd() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSelectionEnd"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetSelectionEnd()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetSelectionEnd

  .method public hidebysig newslot virtual 
          instance void  GotoPosition(int32 pos) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GotoPosition"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GotoPosition(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::GotoPosition

  .method public hidebysig newslot virtual 
          instance void  ReplaceSelectedText(string szText) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ReplaceSelectedText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::ReplaceSelectedText(string)
    IL_0020:  ret
  } // end of method AxEditorCtrl::ReplaceSelectedText

  .method public hidebysig newslot virtual 
          instance int32  ReplaceAll(string szFind,
                                     string szReplace,
                                     bool bUseSelection) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  4
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ReplaceAll"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::ReplaceAll(string,
                                                                                              string,
                                                                                              bool)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ret
  } // end of method AxEditorCtrl::ReplaceAll

  .method public hidebysig newslot virtual 
          instance void  SetBackground(uint32 crBackground) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetBackground"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetBackground(uint32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetBackground

  .method public hidebysig newslot virtual 
          instance void  SelectAll() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SelectAll"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SelectAll()
    IL_001f:  ret
  } // end of method AxEditorCtrl::SelectAll

  .method public hidebysig newslot virtual 
          instance string  GetLineText(uint32 lLine) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetLineText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance string [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetLineText(uint32)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::GetLineText

  .method public hidebysig newslot virtual 
          instance int32  IsModelEditor() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IsModelEditor"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::IsModelEditor()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::IsModelEditor

  .method public hidebysig newslot virtual 
          instance string  LexerModelTaskKeywords() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "LexerModelTaskKeywords"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance string [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::LexerModelTaskKeywords()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::LexerModelTaskKeywords

  .method public hidebysig newslot virtual 
          instance string  LexerScriptKeywords() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "LexerScriptKeywords"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance string [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::LexerScriptKeywords()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::LexerScriptKeywords

  .method public hidebysig newslot virtual 
          instance void  SetText(string szText) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetText"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetText(string)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetText

  .method public hidebysig newslot virtual 
          instance void  SetEditor(int32 lEditorType) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetEditor"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetEditor(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetEditor

  .method public hidebysig newslot virtual 
          instance bool  IsLineCommented() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IsLineCommented"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::IsLineCommented()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::IsLineCommented

  .method public hidebysig newslot virtual 
          instance int32  GetStartLinePos(int32 nLine) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetStartLinePos"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetStartLinePos(int32)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::GetStartLinePos

  .method public hidebysig newslot virtual 
          instance int32  GetEndLinePos(int32 nLine) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetEndLinePos"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetEndLinePos(int32)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::GetEndLinePos

  .method public hidebysig newslot virtual 
          instance void  CommentSelectedLines() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CommentSelectedLines"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::CommentSelectedLines()
    IL_001f:  ret
  } // end of method AxEditorCtrl::CommentSelectedLines

  .method public hidebysig newslot virtual 
          instance int32  UncommentSelectedLines(int32 bDoIt) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "UncommentSelectedLines"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::UncommentSelectedLines(int32)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::UncommentSelectedLines

  .method public hidebysig newslot virtual 
          instance void  SelectCommentedLines() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SelectCommentedLines"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SelectCommentedLines()
    IL_001f:  ret
  } // end of method AxEditorCtrl::SelectCommentedLines

  .method public hidebysig newslot virtual 
          instance int32  GetIndent() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetIndent"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetIndent()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetIndent

  .method public hidebysig newslot virtual 
          instance void  SetIndent(int32 nIndent) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetIndent"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetIndent(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetIndent

  .method public hidebysig newslot virtual 
          instance void  IndentSelectedLines(bool bIncreaseIndent) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IndentSelectedLines"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::IndentSelectedLines(bool)
    IL_0020:  ret
  } // end of method AxEditorCtrl::IndentSelectedLines

  .method public hidebysig newslot virtual 
          instance void  IndentLine(int32 nLine,
                                    bool bIncreaseIndent) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "IndentLine"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::IndentLine(int32,
                                                                                             bool)
    IL_0021:  ret
  } // end of method AxEditorCtrl::IndentLine

  .method public hidebysig newslot virtual 
          instance bool  SearchForward(string szText) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SearchForward"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SearchForward(string)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::SearchForward

  .method public hidebysig newslot virtual 
          instance bool  SearchBackward(string szText) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SearchBackward"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SearchBackward(string)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxEditorCtrl::SearchBackward

  .method public hidebysig newslot virtual 
          instance void  Clear() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Clear"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::Clear()
    IL_001f:  ret
  } // end of method AxEditorCtrl::Clear

  .method public hidebysig newslot virtual 
          instance void  SetSelectionStart(int32 lStartPos) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSelectionStart"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetSelectionStart(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetSelectionStart

  .method public hidebysig newslot virtual 
          instance void  SetSelectionEnd(int32 lEndPos) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSelectionEnd"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetSelectionEnd(int32)
    IL_0020:  ret
  } // end of method AxEditorCtrl::SetSelectionEnd

  .method public hidebysig newslot virtual 
          instance void  SetSavePoint() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSavePoint"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetSavePoint()
    IL_001f:  ret
  } // end of method AxEditorCtrl::SetSavePoint

  .method public hidebysig newslot virtual 
          instance string  GetFontName() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetFontName"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance string [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetFontName()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetFontName

  .method public hidebysig newslot virtual 
          instance int32  GetFontSize() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetFontSize"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetFontSize()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetFontSize

  .method public hidebysig newslot virtual 
          instance bool  GetFontBold() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetFontBold"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetFontBold()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetFontBold

  .method public hidebysig newslot virtual 
          instance bool  GetFontItalic() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetFontItalic"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance bool [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetFontItalic()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetFontItalic

  .method public hidebysig newslot virtual 
          instance void  SetFont(string sFontName,
                                 int32 nFontSize,
                                 bool bBold,
                                 bool bItalic) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetFont"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    bItalic
    IL_001f:  callvirt   instance void [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::SetFont(string,
                                                                                          int32,
                                                                                          bool,
                                                                                          bool)
    IL_0024:  ret
  } // end of method AxEditorCtrl::SetFont

  .method public hidebysig newslot virtual 
          instance int32  GetModify() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetModify"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
    IL_001a:  callvirt   instance int32 [EditorCtrlLib]EditorCtrlLib._DEditorCtrl::GetModify()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxEditorCtrl::GetModify

  .method family hidebysig virtual instance void 
          CreateSink() cil managed
  {
    // Code size       51 (0x33)
    .maxstack  4
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  newobj     instance void AxEditorCtrlLib.AxEditorCtrlEventMulticaster::.ctor(class AxEditorCtrlLib.AxEditorCtrl)
      IL_0007:  stfld      class AxEditorCtrlLib.AxEditorCtrlEventMulticaster AxEditorCtrlLib.AxEditorCtrl::eventMulticaster
      IL_000c:  ldarg.0
      IL_000d:  ldarg.0
      IL_000e:  ldfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
      IL_0013:  ldarg.0
      IL_0014:  ldfld      class AxEditorCtrlLib.AxEditorCtrlEventMulticaster AxEditorCtrlLib.AxEditorCtrl::eventMulticaster
      IL_0019:  ldtoken    [EditorCtrlLib]EditorCtrlLib._DEditorCtrlEvents
      IL_001e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0023:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::.ctor(object,
                                                                                                                        object,
                                                                                                                        class [mscorlib]System.Type)
      IL_0028:  stfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxEditorCtrlLib.AxEditorCtrl::cookie
      IL_002d:  leave.s    IL_0032

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_002f:  pop
      IL_0030:  leave.s    IL_0032

    }  // end handler
    IL_0032:  ret
  } // end of method AxEditorCtrl::CreateSink

  .method family hidebysig virtual instance void 
          DetachSink() cil managed
  {
    // Code size       17 (0x11)
    .maxstack  1
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxEditorCtrlLib.AxEditorCtrl::cookie
      IL_0006:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::Disconnect()
      IL_000b:  leave.s    IL_0010

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_000d:  pop
      IL_000e:  leave.s    IL_0010

    }  // end handler
    IL_0010:  ret
  } // end of method AxEditorCtrl::DetachSink

  .method family hidebysig virtual instance void 
          AttachInterfaces() cil managed
  {
    // Code size       23 (0x17)
    .maxstack  2
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  call       instance object [System.Windows.Forms]System.Windows.Forms.AxHost::GetOcx()
      IL_0007:  castclass  [EditorCtrlLib]EditorCtrlLib._DEditorCtrl
      IL_000c:  stfld      class [EditorCtrlLib]EditorCtrlLib._DEditorCtrl AxEditorCtrlLib.AxEditorCtrl::ocx
      IL_0011:  leave.s    IL_0016

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_0013:  pop
      IL_0014:  leave.s    IL_0016

    }  // end handler
    IL_0016:  ret
  } // end of method AxEditorCtrl::AttachInterfaces

  .method assembly hidebysig instance void 
          RaiseOnContextMenuOpening(object sender,
                                    class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxEditorCtrlLib.AxEditorCtrl::ContextMenuOpening
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxEditorCtrlLib.AxEditorCtrl::ContextMenuOpening
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxEditorCtrl::RaiseOnContextMenuOpening

  .event [mscorlib]System.EventHandler ContextMenuOpening
  {
    .removeon instance void AxEditorCtrlLib.AxEditorCtrl::remove_ContextMenuOpening(class [mscorlib]System.EventHandler)
    .addon instance void AxEditorCtrlLib.AxEditorCtrl::add_ContextMenuOpening(class [mscorlib]System.EventHandler)
  } // end of event AxEditorCtrl::ContextMenuOpening
  .property instance callconv(8) bool IsReadOnly()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 26 00 00 00 00 00 )                         // ..&.....
    .custom instance void [System]System.ComponentModel.DesignerSerializationVisibilityAttribute::.ctor(valuetype [System]System.ComponentModel.DesignerSerializationVisibility) = ( 01 00 00 00 00 00 00 00 ) 
    .get instance bool AxEditorCtrlLib.AxEditorCtrl::get_IsReadOnly()
    .set instance void AxEditorCtrlLib.AxEditorCtrl::set_IsReadOnly(bool)
  } // end of property AxEditorCtrl::IsReadOnly
} // end of class AxEditorCtrlLib.AxEditorCtrl

.class public auto ansi beforefieldinit AxEditorCtrlLib.AxEditorCtrlEventMulticaster
       extends [mscorlib]System.Object
       implements [EditorCtrlLib]EditorCtrlLib._DEditorCtrlEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .field private class AxEditorCtrlLib.AxEditorCtrl parent
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class AxEditorCtrlLib.AxEditorCtrl parent) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class AxEditorCtrlLib.AxEditorCtrl AxEditorCtrlLib.AxEditorCtrlEventMulticaster::parent
    IL_000d:  ret
  } // end of method AxEditorCtrlEventMulticaster::.ctor

  .method public hidebysig newslot virtual 
          instance void  ContextMenuOpening() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxEditorCtrlLib.AxEditorCtrl AxEditorCtrlLib.AxEditorCtrlEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxEditorCtrlLib.AxEditorCtrl AxEditorCtrlLib.AxEditorCtrlEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxEditorCtrlLib.AxEditorCtrl::RaiseOnContextMenuOpening(object,
                                                                                               class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxEditorCtrlEventMulticaster::ContextMenuOpening

} // end of class AxEditorCtrlLib.AxEditorCtrlEventMulticaster


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file orig.ildasm.res
