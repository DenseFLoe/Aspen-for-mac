﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AxIconEditorAxLib.AxIconEditorAx
  AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler
  AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent
  AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler
  AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent
  AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler
  AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent
  AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler
  AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent
  AxIconEditorAxLib.AxIconEditorAxEventMulticaster
}

// Metadata version: v4.0.30319
.assembly extern System.Windows.Forms
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern IconEditorAxLib
{
  .publickeytoken = (B0 56 89 B3 9D EE FB CD )                         // .V......
  .ver 41:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly AxIconEditorAxLib
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/TypeLibraryTimeStampAttribute::.ctor(string) = ( 01 00 13 30 34 2F 31 34 2F 32 30 32 35 20 30 39   // ...04/14/2025 09
                                                                                                                           3A 30 37 3A 35 31 00 00 )                         // :07:51..
  .custom instance void [mscorlib]System.Reflection.AssemblyKeyFileAttribute::.ctor(string) = ( 01 00 40 2E 2E 5C 70 61 63 6B 61 67 65 73 5C 41   // ..@..\packages\A
                                                                                                73 70 65 6E 54 65 63 68 2E 53 74 72 6F 6E 67 4E   // spenTech.StrongN
                                                                                                61 6D 65 2E 53 4E 4B 2E 31 2E 30 2E 30 5C 63 6F   // ame.SNK.1.0.0\co
                                                                                                6E 74 65 6E 74 5C 41 73 70 65 6E 74 65 63 68 2E   // ntent\Aspentech.
                                                                                                73 6E 6B 00 00 )                                  // snk..
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                31 CE F7 DF 85 4A 51 60 93 9C 58 8A 09 81 30 D8   // 1....JQ`..X...0.
                3B 58 C6 41 43 FE 98 DE 4F EA 84 44 85 EE C0 F8   // ;X.AC...O..D....
                BF 75 0A 6A 39 BA 8A 55 2E 37 20 73 B6 95 3A 09   // .u.j9..U.7 s..:.
                53 17 FB FB A3 6E B8 37 F2 D0 14 D6 2D 52 2D 2C   // S....n.7....-R-,
                B2 4F 39 B6 12 E0 DA 27 6D BF 15 4A 5D 0F 84 0D   // .O9....'m..J]...
                59 7F 81 E6 0E 83 1D 25 B6 EB C3 47 9D 69 C3 A6   // Y......%...G.i..
                6A 21 E7 D3 A8 62 09 D1 D3 50 BB 90 86 82 98 3C   // j!...b...P.....<
                80 C0 F7 D4 3B 60 C3 48 79 73 35 A7 33 B2 61 C8 ) // ....;`.Hys5.3.a.
  .hash algorithm 0x00008004
  .ver 41:0:0:0
}
.module AxIconEditorAxLib.dll
// MVID: {adc8c06b-9ac6-4c2c-8c4e-b969b52f056b}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x000001B059DA0000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi beforefieldinit AxIconEditorAxLib.AxIconEditorAx
       extends [System.Windows.Forms]System.Windows.Forms.AxHost
{
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ClsidAttribute::.ctor(string) = ( 01 00 26 7B 31 38 65 37 39 65 33 30 2D 63 38 66   // ..&{18e79e30-c8f
                                                                                                            31 2D 34 31 30 30 2D 61 38 65 35 2D 61 64 35 34   // 1-4100-a8e5-ad54
                                                                                                            65 65 66 36 35 36 39 39 7D 00 00 )                // eef65699}..
  .custom instance void [System]System.ComponentModel.DesignTimeVisibleAttribute::.ctor(bool) = ( 01 00 01 00 00 ) 
  .custom instance void [System]System.ComponentModel.DefaultEventAttribute::.ctor(string) = ( 01 00 08 53 65 6C 65 63 74 65 64 00 00 )          // ...Selected..
  .field private class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx ocx
  .field private class AxIconEditorAxLib.AxIconEditorAxEventMulticaster eventMulticaster
  .field private class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie cookie
  .field private class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler Selected
  .field private class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler HistoryModified
  .field private class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler IconModified
  .field private class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler ZoomChanged
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "18e79e30-c8f1-4100-a8e5-ad54eef65699"
    IL_0006:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::.ctor(string)
    IL_000b:  ret
  } // end of method AxIconEditorAx::.ctor

  .method public hidebysig specialname instance void 
          add_Selected(class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler AxIconEditorAxLib.AxIconEditorAx::Selected
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler AxIconEditorAxLib.AxIconEditorAx::Selected
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler>(!!0&,
                                                                                                                                                        !!0,
                                                                                                                                                        !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::add_Selected

  .method public hidebysig specialname instance void 
          remove_Selected(class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler AxIconEditorAxLib.AxIconEditorAx::Selected
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler AxIconEditorAxLib.AxIconEditorAx::Selected
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler>(!!0&,
                                                                                                                                                        !!0,
                                                                                                                                                        !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::remove_Selected

  .method public hidebysig specialname instance void 
          add_HistoryModified(class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::HistoryModified
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::HistoryModified
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler>(!!0&,
                                                                                                                                                               !!0,
                                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::add_HistoryModified

  .method public hidebysig specialname instance void 
          remove_HistoryModified(class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::HistoryModified
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::HistoryModified
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler>(!!0&,
                                                                                                                                                               !!0,
                                                                                                                                                               !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::remove_HistoryModified

  .method public hidebysig specialname instance void 
          add_IconModified(class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::IconModified
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::IconModified
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler>(!!0&,
                                                                                                                                                            !!0,
                                                                                                                                                            !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::add_IconModified

  .method public hidebysig specialname instance void 
          remove_IconModified(class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::IconModified
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::IconModified
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler>(!!0&,
                                                                                                                                                            !!0,
                                                                                                                                                            !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::remove_IconModified

  .method public hidebysig specialname instance void 
          add_ZoomChanged(class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler AxIconEditorAxLib.AxIconEditorAx::ZoomChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler AxIconEditorAxLib.AxIconEditorAx::ZoomChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler>(!!0&,
                                                                                                                                                           !!0,
                                                                                                                                                           !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::add_ZoomChanged

  .method public hidebysig specialname instance void 
          remove_ZoomChanged(class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler V_0,
             class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler V_1,
             class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler AxIconEditorAxLib.AxIconEditorAx::ZoomChanged
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler AxIconEditorAxLib.AxIconEditorAx::ZoomChanged
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler>(!!0&,
                                                                                                                                                           !!0,
                                                                                                                                                           !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxIconEditorAx::remove_ZoomChanged

  .method public hidebysig newslot virtual 
          instance void  Initialize() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Initialize"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::Initialize()
    IL_001f:  ret
  } // end of method AxIconEditorAx::Initialize

  .method public hidebysig newslot virtual 
          instance void  SetModelIcon(object pIcon) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetModelIcon"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetModelIcon(object)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetModelIcon

  .method public hidebysig newslot virtual 
          instance void  SetModelLibrary(object pLib) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetModelLibrary"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetModelLibrary(object)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetModelLibrary

  .method public hidebysig newslot virtual 
          instance void  SaveCurrentIcon() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SaveCurrentIcon"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SaveCurrentIcon()
    IL_001f:  ret
  } // end of method AxIconEditorAx::SaveCurrentIcon

  .method public hidebysig newslot virtual 
          instance void  ImportDXF(string sPath) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ImportDXF"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::ImportDXF(string)
    IL_0020:  ret
  } // end of method AxIconEditorAx::ImportDXF

  .method public hidebysig newslot virtual 
          instance void  GenerateScript() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GenerateScript"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GenerateScript()
    IL_001f:  ret
  } // end of method AxIconEditorAx::GenerateScript

  .method public hidebysig newslot virtual 
          instance void  RunScript() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "RunScript"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::RunScript()
    IL_001f:  ret
  } // end of method AxIconEditorAx::RunScript

  .method public hidebysig newslot virtual 
          instance void  DrawObject(int32 iId) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "DrawObject"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::DrawObject(int32)
    IL_0020:  ret
  } // end of method AxIconEditorAx::DrawObject

  .method public hidebysig newslot virtual 
          instance int32  HasSelectedObject() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int32 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "HasSelectedObject"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int32 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::HasSelectedObject()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::HasSelectedObject

  .method public hidebysig newslot virtual 
          instance void  GetTextAttribute(string& sfontname,
                                          int32& isize,
                                          int32& istyle,
                                          int32& iorientation,
                                          int32& icolor) cil managed
  {
    // Code size       39 (0x27)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetTextAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iorientation
    IL_001f:  ldarg.s    icolor
    IL_0021:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetTextAttribute(string&,
                                                                                                         int32&,
                                                                                                         int32&,
                                                                                                         int32&,
                                                                                                         int32&)
    IL_0026:  ret
  } // end of method AxIconEditorAx::GetTextAttribute

  .method public hidebysig newslot virtual 
          instance void  SetTextAttribute(string sfontname,
                                          int32 isize,
                                          int32 istyle,
                                          int32 iorientation,
                                          int32 icolor,
                                          int32 ifSel) cil managed
  {
    // Code size       41 (0x29)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetTextAttribute"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    iorientation
    IL_001f:  ldarg.s    icolor
    IL_0021:  ldarg.s    ifSel
    IL_0023:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetTextAttribute(string,
                                                                                                         int32,
                                                                                                         int32,
                                                                                                         int32,
                                                                                                         int32,
                                                                                                         int32)
    IL_0028:  ret
  } // end of method AxIconEditorAx::SetTextAttribute

  .method public hidebysig newslot virtual 
          instance void  FireSelectedEventWrep(int16 objectId) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FireSelectedEventWrep"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::FireSelectedEventWrep(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::FireSelectedEventWrep

  .method public hidebysig newslot virtual 
          instance string  GetUndoList() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetUndoList"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance string [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetUndoList()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetUndoList

  .method public hidebysig newslot virtual 
          instance string  GetRedoList() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetRedoList"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance string [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetRedoList()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetRedoList

  .method public hidebysig newslot virtual 
          instance void  SetOneStepUndo() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetOneStepUndo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetOneStepUndo()
    IL_001f:  ret
  } // end of method AxIconEditorAx::SetOneStepUndo

  .method public hidebysig newslot virtual 
          instance void  SetStepsUndo(int16 curIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetStepsUndo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetStepsUndo(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetStepsUndo

  .method public hidebysig newslot virtual 
          instance void  SetOneStepRedo() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetOneStepRedo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetOneStepRedo()
    IL_001f:  ret
  } // end of method AxIconEditorAx::SetOneStepRedo

  .method public hidebysig newslot virtual 
          instance void  SetStepsRedo(int16 curIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetStepsRedo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetStepsRedo(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetStepsRedo

  .method public hidebysig newslot virtual 
          instance void  FireHistoryModifiedEventWrep(int16 objectId) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FireHistoryModifiedEventWrep"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::FireHistoryModifiedEventWrep(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::FireHistoryModifiedEventWrep

  .method public hidebysig newslot virtual 
          instance int16  GetObjectLineColorIndex() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetObjectLineColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetObjectLineColorIndex()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetObjectLineColorIndex

  .method public hidebysig newslot virtual 
          instance int16  GetObjectLineTypeIndex() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetObjectLineTypeIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetObjectLineTypeIndex()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetObjectLineTypeIndex

  .method public hidebysig newslot virtual 
          instance void  SetObjectLineColorIndex(int16 colorIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetObjectLineColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetObjectLineColorIndex(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetObjectLineColorIndex

  .method public hidebysig newslot virtual 
          instance void  SetObjectLineTypeIndex(int16 typeLineIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetObjectLineTypeIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetObjectLineTypeIndex(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetObjectLineTypeIndex

  .method public hidebysig newslot virtual 
          instance int16  GetFillMode() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetFillMode"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetFillMode()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetFillMode

  .method public hidebysig newslot virtual 
          instance void  SetFillMode(int16 fillMode) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetFillMode"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetFillMode(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetFillMode

  .method public hidebysig newslot virtual 
          instance int16  GetObjectFillColorIndex() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetObjectFillColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetObjectFillColorIndex()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetObjectFillColorIndex

  .method public hidebysig newslot virtual 
          instance void  SetObjectFillColorIndex(int16 colorIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetObjectFillColorIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetObjectFillColorIndex(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetObjectFillColorIndex

  .method public hidebysig newslot virtual 
          instance void  SetClickRotate(int16 iNumBtn) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetClickRotate"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetClickRotate(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetClickRotate

  .method public hidebysig newslot virtual 
          instance int16  GetGrid() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetGrid"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetGrid()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetGrid

  .method public hidebysig newslot virtual 
          instance void  SetGrid(int16 iEnabled) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetGrid"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetGrid(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetGrid

  .method public hidebysig newslot virtual 
          instance int16  GetSnap() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetSnap"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetSnap()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetSnap

  .method public hidebysig newslot virtual 
          instance void  SetSnap(int16 iEnabled) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetSnap"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetSnap(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetSnap

  .method public hidebysig newslot virtual 
          instance int16  GetGridSizeIndex() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetGridSizeIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetGridSizeIndex()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetGridSizeIndex

  .method public hidebysig newslot virtual 
          instance void  SetGridSizeIndex(int16 iIndex) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetGridSizeIndex"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetGridSizeIndex(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetGridSizeIndex

  .method public hidebysig newslot virtual 
          instance int16  GetRotateEnabled() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetRotateEnabled"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetRotateEnabled()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetRotateEnabled

  .method public hidebysig newslot virtual 
          instance int16  GetIconModified() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetIconModified"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::GetIconModified()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::GetIconModified

  .method public hidebysig newslot virtual 
          instance void  FireIconModifiedEventWrep(int16 objectId) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FireIconModifiedEventWrep"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::FireIconModifiedEventWrep(int16)
    IL_0020:  ret
  } // end of method AxIconEditorAx::FireIconModifiedEventWrep

  .method public hidebysig newslot virtual 
          instance void  CheckSaveIcon() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CheckSaveIcon"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::CheckSaveIcon()
    IL_001f:  ret
  } // end of method AxIconEditorAx::CheckSaveIcon

  .method public hidebysig newslot virtual 
          instance void  InvokeMenuItem(int32 command) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "InvokeMenuItem"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::InvokeMenuItem(int32)
    IL_0020:  ret
  } // end of method AxIconEditorAx::InvokeMenuItem

  .method public hidebysig newslot virtual 
          instance void  ZoomToScale(float32 newScale) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ZoomToScale"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::ZoomToScale(float32)
    IL_0020:  ret
  } // end of method AxIconEditorAx::ZoomToScale

  .method public hidebysig newslot virtual 
          instance void  ResetActiveCtr() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "ResetActiveCtr"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::ResetActiveCtr()
    IL_001f:  ret
  } // end of method AxIconEditorAx::ResetActiveCtr

  .method public hidebysig newslot virtual 
          instance int16  FocusInTextEdit() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (int16 V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "FocusInTextEdit"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  callvirt   instance int16 [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::FocusInTextEdit()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxIconEditorAx::FocusInTextEdit

  .method public hidebysig newslot virtual 
          instance void  HideToolbars(bool bHide) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "HideToolbars"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::HideToolbars(bool)
    IL_0020:  ret
  } // end of method AxIconEditorAx::HideToolbars

  .method public hidebysig newslot virtual 
          instance void  SetACMModelIcon(object pIcon) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetACMModelIcon"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetACMModelIcon(object)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetACMModelIcon

  .method public hidebysig newslot virtual 
          instance void  SetAskForSaveWhenClose(bool bAsk) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetAskForSaveWhenClose"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::SetAskForSaveWhenClose(bool)
    IL_0020:  ret
  } // end of method AxIconEditorAx::SetAskForSaveWhenClose

  .method public hidebysig newslot virtual 
          instance void  KeyDown(int32 nChar,
                                 int32 nRepCnt,
                                 int32 nFlags) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "KeyDown"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance void [IconEditorAxLib]IconEditorAxLib._DIconEditorAx::KeyDown(int32,
                                                                                                int32,
                                                                                                int32)
    IL_0022:  ret
  } // end of method AxIconEditorAx::KeyDown

  .method family hidebysig virtual instance void 
          CreateSink() cil managed
  {
    // Code size       51 (0x33)
    .maxstack  4
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  newobj     instance void AxIconEditorAxLib.AxIconEditorAxEventMulticaster::.ctor(class AxIconEditorAxLib.AxIconEditorAx)
      IL_0007:  stfld      class AxIconEditorAxLib.AxIconEditorAxEventMulticaster AxIconEditorAxLib.AxIconEditorAx::eventMulticaster
      IL_000c:  ldarg.0
      IL_000d:  ldarg.0
      IL_000e:  ldfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
      IL_0013:  ldarg.0
      IL_0014:  ldfld      class AxIconEditorAxLib.AxIconEditorAxEventMulticaster AxIconEditorAxLib.AxIconEditorAx::eventMulticaster
      IL_0019:  ldtoken    [IconEditorAxLib]IconEditorAxLib._DIconEditorAxEvents
      IL_001e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0023:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::.ctor(object,
                                                                                                                        object,
                                                                                                                        class [mscorlib]System.Type)
      IL_0028:  stfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxIconEditorAxLib.AxIconEditorAx::cookie
      IL_002d:  leave.s    IL_0032

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_002f:  pop
      IL_0030:  leave.s    IL_0032

    }  // end handler
    IL_0032:  ret
  } // end of method AxIconEditorAx::CreateSink

  .method family hidebysig virtual instance void 
          DetachSink() cil managed
  {
    // Code size       17 (0x11)
    .maxstack  1
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxIconEditorAxLib.AxIconEditorAx::cookie
      IL_0006:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::Disconnect()
      IL_000b:  leave.s    IL_0010

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_000d:  pop
      IL_000e:  leave.s    IL_0010

    }  // end handler
    IL_0010:  ret
  } // end of method AxIconEditorAx::DetachSink

  .method family hidebysig virtual instance void 
          AttachInterfaces() cil managed
  {
    // Code size       23 (0x17)
    .maxstack  2
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  call       instance object [System.Windows.Forms]System.Windows.Forms.AxHost::GetOcx()
      IL_0007:  castclass  [IconEditorAxLib]IconEditorAxLib._DIconEditorAx
      IL_000c:  stfld      class [IconEditorAxLib]IconEditorAxLib._DIconEditorAx AxIconEditorAxLib.AxIconEditorAx::ocx
      IL_0011:  leave.s    IL_0016

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_0013:  pop
      IL_0014:  leave.s    IL_0016

    }  // end handler
    IL_0016:  ret
  } // end of method AxIconEditorAx::AttachInterfaces

  .method assembly hidebysig instance void 
          RaiseOnSelected(object sender,
                          class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler AxIconEditorAxLib.AxIconEditorAx::Selected
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler AxIconEditorAxLib.AxIconEditorAx::Selected
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler::Invoke(object,
                                                                                                           class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent)
    IL_0015:  ret
  } // end of method AxIconEditorAx::RaiseOnSelected

  .method assembly hidebysig instance void 
          RaiseOnHistoryModified(object sender,
                                 class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::HistoryModified
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::HistoryModified
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler::Invoke(object,
                                                                                                                  class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent)
    IL_0015:  ret
  } // end of method AxIconEditorAx::RaiseOnHistoryModified

  .method assembly hidebysig instance void 
          RaiseOnIconModified(object sender,
                              class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::IconModified
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler AxIconEditorAxLib.AxIconEditorAx::IconModified
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler::Invoke(object,
                                                                                                               class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent)
    IL_0015:  ret
  } // end of method AxIconEditorAx::RaiseOnIconModified

  .method assembly hidebysig instance void 
          RaiseOnZoomChanged(object sender,
                             class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler AxIconEditorAxLib.AxIconEditorAx::ZoomChanged
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler AxIconEditorAxLib.AxIconEditorAx::ZoomChanged
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler::Invoke(object,
                                                                                                              class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent)
    IL_0015:  ret
  } // end of method AxIconEditorAx::RaiseOnZoomChanged

  .event AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler Selected
  {
    .addon instance void AxIconEditorAxLib.AxIconEditorAx::add_Selected(class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler)
    .removeon instance void AxIconEditorAxLib.AxIconEditorAx::remove_Selected(class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler)
  } // end of event AxIconEditorAx::Selected
  .event AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler HistoryModified
  {
    .removeon instance void AxIconEditorAxLib.AxIconEditorAx::remove_HistoryModified(class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler)
    .addon instance void AxIconEditorAxLib.AxIconEditorAx::add_HistoryModified(class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler)
  } // end of event AxIconEditorAx::HistoryModified
  .event AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler IconModified
  {
    .removeon instance void AxIconEditorAxLib.AxIconEditorAx::remove_IconModified(class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler)
    .addon instance void AxIconEditorAxLib.AxIconEditorAx::add_IconModified(class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler)
  } // end of event AxIconEditorAx::IconModified
  .event AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler ZoomChanged
  {
    .addon instance void AxIconEditorAxLib.AxIconEditorAx::add_ZoomChanged(class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler)
    .removeon instance void AxIconEditorAxLib.AxIconEditorAx::remove_ZoomChanged(class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler)
  } // end of event AxIconEditorAx::ZoomChanged
} // end of class AxIconEditorAxLib.AxIconEditorAx

.class public auto ansi sealed AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DIconEditorAxEvents_SelectedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent e) runtime managed
  {
  } // end of method _DIconEditorAxEvents_SelectedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DIconEditorAxEvents_SelectedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DIconEditorAxEvents_SelectedEventHandler::EndInvoke

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEventHandler

.class public auto ansi beforefieldinit AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent
       extends [mscorlib]System.Object
{
  .field public int16 objectId
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int16 objectId) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int16 AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent::objectId
    IL_000d:  ret
  } // end of method _DIconEditorAxEvents_SelectedEvent::.ctor

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent

.class public auto ansi sealed AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DIconEditorAxEvents_HistoryModifiedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent e) runtime managed
  {
  } // end of method _DIconEditorAxEvents_HistoryModifiedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DIconEditorAxEvents_HistoryModifiedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DIconEditorAxEvents_HistoryModifiedEventHandler::EndInvoke

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEventHandler

.class public auto ansi beforefieldinit AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent
       extends [mscorlib]System.Object
{
  .field public int16 objectId
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int16 objectId) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int16 AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent::objectId
    IL_000d:  ret
  } // end of method _DIconEditorAxEvents_HistoryModifiedEvent::.ctor

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent

.class public auto ansi sealed AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DIconEditorAxEvents_IconModifiedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent e) runtime managed
  {
  } // end of method _DIconEditorAxEvents_IconModifiedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DIconEditorAxEvents_IconModifiedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DIconEditorAxEvents_IconModifiedEventHandler::EndInvoke

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEventHandler

.class public auto ansi beforefieldinit AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent
       extends [mscorlib]System.Object
{
  .field public int16 objectId
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int16 objectId) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int16 AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent::objectId
    IL_000d:  ret
  } // end of method _DIconEditorAxEvents_IconModifiedEvent::.ctor

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent

.class public auto ansi sealed AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DIconEditorAxEvents_ZoomChangedEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent e) runtime managed
  {
  } // end of method _DIconEditorAxEvents_ZoomChangedEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DIconEditorAxEvents_ZoomChangedEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DIconEditorAxEvents_ZoomChangedEventHandler::EndInvoke

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEventHandler

.class public auto ansi beforefieldinit AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent
       extends [mscorlib]System.Object
{
  .field public float32 oldScale
  .field public float32 newScale
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(float32 oldScale,
                               float32 newScale) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      float32 AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent::oldScale
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      float32 AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent::newScale
    IL_0014:  ret
  } // end of method _DIconEditorAxEvents_ZoomChangedEvent::.ctor

} // end of class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent

.class public auto ansi beforefieldinit AxIconEditorAxLib.AxIconEditorAxEventMulticaster
       extends [mscorlib]System.Object
       implements [IconEditorAxLib]IconEditorAxLib._DIconEditorAxEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .field private class AxIconEditorAxLib.AxIconEditorAx parent
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class AxIconEditorAxLib.AxIconEditorAx parent) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_000d:  ret
  } // end of method AxIconEditorAxEventMulticaster::.ctor

  .method public hidebysig newslot virtual 
          instance void  Selected(int16 objectId) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent::.ctor(int16)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxIconEditorAxLib.AxIconEditorAx::RaiseOnSelected(object,
                                                                                         class AxIconEditorAxLib._DIconEditorAxEvents_SelectedEvent)
    IL_0019:  ret
  } // end of method AxIconEditorAxEventMulticaster::Selected

  .method public hidebysig newslot virtual 
          instance void  HistoryModified(int16 objectId) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent::.ctor(int16)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxIconEditorAxLib.AxIconEditorAx::RaiseOnHistoryModified(object,
                                                                                                class AxIconEditorAxLib._DIconEditorAxEvents_HistoryModifiedEvent)
    IL_0019:  ret
  } // end of method AxIconEditorAxEventMulticaster::HistoryModified

  .method public hidebysig newslot virtual 
          instance void  IconModified(int16 objectId) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent::.ctor(int16)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxIconEditorAxLib.AxIconEditorAx::RaiseOnIconModified(object,
                                                                                             class AxIconEditorAxLib._DIconEditorAxEvents_IconModifiedEvent)
    IL_0019:  ret
  } // end of method AxIconEditorAxEventMulticaster::IconModified

  .method public hidebysig newslot virtual 
          instance void  ZoomChanged(float32 oldScale,
                                     float32 newScale) cil managed
  {
    // Code size       27 (0x1b)
    .maxstack  3
    .locals init (class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  newobj     instance void AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent::.ctor(float32,
                                                                                                      float32)
    IL_0007:  stloc.0
    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_000e:  ldarg.0
    IL_000f:  ldfld      class AxIconEditorAxLib.AxIconEditorAx AxIconEditorAxLib.AxIconEditorAxEventMulticaster::parent
    IL_0014:  ldloc.0
    IL_0015:  callvirt   instance void AxIconEditorAxLib.AxIconEditorAx::RaiseOnZoomChanged(object,
                                                                                            class AxIconEditorAxLib._DIconEditorAxEvents_ZoomChangedEvent)
    IL_001a:  ret
  } // end of method AxIconEditorAxEventMulticaster::ZoomChanged

} // end of class AxIconEditorAxLib.AxIconEditorAxEventMulticaster


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125\router\work\m-near-partial\axil\b28e3ef2\orig.ildasm.res
