#!/usr/bin/env python3
"""Re-anchor IL token operands in an ilasm-assembled candidate to the original
assembly's metadata tokens.

`ilasm` assigns MemberRef/TypeRef/Field/Method/String tokens in its own parse
order, which need not match the original aximp writer.  Every method body of the
candidate has the same length and the same non-token bytes as the original (that
is verified here); only the 4-byte token operands differ.  This script maps each
operand to the original token by its Cecil-rendered identity (method/field/type
FullName, or #US string value) and patches the raw code bytes.  It then asserts
that every method body is byte-identical to the original's.

Usage: token_patch.py <candidate.dll> <original.dll> <orig.operands.json>
                       <cand.operands.json> <out.dll> <report.json>
"""
import json
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]      # router
sys.path.insert(0, str(ROOT / "managed"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
import clr_meta  # noqa: E402


def read_us(pe, cli, root):
    stream = root["streams"]["#US"]
    data = pe.get_data(cli["metadata_rva"] + stream["offset"], stream["size"])
    out = {}
    at = 1
    while at < len(data):
        b0 = data[at]
        if b0 & 0x80 == 0:
            n, s = b0, at + 1
        elif b0 & 0xC0 == 0x80:
            n, s = ((b0 & 0x3F) << 8) | data[at + 1], at + 2
        else:
            n, s = ((b0 & 0x1F) << 24) | (data[at + 1] << 16) | (data[at + 2] << 8) | data[at + 3], at + 4
        blob = data[s:s + n]
        if n >= 1:
            text = blob[:n - 1].decode("utf-16-le", "replace")
            out.setdefault(text, 0x70000000 | at)
        at = s + n
    return out


def method_code_start(pe, root, token):
    row = clr_meta.read_row(root["bytes"], root["tables"], 0x06, token & 0xFFFFFF)
    rva = row[0]
    size, head, code, flags = clr_meta.method_extent(pe, rva)
    return pe.get_offset_from_rva(rva) + head


def bodies(path):
    data = Path(path).read_bytes()
    pe, cli, root = clr_meta.read_image(data)
    out = []
    for m in clr_meta.method_defs(pe, cli, root):
        if m["rva"]:
            size, head, code, flags = clr_meta.method_extent(pe, m["rva"])
            off = pe.get_offset_from_rva(m["rva"])
            out.append(data[off:off + size])
        else:
            out.append(b"")
    return data, pe, cli, root, out


def type_ref_key(pe, cli, root, rid):
    """Semantic key of a TypeRef: (scope, namespace, name)."""
    row = clr_meta.read_row(root["bytes"], root["tables"], 0x01, rid)
    ns = clr_meta.strings(pe, cli, root, row[2])
    name = clr_meta.strings(pe, cli, root, row[1])
    raw = row[0]
    tag, index = raw & 3, raw >> 2
    if tag == 2 and index:
        a = clr_meta.read_row(root["bytes"], root["tables"], 0x23, index)
        scope = clr_meta.strings(pe, cli, root, a[6])
    elif tag == 1 and index:
        scope = "moduleref"
    elif tag == 3 and index:
        scope = "typeref"
    else:
        scope = "module"
    return (scope, ns, name)


def patch_eh_types(data, pe, cli, root, target):
    """Rewrite catch-clause ClassToken TypeRef tokens to `target`'s tokens."""
    fixed = 0
    for m in clr_meta.method_defs(pe, cli, root):
        if not m["rva"] or not (m["method_flags"] & 8):
            continue
        off = pe.get_offset_from_rva(m["rva"])
        size, head, code, flags = clr_meta.method_extent(pe, m["rva"])
        at = head + code
        if at & 3:
            at += 4 - (at & 3)
        kind = data[off + at]
        if kind == 1:
            clause_size = 12
            count = (data[off + at + 1] | (data[off + at + 2] << 8)) // clause_size
            count_at = at + 4
        elif kind == 0x41:
            clause_size = 24
            count = int.from_bytes(data[off + at + 1:off + at + 4], "little") // clause_size
            count_at = at + 4
        else:
            continue
        for i in range(count):
            c = off + count_at + i * clause_size
            if kind == 1:
                fl = struct.unpack_from("<H", data, c)[0]
                tok_at, tok = c + 8, struct.unpack_from("<I", data, c + 8)[0]
            else:
                fl = struct.unpack_from("<I", data, c)[0]
                tok_at, tok = c + 20, struct.unpack_from("<I", data, c + 20)[0]
            if fl & 7 != 0 or not tok:
                continue
            if tok >> 24 not in (0x01, 0x02):
                continue
            rid = tok & 0xFFFFFF
            if tok >> 24 == 0x01:
                key = type_ref_key(pe, cli, root, rid)
            else:
                t = clr_meta.read_row(root["bytes"], root["tables"], 0x02, rid)
                key = ("typedef", clr_meta.strings(pe, cli, root, t[2]),
                       clr_meta.strings(pe, cli, root, t[1]))
            new_tok = target.get(key)
            if new_tok is None:
                raise SystemExit("unmapped EH type %r" % (key,))
            if new_tok != tok:
                struct.pack_into("<I", data, tok_at, new_tok)
                fixed += 1
    return fixed


def main(cand_path, orig_path, orig_ops, cand_ops, out_path, report_path):
    orig = json.loads(Path(orig_ops).read_text(encoding="utf-8"))
    cand = json.loads(Path(cand_ops).read_text(encoding="utf-8"))
    odata, ope, ocli, oroot, obodies = bodies(orig_path)
    cdata, cpe, ccli, croot, cbodies = bodies(cand_path)
    ous = read_us(ope, ocli, oroot)
    ous_rev = {v: k for k, v in ous.items()}
    omap = {}
    for row in orig:
        if row["kind"] == "string":
            if row["key"] not in ous:
                raise SystemExit("string not in original #US heap: %r" % row["key"])
            omap[("string", row["key"])] = ous[row["key"]]
        else:
            omap[(row["kind"], row["key"])] = row["raw"]
    data = bytearray(cdata)
    patched = 0
    missing = []
    kinds = {}
    for row in cand:
        if row["kind"] == "string":
            target = ous.get(row["key"])
        else:
            target = omap.get((row["kind"], row["key"]))
        if target is None:
            missing.append((row["kind"], row["key"]))
            continue
        token = row["method"]
        start = method_code_start(cpe, croot, token)
        at = start + row["offset"] + row["opcode_size"]
        old, = struct.unpack_from("<I", data, at)
        if old != target:
            struct.pack_into("<I", data, at, target)
            patched += 1
            kinds[row["kind"]] = kinds.get(row["kind"], 0) + 1
    if missing:
        raise SystemExit("unmapped operands: %s" % missing[:5])
    orig_tref = {}
    for rid in range(1, oroot["tables"]["layout"].get(0x01, {}).get("rows", 0) + 1):
        orig_tref[type_ref_key(ope, ocli, oroot, rid)] = 0x01000000 | rid
    eh_fixed = patch_eh_types(data, cpe, ccli, croot, orig_tref)
    Path(out_path).write_bytes(bytes(data))
    # verify every body byte-identical
    ndata, npe, ncli, nroot, nbodies = bodies(out_path)
    bad = [i + 1 for i, (a, b) in enumerate(zip(obodies, nbodies)) if a != b]
    report = {"patched_operands": patched, "patched_by_kind": kinds,
              "patched_eh_types": eh_fixed,
              "methods": len(nbodies), "body_mismatches": bad[:20],
              "body_mismatch_count": len(bad),
              "candidate_sha256": __import__("hashlib").sha256(cdata).hexdigest(),
              "output_sha256": __import__("hashlib").sha256(bytes(data)).hexdigest()}
    Path(report_path).write_text(json.dumps(report, ensure_ascii=False, indent=1), encoding="utf-8")
    print(json.dumps({k: v for k, v in report.items() if k != "body_mismatches"}, ensure_ascii=False))


if __name__ == "__main__":
    main(*sys.argv[1:7])
