"""Recompile a saved C# package and restore its original, verified non-code PE records."""

import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import zipfile

import struct

from pe_layout2 import apply_recipe, identified_image


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def quote(path):
    return '"' + str(path) + '"'


def build(package_path, work, *, changed_source=None):
    with zipfile.ZipFile(package_path) as package:
        plan = json.loads(package.read("build-plan.json"))
        work = work.resolve()
        work.mkdir()
        target = work / plan["assembly_name"]
        paths = {}
        for name, expected in plan["build_input_sha256"].items():
            content = package.read(name)
            if sha256(content).hexdigest() != expected:
                raise ValueError(f"Archived build input changed: {name}")
            path = work / Path(name).name
            if changed_source and changed_source[0] == name:
                content = changed_source[1]
            path.write_bytes(content)
            paths[name] = path
        dotnet, compiler = (Path(plan["tool_path"][name]) for name in ("dotnet", "csc"))
        if digest(dotnet) != plan["dotnet_sha256"] or digest(compiler) != plan["csc_sha256"]:
            raise ValueError("A pinned local C# compiler file changed")
        references = {Path(name): expected for name, expected in plan["references"].items()}
        linked = {Path(name): expected for name, expected in plan.get("linked_references", {}).items()}
        if any(digest(path) != pin for path, pin in (references | linked).items()):
            raise ValueError("A pinned local .NET reference assembly changed")
        flags = plan["fixed_flags"] + ["/out:" + quote(target), "/win32res:" + quote(paths["resources/original.res"])]
        if "build/assembly-public-key.snk" in paths:
            flags += ["/publicsign+", "/keyfile:" + quote(paths["build/assembly-public-key.snk"])]
        flags += ["/reference:" + quote(path) for path in references]
        flags += ["/link:" + quote(path) for path in linked]
        flags += ["/resource:" + quote(paths[row["member"]]) + "," + quote(row["manifest_name"]) + "," + row["visibility"]
                  for row in plan.get("managed_resources", ())]
        flags += [quote(path) for name, path in paths.items() if name.startswith("editable/")]
        response = work / "compile.rsp"
        response.write_text("\n".join(flags) + "\n", encoding="utf-8")
        env = os.environ | {"DOTNET_CLI_HOME": str(work), "DOTNET_CLI_TELEMETRY_OPTOUT": "1", "DOTNET_NOLOGO": "1"}
        proc = subprocess.run([str(dotnet), str(compiler), "/noconfig", "@" + str(response)], cwd=work,
                              env=env, capture_output=True, timeout=130, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        (work / "compile.log").write_bytes(proc.stdout + proc.stderr)
        if proc.returncode or not target.is_file():
            raise ValueError((proc.stdout + proc.stderr).decode("utf-8", errors="replace"))
    return target


def controlled_metadata_update(compiled, plan):
    updates = plan.get("type_definition_flags", ())
    if not updates:
        return compiled
    if sha256(compiled).hexdigest() != plan["raw_compiler_output_sha256"]:
        raise ValueError("TypeDef flag edits cannot be applied to changed C# compiler output")
    pe, metadata = identified_image(compiled)
    offset, width = metadata["streams"]["#~"]
    start = pe.get_offset_from_rva(metadata["rva"]) + offset
    data = bytearray(compiled)
    for point in updates:
        at, old, new = (point[k] for k in ("Offset", "OriginalCompilerFlags", "RestoredFlags"))
        if (not start <= at < start + width - 3 or old ^ new != 0x100000 or new & 0x100000
                or struct.unpack_from("<I", compiled, at)[0] != old):
            raise ValueError(f"Unauthorized TypeDef flag edit at file offset {at:#x}")
        struct.pack_into("<I", data, at, new)
    return bytes(data)


def rebuild(package_path, work):
    compiled = build(package_path, work)
    with zipfile.ZipFile(package_path) as package:
        recipe = json.loads(package.read("layout-recipe.json"))
        plan = json.loads(package.read("build-plan.json"))
        candidate = controlled_metadata_update(compiled.read_bytes(), plan)
        result = apply_recipe(candidate, recipe, package.read("original-build/debug-record.bin"),
                              package.read("original-build/certificate-table.bin"),
                              package.read("original-build/strong-name.bin") if recipe["strong_name"] else b"")
    output = work / "exact"
    output.mkdir()
    artifact = output / compiled.name
    artifact.write_bytes(result)
    return artifact


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("archive", type=Path)
    cli.add_argument("new_output_directory", type=Path)
    args = cli.parse_args()
    print(rebuild(args.archive, args.new_output_directory))
