#!/usr/bin/env python3
"""Clear the CLR strong-name slot in an ilasm output.

ilasm emits the Assembly public key but does not sign; it leaves a 128-byte
strong-name slot in the CLR header.  The replay restores the original CLR header
and signature, so the candidate must declare itself unsigned (slot RVA/size 0,
StrongNameSigned flag clear) for the layout recipe's flag/slot consistency check.

Usage: strip_strong_slot.py <in.dll> <out.dll>
"""
import struct
import sys
from pathlib import Path

data = bytearray(Path(sys.argv[1]).read_bytes())
pe = struct.unpack_from("<I", data, 0x3C)[0]
coff = pe + 4
# ilasm stamps the COFF header with the current time; zero it so the assembled
# candidate is deterministic (the recipe replays the original timestamp anyway).
struct.pack_into("<I", data, coff + 4, 0)
num = struct.unpack_from("<H", data, coff + 2)[0]
size_opt = struct.unpack_from("<H", data, coff + 16)[0]
opt = coff + 20
# ilasm also stores a PE checksum over the stamped image; zero it as well.
struct.pack_into("<I", data, opt + 64, 0)
clr_rva, clr_size = struct.unpack_from("<II", data, opt + 96 + 14 * 8)
if not clr_size:
    raise SystemExit("no CLR header")
sections = opt + size_opt
clr_off = None
for i in range(num):
    at = sections + i * 40
    vsize, vaddr, rawsize, rawptr = struct.unpack_from("<IIII", data, at + 8)
    if vaddr <= clr_rva < vaddr + max(vsize, rawsize):
        clr_off = rawptr + (clr_rva - vaddr)
        break
if clr_off is None:
    raise SystemExit("CLR header outside sections")
# ilasm generates a random Module MVID; zero it so the assembled candidate is
# deterministic (the replay restores the original #GUID stream wholesale).
md_rva, md_size = struct.unpack_from("<II", data, clr_off + 8)
md_off = None
for i in range(num):
    at = sections + i * 40
    vsize, vaddr, rawsize, rawptr = struct.unpack_from("<IIII", data, at + 8)
    if vaddr <= md_rva < vaddr + max(vsize, rawsize):
        md_off = rawptr + (md_rva - vaddr)
        break
if md_off is None:
    raise SystemExit("metadata outside sections")
version, = struct.unpack_from("<I", data, md_off + 12)
count = struct.unpack_from("<H", data, md_off + 18 + version)[0]
at = md_off + 20 + version
for _ in range(count):
    offset, length = struct.unpack_from("<II", data, at)
    end = data.index(b"\0", at + 8)
    name = data[at + 8:end].decode("ascii")
    if name == "#GUID" and length >= 16:
        data[md_off + offset:md_off + offset + 16] = bytes(16)
    at = (end + 4) & ~3
struct.pack_into("<II", data, clr_off + 32, 0, 0)
flags = struct.unpack_from("<I", data, clr_off + 16)[0]
struct.pack_into("<I", data, clr_off + 16, flags & ~8)
Path(sys.argv[2]).write_bytes(bytes(data))
print(clr_off)
