using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using Mono.Cecil;
using Mono.Cecil.Cil;

// Dump every instruction operand that carries a metadata token, together with
// the instruction offset and opcode size, so the caller can rewrite token
// operands in the raw method body without re-assembling the IL.
// Usage: OperandDump <assembly> <out.json>
class OperandDump
{
    static void Main(string[] args)
    {
        var asm = AssemblyDefinition.ReadAssembly(args[0]);
        var sb = new StringBuilder();
        sb.Append("[");
        bool first = true;
        foreach (var module in asm.Modules)
            foreach (var type in module.Types)
                Walk(type, sb, ref first);
        sb.Append("]");
        File.WriteAllText(args[1], sb.ToString(), new UTF8Encoding(false));
    }

    static string Esc(string s)
    {
        var b = new StringBuilder();
        foreach (char c in s)
        {
            switch (c)
            {
                case '"': b.Append("\\\""); break;
                case '\\': b.Append("\\\\"); break;
                case '\n': b.Append("\\n"); break;
                case '\r': b.Append("\\r"); break;
                case '\t': b.Append("\\t"); break;
                default:
                    if (c < 0x20) b.Append("\\u" + ((int)c).ToString("x4"));
                    else b.Append(c);
                    break;
            }
        }
        return b.ToString();
    }

    static void Emit(StringBuilder sb, ref bool first, MethodDefinition method, Instruction ins,
                     string kind, string key, uint? raw)
    {
        if (!first) sb.Append(",");
        first = false;
        sb.Append("{\"method\":");
        sb.Append(method.MetadataToken.ToUInt32());
        sb.Append(",\"offset\":");
        sb.Append(ins.Offset);
        sb.Append(",\"opcode_size\":");
        sb.Append(ins.OpCode.Size);
        sb.Append(",\"kind\":\"");
        sb.Append(kind);
        sb.Append("\",\"key\":\"");
        sb.Append(Esc(key));
        sb.Append("\",\"raw\":");
        sb.Append(raw.HasValue ? raw.Value.ToString() : "null");
        sb.Append("}");
    }

    static void Walk(TypeDefinition type, StringBuilder sb, ref bool first)
    {
        foreach (var method in type.Methods)
        {
            if (!method.HasBody) continue;
            foreach (var ins in method.Body.Instructions)
            {
                var ot = ins.OpCode.OperandType;
                var op = ins.Operand;
                switch (ot)
                {
                    case OperandType.InlineMethod:
                    case OperandType.InlineField:
                    case OperandType.InlineType:
                    case OperandType.InlineTok:
                        if (op is MethodReference mr)
                            Emit(sb, ref first, method, ins, "method", mr.FullName, mr.MetadataToken.ToUInt32());
                        else if (op is FieldReference fr)
                            Emit(sb, ref first, method, ins, "field", fr.FullName, fr.MetadataToken.ToUInt32());
                        else if (op is TypeReference tr)
                            Emit(sb, ref first, method, ins, "type", tr.FullName, tr.MetadataToken.ToUInt32());
                        break;
                    case OperandType.InlineString:
                        if (op is string s)
                            Emit(sb, ref first, method, ins, "string", s, null);
                        break;
                }
            }
        }
        foreach (var nested in type.NestedTypes)
            Walk(nested, sb, ref first);
    }
}
