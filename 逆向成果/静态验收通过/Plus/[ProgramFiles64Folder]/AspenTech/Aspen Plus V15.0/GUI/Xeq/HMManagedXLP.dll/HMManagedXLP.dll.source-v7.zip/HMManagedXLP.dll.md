# HMManagedXLP.dll

Aspen Plus V15.0，文件和程序集版本均为 23.1.23.0。安装原件位于 `C:\Program Files\AspenTech\Aspen Plus V15.0\GUI\Xeq\HMManagedXLP.dll`，项目原相对路径为 `[ProgramFiles64Folder]/AspenTech/Aspen Plus V15.0/GUI/Xeq/HMManagedXLP.dll`。原件 71,760 字节，SHA-256 为 `3186d51b396c281ab10ae71c5ba00d6cebdae09bf17eabacb0a08a24ff556e7f`。

固定主干 `adbe73b517acac25da87598cce46de033f630ccb` 中履历为待静态验收。本包为本轮制作件，静态覆盖见本说明和 `evidence/producer-compare.json`，整件裁定由任务负责人与独立复核员确认。

## 源码与回编输入

- `HMManagedXLP.dll.cs` 复用本机夜班 `HMManagedXLP.dll.v6.zip` 中的可编辑 C#。历史包 SHA-256 为 `5aa90a9d414b4e94fc3d49710909894eb6b6e70b9325e9a8e0280615f9be8acc`，当前 C# SHA-256 为 `4c29aad81ff6ea426311e290e479227c442781c19a2b0b4a61dcc9e22955d017`。历史包中经 Roslyn 3.8.0 校正了迭代器 `Dispose` 编译形态，并恢复了 `FixSolution`、`LoadSolutionFile` 和成员顺序。
- `build/assembly-public-key.snk` 为历史包从原件 Assembly.PublicKey 提取的 160 字节公开身份资料，SHA-256 为 `c8f680aeff6efc2ba09e5ec3dc683c7c025a283d3c3b6ff68b08b727afc2f7d9`。Roslyn 的 `/publicsign+` 保留公钥标记和身份，生成的 128 字节强名槽为零。静态比较按原件公钥、签名声明和程序集身份核对。Windows 部署如需签名验证，须另外解决有效签名。
- `build.py` 只调用 C# 编译器，输入为 C#、公钥和标准库引用。没有读取原件、回放元数据、重发令牌、附加证书或安装原件 PE 片段的构建步骤。指定 `/highentropyva+` 后 PE 的 `DllCharacteristics` 旗标与原件同为 `0x8560`。版本资源由 Roslyn 使用程序集特性生成，源包无需另带 PE 资源二进制。

## 从空目录构建和比较

在一个新的工作目录解压本包，再从包根执行以下 PowerShell 示例。将变量设为各依赖的完整路径，输出目录使用一个新的空路径。

```powershell
python -B build.py --dotnet $Dotnet --csc $Csc --netstandard-ref $NetstandardReference --out-dir .\build-output
python -B compare.py --original $Original --rebuilt .\build-output\HMManagedXLP.dll --acceptance-tools $AcceptanceTools --report .\build-output\compare.json
```

- 构建使用 Python 3.12.10、Windows x64 .NET Runtime 9.0.23 托管运行时和 `Microsoft.Net.Compilers.Toolset` 3.8.0 中的 `tasks/netcoreapp3.1/bincore/csc.dll`（实测版本 `3.8.0-5.20562.2 (8de9e4b2)`，csc 同目录文件须保留），引用使用 `NETStandard.Library` 2.0.3 中的 `build/netstandard2.0/ref/netstandard.dll`。工具和引用文件由使用方提供。此命令无需 .NET SDK、Aspen 安装、Excel 或原件。输出为 `build-output/HMManagedXLP.dll`、`build-output/build.json` 和临时子目录。实测 DLL 为 61,440 字节，SHA-256 为 `eb77334b8462c4b72663bf50f698763df38c85bcda98fe6edbbe47be2833a574`。
- 比较需要读取安装原件、Python 的 `pefile==2024.8.26`、PATH 上的 PowerShell 7.6.9 (`pwsh`) 和原样共享项目工具 `tools/reverse_acceptance`。本机默认 PowerShell 7.2.2 缺少 `Stream.ReadExactly`，实测需将可用的现代 PowerShell 目录提前到 PATH。报告记录本次调用的共享源码指纹。其余运行时及临时文件可以用 `TEMP`、`TMP` 和 `TMPDIR` 指向输出目录。

## 制作方实测

- 665 条 MethodDef 均按声明与实现类别逐条配对。406 条 CIL 实现覆盖 13,581 字节 IL、局部签名、栈、分支操作数及 4 条异常区。259 条是原件 RVA 为零的 `hmxlpxmps` P/Invoke 声明，签名、flags、ImplMap 和封送元数据由双方相等的 CLR metadata 验证；原件和候选比较均无未配对、歧义或方法差异。
- 共享托管比较器只将 MethodDef 的物理 RVA 和 Module.Mvid 对应的 GUID 槽归零，即可得到相同的整个 CLR metadata 摘要。其余元数据均纳入比较，包括 32 TypeDef（含 `<Module>`）、174 Field、71 Property、17 MethodImpl、2 FieldMarshal、21 CustomAttribute、259 ImplMap 及 1 AssemblyRef。程序集身份为 `HMManagedXLP, Version=23.1.23.0, Culture=neutral, PublicKeyToken=a6bddcad966d1a06`。唯一 AssemblyRef 是 `netstandard, Version=2.0.0.0, Culture=neutral, PublicKeyToken=cc7b13ffcd2ddd51`。
- 两边均无 CLR ManifestResource、外部 CLR 模块和 FieldRVA。唯一原生版本资源为 `RT_VERSION/1/0`，代码页 0，长度 1,168 字节，两边的完整 payload SHA-256 均为 `22717259245a968d01b6e7b4b069e94d583e762266485850f613540f61777abc`。PE32/IL-only 上下文、节权限、DLL flags、`mscoree.dll!_CorDllMain` 引导入口及其实际重定位一致。
- 独立构建产物保留自身 MVID、时间戳、校验和及可重复构建标记。原件的 CodeView/PDB 校验信息、Authenticode 证书表和实际强名签名由安装包提供。它们未从原件带入源包。调试目录尺寸变化使 PE 引导入口及对应重定位的物理 RVA 改变。

## 兼容边界

- 安装同目录的 Windows x64 `hmxlpxmps.dll` 文件版本为 13.1.23.0，SHA-256 为 `9c3bb9b814fda2afa3df159e8d617e7f9731a72945f4ba78d4437d0495ca3cea`。原件声明本身不指定外部库的文件版本。安装提供方对 259 条导入声明有 258 条按名称精确匹配。`0x06000245 SetBMLMonotoneOption` 在安装提供方缺名，现有 `SetMonotoneOption` 是另一名字。本包保留原件声明，真实运行是否触达此绑定留待 Windows 宿主对照。
- `ModelEquations.dll` 7.0.2.0 的静态 AssemblyRef 实际引用本程序集及其公钥标记。当前目标的 AssemblyRef 与 ModuleRef 清单没有 Excel 或 Excel Interop 项，源码中也未发现直接 Excel API。Excel 作为潜在上层宿主仍需实际加载和调用链证据，本轮只比较该 DLL 的静态内容。

适用标准为固定主干的 `docs/static-acceptance.md`。本轮的静态方法、结构及资源核对使用实装原件和直接编译产物。Windows 运行对照、Excel 宿主和外部提供方运行行为留在相应后续阶段。
