"""Compare a fresh build against the installed original with the project's static readers."""

import argparse
import hashlib
import json
from pathlib import Path
import sys
import tempfile

import pefile


def digest(content):
    return hashlib.sha256(content).hexdigest()


def pe_facts(content):
    pe = pefile.PE(data=content)
    opt = pe.OPTIONAL_HEADER
    fh = pe.FILE_HEADER
    base = opt.AddressOfEntryPoint
    directories = opt.DATA_DIRECTORY
    sections = [
        [s.Name.rstrip(b"\x00").decode("ascii"), s.Characteristics] for s in pe.sections
    ]
    imports = [
        [entry.dll.decode("ascii"),
         [[i.name.decode("ascii") if i.name else None, i.ordinal, i.address - opt.ImageBase]
          for i in entry.imports]] for entry in getattr(pe, "DIRECTORY_ENTRY_IMPORT", ())
    ]
    # Ignore ABSOLUTE relocation-table padding. Express actual relocations in
    # terms of the bootstrap entry, whose RVA moves with build metadata.
    relocations = [
        [i.type, i.rva - base]
        for block in getattr(pe, "DIRECTORY_ENTRY_BASERELOC", ()) for i in block.entries
        if i.type
    ]
    # Loader-facing facts complement the managed reader. Security/debug
    # directories, COFF timestamp, checksum and physical RVAs are reported
    # separately as build provenance.
    context = {
        "machine": fh.Machine,
        "coff_characteristics": fh.Characteristics,
        "pe_magic": opt.Magic,
        "dll_characteristics": opt.DllCharacteristics,
        "image_base": opt.ImageBase,
        "subsystem": opt.Subsystem,
        "subsystem_version": [opt.MajorSubsystemVersion, opt.MinorSubsystemVersion],
        "file_alignment": opt.FileAlignment,
        "section_alignment": opt.SectionAlignment,
        "section_flags": sections,
        "imports": imports,
        "entry_prefix": pe.get_data(base, 6).hex(),
        "relocations_relative_to_entry": relocations,
        "directories_excluding_security_and_debug": [
            [i, d.name, bool(d.VirtualAddress), d.Size]
            for i, d in enumerate(directories) if i not in (4, 6)
        ],
    }
    cor = directories[14]
    cli = pe.get_data(cor.VirtualAddress, cor.Size)
    strong_rva = int.from_bytes(cli[32:36], "little")
    strong_size = int.from_bytes(cli[36:40], "little")
    strong_bytes = pe.get_data(strong_rva, strong_size) if strong_size else b""
    provenance = {
        "timestamp": fh.TimeDateStamp,
        "checksum": opt.CheckSum,
        "entry_rva": base,
        "certificate_bytes": directories[4].Size,
        "debug_records": [
            [entry.struct.Type, entry.struct.SizeOfData]
            for entry in getattr(pe, "DIRECTORY_ENTRY_DEBUG", ())
        ],
        "strong_name_bytes": strong_size,
        "strong_name_nonzero": any(strong_bytes),
    }
    pe.close()
    return context, provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", required=True, type=Path)
    parser.add_argument("--rebuilt", required=True, type=Path)
    parser.add_argument("--acceptance-tools", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    args.report.parent.mkdir(parents=True, exist_ok=True)
    sys.dont_write_bytecode = True
    tools = args.acceptance_tools.resolve(strict=True)
    sys.path.insert(0, str(tools))
    import managed
    import pe_resources

    original = args.original.read_bytes()
    rebuilt = args.rebuilt.read_bytes()
    # managed.check uses TemporaryDirectory. Keep its original-byte copy
    # within the explicit report location and let the tool remove it.
    tempfile.tempdir = str(args.report.parent.resolve())
    clr = managed.check(original, args.rebuilt.resolve(strict=True))
    pe_context, provenance = [], []
    resource_details = []
    for binary in (original, rebuilt):
        context, build_fields = pe_facts(binary)
        pe_context.append(context)
        provenance.append(build_fields)
        resource_details.append(pe_resources._rows(binary))
    resources_equal = (
        {k: v[1:] for k, v in resource_details[0].items()}
        == {k: v[1:] for k, v in resource_details[1].items()}
    )
    pe_context_equal = pe_context[0] == pe_context[1]
    result = {
        "inputs_sha256": dict(original=digest(original), rebuilt=digest(rebuilt)),
        "tool_sha256": {
            name: digest((tools / name).read_bytes()) for name in
            ("managed.py", "ManagedEvidence.cs", "pe_resources.py", "version_resource.py")
        },
        "pefile_version": pefile.__version__,
        "clr": clr,
        "pe_resources_equal": resources_equal,
        "pe_resources": {
            side: [
                {"type": key[0], "name": key[1], "language": key[2], "rva": row[0],
                 "size": row[1], "code_page": row[2], "sha256": row[3]}
                for key, row in sorted(resources.items())
            ]
            for side, resources in zip(("original", "rebuilt"), resource_details)
        },
        "pe_context_equal": pe_context_equal,
        "pe_context": dict(zip(("original", "rebuilt"), pe_context)),
        "build_provenance": dict(zip(("original", "rebuilt"), provenance)),
    }
    passed = clr["status"] == "pass" and resources_equal and pe_context_equal
    result["compared_checks_pass"] = passed
    args.report.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"CLR: {clr['status']}; PE resources equal: {resources_equal}; PE context equal: {pe_context_equal}")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
