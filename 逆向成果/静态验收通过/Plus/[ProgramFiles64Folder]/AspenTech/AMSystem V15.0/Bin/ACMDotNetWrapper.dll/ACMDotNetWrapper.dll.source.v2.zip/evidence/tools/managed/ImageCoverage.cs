using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Security.Cryptography;

public static class ImageCoverage
{
    public static object Inspect(string path, out bool fullyCovered)
    {
        using var file = File.OpenRead(path);
        using var image = new PEReader(file);
        var header = image.PEHeaders;
        var metadata = image.GetMetadataReader(MetadataReaderOptions.None);
        var fileBytes = image.GetEntireImage().GetContent().ToArray();
        var owned = new List<(int Start, int End, string Owner)>();
        int FileOffset(int rva)
        {
            var section = header.SectionHeaders.Single(s => rva >= s.VirtualAddress && rva < s.VirtualAddress + s.VirtualSize);
            return section.PointerToRawData + rva - section.VirtualAddress;
        }
        void Add(string owner, int rva, int size)
        {
            if (size <= 0) return;
            var start = FileOffset(rva);
            owned.Add((start, checked(start + size), owner));
        }
        var corDirectory = header.PEHeader.CorHeaderTableDirectory;
        Add("COR20", corDirectory.RelativeVirtualAddress, corDirectory.Size);
        var cor = header.CorHeader;
        Add("CLI metadata", cor.MetadataDirectory.RelativeVirtualAddress, cor.MetadataDirectory.Size);
        Add("CLI resources", cor.ResourcesDirectory.RelativeVirtualAddress, cor.ResourcesDirectory.Size);
        Add("Strong name", cor.StrongNameSignatureDirectory.RelativeVirtualAddress, cor.StrongNameSignatureDirectory.Size);
        var methods = metadata.MethodDefinitions.Select(handle =>
        {
            var method = metadata.GetMethodDefinition(handle);
            var type = metadata.GetTypeDefinition(method.GetDeclaringType());
            var rva = method.RelativeVirtualAddress;
            string token = MetadataTokens.GetToken(handle).ToString("x8");
            var codeType = method.ImplAttributes & System.Reflection.MethodImplAttributes.CodeTypeMask;
            var managedType = method.ImplAttributes & System.Reflection.MethodImplAttributes.ManagedMask;
            var cil = codeType == System.Reflection.MethodImplAttributes.IL &&
                managedType == System.Reflection.MethodImplAttributes.Managed;
            MethodBodyBlock body = rva != 0 && cil ? image.GetMethodBody(rva) : null;
            if (body != null) Add(token, rva, body.Size);
            var import = method.GetImport();
            string importName = import.Module.IsNil ? null : metadata.GetString(metadata.GetModuleReference(import.Module).Name) + "!" + metadata.GetString(import.Name);
            return new { token, type = metadata.GetString(type.Name), name = metadata.GetString(method.Name), rva,
                         size = body?.Size ?? 0, regions = body?.ExceptionRegions.Length ?? 0, cil,
                         impl = method.ImplAttributes.ToString(), import_name = importName, import_flags = import.Attributes.ToString() };
        }).ToArray();
        int nonzeroExecutableGapBytes = 0;
        var executable = header.SectionHeaders.Where(s => (s.SectionCharacteristics & SectionCharacteristics.MemExecute) != 0).Select(s =>
        {
            int end = s.PointerToRawData + Math.Min(s.VirtualSize, s.SizeOfRawData);
            var inSection = owned.Where(x => x.Start >= s.PointerToRawData && x.End <= end).OrderBy(x => x.Start).ToArray();
            var gaps = new List<object>();
            void AddGap(int start, int finish)
            {
                var bytes = fileBytes.AsSpan(start, finish - start);
                int nonzero = 0;
                foreach (byte b in bytes) if (b != 0) nonzero++;
                nonzeroExecutableGapBytes += nonzero;
                gaps.Add(new { offset = start, length = bytes.Length, nonzero, data_hex = nonzero > 0 ? Convert.ToHexString(bytes) : null });
            }
            int next = s.PointerToRawData;
            foreach (var region in inSection)
            {
                if (region.Start < next) throw new InvalidDataException("Overlapping executable mappings");
                if (region.Start > next) AddGap(next, region.Start);
                next = region.End;
            }
            if (next < end) AddGap(next, end);
            return new { section = s.Name, start = s.PointerToRawData, end, ranges = inSection.Length, gaps };
        }).ToArray();
        var refs = metadata.AssemblyReferences.Select(handle =>
        {
            var reference = metadata.GetAssemblyReference(handle);
            return new { name = metadata.GetString(reference.Name), version = reference.Version.ToString(),
                         key_or_token = Convert.ToHexString(metadata.GetBlobBytes(reference.PublicKeyOrToken)) };
        });
        var assembly = metadata.GetAssemblyDefinition();
        fullyCovered = nonzeroExecutableGapBytes == 0 && methods.All(x => x.rva == 0 || x.cil);
        return new {
            sha256 = Convert.ToHexString(SHA256.HashData(fileBytes)).ToLowerInvariant(),
            assembly = metadata.GetString(assembly.Name), version = assembly.Version.ToString(),
            module = metadata.GetString(metadata.GetModuleDefinition().Name),
            type_defs = metadata.TypeDefinitions.Count,
            method_defs = methods.Length,
            typed_method_bodies = methods.Count(x => x.rva != 0 && x.cil),
            native_method_rvas = methods.Where(x => x.rva != 0 && !x.cil).Select(x => x.rva).ToArray(),
            nonzero_executable_gap_bytes = nonzeroExecutableGapBytes,
            mvid = metadata.GetGuid(metadata.GetModuleDefinition().Mvid),
            exception_regions = methods.Sum(x => x.regions),
            assembly_refs = refs.ToArray(),
            manifest_resource_count = metadata.ManifestResources.Count,
            total_table_rows = Enum.GetValues<TableIndex>().Select(t => new { name = t.ToString(), rows = metadata.GetTableRowCount(t) }).Where(t => t.rows > 0).ToArray(),
            executable, methods
        };
    }
}

