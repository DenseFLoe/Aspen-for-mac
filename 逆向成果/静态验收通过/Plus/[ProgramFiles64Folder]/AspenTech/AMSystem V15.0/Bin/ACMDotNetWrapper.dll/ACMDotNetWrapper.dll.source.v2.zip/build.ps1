[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$OutputDirectory,
    [string]$Ilasm = (Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/ilasm.exe')
)
$ErrorActionPreference = 'Stop'
$Ilasm = (Get-Item -LiteralPath $Ilasm).FullName
$OutputDirectory = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($OutputDirectory)
if (Test-Path -LiteralPath $OutputDirectory) {
    if (!(Test-Path -LiteralPath $OutputDirectory -PathType Container) -or
        @(Get-ChildItem -LiteralPath $OutputDirectory -Force).Count) {
        throw 'Choose a new or empty output directory.'
    }
} else {
    $null = New-Item -ItemType Directory -Path $OutputDirectory
}

$source = Join-Path $PSScriptRoot 'source'
$result = Join-Path $OutputDirectory 'ACMDotNetWrapper.dll'
$previousTemp = $env:TEMP
$previousTmp = $env:TMP
try {
    $env:TEMP = $OutputDirectory
    $env:TMP = $OutputDirectory
    Push-Location -LiteralPath $source
    try {
        & $Ilasm /DLL /PE64 /X64 /QUIET /NOCORSTUB /HIGHENTROPYVA /SSVER=6.0 /RESOURCE=original.res "/OUTPUT=$result" ACMDotNetWrapper.dll.il
        if ($LASTEXITCODE -ne 0 -or !(Test-Path -LiteralPath $result -PathType Leaf)) {
            throw 'IL assembly failed.'
        }
    } finally {
        Pop-Location
    }
    Get-FileHash -LiteralPath $result -Algorithm SHA256
} finally {
    $env:TEMP = $previousTemp
    $env:TMP = $previousTmp
}

