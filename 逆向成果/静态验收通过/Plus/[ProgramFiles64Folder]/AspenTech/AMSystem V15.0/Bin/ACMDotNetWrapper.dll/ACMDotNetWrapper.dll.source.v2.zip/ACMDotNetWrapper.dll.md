# ACMDotNetWrapper.dll

本件为 Aspen Plus V15.0 的 x64 VB.NET WinForms 包装程序集。文件和程序集版本均为 `41.0.0.613`。安装原件位于 `C:\Program Files\AspenTech\AMSystem V15.0\Bin\ACMDotNetWrapper.dll`，原相对路径为 `[ProgramFiles64Folder]/AspenTech/AMSystem V15.0/Bin/ACMDotNetWrapper.dll`。原件共 22,056 字节，SHA-256 为 `8fa9d484b3d3b34afbd4406596cba850ad8ebaf8a992f89e740be84f2fa1a3b7`。本文件记录制作方静态核对结果。交付冻结后由另一名复核员复跑并单独裁定。

固定主干 `adbe73b517acac25da87598cce46de033f630ccb` 上的状态为待静态验收。历史 v6 包 SHA-256 为 `a3b8c03ca9a0d14cb7d5898f8b2f1195f4a49bc13f99443fd5ec12d25c926e00`。本轮沿用其中的 ildasm 文本及两份必要资源，补回原件的程序集级 `DebuggableAttribute` 值 `0100070100000000`，并以 `.locals init ()` 保留 `Wrapper::.ctor()` 的 InitLocals 位。新 IL 源的 SHA-256 为 `f6312aa134a908f9b1fda6490425cd3608d427101ab81eddc1d8bf12a22d0759`。

[固定主干逐件标准](https://github.com/DenseFLoe/Aspen-for-mac/blob/adbe73b517acac25da87598cce46de033f630ccb/docs/static-acceptance.md) · [固定主干对象](https://github.com/DenseFLoe/Aspen-for-mac/blob/adbe73b517acac25da87598cce46de033f630ccb/%E9%80%86%E5%90%91%E6%88%90%E6%9E%9C/%E5%BE%85%E9%9D%99%E6%80%81%E9%AA%8C%E6%94%B6/Plus/%5BProgramFiles64Folder%5D/AspenTech/AMSystem%20V15.0/Bin/ACMDotNetWrapper.dll/README.md)

## 源码汇编

在新的空目录解包，在包根用 PowerShell 执行。

```powershell
.\build.ps1 -OutputDirectory .\rebuilt
```

该命令从 `source/ACMDotNetWrapper.dll.il`、`source/ACMDotNetWrapper.Wrapper.resources` 和 `source/original.res` 生成 `rebuilt/ACMDotNetWrapper.dll`。使用 Windows 随 .NET Framework 4.8 提供的 x64 `ilasm.exe`，实测版本 4.8.4161.0、SHA-256 `486be223bcf745332cb86a2b0bb3399e5bc89fc2c31c4b3ac6a9ea13cf82fb3f`。可通过 `-Ilasm` 指定该工具的路径。编译只读取包内的三个源输入。程序集绑定由 IL 自带的 AssemblyRef 和 ModuleRef 表达，汇编无需原件、Aspen 二进制、.NET SDK 或预编译候选。`/NOCORSTUB` 保留原件无原生 CLR 引导壳的结构，`/HIGHENTROPYVA /SSVER=6.0` 对应原件的 PE 标志及子系统版本。

## 对照原件

静态比较需要安装原件、.NET SDK 9、Mono.Cecil 0.11.6、Python 3 和 pefile 2024.8.26。实测 SDK 9.0.321、.NET 运行时 9.0.23、Python 3.12.10、Cecil 程序集版本 0.11.6.0。实测 Mono.Cecil.dll SHA-256 为 `831dca77470d85cb6ffbea3072daa7a3df5b7c9fcfd9c3f43674a9be99d4bfcf`。本机既有副本位于项目根的 `.local/codex-router/round-20261128-codex-five/controller/20261128-04/first/package/tools/Mono.Cecil.dll`，SDK 位于 `.local/patrol-0857/review340/net9/dotnet.exe`，pefile 已在 `.local/aspen-acceptance-work/deps`。如果 pefile 已在 Python 环境中可导入，可省略 `-PeFileDirectory`。

```powershell
.\compare.ps1 -Original 'C:\Program Files\AspenTech\AMSystem V15.0\Bin\ACMDotNetWrapper.dll' `
  -Candidate .\rebuilt\ACMDotNetWrapper.dll -ReportDirectory .\report `
  -Cecil 'C:\依赖目录\Mono.Cecil.dll' -Dotnet 'C:\SDK目录\dotnet.exe' `
  -PeFileDirectory 'C:\Python依赖目录'
```

`report/managed.json` 和 `report/pe.json` 分别比较运行中提供的两个文件。源码位于 `evidence/tools`。托管证据以类型作用域、签名和泛型参数定位每个方法，读取真实产物中的每条指令、绑定、分支位置、局部变量、InitLocals、MaxStack、异常类型及范围。PE 对照按资源树路径、长度、语言和代码页后再对比叶载荷，另检查 CLR/PE 头、入口、原生目录及导入。证据目录中另附制作方一次实际测量。

## 本轮静态核对

- 31 对定义与 30 对方法体一致，共 768 条 CIL 指令。3 个异常区分别为 `GetOCXWhWnd` 的筛选器，以及 `UserControl_Hide` 和 `UserControl_Terminate` 的捕获区。逐方法报告给出原件与候选令牌、RVA、方法体规范化摘要和 121 条方法调用、构造器或委托绑定指令。
- 35 项结构记录一致，含 7 个类型定义、11 个字段、8 个属性、5 个程序集引用、1 个 ModuleRef、1 个托管资源以及程序集和模块描述。两侧有效 CLI 表的行数一致，63 项 TypeRef 和 92 项 MemberRef 的解析结果及重复次数一致。元数据令牌顺序和流布局由 ilasm 重建。
- 唯一托管资源 `ACMDotNetWrapper.Wrapper.resources` 是 487 字节，SHA-256 为 `d93a227e745007f3ec40f50bb675aea840df6c96018c1286e5bb9f3bdb2eb34a`。唯一键 `ToolTip1.Location` 的类型为 `System.Drawing.Point`，两侧原始数据一致。唯一 PE 版本资源 `(16, 1, 0)` 的代码页 0、1,006 字节和 SHA-256 `9c2386cfe99f904f9e070f55240b5f07ba6ccdaa07864ea97adfa5af8c1f5422` 一致。
- `Wrapper::.ctor` 原件令牌 `06000008` 把 VisibleChanged、Resize、Disposed 绑定到托管处理程序。`InitializeComponent` 原件令牌 `0600000a` 创建容器及 ToolTip，配置父控件的位置、大小、字体与名称。布局和事件绑定都在逐指令对照范围。
- 两端均为 PE32+、AMD64、ILONLY，PE 和 CLI 入口均为零。PE 导入、导出、异常展开、TLS、CLR 原生头、虚表修正和导出跳板为空。SRM 将原件 `.text` 映射为 30 个完整 CIL 方法体、CLR 头、CLI 元数据和资源共 33 项。余下 17 字节都是零填充。候选对应的 33 项之外也都是零填充。
- 唯一无体声明 `GetParent(int32) → int32`（原件 `0600000b`）通过 P/Invoke 使用 Windows 的 `user32.dll!GetParent`，保留 PreserveSig、ExactSpelling、CharSetAnsi、SetLastError 和 CallingConventionWinApi。系统实现位于外部 Windows DLL。Framework 引用为 `mscorlib`、`System`、`System.Windows.Forms`、`System.Drawing` 4.0.0.0 及 `Microsoft.VisualBasic` 10.0.0.0，具体公钥标记见报告。
- `set_ControlContext`（原件 `0600000d`）使用 VB 后期绑定访问 ControlContext、CustomControl、UserControl 和 OCXhWnd 等成员，并经 `Interaction.CreateObject` 创建运行时提供的对象。`UserControl_Resize`（`06000014`）调用 SetBounds。隐藏和终止路径调用 Dispose。外部 ActiveX/COM 类由传入上下文与 Windows 注册提供，本件未声明可固定的 OCX 版本。

## 产物差异及后续核对

实测直接汇编产物为 11,776 字节，制作方两次输出的 SHA-256 分别为 `bd85605ab4a91c5d783da8dfb095bb2ab841341474ca7804573f2ff7d58dff06` 和 `215751824f5fddc6b04027c7bbfe8ebd6a5f58c2ac67dd1bf10e6416e960d122`。同秒两次输出仅有 MVID 的 16 字节变化，重新运行也可能变更 COFF 时间戳。验收使用方法、结构、绑定和资源的静态对照。

原版有 10,280 字节的 Authenticode 证书表。候选为汇编器直接生成的无签名文件，PE 校验和为 0，元数据和资源 RVA、填充及节长按新布局生成。签名有效性及 Windows 下的实际 WinForms、ActiveX/COM 加载和交互留待重建对照阶段。

## 比较器复核修订 v2

静态比较在判定前完成可执行区间的扫描。空目录复跑通过，原件和候选的可执行虚拟范围均无未归属的非零字节。将候选文件偏移 `584` 的一个间隙字节从 `00` 改为 `01` 后，比较器报告 1 个未归属的非零字节并以状态码 1 退出。原件和候选的 `.text` 文件对齐尾部也分别复查了 420 和 245 字节，均为零。

修订后制作方生成的候选 SHA-256 为 `24393359583c5914001ba7ba4f246c45222e6a1ba5b6c5e885dc789af394d256`。本包证据对应此产物。
