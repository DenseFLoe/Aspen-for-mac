import argparse
import hashlib
import json
from pathlib import Path
import struct

import pefile


def digest(payload):
    return hashlib.sha256(payload).hexdigest()


def snapshot(filename):
    data = Path(filename).read_bytes()
    pe = pefile.PE(data=data)
    header = pe.OPTIONAL_HEADER
    directories = header.DATA_DIRECTORY

    def resource_leaves(directory, path=()):
        for entry in directory.entries:
            key = str(entry.name) if entry.name is not None else entry.id
            if hasattr(entry, "directory"):
                yield from resource_leaves(entry.directory, (*path, key))
            else:
                node = entry.data.struct
                payload = pe.get_data(node.OffsetToData, node.Size)
                if len(payload) != node.Size:
                    raise ValueError(f"Truncated PE resource {(*path, key)}")
                yield {
                    "path": [*path, key], "size": node.Size,
                    "code_page": node.CodePage, "sha256": digest(payload),
                }

    cli = directories[14]
    (clr_size, major, minor, meta_rva, meta_size, flags, entry,
     res_rva, res_size, strong_rva, strong_size, manager_rva, manager_size,
     vtable_rva, vtable_size, jumps_rva, jumps_size, native_rva,
     native_size) = struct.unpack("<IHH16I", pe.get_data(cli.VirtualAddress, 72))
    security = directories[4]
    return {
        "sha256": digest(data),
        "size": len(data),
        "abi": {
            "machine": pe.FILE_HEADER.Machine,
            "file_characteristics": pe.FILE_HEADER.Characteristics,
            "pe_magic": header.Magic,
            "entry_rva": header.AddressOfEntryPoint,
            "subsystem": header.Subsystem,
            "dll_characteristics": header.DllCharacteristics,
            "os_version": [header.MajorOperatingSystemVersion, header.MinorOperatingSystemVersion],
            "subsystem_version": [header.MajorSubsystemVersion, header.MinorSubsystemVersion],
            "stack_reserve": header.SizeOfStackReserve,
            "stack_commit": header.SizeOfStackCommit,
            "heap_reserve": header.SizeOfHeapReserve,
            "heap_commit": header.SizeOfHeapCommit,
            "clr_header_size": clr_size,
            "clr_runtime_version": [major, minor],
            "cor_flags": flags,
            "clr_entry": entry,
            "strong_name": [strong_rva, strong_size],
            "code_manager": [manager_rva, manager_size],
            "vtable_fixups": [vtable_rva, vtable_size],
            "export_jumps": [jumps_rva, jumps_size],
            "managed_native_header": [native_rva, native_size],
        },
        "directory_sizes": {item.name: item.Size for item in directories},
        "imports": [
            {"library": module.dll.decode("ascii"), "symbols": [
                symbol.name.decode("ascii") if symbol.name is not None else symbol.ordinal
                for symbol in module.imports
            ]}
            for module in getattr(pe, "DIRECTORY_ENTRY_IMPORT", [])
        ],
        "resource_leaves": list(resource_leaves(pe.DIRECTORY_ENTRY_RESOURCE))
        if hasattr(pe, "DIRECTORY_ENTRY_RESOURCE") else [],
        "layout": {
            "timestamp": pe.FILE_HEADER.TimeDateStamp, "checksum": header.CheckSum,
            "image_base": header.ImageBase, "section_alignment": header.SectionAlignment,
            "file_alignment": header.FileAlignment,
            "metadata": [meta_rva, meta_size], "managed_resources": [res_rva, res_size],
            "sections": [
                {"name": section.Name.rstrip(b"\0").decode("ascii"), "rva": section.VirtualAddress,
                 "virtual_size": section.Misc_VirtualSize, "flags": section.Characteristics}
                for section in pe.sections
            ],
            "certificate_size": security.Size,
            "certificate_sha256": digest(data[security.VirtualAddress:security.VirtualAddress + security.Size])
            if security.Size else None,
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("original")
    parser.add_argument("candidate")
    parser.add_argument("report", type=Path)
    args = parser.parse_args()
    old = snapshot(args.original)
    new = snapshot(args.candidate)
    required_pe_directories = ("EXPORT", "IMPORT", "EXCEPTION", "TLS", "LOAD_CONFIG", "IAT", "DELAY_IMPORT")
    relevant_directories = [
        name for name in old["directory_sizes"] if name.removeprefix("IMAGE_DIRECTORY_ENTRY_") in required_pe_directories
    ]
    equal_abi = old["abi"] == new["abi"]
    equal_resource_leaves = old["resource_leaves"] == new["resource_leaves"]
    equal_native_directories = all(old["directory_sizes"][name] == new["directory_sizes"][name]
                                   for name in relevant_directories)
    equal_imports = old["imports"] == new["imports"]
    report = {
        "tool": {"pefile": pefile.__version__},
        "original": old, "candidate": new, "equal_abi": equal_abi,
        "abi_differences": {name: [value, new["abi"][name]]
                            for name, value in old["abi"].items() if value != new["abi"][name]},
        "equal_resource_leaves": equal_resource_leaves,
        "equal_imports": equal_imports, "equal_native_directory_sizes": equal_native_directories,
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    return 0 if equal_abi and equal_resource_leaves and equal_native_directories and equal_imports else 1


if __name__ == "__main__":
    raise SystemExit(main())

