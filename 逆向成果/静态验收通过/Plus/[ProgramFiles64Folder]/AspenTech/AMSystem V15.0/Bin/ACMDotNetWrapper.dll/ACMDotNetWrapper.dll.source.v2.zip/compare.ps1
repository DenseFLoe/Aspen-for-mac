[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$Original,
    [Parameter(Mandatory)]
    [string]$Candidate,
    [Parameter(Mandatory)]
    [string]$ReportDirectory,
    [Parameter(Mandatory)]
    [string]$Cecil,
    [string]$Dotnet = 'dotnet',
    [string]$Python = 'python',
    [string]$PeFileDirectory
)
$ErrorActionPreference = 'Stop'
$Original = (Get-Item -LiteralPath $Original).FullName
$Candidate = (Get-Item -LiteralPath $Candidate).FullName
$Cecil = (Get-Item -LiteralPath $Cecil).FullName
$Dotnet = (Get-Command -Name $Dotnet -CommandType Application).Source
$Python = (Get-Command -Name $Python -CommandType Application).Source
$ReportDirectory = $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ReportDirectory)
if (Test-Path -LiteralPath $ReportDirectory) {
    if (!(Test-Path -LiteralPath $ReportDirectory -PathType Container) -or
        @(Get-ChildItem -LiteralPath $ReportDirectory -Force).Count) {
        throw 'Choose a new or empty report directory.'
    }
} else {
    $null = New-Item -ItemType Directory -Path $ReportDirectory
}

$tools = Join-Path $PSScriptRoot 'evidence/tools'
$project = Join-Path $ReportDirectory 'managed-audit'
$null = New-Item -ItemType Directory -Path $project
foreach ($file in Get-ChildItem -LiteralPath (Join-Path $tools 'managed') -File) {
    Copy-Item -LiteralPath $file.FullName -Destination $project
}
Copy-Item -LiteralPath $Cecil -Destination (Join-Path $project 'Mono.Cecil.dll')

$cache = Join-Path $ReportDirectory 'tool-cache'
$null = New-Item -ItemType Directory -Path $cache
$overrides = @{
    TEMP = $cache
    TMP = $cache
    DOTNET_CLI_HOME = $cache
    DOTNET_CLI_TELEMETRY_OPTOUT = '1'
    DOTNET_GENERATE_ASPNET_CERTIFICATE = 'false'
    DOTNET_CLI_WORKLOAD_UPDATE_NOTIFY_DISABLE = 'true'
    NUGET_PACKAGES = (Join-Path $cache 'nuget')
    NUGET_HTTP_CACHE_PATH = (Join-Path $cache 'nuget-http')
    NUGET_PLUGINS_CACHE_PATH = (Join-Path $cache 'nuget-plugins')
}
if ($PeFileDirectory) {
    $overrides.PYTHONPATH = (Get-Item -LiteralPath $PeFileDirectory).FullName
}
$previous = @{}
foreach ($name in $overrides.Keys) {
    $previous[$name] = [Environment]::GetEnvironmentVariable($name, 'Process')
    [Environment]::SetEnvironmentVariable($name, $overrides[$name], 'Process')
}
try {
    & $Dotnet build (Join-Path $project 'Audit.csproj') --nologo --ignore-failed-sources --disable-build-servers
    if ($LASTEXITCODE -ne 0) {
        throw 'Building the comparison tool failed.'
    }
    & $Dotnet (Join-Path $project 'bin/Debug/net9.0/Audit.dll') $Original $Candidate (Join-Path $ReportDirectory 'managed.json')
    $managedStatus = $LASTEXITCODE
    & $Python -B (Join-Path $tools 'pe_audit.py') $Original $Candidate (Join-Path $ReportDirectory 'pe.json')
    if ($LASTEXITCODE -ne 0 -or $managedStatus -ne 0) {
        throw 'Static comparison found differences or could not complete. Check the report directory.'
    }
} finally {
    foreach ($name in $previous.Keys) {
        [Environment]::SetEnvironmentVariable($name, $previous[$name], 'Process')
    }
}

