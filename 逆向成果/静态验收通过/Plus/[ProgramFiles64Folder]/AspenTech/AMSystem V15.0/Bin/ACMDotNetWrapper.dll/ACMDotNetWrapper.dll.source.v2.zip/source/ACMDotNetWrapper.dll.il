﻿
//  .NET IL Disassembler.  Version 9.0.23



// Metadata version: v4.0.30319
.module extern user32.dll
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern Microsoft.VisualBasic
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 10:0:0:0
}
.assembly extern System.Windows.Forms
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern System.Drawing
{
  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
  .ver 4:0:0:0
}
.assembly ACMDotNetWrapper
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.

  .custom instance void [mscorlib]System.Diagnostics.DebuggableAttribute::.ctor(valuetype [mscorlib]System.Diagnostics.DebuggableAttribute/DebuggingModes) = ( 01 00 07 01 00 00 00 00 ) 

  .custom instance void [mscorlib]System.Reflection.AssemblyTitleAttribute::.ctor(string) = ( 01 00 14 2E 4E 45 54 20 63 6F 6E 74 72 6F 6C 20   // ....NET control 
                                                                                              77 72 61 70 70 65 72 00 00 )                      // wrapper..
  .custom instance void [mscorlib]System.Reflection.AssemblyDescriptionAttribute::.ctor(string) = ( 01 00 14 2E 4E 45 54 20 63 6F 6E 74 72 6F 6C 20   // ....NET control 
                                                                                                    77 72 61 70 70 65 72 00 00 )                      // wrapper..
  .custom instance void [mscorlib]System.Reflection.AssemblyCompanyAttribute::.ctor(string) = ( 01 00 16 41 73 70 65 6E 20 54 65 63 68 6E 6F 6C   // ...Aspen Technol
                                                                                                6F 67 79 2C 20 49 6E 63 2E 00 00 )                // ogy, Inc...
  .custom instance void [mscorlib]System.Reflection.AssemblyProductAttribute::.ctor(string) = ( 01 00 18 41 73 70 65 6E 20 43 75 73 74 6F 6D 20   // ...Aspen Custom 
                                                                                                4D 6F 64 65 6C 65 72 20 28 52 29 00 00 )          // Modeler (R)..
  .custom instance void [mscorlib]System.Reflection.AssemblyCopyrightAttribute::.ctor(string) = ( 01 00 19 43 6F 70 79 72 69 67 68 74 20 28 63 29   // ...Copyright (c)
                                                                                                  20 31 39 39 32 20 2D 20 32 30 30 39 00 00 )       //  1992 - 2009..
  .custom instance void [mscorlib]System.Reflection.AssemblyTrademarkAttribute::.ctor(string) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 01 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.Versioning.TargetFrameworkAttribute::.ctor(string) = ( 01 00 1A 2E 4E 45 54 46 72 61 6D 65 77 6F 72 6B   // ....NETFramework
                                                                                                        2C 56 65 72 73 69 6F 6E 3D 76 34 2E 38 01 00 54   // ,Version=v4.8..T
                                                                                                        0E 14 46 72 61 6D 65 77 6F 72 6B 44 69 73 70 6C   // ..FrameworkDispl
                                                                                                        61 79 4E 61 6D 65 12 2E 4E 45 54 20 46 72 61 6D   // ayName..NET Fram
                                                                                                        65 77 6F 72 6B 20 34 2E 38 )                      // ework 4.8
  .hash algorithm 0x00008004
  .ver 41:0:0:613
}
.mresource public ACMDotNetWrapper.Wrapper.resources
{
  // Offset: 0x00000000 Length: 0x000001E7
  // WARNING: managed resource file ACMDotNetWrapper.Wrapper.resources created
}
.module ACMDotNetWrapper.dll
// MVID: {69a263cc-0881-4ac4-a5aa-2bfb799bcd41}
.imagebase 0x0000000180000000
.file alignment 0x00000200
.stackreserve 0x0000000000400000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000001    //  ILONLY
// Image base: 0x00000270D4490000


// =============== CLASS MEMBERS DECLARATION ===================

.class private auto ansi ACMDotNetWrapper.My.MyApplication
       extends [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.ApplicationBase
{
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 0A 4D 79 54 65 6D 70 6C 61 74 65 08 31 31   // ...MyTemplate.11
                                                                                                  2E 30 2E 30 2E 30 00 00 )                         // .0.0.0..
  .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.ApplicationBase::.ctor()
    IL_0006:  ret
  } // end of method MyApplication::.ctor

} // end of class ACMDotNetWrapper.My.MyApplication

.class private auto ansi ACMDotNetWrapper.My.MyComputer
       extends [Microsoft.VisualBasic]Microsoft.VisualBasic.Devices.Computer
{
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 0A 4D 79 54 65 6D 70 6C 61 74 65 08 31 31   // ...MyTemplate.11
                                                                                                  2E 30 2E 30 2E 30 00 00 )                         // .0.0.0..
  .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  call       instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.Devices.Computer::.ctor()
    IL_0007:  nop
    IL_0008:  ret
  } // end of method MyComputer::.ctor

} // end of class ACMDotNetWrapper.My.MyComputer

.class private auto ansi sealed beforefieldinit ACMDotNetWrapper.My.MyProject
       extends [mscorlib]System.Object
{
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.StandardModuleAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.HideModuleNameAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [System]System.CodeDom.Compiler.GeneratedCodeAttribute::.ctor(string,
                                                                                      string) = ( 01 00 0A 4D 79 54 65 6D 70 6C 61 74 65 08 31 31   // ...MyTemplate.11
                                                                                                  2E 30 2E 30 2E 30 00 00 )                         // .0.0.0..
  .class auto ansi sealed nested assembly MyWebServices
         extends [mscorlib]System.Object
  {
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.MyGroupCollectionAttribute::.ctor(string,
                                                                                                         string,
                                                                                                         string,
                                                                                                         string) = ( 01 00 34 53 79 73 74 65 6D 2E 57 65 62 2E 53 65   // ..4System.Web.Se
                                                                                                                     72 76 69 63 65 73 2E 50 72 6F 74 6F 63 6F 6C 73   // rvices.Protocols
                                                                                                                     2E 53 6F 61 70 48 74 74 70 43 6C 69 65 6E 74 50   // .SoapHttpClientP
                                                                                                                     72 6F 74 6F 63 6F 6C 12 43 72 65 61 74 65 5F 5F   // rotocol.Create__
                                                                                                                     49 6E 73 74 61 6E 63 65 5F 5F 13 44 69 73 70 6F   // Instance__.Dispo
                                                                                                                     73 65 5F 5F 49 6E 73 74 61 6E 63 65 5F 5F 00 00   // se__Instance__..
                                                                                                                     00 ) 
    .method public hidebysig strict virtual 
            instance bool  Equals(object o) cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       18 (0x12)
      .maxstack  2
      .locals init (bool V_0)
      IL_0000:  nop
      IL_0001:  ldarg.0
      IL_0002:  ldarg.1
      IL_0003:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
      IL_0008:  call       instance bool [mscorlib]System.Object::Equals(object)
      IL_000d:  stloc.0
      IL_000e:  br.s       IL_0010

      IL_0010:  ldloc.0
      IL_0011:  ret
    } // end of method MyWebServices::Equals

    .method public hidebysig strict virtual 
            instance int32  GetHashCode() cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       12 (0xc)
      .maxstack  1
      .locals init (int32 V_0)
      IL_0000:  nop
      IL_0001:  ldarg.0
      IL_0002:  call       instance int32 [mscorlib]System.Object::GetHashCode()
      IL_0007:  stloc.0
      IL_0008:  br.s       IL_000a

      IL_000a:  ldloc.0
      IL_000b:  ret
    } // end of method MyWebServices::GetHashCode

    .method assembly hidebysig instance class [mscorlib]System.Type 
            GetType() cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       16 (0x10)
      .maxstack  1
      .locals init (class [mscorlib]System.Type V_0)
      IL_0000:  nop
      IL_0001:  ldtoken    ACMDotNetWrapper.My.MyProject/MyWebServices
      IL_0006:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_000b:  stloc.0
      IL_000c:  br.s       IL_000e

      IL_000e:  ldloc.0
      IL_000f:  ret
    } // end of method MyWebServices::GetType

    .method public hidebysig strict virtual 
            instance string  ToString() cil managed
    {
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       12 (0xc)
      .maxstack  1
      .locals init (string V_0)
      IL_0000:  nop
      IL_0001:  ldarg.0
      IL_0002:  call       instance string [mscorlib]System.Object::ToString()
      IL_0007:  stloc.0
      IL_0008:  br.s       IL_000a

      IL_000a:  ldloc.0
      IL_000b:  ret
    } // end of method MyWebServices::ToString

    .method private static !!T  Create__Instance__<.ctor T>(!!T 'instance') cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       29 (0x1d)
      .maxstack  2
      .locals init (!!T V_0,
               bool V_1)
      IL_0000:  nop
      IL_0001:  ldarg.0
      IL_0002:  box        !!T
      IL_0007:  ldnull
      IL_0008:  ceq
      IL_000a:  stloc.1
      IL_000b:  ldloc.1
      IL_000c:  brfalse.s  IL_0016

      IL_000e:  call       !!0 [mscorlib]System.Activator::CreateInstance<!!0>()
      IL_0013:  stloc.0
      IL_0014:  br.s       IL_001b

      IL_0016:  nop
      IL_0017:  ldarg.0
      IL_0018:  stloc.0
      IL_0019:  br.s       IL_001b

      IL_001b:  ldloc.0
      IL_001c:  ret
    } // end of method MyWebServices::Create__Instance__

    .method private instance void  Dispose__Instance__<T>(!!T& 'instance') cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       9 (0x9)
      .maxstack  8
      IL_0000:  nop
      IL_0001:  ldarg.1
      IL_0002:  initobj    !!T
      IL_0008:  ret
    } // end of method MyWebServices::Dispose__Instance__

    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      // Code size       9 (0x9)
      .maxstack  8
      IL_0000:  nop
      IL_0001:  ldarg.0
      IL_0002:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0007:  nop
      IL_0008:  ret
    } // end of method MyWebServices::.ctor

  } // end of class MyWebServices

  .class auto ansi sealed nested assembly ThreadSafeObjectProvider`1<.ctor T>
         extends [mscorlib]System.Object
  {
    .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
    .field private initonly class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T> m_Context
    .method assembly specialname instance !T 
            get_GetInstance() cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      // Code size       53 (0x35)
      .maxstack  2
      .locals init (!T V_0,
               !T V_1,
               bool V_2)
      IL_0000:  nop
      IL_0001:  ldarg.0
      IL_0002:  ldfld      class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!0> class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<!T>::m_Context
      IL_0007:  callvirt   instance !0 class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T>::get_Value()
      IL_000c:  stloc.1
      IL_000d:  ldloc.1
      IL_000e:  box        !T
      IL_0013:  ldnull
      IL_0014:  ceq
      IL_0016:  stloc.2
      IL_0017:  ldloc.2
      IL_0018:  brfalse.s  IL_002e

      IL_001a:  call       !!0 [mscorlib]System.Activator::CreateInstance<!T>()
      IL_001f:  stloc.1
      IL_0020:  ldarg.0
      IL_0021:  ldfld      class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!0> class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<!T>::m_Context
      IL_0026:  ldloc.1
      IL_0027:  callvirt   instance void class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T>::set_Value(!0)
      IL_002c:  nop
      IL_002d:  nop
      IL_002e:  nop
      IL_002f:  ldloc.1
      IL_0030:  stloc.0
      IL_0031:  br.s       IL_0033

      IL_0033:  ldloc.0
      IL_0034:  ret
    } // end of method ThreadSafeObjectProvider`1::get_GetInstance

    .method public specialname rtspecialname 
            instance void  .ctor() cil managed
    {
      .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
      .custom instance void [System]System.ComponentModel.EditorBrowsableAttribute::.ctor(valuetype [System]System.ComponentModel.EditorBrowsableState) = ( 01 00 01 00 00 00 00 00 ) 
      // Code size       20 (0x14)
      .maxstack  8
      IL_0000:  nop
      IL_0001:  ldarg.0
      IL_0002:  call       instance void [mscorlib]System.Object::.ctor()
      IL_0007:  nop
      IL_0008:  ldarg.0
      IL_0009:  newobj     instance void class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!T>::.ctor()
      IL_000e:  stfld      class [Microsoft.VisualBasic]Microsoft.VisualBasic.MyServices.Internal.ContextValue`1<!0> class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<!T>::m_Context
      IL_0013:  ret
    } // end of method ThreadSafeObjectProvider`1::.ctor

    .property instance callconv(8) !T GetInstance()
    {
      .get instance !T ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1::get_GetInstance()
    } // end of property ThreadSafeObjectProvider`1::GetInstance
  } // end of class ThreadSafeObjectProvider`1

  .field private static initonly class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyComputer> m_ComputerObjectProvider
  .field private static initonly class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyApplication> m_AppObjectProvider
  .field private static initonly class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User> m_UserObjectProvider
  .field private static initonly class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyProject/MyWebServices> m_MyWebServicesObjectProvider
  .method private specialname rtspecialname static 
          void  .cctor() cil managed
  {
    // Code size       41 (0x29)
    .maxstack  8
    IL_0000:  newobj     instance void class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyComputer>::.ctor()
    IL_0005:  stsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyComputer> ACMDotNetWrapper.My.MyProject::m_ComputerObjectProvider
    IL_000a:  newobj     instance void class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyApplication>::.ctor()
    IL_000f:  stsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyApplication> ACMDotNetWrapper.My.MyProject::m_AppObjectProvider
    IL_0014:  newobj     instance void class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User>::.ctor()
    IL_0019:  stsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User> ACMDotNetWrapper.My.MyProject::m_UserObjectProvider
    IL_001e:  newobj     instance void class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyProject/MyWebServices>::.ctor()
    IL_0023:  stsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyProject/MyWebServices> ACMDotNetWrapper.My.MyProject::m_MyWebServicesObjectProvider
    IL_0028:  ret
  } // end of method MyProject::.cctor

  .method assembly specialname static class ACMDotNetWrapper.My.MyComputer 
          get_Computer() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       16 (0x10)
    .maxstack  1
    .locals init (class ACMDotNetWrapper.My.MyComputer V_0)
    IL_0000:  nop
    IL_0001:  ldsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyComputer> ACMDotNetWrapper.My.MyProject::m_ComputerObjectProvider
    IL_0006:  callvirt   instance !0 class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyComputer>::get_GetInstance()
    IL_000b:  stloc.0
    IL_000c:  br.s       IL_000e

    IL_000e:  ldloc.0
    IL_000f:  ret
  } // end of method MyProject::get_Computer

  .method assembly specialname static class ACMDotNetWrapper.My.MyApplication 
          get_Application() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       16 (0x10)
    .maxstack  1
    .locals init (class ACMDotNetWrapper.My.MyApplication V_0)
    IL_0000:  nop
    IL_0001:  ldsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyApplication> ACMDotNetWrapper.My.MyProject::m_AppObjectProvider
    IL_0006:  callvirt   instance !0 class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyApplication>::get_GetInstance()
    IL_000b:  stloc.0
    IL_000c:  br.s       IL_000e

    IL_000e:  ldloc.0
    IL_000f:  ret
  } // end of method MyProject::get_Application

  .method assembly specialname static class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User 
          get_User() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       16 (0x10)
    .maxstack  1
    .locals init (class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User V_0)
    IL_0000:  nop
    IL_0001:  ldsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User> ACMDotNetWrapper.My.MyProject::m_UserObjectProvider
    IL_0006:  callvirt   instance !0 class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User>::get_GetInstance()
    IL_000b:  stloc.0
    IL_000c:  br.s       IL_000e

    IL_000e:  ldloc.0
    IL_000f:  ret
  } // end of method MyProject::get_User

  .method assembly specialname static class ACMDotNetWrapper.My.MyProject/MyWebServices 
          get_WebServices() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       16 (0x10)
    .maxstack  1
    .locals init (class ACMDotNetWrapper.My.MyProject/MyWebServices V_0)
    IL_0000:  nop
    IL_0001:  ldsfld     class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyProject/MyWebServices> ACMDotNetWrapper.My.MyProject::m_MyWebServicesObjectProvider
    IL_0006:  callvirt   instance !0 class ACMDotNetWrapper.My.MyProject/ThreadSafeObjectProvider`1<class ACMDotNetWrapper.My.MyProject/MyWebServices>::get_GetInstance()
    IL_000b:  stloc.0
    IL_000c:  br.s       IL_000e

    IL_000e:  ldloc.0
    IL_000f:  ret
  } // end of method MyProject::get_WebServices

  .property callconv(8) class ACMDotNetWrapper.My.MyComputer
          Computer()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 0B 4D 79 2E 43 6F 6D 70 75 74 65 72 00 00 ) // ...My.Computer..
    .get class ACMDotNetWrapper.My.MyComputer ACMDotNetWrapper.My.MyProject::get_Computer()
  } // end of property MyProject::Computer
  .property callconv(8) class ACMDotNetWrapper.My.MyApplication
          Application()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 0E 4D 79 2E 41 70 70 6C 69 63 61 74 69 6F   // ...My.Applicatio
                                                                                                       6E 00 00 )                                        // n..
    .get class ACMDotNetWrapper.My.MyApplication ACMDotNetWrapper.My.MyProject::get_Application()
  } // end of property MyProject::Application
  .property callconv(8) class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User
          User()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 07 4D 79 2E 55 73 65 72 00 00 )             // ...My.User..
    .get class [Microsoft.VisualBasic]Microsoft.VisualBasic.ApplicationServices.User ACMDotNetWrapper.My.MyProject::get_User()
  } // end of property MyProject::User
  .property callconv(8) class ACMDotNetWrapper.My.MyProject/MyWebServices
          WebServices()
  {
    .custom instance void [System]System.ComponentModel.Design.HelpKeywordAttribute::.ctor(string) = ( 01 00 0E 4D 79 2E 57 65 62 53 65 72 76 69 63 65   // ...My.WebService
                                                                                                       73 00 00 )                                        // s..
    .get class ACMDotNetWrapper.My.MyProject/MyWebServices ACMDotNetWrapper.My.MyProject::get_WebServices()
  } // end of property MyProject::WebServices
} // end of class ACMDotNetWrapper.My.MyProject

.class public auto ansi ACMDotNetWrapper.Wrapper
       extends [System.Windows.Forms]System.Windows.Forms.UserControl
{
  .custom instance void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.DesignerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ProgIdAttribute::.ctor(string) = ( 01 00 1D 41 43 4D 44 6F 74 4E 65 74 57 72 61 70   // ...ACMDotNetWrap
                                                                                                    70 65 72 2E 57 72 61 70 70 65 72 2E 34 31 2E 30   // per.Wrapper.41.0
                                                                                                    00 00 ) 
  .field private class [System]System.ComponentModel.IContainer components
  .field public class [System.Windows.Forms]System.Windows.Forms.ToolTip ToolTip1
  .field private object NETControl
  .field private object mControlContext
  .field private string mNetID
  .field private string mControlName
  .method public specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       73 (0x49)
    .maxstack  3
    .locals init ()
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  call       instance void [System.Windows.Forms]System.Windows.Forms.UserControl::.ctor()
    IL_0007:  nop
    IL_0008:  ldarg.0
    IL_0009:  ldarg.0
    IL_000a:  ldftn      instance void ACMDotNetWrapper.Wrapper::UserControl_Hide(object,
                                                                                  class [mscorlib]System.EventArgs)
    IL_0010:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_0015:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::add_VisibleChanged(class [mscorlib]System.EventHandler)
    IL_001a:  nop
    IL_001b:  ldarg.0
    IL_001c:  ldarg.0
    IL_001d:  ldftn      instance void ACMDotNetWrapper.Wrapper::UserControl_Resize(object,
                                                                                    class [mscorlib]System.EventArgs)
    IL_0023:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_0028:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::add_Resize(class [mscorlib]System.EventHandler)
    IL_002d:  nop
    IL_002e:  ldarg.0
    IL_002f:  ldarg.0
    IL_0030:  ldftn      instance void ACMDotNetWrapper.Wrapper::'_Lambda$__R0-1'(object,
                                                                                  class [mscorlib]System.EventArgs)
    IL_0036:  newobj     instance void [mscorlib]System.EventHandler::.ctor(object,
                                                                            native int)
    IL_003b:  call       instance void [System]System.ComponentModel.Component::add_Disposed(class [mscorlib]System.EventHandler)
    IL_0040:  nop
    IL_0041:  ldarg.0
    IL_0042:  call       instance void ACMDotNetWrapper.Wrapper::InitializeComponent()
    IL_0047:  nop
    IL_0048:  ret
  } // end of method Wrapper::.ctor

  .method family hidebysig strict virtual 
          instance void  Dispose(bool Disposing) cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerNonUserCodeAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       51 (0x33)
    .maxstack  2
    .locals init (bool V_0,
             bool V_1)
    IL_0000:  nop
    IL_0001:  ldarg.1
    IL_0002:  stloc.0
    IL_0003:  ldloc.0
    IL_0004:  brfalse.s  IL_0029

    IL_0006:  ldarg.0
    IL_0007:  call       instance void ACMDotNetWrapper.Wrapper::UserControl_Terminate()
    IL_000c:  nop
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class [System]System.ComponentModel.IContainer ACMDotNetWrapper.Wrapper::components
    IL_0013:  ldnull
    IL_0014:  cgt.un
    IL_0016:  stloc.1
    IL_0017:  ldloc.1
    IL_0018:  brfalse.s  IL_0027

    IL_001a:  ldarg.0
    IL_001b:  ldfld      class [System]System.ComponentModel.IContainer ACMDotNetWrapper.Wrapper::components
    IL_0020:  callvirt   instance void [mscorlib]System.IDisposable::Dispose()
    IL_0025:  nop
    IL_0026:  nop
    IL_0027:  nop
    IL_0028:  nop
    IL_0029:  nop
    IL_002a:  ldarg.0
    IL_002b:  ldarg.1
    IL_002c:  call       instance void [System.Windows.Forms]System.Windows.Forms.ContainerControl::Dispose(bool)
    IL_0031:  nop
    IL_0032:  ret
  } // end of method Wrapper::Dispose

  .method private instance void  InitializeComponent() cil managed
  {
    .custom instance void [mscorlib]System.Diagnostics.DebuggerStepThroughAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       154 (0x9a)
    .maxstack  6
    .locals init (class [mscorlib]System.Resources.ResourceManager V_0)
    IL_0000:  nop
    IL_0001:  ldtoken    ACMDotNetWrapper.Wrapper
    IL_0006:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_000b:  newobj     instance void [mscorlib]System.Resources.ResourceManager::.ctor(class [mscorlib]System.Type)
    IL_0010:  stloc.0
    IL_0011:  ldarg.0
    IL_0012:  newobj     instance void [System]System.ComponentModel.Container::.ctor()
    IL_0017:  stfld      class [System]System.ComponentModel.IContainer ACMDotNetWrapper.Wrapper::components
    IL_001c:  ldarg.0
    IL_001d:  ldarg.0
    IL_001e:  ldfld      class [System]System.ComponentModel.IContainer ACMDotNetWrapper.Wrapper::components
    IL_0023:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.ToolTip::.ctor(class [System]System.ComponentModel.IContainer)
    IL_0028:  stfld      class [System.Windows.Forms]System.Windows.Forms.ToolTip ACMDotNetWrapper.Wrapper::ToolTip1
    IL_002d:  ldarg.0
    IL_002e:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::SuspendLayout()
    IL_0033:  nop
    IL_0034:  ldarg.0
    IL_0035:  ldfld      class [System.Windows.Forms]System.Windows.Forms.ToolTip ACMDotNetWrapper.Wrapper::ToolTip1
    IL_003a:  ldc.i4.1
    IL_003b:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.ToolTip::set_Active(bool)
    IL_0040:  nop
    IL_0041:  ldarg.0
    IL_0042:  ldc.i4     0x244
    IL_0047:  ldc.i4     0x17c
    IL_004c:  newobj     instance void [System.Drawing]System.Drawing.Size::.ctor(int32,
                                                                                  int32)
    IL_0051:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::set_ClientSize(valuetype [System.Drawing]System.Drawing.Size)
    IL_0056:  nop
    IL_0057:  ldarg.0
    IL_0058:  ldc.i4.0
    IL_0059:  ldc.i4.0
    IL_005a:  newobj     instance void [System.Drawing]System.Drawing.Point::.ctor(int32,
                                                                                   int32)
    IL_005f:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::set_Location(valuetype [System.Drawing]System.Drawing.Point)
    IL_0064:  nop
    IL_0065:  ldarg.0
    IL_0066:  ldstr      "Arial"
    IL_006b:  ldc.r4     8
    IL_0070:  ldc.i4.0
    IL_0071:  ldc.i4.3
    IL_0072:  ldc.i4.0
    IL_0073:  newobj     instance void [System.Drawing]System.Drawing.Font::.ctor(string,
                                                                                  float32,
                                                                                  valuetype [System.Drawing]System.Drawing.FontStyle,
                                                                                  valuetype [System.Drawing]System.Drawing.GraphicsUnit,
                                                                                  uint8)
    IL_0078:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::set_Font(class [System.Drawing]System.Drawing.Font)
    IL_007d:  nop
    IL_007e:  ldarg.0
    IL_007f:  ldstr      "Wrapper"
    IL_0084:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::set_Name(string)
    IL_0089:  nop
    IL_008a:  ldarg.0
    IL_008b:  ldc.i4.0
    IL_008c:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::ResumeLayout(bool)
    IL_0091:  nop
    IL_0092:  ldarg.0
    IL_0093:  call       instance void [System.Windows.Forms]System.Windows.Forms.Control::PerformLayout()
    IL_0098:  nop
    IL_0099:  ret
  } // end of method Wrapper::InitializeComponent

  .method private static pinvokeimpl("user32.dll" nomangle ansi lasterr winapi) 
          int32  GetParent(int32 hwnd) cil managed preservesig
  {
  }
  .method public specialname instance object 
          get_ControlContext() cil managed
  {
    // Code size       15 (0xf)
    .maxstack  1
    .locals init (object V_0)
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldfld      object ACMDotNetWrapper.Wrapper::mControlContext
    IL_0007:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_000c:  stloc.0
    IL_000d:  ldloc.0
    IL_000e:  ret
  } // end of method Wrapper::get_ControlContext

  .method public specialname instance void 
          set_ControlContext(object Value) cil managed
  {
    // Code size       415 (0x19f)
    .maxstack  8
    .locals init (string V_0,
             bool V_1,
             bool V_2,
             bool V_3,
             bool V_4,
             int32 V_5,
             native int V_6)
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldfld      object ACMDotNetWrapper.Wrapper::mControlContext
    IL_0007:  ldnull
    IL_0008:  cgt.un
    IL_000a:  ldarg.1
    IL_000b:  ldnull
    IL_000c:  ceq
    IL_000e:  and
    IL_000f:  stloc.1
    IL_0010:  ldloc.1
    IL_0011:  brfalse.s  IL_007c

    IL_0013:  ldarg.0
    IL_0014:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0019:  ldnull
    IL_001a:  ldstr      "ControlContext"
    IL_001f:  ldc.i4.1
    IL_0020:  newarr     [mscorlib]System.Object
    IL_0025:  ldnull
    IL_0026:  ldnull
    IL_0027:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateSet(object,
                                                                                                                    class [mscorlib]System.Type,
                                                                                                                    string,
                                                                                                                    object[],
                                                                                                                    string[],
                                                                                                                    class [mscorlib]System.Type[])
    IL_002c:  nop
    IL_002d:  ldarg.0
    IL_002e:  ldnull
    IL_002f:  stfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0034:  ldarg.0
    IL_0035:  call       instance string ACMDotNetWrapper.Wrapper::get_ControlName()
    IL_003a:  ldstr      ""
    IL_003f:  ldc.i4.0
    IL_0040:  call       int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Operators::CompareString(string,
                                                                                                                      string,
                                                                                                                      bool)
    IL_0045:  ldc.i4.0
    IL_0046:  ceq
    IL_0048:  stloc.2
    IL_0049:  ldloc.2
    IL_004a:  brfalse.s  IL_0058

    IL_004c:  ldarg.0
    IL_004d:  ldstr      "CustomControl"
    IL_0052:  call       instance void ACMDotNetWrapper.Wrapper::set_ControlName(string)
    IL_0057:  nop
    IL_0058:  ldarg.0
    IL_0059:  call       instance class [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection [System.Windows.Forms]System.Windows.Forms.Control::get_Controls()
    IL_005e:  ldarg.0
    IL_005f:  ldfld      string ACMDotNetWrapper.Wrapper::mControlName
    IL_0064:  call       int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ToInteger(string)
    IL_0069:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection::RemoveAt(int32)
    IL_006e:  nop
    IL_006f:  ldarg.0
    IL_0070:  ldstr      ""
    IL_0075:  call       instance void ACMDotNetWrapper.Wrapper::set_DotNetID(string)
    IL_007a:  nop
    IL_007b:  nop
    IL_007c:  nop
    IL_007d:  ldarg.0
    IL_007e:  ldarg.1
    IL_007f:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_0084:  stfld      object ACMDotNetWrapper.Wrapper::mControlContext
    IL_0089:  ldarg.0
    IL_008a:  ldfld      object ACMDotNetWrapper.Wrapper::mControlContext
    IL_008f:  ldnull
    IL_0090:  cgt.un
    IL_0092:  ldarg.0
    IL_0093:  ldfld      string ACMDotNetWrapper.Wrapper::mNetID
    IL_0098:  ldstr      ""
    IL_009d:  ldc.i4.0
    IL_009e:  call       int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Operators::CompareString(string,
                                                                                                                      string,
                                                                                                                      bool)
    IL_00a3:  ldc.i4.0
    IL_00a4:  cgt.un
    IL_00a6:  and
    IL_00a7:  stloc.3
    IL_00a8:  ldloc.3
    IL_00a9:  brfalse    IL_019d

    IL_00ae:  ldarg.0
    IL_00af:  ldfld      object ACMDotNetWrapper.Wrapper::mControlContext
    IL_00b4:  ldnull
    IL_00b5:  ldstr      "getpath"
    IL_00ba:  ldc.i4.0
    IL_00bb:  newarr     [mscorlib]System.Object
    IL_00c0:  ldnull
    IL_00c1:  ldnull
    IL_00c2:  ldnull
    IL_00c3:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateGet(object,
                                                                                                                      class [mscorlib]System.Type,
                                                                                                                      string,
                                                                                                                      object[],
                                                                                                                      string[],
                                                                                                                      class [mscorlib]System.Type[],
                                                                                                                      bool[])
    IL_00c8:  call       string [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ToString(object)
    IL_00cd:  stloc.0
    IL_00ce:  ldloc.0
    IL_00cf:  ldstr      ""
    IL_00d4:  ldc.i4.0
    IL_00d5:  call       int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Operators::CompareString(string,
                                                                                                                      string,
                                                                                                                      bool)
    IL_00da:  ldc.i4.0
    IL_00db:  ceq
    IL_00dd:  stloc.s    V_4
    IL_00df:  ldloc.s    V_4
    IL_00e1:  brfalse.s  IL_00e9

    IL_00e3:  ldstr      "UserControl"
    IL_00e8:  stloc.0
    IL_00e9:  ldarg.0
    IL_00ea:  ldarg.0
    IL_00eb:  call       instance string ACMDotNetWrapper.Wrapper::get_DotNetID()
    IL_00f0:  ldstr      ""
    IL_00f5:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.Interaction::CreateObject(string,
                                                                                                       string)
    IL_00fa:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_00ff:  stfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0104:  ldarg.0
    IL_0105:  call       instance class [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection [System.Windows.Forms]System.Windows.Forms.Control::get_Controls()
    IL_010a:  ldarg.0
    IL_010b:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0110:  castclass  [System.Windows.Forms]System.Windows.Forms.Control
    IL_0115:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection::Add(class [System.Windows.Forms]System.Windows.Forms.Control)
    IL_011a:  nop
    IL_011b:  ldarg.0
    IL_011c:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0121:  ldnull
    IL_0122:  ldstr      "ControlContext"
    IL_0127:  ldc.i4.1
    IL_0128:  newarr     [mscorlib]System.Object
    IL_012d:  dup
    IL_012e:  ldc.i4.0
    IL_012f:  ldarg.0
    IL_0130:  ldfld      object ACMDotNetWrapper.Wrapper::mControlContext
    IL_0135:  stelem.ref
    IL_0136:  ldnull
    IL_0137:  ldnull
    IL_0138:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateSet(object,
                                                                                                                    class [mscorlib]System.Type,
                                                                                                                    string,
                                                                                                                    object[],
                                                                                                                    string[],
                                                                                                                    class [mscorlib]System.Type[])
    IL_013d:  nop
    IL_013e:  ldarg.0
    IL_013f:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0144:  ldnull
    IL_0145:  ldstr      "OCXhWnd"
    IL_014a:  ldc.i4.1
    IL_014b:  newarr     [mscorlib]System.Object
    IL_0150:  dup
    IL_0151:  ldc.i4.0
    IL_0152:  ldarg.0
    IL_0153:  ldarg.0
    IL_0154:  call       instance native int [System.Windows.Forms]System.Windows.Forms.Control::get_Handle()
    IL_0159:  stloc.s    V_6
    IL_015b:  ldloca.s   V_6
    IL_015d:  call       instance int32 [mscorlib]System.IntPtr::ToInt32()
    IL_0162:  stloc.s    V_5
    IL_0164:  ldloca.s   V_5
    IL_0166:  call       instance int32 ACMDotNetWrapper.Wrapper::GetOCXWhWnd(int32&)
    IL_016b:  box        [mscorlib]System.Int32
    IL_0170:  stelem.ref
    IL_0171:  ldnull
    IL_0172:  ldnull
    IL_0173:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateSet(object,
                                                                                                                    class [mscorlib]System.Type,
                                                                                                                    string,
                                                                                                                    object[],
                                                                                                                    string[],
                                                                                                                    class [mscorlib]System.Type[])
    IL_0178:  nop
    IL_0179:  ldarg.0
    IL_017a:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_017f:  ldnull
    IL_0180:  ldstr      "Visible"
    IL_0185:  ldc.i4.1
    IL_0186:  newarr     [mscorlib]System.Object
    IL_018b:  dup
    IL_018c:  ldc.i4.0
    IL_018d:  ldc.i4.1
    IL_018e:  box        [mscorlib]System.Boolean
    IL_0193:  stelem.ref
    IL_0194:  ldnull
    IL_0195:  ldnull
    IL_0196:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateSet(object,
                                                                                                                    class [mscorlib]System.Type,
                                                                                                                    string,
                                                                                                                    object[],
                                                                                                                    string[],
                                                                                                                    class [mscorlib]System.Type[])
    IL_019b:  nop
    IL_019c:  nop
    IL_019d:  nop
    IL_019e:  ret
  } // end of method Wrapper::set_ControlContext

  .method public specialname instance string 
          get_DotNetID() cil managed
  {
    // Code size       10 (0xa)
    .maxstack  1
    .locals init (string V_0)
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldfld      string ACMDotNetWrapper.Wrapper::mNetID
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  ret
  } // end of method Wrapper::get_DotNetID

  .method public specialname instance void 
          set_DotNetID(string Value) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldarg.1
    IL_0003:  stfld      string ACMDotNetWrapper.Wrapper::mNetID
    IL_0008:  ret
  } // end of method Wrapper::set_DotNetID

  .method private specialname instance string 
          get_ControlName() cil managed
  {
    // Code size       10 (0xa)
    .maxstack  1
    .locals init (string V_0)
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldfld      string ACMDotNetWrapper.Wrapper::mControlName
    IL_0007:  stloc.0
    IL_0008:  ldloc.0
    IL_0009:  ret
  } // end of method Wrapper::get_ControlName

  .method private specialname instance void 
          set_ControlName(string Value) cil managed
  {
    // Code size       9 (0x9)
    .maxstack  8
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldarg.1
    IL_0003:  stfld      string ACMDotNetWrapper.Wrapper::mControlName
    IL_0008:  ret
  } // end of method Wrapper::set_ControlName

  .method public instance int32  GetOCXWhWnd(int32& UserControl_hWnd) cil managed
  {
    // Code size       169 (0xa9)
    .maxstack  3
    .locals init (int32 V_0,
             int32 V_1,
             int32 V_2,
             int32 V_3,
             bool V_4)
    IL_0000:  nop
    .try
    {
      IL_0001:  nop
      IL_0002:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::ClearProjectError()
      IL_0007:  nop
      IL_0008:  ldc.i4.s   -2
      IL_000a:  stloc.1
      IL_000b:  ldc.i4.2
      IL_000c:  stloc.3
      IL_000d:  ldarg.1
      IL_000e:  ldind.i4
      IL_000f:  call       int32 ACMDotNetWrapper.Wrapper::GetParent(int32)
      IL_0014:  call       int32 ACMDotNetWrapper.Wrapper::GetParent(int32)
      IL_0019:  stloc.0
      IL_001a:  ldc.i4.3
      IL_001b:  stloc.3
      IL_001c:  call       class [Microsoft.VisualBasic]Microsoft.VisualBasic.ErrObject [Microsoft.VisualBasic]Microsoft.VisualBasic.Information::Err()
      IL_0021:  callvirt   instance int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.ErrObject::get_Number()
      IL_0026:  ldc.i4.0
      IL_0027:  cgt.un
      IL_0029:  stloc.s    V_4
      IL_002b:  ldloc.s    V_4
      IL_002d:  brfalse.s  IL_0033

      IL_002f:  ldc.i4.4
      IL_0030:  stloc.3
      IL_0031:  ldc.i4.0
      IL_0032:  stloc.0
      IL_0033:  leave.s    IL_009e

      IL_0035:  ldloc.2
      IL_0036:  ldc.i4.1
      IL_0037:  add
      IL_0038:  ldc.i4.0
      IL_0039:  stloc.2
      IL_003a:  switch     ( 
                            IL_0057,
                            IL_0002,
                            IL_000b,
                            IL_001a,
                            IL_002f,
                            IL_0033)
      IL_0057:  leave.s    IL_0093

      IL_0059:  ldloc.3
      IL_005a:  stloc.2
      IL_005b:  ldloc.1
      IL_005c:  ldc.i4.s   -2
      IL_005e:  bgt.s      IL_0063

      IL_0060:  ldc.i4.1
      IL_0061:  br.s       IL_0064

      IL_0063:  ldloc.1
      IL_0064:  switch     ( 
                            IL_0071,
                            IL_0035)
      IL_0071:  leave.s    IL_0093

    }  // end .try
    filter
    {
      IL_0073:  isinst     [mscorlib]System.Exception
      IL_0078:  ldnull
      IL_0079:  cgt.un
      IL_007b:  ldloc.1
      IL_007c:  ldc.i4.0
      IL_007d:  cgt.un
      IL_007f:  and
      IL_0080:  ldloc.2
      IL_0081:  ldc.i4.0
      IL_0082:  ceq
      IL_0084:  and
      IL_0085:  endfilter
    }  // end filter
    {  // handler
      IL_0087:  castclass  [mscorlib]System.Exception
      IL_008c:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::SetProjectError(class [mscorlib]System.Exception)
      IL_0091:  leave.s    IL_0059

    }  // end handler
    IL_0093:  ldc.i4     0x800a0033
    IL_0098:  call       class [mscorlib]System.Exception [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::CreateProjectError(int32)
    IL_009d:  throw

    IL_009e:  ldloc.2
    IL_009f:  brfalse.s  IL_00a7

    IL_00a1:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::ClearProjectError()
    IL_00a6:  nop
    IL_00a7:  ldloc.0
    IL_00a8:  ret
  } // end of method Wrapper::GetOCXWhWnd

  .method private instance void  UserControl_Hide(object sender,
                                                  class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       181 (0xb5)
    .maxstack  8
    .locals init (string V_0,
             bool V_1,
             bool V_2,
             class [mscorlib]System.Exception V_3)
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  call       instance bool [System.Windows.Forms]System.Windows.Forms.Control::get_Visible()
    IL_0007:  ldc.i4.0
    IL_0008:  ceq
    IL_000a:  ldarg.0
    IL_000b:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0010:  ldnull
    IL_0011:  cgt.un
    IL_0013:  and
    IL_0014:  stloc.1
    IL_0015:  ldloc.1
    IL_0016:  brfalse    IL_00b3

    IL_001b:  ldarg.0
    IL_001c:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0021:  ldnull
    IL_0022:  ldstr      "Name"
    IL_0027:  ldc.i4.0
    IL_0028:  newarr     [mscorlib]System.Object
    IL_002d:  ldnull
    IL_002e:  ldnull
    IL_002f:  ldnull
    IL_0030:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateGet(object,
                                                                                                                      class [mscorlib]System.Type,
                                                                                                                      string,
                                                                                                                      object[],
                                                                                                                      string[],
                                                                                                                      class [mscorlib]System.Type[],
                                                                                                                      bool[])
    IL_0035:  call       string [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ToString(object)
    IL_003a:  stloc.0
    IL_003b:  ldloc.0
    IL_003c:  ldstr      ""
    IL_0041:  ldc.i4.0
    IL_0042:  call       int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Operators::CompareString(string,
                                                                                                                      string,
                                                                                                                      bool)
    IL_0047:  ldc.i4.0
    IL_0048:  ceq
    IL_004a:  stloc.2
    IL_004b:  ldloc.2
    IL_004c:  brfalse.s  IL_0054

    IL_004e:  ldstr      "UserControl"
    IL_0053:  stloc.0
    IL_0054:  nop
    .try
    {
      IL_0055:  nop
      IL_0056:  ldarg.0
      IL_0057:  call       instance class [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection [System.Windows.Forms]System.Windows.Forms.Control::get_Controls()
      IL_005c:  ldloc.0
      IL_005d:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection::RemoveByKey(string)
      IL_0062:  nop
      IL_0063:  leave.s    IL_0074

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_0065:  dup
      IL_0066:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::SetProjectError(class [mscorlib]System.Exception)
      IL_006b:  stloc.3
      IL_006c:  nop
      IL_006d:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::ClearProjectError()
      IL_0072:  leave.s    IL_0074

    }  // end handler
    IL_0074:  nop
    IL_0075:  ldarg.0
    IL_0076:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_007b:  ldnull
    IL_007c:  ldstr      "ControlContext"
    IL_0081:  ldc.i4.1
    IL_0082:  newarr     [mscorlib]System.Object
    IL_0087:  ldnull
    IL_0088:  ldnull
    IL_0089:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateSet(object,
                                                                                                                    class [mscorlib]System.Type,
                                                                                                                    string,
                                                                                                                    object[],
                                                                                                                    string[],
                                                                                                                    class [mscorlib]System.Type[])
    IL_008e:  nop
    IL_008f:  ldarg.0
    IL_0090:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0095:  ldnull
    IL_0096:  ldstr      "Dispose"
    IL_009b:  ldc.i4.0
    IL_009c:  newarr     [mscorlib]System.Object
    IL_00a1:  ldnull
    IL_00a2:  ldnull
    IL_00a3:  ldnull
    IL_00a4:  ldc.i4.1
    IL_00a5:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateCall(object,
                                                                                                                       class [mscorlib]System.Type,
                                                                                                                       string,
                                                                                                                       object[],
                                                                                                                       string[],
                                                                                                                       class [mscorlib]System.Type[],
                                                                                                                       bool[],
                                                                                                                       bool)
    IL_00aa:  pop
    IL_00ab:  ldarg.0
    IL_00ac:  ldnull
    IL_00ad:  stfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_00b2:  nop
    IL_00b3:  nop
    IL_00b4:  ret
  } // end of method Wrapper::UserControl_Hide

  .method private instance void  UserControl_Resize(object eventSender,
                                                    class [mscorlib]System.EventArgs eventArgs) cil managed
  {
    // Code size       250 (0xfa)
    .maxstack  10
    .locals init (bool V_0,
             valuetype [System.Drawing]System.Drawing.Rectangle V_1,
             valuetype [System.Drawing]System.Drawing.Rectangle V_2,
             object[] V_3,
             bool[] V_4,
             valuetype [System.Drawing]System.Drawing.Rectangle V_5)
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0007:  ldnull
    IL_0008:  cgt.un
    IL_000a:  stloc.0
    IL_000b:  ldloc.0
    IL_000c:  brfalse    IL_00f8

    IL_0011:  ldarg.0
    IL_0012:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0017:  ldnull
    IL_0018:  ldstr      "SetBounds"
    IL_001d:  ldc.i4.4
    IL_001e:  newarr     [mscorlib]System.Object
    IL_0023:  dup
    IL_0024:  ldc.i4.0
    IL_0025:  ldarg.0
    IL_0026:  call       instance valuetype [System.Drawing]System.Drawing.Rectangle [System.Windows.Forms]System.Windows.Forms.Control::get_ClientRectangle()
    IL_002b:  stloc.s    V_5
    IL_002d:  ldloca.s   V_5
    IL_002f:  call       instance int32 [System.Drawing]System.Drawing.Rectangle::get_Left()
    IL_0034:  box        [mscorlib]System.Int32
    IL_0039:  stelem.ref
    IL_003a:  dup
    IL_003b:  ldc.i4.1
    IL_003c:  ldarg.0
    IL_003d:  call       instance valuetype [System.Drawing]System.Drawing.Rectangle [System.Windows.Forms]System.Windows.Forms.Control::get_ClientRectangle()
    IL_0042:  stloc.s    V_5
    IL_0044:  ldloca.s   V_5
    IL_0046:  call       instance int32 [System.Drawing]System.Drawing.Rectangle::get_Top()
    IL_004b:  box        [mscorlib]System.Int32
    IL_0050:  stelem.ref
    IL_0051:  dup
    IL_0052:  ldc.i4.2
    IL_0053:  ldarg.0
    IL_0054:  call       instance valuetype [System.Drawing]System.Drawing.Rectangle [System.Windows.Forms]System.Windows.Forms.Control::get_ClientRectangle()
    IL_0059:  dup
    IL_005a:  stloc.1
    IL_005b:  stloc.s    V_5
    IL_005d:  ldloca.s   V_5
    IL_005f:  call       instance int32 [System.Drawing]System.Drawing.Rectangle::get_Width()
    IL_0064:  box        [mscorlib]System.Int32
    IL_0069:  stelem.ref
    IL_006a:  dup
    IL_006b:  ldc.i4.3
    IL_006c:  ldarg.0
    IL_006d:  call       instance valuetype [System.Drawing]System.Drawing.Rectangle [System.Windows.Forms]System.Windows.Forms.Control::get_ClientRectangle()
    IL_0072:  dup
    IL_0073:  stloc.2
    IL_0074:  stloc.s    V_5
    IL_0076:  ldloca.s   V_5
    IL_0078:  call       instance int32 [System.Drawing]System.Drawing.Rectangle::get_Height()
    IL_007d:  box        [mscorlib]System.Int32
    IL_0082:  stelem.ref
    IL_0083:  dup
    IL_0084:  stloc.3
    IL_0085:  ldnull
    IL_0086:  ldnull
    IL_0087:  ldc.i4.4
    IL_0088:  newarr     [mscorlib]System.Boolean
    IL_008d:  dup
    IL_008e:  ldc.i4.2
    IL_008f:  ldc.i4.1
    IL_0090:  stelem.i1
    IL_0091:  dup
    IL_0092:  ldc.i4.3
    IL_0093:  ldc.i4.1
    IL_0094:  stelem.i1
    IL_0095:  dup
    IL_0096:  stloc.s    V_4
    IL_0098:  ldc.i4.1
    IL_0099:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateCall(object,
                                                                                                                       class [mscorlib]System.Type,
                                                                                                                       string,
                                                                                                                       object[],
                                                                                                                       string[],
                                                                                                                       class [mscorlib]System.Type[],
                                                                                                                       bool[],
                                                                                                                       bool)
    IL_009e:  pop
    IL_009f:  ldloc.s    V_4
    IL_00a1:  ldc.i4.2
    IL_00a2:  ldelem.u1
    IL_00a3:  brtrue.s   IL_00a7

    IL_00a5:  br.s       IL_00cb

    IL_00a7:  ldloca.s   V_1
    IL_00a9:  ldloc.3
    IL_00aa:  ldc.i4.2
    IL_00ab:  ldelem.ref
    IL_00ac:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_00b1:  ldtoken    [mscorlib]System.Int32
    IL_00b6:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00bb:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ChangeType(object,
                                                                                                                      class [mscorlib]System.Type)
    IL_00c0:  unbox.any  [mscorlib]System.Int32
    IL_00c5:  call       instance void [System.Drawing]System.Drawing.Rectangle::set_Width(int32)
    IL_00ca:  nop
    IL_00cb:  ldloc.s    V_4
    IL_00cd:  ldc.i4.3
    IL_00ce:  ldelem.u1
    IL_00cf:  brtrue.s   IL_00d3

    IL_00d1:  br.s       IL_00f7

    IL_00d3:  ldloca.s   V_2
    IL_00d5:  ldloc.3
    IL_00d6:  ldc.i4.3
    IL_00d7:  ldelem.ref
    IL_00d8:  call       object [mscorlib]System.Runtime.CompilerServices.RuntimeHelpers::GetObjectValue(object)
    IL_00dd:  ldtoken    [mscorlib]System.Int32
    IL_00e2:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
    IL_00e7:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ChangeType(object,
                                                                                                                      class [mscorlib]System.Type)
    IL_00ec:  unbox.any  [mscorlib]System.Int32
    IL_00f1:  call       instance void [System.Drawing]System.Drawing.Rectangle::set_Height(int32)
    IL_00f6:  nop
    IL_00f7:  nop
    IL_00f8:  nop
    IL_00f9:  ret
  } // end of method Wrapper::UserControl_Resize

  .method private instance void  UserControl_Terminate() cil managed
  {
    // Code size       171 (0xab)
    .maxstack  8
    .locals init (string V_0,
             bool V_1,
             bool V_2,
             class [mscorlib]System.Exception V_3)
    IL_0000:  nop
    IL_0001:  ldarg.0
    IL_0002:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0007:  ldnull
    IL_0008:  cgt.un
    IL_000a:  stloc.1
    IL_000b:  ldloc.1
    IL_000c:  brfalse    IL_00a9

    IL_0011:  ldarg.0
    IL_0012:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0017:  ldnull
    IL_0018:  ldstr      "Name"
    IL_001d:  ldc.i4.0
    IL_001e:  newarr     [mscorlib]System.Object
    IL_0023:  ldnull
    IL_0024:  ldnull
    IL_0025:  ldnull
    IL_0026:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateGet(object,
                                                                                                                      class [mscorlib]System.Type,
                                                                                                                      string,
                                                                                                                      object[],
                                                                                                                      string[],
                                                                                                                      class [mscorlib]System.Type[],
                                                                                                                      bool[])
    IL_002b:  call       string [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Conversions::ToString(object)
    IL_0030:  stloc.0
    IL_0031:  ldloc.0
    IL_0032:  ldstr      ""
    IL_0037:  ldc.i4.0
    IL_0038:  call       int32 [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.Operators::CompareString(string,
                                                                                                                      string,
                                                                                                                      bool)
    IL_003d:  ldc.i4.0
    IL_003e:  ceq
    IL_0040:  stloc.2
    IL_0041:  ldloc.2
    IL_0042:  brfalse.s  IL_004a

    IL_0044:  ldstr      "UserControl"
    IL_0049:  stloc.0
    IL_004a:  nop
    .try
    {
      IL_004b:  nop
      IL_004c:  ldarg.0
      IL_004d:  call       instance class [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection [System.Windows.Forms]System.Windows.Forms.Control::get_Controls()
      IL_0052:  ldloc.0
      IL_0053:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.Control/ControlCollection::RemoveByKey(string)
      IL_0058:  nop
      IL_0059:  leave.s    IL_006a

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_005b:  dup
      IL_005c:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::SetProjectError(class [mscorlib]System.Exception)
      IL_0061:  stloc.3
      IL_0062:  nop
      IL_0063:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.ProjectData::ClearProjectError()
      IL_0068:  leave.s    IL_006a

    }  // end handler
    IL_006a:  nop
    IL_006b:  ldarg.0
    IL_006c:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_0071:  ldnull
    IL_0072:  ldstr      "ControlContext"
    IL_0077:  ldc.i4.1
    IL_0078:  newarr     [mscorlib]System.Object
    IL_007d:  ldnull
    IL_007e:  ldnull
    IL_007f:  call       void [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateSet(object,
                                                                                                                    class [mscorlib]System.Type,
                                                                                                                    string,
                                                                                                                    object[],
                                                                                                                    string[],
                                                                                                                    class [mscorlib]System.Type[])
    IL_0084:  nop
    IL_0085:  ldarg.0
    IL_0086:  ldfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_008b:  ldnull
    IL_008c:  ldstr      "Dispose"
    IL_0091:  ldc.i4.0
    IL_0092:  newarr     [mscorlib]System.Object
    IL_0097:  ldnull
    IL_0098:  ldnull
    IL_0099:  ldnull
    IL_009a:  ldc.i4.1
    IL_009b:  call       object [Microsoft.VisualBasic]Microsoft.VisualBasic.CompilerServices.NewLateBinding::LateCall(object,
                                                                                                                       class [mscorlib]System.Type,
                                                                                                                       string,
                                                                                                                       object[],
                                                                                                                       string[],
                                                                                                                       class [mscorlib]System.Type[],
                                                                                                                       bool[],
                                                                                                                       bool)
    IL_00a0:  pop
    IL_00a1:  ldarg.0
    IL_00a2:  ldnull
    IL_00a3:  stfld      object ACMDotNetWrapper.Wrapper::NETControl
    IL_00a8:  nop
    IL_00a9:  nop
    IL_00aa:  ret
  } // end of method Wrapper::UserControl_Terminate

  .method private specialname instance void 
          '_Lambda$__R0-1'(object a0,
                           class [mscorlib]System.EventArgs a1) cil managed
  {
    .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) 
    .custom instance void [mscorlib]System.Diagnostics.DebuggerHiddenAttribute::.ctor() = ( 01 00 00 00 ) 
    // Code size       7 (0x7)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void ACMDotNetWrapper.Wrapper::UserControl_Terminate()
    IL_0006:  ret
  } // end of method Wrapper::'_Lambda$__R0-1'

  .property instance callconv(8) object ControlContext()
  {
    .get instance object ACMDotNetWrapper.Wrapper::get_ControlContext()
    .set instance void ACMDotNetWrapper.Wrapper::set_ControlContext(object)
  } // end of property Wrapper::ControlContext
  .property instance callconv(8) string DotNetID()
  {
    .get instance string ACMDotNetWrapper.Wrapper::get_DotNetID()
    .set instance void ACMDotNetWrapper.Wrapper::set_DotNetID(string)
  } // end of property Wrapper::DotNetID
  .property instance callconv(8) string ControlName()
  {
    .get instance string ACMDotNetWrapper.Wrapper::get_ControlName()
    .set instance void ACMDotNetWrapper.Wrapper::set_ControlName(string)
  } // end of property Wrapper::ControlName
} // end of class ACMDotNetWrapper.Wrapper


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file orig.ildasm.res
