using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Navigation;
using AspenTech.HtmlHelp.StrongNameInvoke;
using Common;
using Microsoft.Win32;
using P2ConvertCore;
using P2ConvertGUI.Properties;
using P2Objects;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("P2Converter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("P2Converter")]
[assembly: AssemblyCopyright("Copyright © 2024 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("41.0.0.0")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace P2ConvertGUI
{
	[Guid("262321F5-EBBB-4C5F-AC8E-3D7D94990DD6")]
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.None)]
	[ComSourceInterfaces(typeof(IApplicationEvents))]
	public class ApplicationV150 : Window, IApplication, IComponentConnector
	{
		public static readonly DependencyProperty AppTitleProperty = DependencyProperty.Register("AppTitle", typeof(string), typeof(ApplicationV150), new PropertyMetadata("PRO/II Converter"));

		public static readonly DependencyProperty ConvertTypeProperty = DependencyProperty.Register("ConvertType", typeof(ConvertType), typeof(ApplicationV150), new PropertyMetadata(ConvertType.HYSYS));

		private ObservableCollection<P2BaseObject> m_oclObjects = new ObservableCollection<P2BaseObject>();

		private P2BaseObject m_P2Objects;

		private FindDlg dlgFind;

		public string AppTitle
		{
			get
			{
				return (string)GetValue(AppTitleProperty);
			}
			set
			{
				SetValue(AppTitleProperty, value);
			}
		}

		public ConvertType ConvertType
		{
			get
			{
				return (ConvertType)GetValue(ConvertTypeProperty);
			}
			set
			{
				SetValue(ConvertTypeProperty, value);
				SetGUIType(value);
			}
		}

		private void SetGUIType(ConvertType type)
		{
			switch (type)
			{
			case ConvertType.HYSYS:
				cmbType.IsEnabled = false;
				((TabItem)tabOutput.Items[1]).Visibility = Visibility.Collapsed;
				break;
			case ConvertType.AspenPlus:
				cmbType.SelectedIndex = 1;
				cmbType.IsEnabled = false;
				tabOutput.SelectedIndex = 1;
				((TabItem)tabOutput.Items[0]).Visibility = Visibility.Collapsed;
				break;
			case ConvertType.All:
				cmbType.IsEnabled = true;
				((TabItem)tabOutput.Items[0]).Visibility = Visibility.Visible;
				((TabItem)tabOutput.Items[1]).Visibility = Visibility.Visible;
				break;
			}
		}

		public ApplicationV150()
		{
			InitializeComponent();
			InputBinding inputBinding = new InputBinding(ApplicationCommands.Find, new KeyGesture(Key.F, ModifierKeys.Control));
			base.InputBindings.Add(inputBinding);
			CommandBinding commandBinding = new CommandBinding(ApplicationCommands.Find);
			commandBinding.Executed += HandlerFind;
			base.CommandBindings.Add(commandBinding);
			base.KeyDown += BtnHelp_KeyDown;
			base.Loaded += delegate
			{
				dlgFind = new FindDlg();
				dlgFind.Owner = this;
				dlgFind.tvwFind = tvwPro2File;
				hysysOutput.SelectedIndex = 0;
				RegOptions.Load();
			};
		}

		private void HandlerFind(object obSender, ExecutedRoutedEventArgs e)
		{
		}

		private void mainWindow_Loaded(object sender, RoutedEventArgs e)
		{
			SetEOSPanel();
			BaseObject.ApplicationFolder = Path.GetDirectoryName(Process.GetCurrentProcess().MainModule.FileName);
		}

		private void btnOpen_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Forms.OpenFileDialog openFileDialog = new System.Windows.Forms.OpenFileDialog();
			openFileDialog.Multiselect = true;
			openFileDialog.Filter = P2Globalization.GetString("FileFilter");
			if (string.IsNullOrEmpty(ApplicationName.appName))
			{
				ApplicationName.appName = cmbType.Text;
			}
			if (openFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
			{
				DebugPrint.Clear(LeaveParse: false);
				btnRun.IsEnabled = true;
				edtOutputHYSYS.Document.Blocks.Clear();
				edtOutputPlus.Document.Blocks.Clear();
				if (cmbType.SelectedIndex == 0)
				{
					DebugPrint.OutputText = edtOutputHYSYS;
				}
				else
				{
					DebugPrint.OutputText = edtOutputPlus;
				}
				tabOutput.SelectedIndex = cmbType.SelectedIndex;
				IP2ConvertCore iP2ConvertCore = null;
				try
				{
					iP2ConvertCore = Activator.CreateInstance(Type.GetTypeFromProgID("P2ConvertCore.P2ConvertCoreV150", throwOnError: true)) as IP2ConvertCore;
				}
				catch (Exception ex)
				{
					System.Windows.MessageBox.Show(ex.Message);
					return;
				}
				m_P2Objects = iP2ConvertCore.Parse(openFileDialog.FileName, out var visual);
				P2Component p2Component = null;
				foreach (P2BaseObject child in m_P2Objects.Children)
				{
					if (child is P2Component)
					{
						p2Component = child as P2Component;
						break;
					}
				}
				m_oclObjects.Clear();
				m_oclObjects.Add(visual);
				tvwPro2File.ItemsSource = m_oclObjects;
				AppTitle = P2Globalization.GetString("AppTitle") + openFileDialog.FileName;
				iP2ConvertCore = null;
				ExpandAll(tvwPro2File);
				Options.IsEosHYSYSProp = true;
				if (p2Component != null && p2Component.SolidComponentExists && ConvertType != ConvertType.AspenPlus)
				{
					System.Windows.MessageBox.Show("Model includes solid component should be converted to Aspen Plus instead of Aspen HYSYS. Please start \"PROII to Aspen Plus Converter\" application.", P2Globalization.GetString("P2Convert"), MessageBoxButton.OK, MessageBoxImage.Asterisk);
					btnRun.IsEnabled = false;
				}
				else
				{
					dlgFind.CurrentObject = visual;
					tvwPro2File.Focus();
				}
			}
		}

		private void ExpandAll(ItemsControl control)
		{
			if (control == null)
			{
				return;
			}
			foreach (object item in (IEnumerable)control.Items)
			{
				if (control.ItemContainerGenerator.ContainerFromItem(item) is TreeViewItem { HasItems: not false } treeViewItem)
				{
					treeViewItem.IsExpanded = true;
					treeViewItem.UpdateLayout();
					ExpandAll(treeViewItem);
				}
			}
		}

		private void btnRun_Click(object sender, RoutedEventArgs e)
		{
			if (m_oclObjects.Count == 0)
			{
				System.Windows.MessageBox.Show(P2Globalization.GetString("OpenFirst"), AppTitle, MessageBoxButton.OK, MessageBoxImage.Hand);
				return;
			}
			base.Cursor = System.Windows.Input.Cursors.Wait;
			edtOutputHYSYS.Document.Blocks.Clear();
			edtOutputPlus.Document.Blocks.Clear();
			DebugPrint.Clear(LeaveParse: true);
			if (cmbType.SelectedIndex == 0)
			{
				(Activator.CreateInstance(Type.GetTypeFromProgID("P2ConvertCore.P2ConvertCoreV150")) as IP2ConvertCore).ConvertHYSYS2(m_P2Objects);
				SetEOSPanel();
			}
			else
			{
				string text = P2Globalization.GetString("AppTitle");
				Convert2Plus(AppTitle.Substring(text.Length, AppTitle.Length - text.Length), delegate(string filePath)
				{
					PrintErrorMessage(filePath);
				});
			}
			base.Cursor = System.Windows.Input.Cursors.Arrow;
		}

		private void PrintErrorMessage(string filePath)
		{
			try
			{
				edtOutputPlus.Document.Blocks.Clear();
				if (File.Exists(filePath))
				{
					string[] array = File.ReadAllLines(filePath);
					Paragraph paragraph = new Paragraph();
					string[] array2 = array;
					foreach (string text in array2)
					{
						Run run = new Run(text + "\r\n");
						if (text.Contains("*ERROR*"))
						{
							run.Foreground = new SolidColorBrush(Colors.Red);
						}
						else if (text.Contains("*WARNING*"))
						{
							run.Foreground = new SolidColorBrush(Colors.Blue);
						}
						else if (text.Contains("Version:"))
						{
							continue;
						}
						paragraph.Inlines.Add(run);
					}
					edtOutputPlus.Document.Blocks.Add(paragraph);
				}
				else
				{
					edtOutputPlus.AppendText("Conversion Completed.");
				}
			}
			catch
			{
			}
		}

		private void tvwPro2File_MouseDoubleClick(object sender, MouseButtonEventArgs e)
		{
		}

		private void SetEOSPanel()
		{
			if (options == null)
			{
				return;
			}
			if (cmbType.SelectedIndex == 0)
			{
				options.IsEnabled = true;
			}
			else
			{
				options.IsEnabled = false;
			}
		}

		private void cmbType_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			SetEOSPanel();
			if (base.IsInitialized)
			{
				if (((System.Windows.Controls.ComboBox)sender).SelectedIndex == 0)
				{
					ApplicationName.appName = "HYSYS";
				}
				else
				{
					ApplicationName.appName = "Aspen Plus";
				}
			}
		}

		private void options_Click(object sender, RoutedEventArgs e)
		{
			Options obj = new Options();
			bool eosPropStatus = false;
			if (P2BaseObject.g_Map != null && P2BaseObject.g_Map.ContainsKey(Categories.Thermodynamic) && P2BaseObject.g_Map[Categories.Thermodynamic] is P2ThermoDynamic p2ThermoDynamic)
			{
				if (p2ThermoDynamic.IsNeedEnableEOSSelection())
				{
					eosPropStatus = true;
				}
				else
				{
					eosPropStatus = false;
				}
			}
			obj.SetEosPropStatus(eosPropStatus);
			obj.ShowDialog();
			RegOptions.Save();
		}

		private void hysysOutput_SelectionChanged(object sender, SelectionChangedEventArgs e)
		{
			switch (((System.Windows.Controls.ComboBox)sender).SelectedIndex)
			{
			case 0:
				DebugPrint.ShowLevel = ShowWarningLevel.All;
				break;
			case 1:
				DebugPrint.ShowLevel = ShowWarningLevel.Notes;
				break;
			case 2:
				DebugPrint.ShowLevel = ShowWarningLevel.Warning;
				break;
			case 3:
				DebugPrint.ShowLevel = ShowWarningLevel.Error;
				break;
			}
			DebugPrint.Refresh();
		}

		private Window aplusHelpWin;

		private HtmlHelpStrongNameInvoker htmlHelpMain;

		private string htmlHelpSelfExtractor = string.Empty;

		private string uriHtmlHelpSite = string.Empty;

		private bool ConvertVersionNumberToDouble(string version, out double result)
		{
			if (string.IsNullOrEmpty(version))
			{
				result = 12.0;
				return true;
			}
			if (Regex.IsMatch(version, "^[V,v]{1}[0-9]{1,2}\\.[0-9]"))
			{
				double.TryParse(version.Substring(1), out result);
				return true;
			}
			result = 0.0;
			return false;
		}

		private void btnHelp_Click(object sender, RoutedEventArgs e)
		{
			RegistryKey rootKey = RetrieveKey();
			if (ApplicationName.appName == "Aspen Plus")
			{
				showWebHelpForAspenPlus(rootKey);
				return;
			}
			if (!ConvertVersionNumberToDouble(HYSYSVersionNumber.versionNumber, out var result))
			{
				return;
			}
			if (result >= 11.0)
			{
				if (htmlHelpMain == null)
				{
					InitializeHtmlHelpComponent(rootKey);
				}
				ShowHelpPage();
				return;
			}
			try
			{
				Process process = new Process();
				process.StartInfo.FileName = string.Format("{0}\\HYSYS PROII Converter_V1.5.pdf", Environment.CurrentDirectory);
				process.Start();
			}
			catch (Exception)
			{
				System.Windows.MessageBox.Show(P2Globalization.GetString("PDFNotInstalled"), AppTitle, MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}

		private RegistryKey RetrieveKey()
		{
			return RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, Environment.Is64BitOperatingSystem ? RegistryView.Registry64 : RegistryView.Registry32);
		}

		private void showWebHelpForAspenPlus(RegistryKey rootKey)
		{
			RegistryKey registryKey = rootKey.OpenSubKey("Software\\AspenTech\\Aspen Plus\\" + HYSYSVersionNumber.InternalVersion + "\\mm");
			if (registryKey == null)
			{
				registryKey = rootKey.OpenSubKey("Software\\Wow6432Node\\AspenTech\\Aspen Plus\\" + HYSYSVersionNumber.InternalVersion + "\\mm");
			}
			string uriString = string.Empty;
			if (registryKey != null)
			{
				List<string> list = new List<string>();
				list.AddRange(registryKey.GetValueNames());
				if (list.Contains("HtmlHelpRoot"))
				{
					uriString = registryKey.GetValue("HtmlHelpRoot").ToString();
					uriString = uriString.Replace("apwn.htm", "Subsystems/userguide1/Content/html/converting_pro_ii_input_keyword_files.htm");
				}
				registryKey.Close();
			}
			System.Windows.Controls.WebBrowser webBrowser = new System.Windows.Controls.WebBrowser();
			Uri uri = new Uri(uriString);
			webBrowser.Navigating += wb_Navigating;
			if (!string.IsNullOrEmpty(uri.LocalPath) && File.Exists(uri.LocalPath))
			{
				webBrowser.Navigate(uri);
				if (aplusHelpWin == null)
				{
					aplusHelpWin = new Window();
					aplusHelpWin.Closed += aplusHelpWin_Closed;
					aplusHelpWin.Owner = this;
					aplusHelpWin.Title = "PRO/II Converter";
					aplusHelpWin.Content = webBrowser;
				}
				aplusHelpWin.Show();
			}
		}

		private void wb_Navigating(object sender, NavigatingCancelEventArgs e)
		{
			InvokeWebBrowserSilentToSuppressScriptError(sender as System.Windows.Controls.WebBrowser, setSilent: true);
		}

		private void aplusHelpWin_Closed(object sender, EventArgs e)
		{
			aplusHelpWin = null;
		}

		private void InvokeWebBrowserSilentToSuppressScriptError(System.Windows.Controls.WebBrowser wb, bool setSilent)
		{
			FieldInfo field = typeof(System.Windows.Controls.WebBrowser).GetField("_axIWebBrowser2", BindingFlags.Instance | BindingFlags.NonPublic);
			if (field == null)
			{
				return;
			}
			object value = field.GetValue(wb);
			if (value == null)
			{
				return;
			}
			value.GetType().InvokeMember("Silent", BindingFlags.SetProperty, null, value, new object[1] { setSilent });
		}

		private void InitializeHtmlHelpComponent(RegistryKey rootKey)
		{
			if (htmlHelpMain == null)
			{
				htmlHelpMain = new HtmlHelpStrongNameInvoker();
				string htmlHelpPath = GetHtmlHelpPath(rootKey);
				if (!string.IsNullOrEmpty(htmlHelpPath))
				{
					uriHtmlHelpSite = htmlHelpPath;
					htmlHelpSelfExtractor = GetHtmlHelpExtractor(rootKey);
					htmlHelpMain.HtmlHelpInitWrap("PROII Converter", HYSYSVersionNumber.versionNumber, HYSYSVersionNumber.InternalVersion, htmlHelpPath, "PROII Converter", htmlHelpSelfExtractor, bNoSelfExtract: false);
				}
			}
		}

		private static string GetHtmlHelpPath(RegistryKey rootKey)
		{
			string name = "SOFTWARE\\AspenTech\\PROII Converter\\" + HYSYSVersionNumber.InternalVersion;
			RegistryKey registryKey = rootKey.OpenSubKey(name, writable: false);
			if (registryKey == null)
			{
				return null;
			}
			string result = null;
			try
			{
				object value = registryKey.GetValue("HtmlHelpRoot");
				if (value != null)
				{
					result = value.ToString();
				}
			}
			catch (Exception)
			{
			}
			registryKey.Close();
			return result;
		}

		private static string GetHtmlHelpExtractor(RegistryKey rootKey)
		{
			string name = "SOFTWARE\\AspenTech\\PROII Converter\\" + HYSYSVersionNumber.InternalVersion;
			RegistryKey registryKey = rootKey.OpenSubKey(name, writable: false);
			if (registryKey == null)
			{
				return null;
			}
			string result = null;
			try
			{
				object value = registryKey.GetValue("HtmlHelpExtractor");
				if (value != null)
				{
					result = value.ToString();
				}
			}
			catch (Exception)
			{
			}
			registryKey.Close();
			return result;
		}

		private void BtnHelp_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
		{
			if (e.Key == Key.F1)
			{
				btnHelp_Click(sender, null);
			}
		}

		private void ShowHelpPage()
		{
			string strHelpTopicUrl = uriHtmlHelpSite + "#cshid=0";
			htmlHelpMain.HtmlHelpDisplayTopicWrap(strHelpTopicUrl);
		}

		private void Convert2Plus(string filePath, Action<string> printErrorCallback)
		{
			(Activator.CreateInstance(Type.GetTypeFromProgID("P2ConvertCore.P2ConvertCoreV150")) as IP2ConvertCore).ConvertPlus(filePath, bSilence: false, printErrorCallback);
		}

		private void DisposePlusHapp()
		{
			(Activator.CreateInstance(Type.GetTypeFromProgID("P2ConvertCore.P2ConvertCoreV150")) as IP2ConvertCore).DisposePlusHapp();
		}

		[DllImport("user32.dll")]
		public static extern bool FlashWindow(IntPtr hWnd, bool bInvert);

		public string Version => "8.0.0.0";

		public event OnCloseDel OnClose;

		public bool Init(ConvertType type)
		{
			ConvertType = type;
			Show();
			return true;
		}

		private void mainWindow_Closing(object sender, CancelEventArgs e)
		{
			if (htmlHelpMain != null)
			{
				htmlHelpMain.HtmlHelpCloseWrap();
				htmlHelpMain = null;
			}
			if (this.OnClose != null)
			{
				this.OnClose();
			}
			if (cmbType.SelectedIndex == 1)
			{
				DisposePlusHapp();
			}
		}

		public void Uninit()
		{
		}

		public bool InitFromFile(string strFilePath, ConvertType type)
		{
			return true;
		}

		internal ApplicationV150 mainWindow;

		internal System.Windows.Controls.ComboBox cmbType;

		internal System.Windows.Controls.Button options;

		internal System.Windows.Controls.Button btnRun;

		internal System.Windows.Controls.Button btnHelp;

		internal System.Windows.Controls.TreeView tvwPro2File;

		internal GridSplitter gridSplitter;

		internal System.Windows.Controls.TabControl tabOutput;

		internal System.Windows.Controls.ComboBox hysysOutput;

		internal System.Windows.Controls.RichTextBox edtOutputHYSYS;

		internal System.Windows.Controls.RichTextBox edtOutputPlus;

		private bool _contentLoaded;

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/P2ConvertGUI;component/application.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				mainWindow = (ApplicationV150)target;
				mainWindow.Loaded += mainWindow_Loaded;
				mainWindow.Closing += mainWindow_Closing;
				break;
			case 2:
				((System.Windows.Controls.Button)target).Click += btnOpen_Click;
				break;
			case 3:
				cmbType = (System.Windows.Controls.ComboBox)target;
				cmbType.SelectionChanged += cmbType_SelectionChanged;
				break;
			case 4:
				options = (System.Windows.Controls.Button)target;
				options.Click += options_Click;
				break;
			case 5:
				btnRun = (System.Windows.Controls.Button)target;
				btnRun.Click += btnRun_Click;
				break;
			case 6:
				btnHelp = (System.Windows.Controls.Button)target;
				btnHelp.Click += btnHelp_Click;
				break;
			case 7:
				tvwPro2File = (System.Windows.Controls.TreeView)target;
				tvwPro2File.MouseDoubleClick += tvwPro2File_MouseDoubleClick;
				break;
			case 8:
				gridSplitter = (GridSplitter)target;
				break;
			case 9:
				tabOutput = (System.Windows.Controls.TabControl)target;
				break;
			case 10:
				hysysOutput = (System.Windows.Controls.ComboBox)target;
				hysysOutput.SelectionChanged += hysysOutput_SelectionChanged;
				break;
			case 11:
				edtOutputHYSYS = (System.Windows.Controls.RichTextBox)target;
				break;
			case 12:
				edtOutputPlus = (System.Windows.Controls.RichTextBox)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public enum ConvertType
	{
		HYSYS,
		AspenPlus,
		All
	}
	[Guid("3D6354F3-6ED7-44c8-B9FA-E55D2F15DFD9")]
	[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface IApplication
	{
		[DispId(0)]
		string Version { get; }

		[DispId(1)]
		bool Init(ConvertType type);

		[DispId(2)]
		void Uninit();

		[DispId(3)]
		bool InitFromFile(string strFilePath, ConvertType type);
	}
	[Guid("C0D0FE70-B1F3-4fc5-88C1-B4CD533CD5B6")]
	[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
	public interface IApplicationEvents
	{
		[DispId(4)]
		void OnClose();
	}
	public delegate void OnCloseDel();
	public class FindDlg : Window, IComponentConnector
	{
		public System.Windows.Controls.TreeView tvwFind;

		public P2BaseObject CurrentObject;

		internal System.Windows.Controls.TextBox txtFind;

		private bool _contentLoaded;

		public FindDlg()
		{
			InitializeComponent();
		}

		private void Button_Click(object sender, RoutedEventArgs e)
		{
			if (FindItem2Select(tvwFind, txtFind.Text))
			{
				base.Owner.Activate();
				tvwFind.Focus();
			}
		}

		private bool FindItem2Select(ItemsControl ctrl, string str)
		{
			foreach (object item in (IEnumerable)ctrl.Items)
			{
				P2BaseObject p2BaseObject = item as P2BaseObject;
				TreeViewItem treeViewItem = (TreeViewItem)ctrl.ItemContainerGenerator.ContainerFromItem(p2BaseObject);
				if (p2BaseObject.Name.ToUpper().IndexOf(str.ToUpper()) == -1)
				{
					if (treeViewItem != null && treeViewItem.HasItems && FindItem2Select(treeViewItem, str))
					{
						return true;
					}
					continue;
				}
				treeViewItem.IsSelected = true;
				return true;
			}
			return false;
		}

		private void Window_Activated(object sender, EventArgs e)
		{
			txtFind.Focus();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/P2ConvertGUI;component/finddlg.xaml", UriKind.Relative);
			System.Windows.Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((FindDlg)target).Activated += Window_Activated;
				break;
			case 2:
				txtFind = (System.Windows.Controls.TextBox)target;
				break;
			case 3:
				((System.Windows.Controls.Button)target).Click += Button_Click;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
	public static class RegOptions
	{
		static RegOptions()
		{
		}

		public static void Save()
		{
			Settings.Default.IsEosHYSYSProp = Options.IsEosHYSYSProp;
			Settings.Default.IsHYSYSAirCooler = Options.IsHYSYSAirCooler;
			Settings.Default.IsHYSYSHeaterExchanger = Options.IsHYSYSHeaterExchanger;
			Settings.Default.IsBalanceStreamRef = Options.IsBalanceStreamRef;
			Settings.Default.IgnoreSolvingColumn = Options.IgnoreSolvingColumn;
			Settings.Default.Save();
		}

		public static void Load()
		{
			Options.IsEosHYSYSProp = Settings.Default.IsEosHYSYSProp;
			Options.IsHYSYSAirCooler = Settings.Default.IsHYSYSAirCooler;
			Options.IsHYSYSHeaterExchanger = Settings.Default.IsHYSYSHeaterExchanger;
			Options.IsBalanceStreamRef = Settings.Default.IsBalanceStreamRef;
			Options.IgnoreSolvingColumn = Settings.Default.IgnoreSolvingColumn;
		}
	}
}
namespace P2ConvertGUI.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("P2ConvertGUI.Properties.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal Resources()
		{
		}
	}
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool IsEosHYSYSProp
		{
			get
			{
				return (bool)this["IsEosHYSYSProp"];
			}
			set
			{
				this["IsEosHYSYSProp"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool IsBalanceStreamRef
		{
			get
			{
				return (bool)this["IsBalanceStreamRef"];
			}
			set
			{
				this["IsBalanceStreamRef"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool IsHYSYSAirCooler
		{
			get
			{
				return (bool)this["IsHYSYSAirCooler"];
			}
			set
			{
				this["IsHYSYSAirCooler"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("True")]
		public bool IsHYSYSHeaterExchanger
		{
			get
			{
				return (bool)this["IsHYSYSHeaterExchanger"];
			}
			set
			{
				this["IsHYSYSHeaterExchanger"] = value;
			}
		}

		[UserScopedSetting]
		[DebuggerNonUserCode]
		[DefaultSettingValue("False")]
		public bool IgnoreSolvingColumn
		{
			get
			{
				return (bool)this["IgnoreSolvingColumn"];
			}
			set
			{
				this["IgnoreSolvingColumn"] = value;
			}
		}
	}
}
