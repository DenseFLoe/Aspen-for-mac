using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using System.Threading;
using AspenTech.AspenPlus.Happ;
using Microsoft.VisualBasic;
using Microsoft.Win32;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("P2Converter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("P2Converter")]
[assembly: AssemblyCopyright("Copyright © 2024 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("41.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("062d9f08-92a6-4694-802e-3fd63f963438")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace AspenHelper;

public class AspenHelper : IDisposable
{
	private IHapp App;

	public AspenHelper(string strFilePath)
	{
		App = Interaction.CreateObject("Apwn.Document." + GetCurrentVersion()) as IHapp;
		App.InitFromFile(ref strFilePath, true);
		App.Visible = true;
	}

	private static string GetCurrentVersion()
	{
		RegistryKey registryKey = Registry.LocalMachine.OpenSubKey("Software\\Aspentech\\Aspen Plus\\CurVer");
		if (registryKey != null)
		{
			return registryKey.GetValue(string.Empty).ToString();
		}
		return string.Empty;
	}

	public void Dispose()
	{
		if (App != null)
		{
			App.Close(0);
			Marshal.FinalReleaseComObject(App);
			App = null;
			Thread.Sleep(2000);
		}
	}

	~AspenHelper()
	{
	}

	public void Save(string strFileName)
	{
		if (App != null)
		{
			App.SaveAs(ref strFileName, true);
		}
	}

	public static string GetConvertFilePath()
	{
		return Registry.LocalMachine.OpenSubKey("Software\\Aspentech\\Aspen Plus\\" + GetCurrentVersion() + "\\aplus").GetValue("asptop").ToString() + "\\Xeq\\atp3.exe";
	}

	public static string CheckStreamName(string strFilePath)
	{
		FileStream fileStream = new FileStream(strFilePath, FileMode.Open, FileAccess.Read);
		StreamReader streamReader = new StreamReader(fileStream);
		string str = streamReader.ReadToEnd();
		streamReader.Close();
		fileStream.Close();
		int num = str.IndexOf("UNIT OPERATIONS");
		if (num > 0)
		{
			int nIndex = 0;
			while (true)
			{
				string streamName = GetStreamName(ref str, ref nIndex);
				if (string.IsNullOrEmpty(streamName) || nIndex > num)
				{
					break;
				}
				if (streamName.IndexOf('.') > 0)
				{
					return streamName;
				}
			}
		}
		return "";
	}

	private static string GetStreamName(ref string str, ref int nIndex)
	{
		if (nIndex == 0)
		{
			nIndex = str.IndexOf("STREAM DATA");
			if (nIndex < 0)
			{
				return "";
			}
		}
		int num = 0;
		while (num >= 0)
		{
			num = str.IndexOf("STREAM", nIndex);
			if (num <= 0)
			{
				continue;
			}
			if (str[num - 1] == 'F')
			{
				num += 6;
				continue;
			}
			num = str.IndexOf('=', num + 6);
			if (num > 0)
			{
				int num2 = str.IndexOf(',', num + 1);
				if (num2 < 0)
				{
					num2 = str.IndexOf('\r', num + 1);
				}
				if (num2 > 0)
				{
					string text = str.Substring(num + 1, num2 - num - 1);
					nIndex = num2;
					return text.Trim();
				}
			}
		}
		return "";
	}

	public static bool CutBlockName(string strFilePath, string strNewFilePath)
	{
		FileStream fileStream = new FileStream(strFilePath, FileMode.Open, FileAccess.Read);
		StreamReader streamReader = new StreamReader(fileStream, Encoding.Default);
		string str = streamReader.ReadToEnd();
		streamReader.Close();
		fileStream.Close();
		int num = 0;
		List<string> blocks = new List<string>();
		do
		{
			num = FindBlockName(ref str, num, ref blocks);
		}
		while (num != -1);
		int nIndex = 0;
		List<string> list = new List<string>();
		foreach (string item in blocks)
		{
			list.Add(ConvertBlockName(item, ref nIndex));
		}
		for (int i = 0; i < blocks.Count; i++)
		{
			if (blocks[i] != list[i])
			{
				str = str.Replace(blocks[i], list[i]);
			}
		}
		FileStream fileStream2 = new FileStream(strNewFilePath, FileMode.Create);
		StreamWriter streamWriter = new StreamWriter(fileStream2);
		streamWriter.Write(str);
		streamWriter.Close();
		fileStream2.Close();
		return true;
	}

	private static string ConvertBlockName(string strName, ref int nIndex)
	{
		int num = nIndex.ToString().Length + 1;
		if (num >= 3)
		{
			return nIndex.ToString();
		}
		string result = string.Format("{0}_{1}", strName.Substring(0, 4 - num), nIndex.ToString());
		nIndex++;
		return result;
	}

	private static int FindBlockName(ref string str, int nIndex, ref List<string> blocks)
	{
		int num = str.IndexOf("LNGHX", nIndex);
		if (num > 0)
		{
			num = str.IndexOf("UID", num + 5);
			if (num > 0)
			{
				num = str.IndexOf('=', num + 3);
				if (num > 0)
				{
					int num2 = str.IndexOf(',', num + 1);
					if (num2 == -1)
					{
						num2 = str.IndexOf('\r', num + 1);
					}
					if (num2 != -1)
					{
						string text = str.Substring(num + 1, num2 - num - 1);
						blocks.Add(text.Trim());
						return num;
					}
				}
			}
		}
		return -1;
	}
}
public class SingleAspenPlusDataInstance
{
	private static SingleAspenPlusDataInstance _instance;

	public List<AspenHelper> AspenHelpers { get; set; } = new List<AspenHelper>();

	public Dictionary<string, int> OpenedAspenPlusProcessInfoDic { get; set; } = new Dictionary<string, int>();

	private SingleAspenPlusDataInstance()
	{
	}

	public static SingleAspenPlusDataInstance Instance
	{
		get
		{
			if (_instance == null)
			{
				_instance = new SingleAspenPlusDataInstance();
			}
			return _instance;
		}
	}

}
