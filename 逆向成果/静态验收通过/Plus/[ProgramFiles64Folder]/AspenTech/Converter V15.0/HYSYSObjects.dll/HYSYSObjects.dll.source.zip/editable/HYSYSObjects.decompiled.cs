using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Aspentech.HYSYS;
using Common;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("P2Converter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("P2Converter")]
[assembly: AssemblyCopyright("Copyright © 2024 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("41.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("87426b92-fb43-4d4b-9746-5771d23365db")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace HYSYSObjects;

public class HYSYSAirCooler : HYSYSUnitOperationBase
{
	public bool IsCoCurrent { get; set; }

	public int TubeNumber { get; set; }

	public int TubePassNumber { get; set; }

	public bool IsInlineBundle { get; set; }

	public int TubeRowNumber { get; set; }

	public string TubeMaterial { get; set; }

	public int BayNumberPerUnit { get; set; }

	public int BundleNumberPerBay { get; set; }

	public string FinMaterial { get; set; }

	public bool IsFanForced { get; set; }

	public DoubleValue TubeLength { get; set; }

	public DoubleValue TubeID { get; set; }

	public DoubleValue TubeOD { get; set; }

	public DoubleValue TubeThickness { get; set; }

	public DoubleValue TransPitch { get; set; }

	public DoubleValue LongPitch { get; set; }

	public DoubleValue TubeTCond { get; set; }

	public DoubleValue TubeFoul { get; set; }

	public DoubleValue FinThickness { get; set; }

	public DoubleValue FinTCond { get; set; }

	public DoubleValue AirFouling { get; set; }

	public DoubleValue FanDiameter { get; set; }

	public double FanEfficiency { get; set; }

	public DoubleValue NozInID { get; set; }

	public DoubleValue NozOutID { get; set; }

	public int FanNumber { get; set; }

	public DoubleValue TTempSpec { get; set; }

	public DoubleValue ATempSpec { get; set; }

	public DoubleValue HOCISpec { get; set; }

	public DoubleValue COCISpec { get; set; }

	public DoubleValue HIHOSpec { get; set; }

	public DoubleValue HICOSpec { get; set; }

	public DoubleValue TLFracSpec { get; set; }

	public DoubleValue DP { get; set; }

	public DoubleValue MAXDP { get; set; }

	public DoubleValue MINDP { get; set; }

	public ArrayList TubeConfiguration { get; set; }

	public List<string> TubeSideInletStreams { get; set; }

	public List<string> TubeSideOutletStreams { get; set; }

	public List<string> AirSideInletStreams { get; set; }

	public List<string> TobeDeletedStreams { get; set; }

	public HYSYSAirCooler()
	{
		TubeSideInletStreams = new List<string>();
		TubeSideOutletStreams = new List<string>();
		AirSideInletStreams = new List<string>();
		TobeDeletedStreams = new List<string>();
		TubeConfiguration = new ArrayList();
		TubeConfiguration.Add("1-1");
		TubeConfiguration.Add("2-1");
		TubeConfiguration.Add("3-1");
		TubeConfiguration.Add("4-1");
		TubeConfiguration.Add("2-2");
		TubeConfiguration.Add("3-3");
		TubeConfiguration.Add("4-2");
		TubeConfiguration.Add("4-4");
	}
}
public class HYSYSBaseObject : BaseObject
{
	public static IDictionary<string, HYSYSBaseObject> g_Map { get; set; }

	public static IDictionary<string, IList<string>> g_mapSpec { get; set; }

	public static IDictionary<string, IList<string>> g_mapDefine { get; set; }

	public HYSYSBaseObject()
	{
		Init();
		if (BaseObject._Report != null)
		{
			Report report = BaseObject._Report;
			int hYSYSObjectCount = report.HYSYSObjectCount + 1;
			report.HYSYSObjectCount = hYSYSObjectCount;
		}
	}

	public static void Init()
	{
		if (g_Map == null)
		{
			g_Map = new Dictionary<string, HYSYSBaseObject>();
		}
		if (g_mapSpec == null)
		{
			g_mapSpec = new Dictionary<string, IList<string>>();
		}
		if (g_mapDefine == null)
		{
			g_mapDefine = new Dictionary<string, IList<string>>();
		}
	}
}
public class HYSYSColumn : HYSYSUnitOperationBase
{
	public string IDENTIFICATION { get; set; }

	public List<HYSYSColumn> SIDESTRIPPERS { get; set; }

	public List<HYSYSColumn> SIDERECTIFIERS { get; set; }

	public SolveMethodTypeEnum SolvingMethod { get; set; }

	public ColumnPhaseEnum PhaseType { get; set; }

	public int MaxInterationNumber { get; set; }

	public int stageNumber { get; set; }

	public DoubleValue fixingDampFactor { get; set; }

	public Dictionary<string, int> ColumnFeeds { get; set; }

	public bool bFlashFeed { get; set; }

	public Dictionary<string, Dictionary<int, TypeUnitValue>> ColumnProducts { get; set; }

	public bool bDrawWaterFromCondenser { get; set; }

	public Dictionary<string, int> ExportNetVaporFlow { get; set; }

	public Dictionary<string, int> ExportNetLiquidFlow { get; set; }

	public Dictionary<string, int> ExportTotalVaporFlow { get; set; }

	public Dictionary<string, int> ExportTotalLiquidFlow { get; set; }

	public Dictionary<string, RangeValue> ExportPumpAroundVaporFlow { get; set; }

	public Dictionary<string, RangeValue> ExportPumpAroundLiquidFlow { get; set; }

	public string ExportFeedToReboiler { get; set; }

	public string ExportLiquidFromReboiler { get; set; }

	public string ExportVaporFromReboiler { get; set; }

	public bool bCondenserExist { get; set; }

	public HYSYSCondenserTypeEnum CondenserType { get; set; }

	public DoubleValue CondenserPressure { get; set; }

	public DoubleValue CondenserTemperature { get; set; }

	public DoubleValue CondenserSubcoolDT { get; set; }

	public DoubleValue CondenserEstimateTemp { get; set; }

	public Dictionary<int, Dictionary<int, TypeUnitValue>> DutySpec { get; set; }

	public Dictionary<int, Dictionary<int, TypeUnitValue>> HeatLossGainSpec { get; set; }

	public SortedList<int, int> DutyNO { get; set; }

	public bool bReboilerExist { get; set; }

	public HYSYSReboilerTypeEnum ReboilerType { get; set; }

	public TypeUnitValue ReboilerCirculationRate { get; set; }

	public TypeUnitValue ReboilerReturnStreamLiquidFrac { get; set; }

	public TypeUnitValue ReboilerReturnStreamVaporFrac { get; set; }

	public DoubleValue ReboilerTemperature { get; set; }

	public DoubleValue ReboilerTemperatureRise { get; set; }

	public TypeUnitValue ReboilerLiqProdToReboilerFeedRatioEstimate { get; set; }

	public TypeUnitValue ReboilerVapProdToTeboilerFeedRatioEstimate { get; set; }

	public TypeUnitValue ReboilerMolarFeedFlowrateEstimate { get; set; }

	public List<PumpAround> PA { get; set; }

	public SortedDictionary<int, DoubleValue> PressureProfile { get; set; }

	public DoubleValue ColumnPressureDrop { get; set; }

	public DoubleValue CondenserPressureDrop { get; set; }

	public DoubleValue ReboilerPressureDrop { get; set; }

	public DoubleValue ColumnTopPressure { get; set; }

	public DoubleValue ColumnBottomPressure { get; set; }

	public bool CheckProgramGenerateEstimates { get; set; }

	public Dictionary<int, DoubleValue> TempProfileEstimate { get; set; }

	public Dictionary<int, TypeUnitValue> VaporFlowProfileEstimate { get; set; }

	public Dictionary<int, TypeUnitValue> LiquidFlowProfileEstimate { get; set; }

	public Dictionary<int, Dictionary<int, double>> LiqPhaseCompositionProfileEstimate { get; set; }

	public Dictionary<int, Dictionary<int, double>> L1PhaseCompositionProfileEstimate { get; set; }

	public Dictionary<int, Dictionary<int, double>> L2PhaseCompositionProfileEstimate { get; set; }

	public Dictionary<int, Dictionary<int, double>> VapPhaseCompositionProfileEstimate { get; set; }

	public List<string> VaryDutyIDs { get; set; }

	public List<string> VaryDutyNames { get; set; }

	public List<string> VaryDrawStreamIDs { get; set; }

	public List<string> VaryFeedStreamIDs { get; set; }

	public double EquilTolerance { get; set; }

	public double HeatSpecTolerance { get; set; }

	public List<string> HYSYSMainFlowsheetFeeds { get; set; }

	public List<string> HYSYSMainFlowsheetProducts { get; set; }

	public bool bVLLECheckOn { get; set; }

	public int VLLECheckTrays { get; set; }

	public string VLLECheckSet { get; set; }

	public TypeUnitValue EstRRatio { get; set; }

	public TypeUnitValue EstReflux { get; set; }

	public bool bRROrRefluxEstExist { get; set; }

	public Dictionary<int, int> DutyHCurvePlotPoints { get; set; }

	public Dictionary<string, List<DoubleValue>> HCurvePressureColl { get; set; }

	public Dictionary<string, int> HCurvePoints { get; set; }

	public Dictionary<string, int> HCurveDutyNO { get; set; }

	public List<ColumnTray> colTrays { get; set; }

	public List<columnPack> colPacks { get; set; }

	public Dictionary<string, BackDoor> paColl = new Dictionary<string, BackDoor>();

	public Condenser conderser;

	public Reboiler reboiler;

	public Dictionary<string, ProcessStream> QStreamForDuty = new Dictionary<string, ProcessStream>();

	public HYSYSColumn()
	{
		SIDESTRIPPERS = new List<HYSYSColumn>();
		SIDERECTIFIERS = new List<HYSYSColumn>();
		ColumnFeeds = new Dictionary<string, int>();
		ColumnProducts = new Dictionary<string, Dictionary<int, TypeUnitValue>>();
		DutySpec = new Dictionary<int, Dictionary<int, TypeUnitValue>>();
		HeatLossGainSpec = new Dictionary<int, Dictionary<int, TypeUnitValue>>();
		DutyNO = new SortedList<int, int>();
		PA = new List<PumpAround>();
		PressureProfile = new SortedDictionary<int, DoubleValue>();
		TempProfileEstimate = new Dictionary<int, DoubleValue>();
		VaporFlowProfileEstimate = new Dictionary<int, TypeUnitValue>();
		LiquidFlowProfileEstimate = new Dictionary<int, TypeUnitValue>();
		LiqPhaseCompositionProfileEstimate = new Dictionary<int, Dictionary<int, double>>();
		L1PhaseCompositionProfileEstimate = new Dictionary<int, Dictionary<int, double>>();
		L2PhaseCompositionProfileEstimate = new Dictionary<int, Dictionary<int, double>>();
		VapPhaseCompositionProfileEstimate = new Dictionary<int, Dictionary<int, double>>();
		VaryDutyIDs = new List<string>();
		VaryDutyNames = new List<string>();
		VaryDrawStreamIDs = new List<string>();
		VaryFeedStreamIDs = new List<string>();
		HYSYSMainFlowsheetFeeds = new List<string>();
		HYSYSMainFlowsheetProducts = new List<string>();
		ExportNetVaporFlow = new Dictionary<string, int>();
		ExportNetLiquidFlow = new Dictionary<string, int>();
		ExportTotalLiquidFlow = new Dictionary<string, int>();
		ExportTotalVaporFlow = new Dictionary<string, int>();
		ExportPumpAroundVaporFlow = new Dictionary<string, RangeValue>();
		ExportPumpAroundLiquidFlow = new Dictionary<string, RangeValue>();
		DutyHCurvePlotPoints = new Dictionary<int, int>();
		HCurvePressureColl = new Dictionary<string, List<DoubleValue>>();
		HCurvePoints = new Dictionary<string, int>();
		HCurveDutyNO = new Dictionary<string, int>();
		colTrays = new List<ColumnTray>();
		colPacks = new List<columnPack>();
	}

	public int getDutyNO()
	{
		int num = 0;
		if (DutyNO.Count == 0)
			num = 1;
		else
			num = DutyNO.Keys[DutyNO.Count - 1] + 1;
		DutyNO.Add(num, num);
		return num;
	}

	public void PickupColumnMainFeedsAndProducts(IList<HYSYSStream> stmColl)
	{
		foreach (string outletStream in base.OutletStreams)
		{
			bool flag = true;
			foreach (HYSYSColumn sIDESTRIPPER in SIDESTRIPPERS)
			{
				if (sIDESTRIPPER.InletStreams.Contains(outletStream))
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				foreach (HYSYSColumn sIDERECTIFIER in SIDERECTIFIERS)
				{
					if (sIDERECTIFIER.InletStreams.Contains(outletStream))
					{
						flag = false;
						break;
					}
				}
			}
			if (flag)
			{
				HYSYSMainFlowsheetProducts.Add(outletStream);
			}
		}
		foreach (string inletStream in base.InletStreams)
		{
			bool flag2 = true;
			foreach (HYSYSColumn sIDESTRIPPER2 in SIDESTRIPPERS)
			{
				if (sIDESTRIPPER2.OutletStreams.Contains(inletStream))
				{
					flag2 = false;
					break;
				}
			}
			if (flag2)
			{
				foreach (HYSYSColumn sideRectifier in SIDERECTIFIERS)
				{
					flag2 = false;
					break;
				}
			}
			if (flag2)
			{
				HYSYSMainFlowsheetFeeds.Add(inletStream);
			}
		}
		changeStmInfoOfSubCols(stmColl);
	}

	private void changeStmInfoOfSubCols(IList<HYSYSStream> stmColl)
	{
		foreach (HYSYSColumn sIDESTRIPPER in SIDESTRIPPERS)
		{
			foreach (string outletStream in sIDESTRIPPER.OutletStreams)
			{
				if (base.InletStreams.Contains(outletStream))
				{
					continue;
				}
				if (!HYSYSMainFlowsheetProducts.Contains(outletStream))
				{
					HYSYSMainFlowsheetProducts.Add(outletStream);
				}
				foreach (HYSYSStream item in stmColl)
				{
					if (item.Stream == outletStream && item.Source.UID == sIDESTRIPPER.UID)
					{
						item.Source = this;
						break;
					}
				}
			}
			foreach (string inletStream in sIDESTRIPPER.InletStreams)
			{
				if (base.OutletStreams.Contains(inletStream))
				{
					continue;
				}
				if (!HYSYSMainFlowsheetFeeds.Contains(inletStream))
				{
					HYSYSMainFlowsheetFeeds.Add(inletStream);
				}
				foreach (HYSYSStream item2 in stmColl)
				{
					if (item2.Stream == inletStream && item2.Destination.UID == sIDESTRIPPER.UID)
					{
						item2.Destination = this;
						break;
					}
				}
			}
		}
		foreach (HYSYSColumn sIDERECTIFIER in SIDERECTIFIERS)
		{
			foreach (string outletStream2 in sIDERECTIFIER.OutletStreams)
			{
				if (base.InletStreams.Contains(outletStream2))
				{
					continue;
				}
				if (!HYSYSMainFlowsheetProducts.Contains(outletStream2))
				{
					HYSYSMainFlowsheetProducts.Add(outletStream2);
				}
				foreach (HYSYSStream item3 in stmColl)
				{
					if (item3.Stream == outletStream2 && item3.Source.UID == sIDERECTIFIER.UID)
					{
						item3.Source = this;
						break;
					}
				}
			}
			foreach (string inletStream2 in sIDERECTIFIER.InletStreams)
			{
				if (base.OutletStreams.Contains(inletStream2))
				{
					continue;
				}
				foreach (HYSYSStream item4 in stmColl)
				{
					if (!HYSYSMainFlowsheetFeeds.Contains(inletStream2))
					{
						HYSYSMainFlowsheetFeeds.Add(inletStream2);
					}
					if (item4.Stream == inletStream2 && item4.Destination.UID == sIDERECTIFIER.UID)
					{
						item4.Destination = this;
						break;
					}
				}
			}
		}
	}

	public void SeparateGlobalAndLocalSpecs()
	{
		AnalysisSpecification(this);
		SetLocalSpecs(this);
		foreach (HYSYSColumn sIDESTRIPPER in SIDESTRIPPERS)
		{
			AnalysisSpecification(sIDESTRIPPER);
			SetLocalSpecs(sIDESTRIPPER);
		}
		foreach (HYSYSColumn sIDERECTIFIER in SIDERECTIFIERS)
		{
			AnalysisSpecification(sIDERECTIFIER);
			SetLocalSpecs(sIDERECTIFIER);
		}
	}

	public void SeparateGlobalAndLocalDefines()
	{
		AnalysisDefine(this);
		SetLocalDefines(this);
		foreach (HYSYSColumn sIDESTRIPPER in SIDESTRIPPERS)
		{
			AnalysisDefine(sIDESTRIPPER);
			SetLocalDefines(sIDESTRIPPER);
		}
		foreach (HYSYSColumn sIDERECTIFIER in SIDERECTIFIERS)
		{
			AnalysisDefine(sIDERECTIFIER);
			SetLocalDefines(sIDERECTIFIER);
		}
	}

	private void AnalysisSpecification(HYSYSColumn columnData)
	{
		if (columnData.GlobalSpec == null || columnData.GlobalSpec.Count == 0)
		{
			return;
		}
		List<string> allObjNames = GetAllObjNames();
		foreach (Specification item in columnData.GlobalSpec)
		{
			item.SetGlobalProperty(columnData.UID, columnData.InletStreams, columnData.OutletStreams, allObjNames, HYSYSMainFlowsheetProducts, SubColumnProducts());
		}
	}

	private void AnalysisDefine(HYSYSColumn columnData)
	{
		if (columnData.GlobalDefine == null || columnData.GlobalDefine.Count == 0)
		{
			return;
		}
		List<string> allObjNames = GetAllObjNames();
		foreach (DEFINE item in columnData.GlobalDefine)
		{
			item.SetGlobalProperty(columnData.UID, columnData.InletStreams, columnData.OutletStreams, allObjNames, HYSYSMainFlowsheetProducts);
		}
	}

	private List<string> GetAllObjNames()
	{
		List<string> list = new List<string>();
		list.Add(base.UID);
		foreach (HYSYSColumn sIDESTRIPPER in SIDESTRIPPERS)
		{
			list.Add(sIDESTRIPPER.UID);
		}
		foreach (HYSYSColumn sIDERECTIFIER in SIDERECTIFIERS)
		{
			list.Add(sIDERECTIFIER.UID);
		}
		return list;
	}

	public void RemoveInternalStreams(List<string> internalStreamNames)
	{
		foreach (string internalStreamName in internalStreamNames)
		{
			if (base.InletStreams.Contains(internalStreamName))
			{
				base.InletStreams.Remove(internalStreamName);
			}
			else if (base.OutletStreams.Contains(internalStreamName))
			{
				base.OutletStreams.Remove(internalStreamName);
			}
		}
	}

	private List<string> SubColumnProducts()
	{
		List<string> list = new List<string>();
		foreach (HYSYSColumn sIDESTRIPPER in SIDESTRIPPERS)
		{
			foreach (string outletStream in sIDESTRIPPER.OutletStreams)
			{
				list.Add(outletStream);
			}
		}
		foreach (HYSYSColumn sIDERECTIFIER in SIDERECTIFIERS)
		{
			foreach (string outletStream2 in sIDERECTIFIER.OutletStreams)
			{
				list.Add(outletStream2);
			}
		}
		return list;
	}

	private void SetLocalSpecs(HYSYSColumn columnData)
	{
		if (columnData.GlobalSpec == null || columnData.GlobalSpec.Count == 0)
		{
			return;
		}
		foreach (Specification item in columnData.GlobalSpec)
		{
			if (!item.bGlobalSpec)
			{
				columnData.LocalSpec.Add(item);
			}
		}
	}

	private void SetLocalDefines(HYSYSColumn columnData)
	{
		if (columnData.GlobalDefine == null || columnData.GlobalDefine.Count == 0)
		{
			return;
		}
		foreach (DEFINE item in columnData.GlobalDefine)
		{
			if (!item.bGlobalDefine)
			{
				columnData.LocalDefine.Add(item);
			}
		}
	}
}
public class PumpAround
{
	public int paId { get; set; }

	public string Name { get; set; }

	public int SourceTrayNo { get; set; }

	public int TargetTrayNo { get; set; }

	public string DrawPhase { get; set; }

	public TypeUnitValue PumparoundRate { get; set; }

	public TypeUnitValue ReturnStreamLiqFrac { get; set; }

	public DoubleValue ReturnStreamTemp { get; set; }

	public DoubleValue ReturnStreamTempChange { get; set; }
}
public class ColumnTray
{
	public HydraulicsCalulationModeEnum CalculationMode { get; set; }

	public int StartStage { get; set; }

	public int EndStage { get; set; }

	public TrayTypeEnum TrayType { get; set; }

	public DoubleValue TraySpacing { get; set; }

	public DoubleValue SectionDiameter { get; set; }

	public int NumberOfFlowPaths { get; set; }

	public double MaxFlooding { get; set; }

	public DoubleValue TrayThickness { get; set; }

	public DoubleValue ValveThickness { get; set; }

	public DoubleValue HoleArea { get; set; }

	public DoubleValue DowncomerClearaness { get; set; }

	public DoubleValue SieveHoleDiameter { get; set; }

	public DoubleValue WeirHeight { get; set; }

	public DoubleValue SideDCTopWidth { get; set; }

	public DoubleValue CenterDCTopWidth { get; set; }

	public DoubleValue OffSideDCTopWidth { get; set; }

	public DoubleValue OffCenterDCTopWidth { get; set; }
}
public class columnPack
{
	public HydraulicsCalulationModeEnum CalculationMode { get; set; }

	public int StartStage { get; set; }

	public int EndStage { get; set; }

	public bool IsRandomPack { get; set; }

	public int RandomPackType { get; set; }

	public DoubleValue RandomPackSize { get; set; }

	public DoubleValue SectionDiameter { get; set; }

	public StructuredPackTypeEnum StructurePackType { get; set; }

	public string StructurePackDetail { get; set; }
}
public enum SolveMethodTypeEnum
{
	HYSIMI0,
	MODIFIEDHYSIMIO,
	NEWTONRAPHSONIO,
	SPARSECONTINUATIONSOLVER,
	SIMULTANEOUSCORRECTION,
	OLISOLVER
}
public enum ColumnPhaseEnum
{
	VLL,
	VL,
	LL,
	VLW
}
public enum HYSYSCondenserTypeEnum
{
	TOTAL,
	PARTIAL,
	FULLREFLUX
}
public enum HYSYSReboilerTypeEnum
{
	KETTLE,
	THERMOSIPHONWITHBAFFLE,
	THERMOSIPHONWITHOUTBAFFLE
}
public enum HydraulicsCalulationModeEnum
{
	RATING,
	SIZING
}
public enum TrayTypeEnum
{
	VALVE,
	SIEVE,
	CAP
}
public enum StructuredPackTypeEnum
{
	SULZER,
	FLEXE,
	FLEXI,
	INTALOX,
	KGWIGEGAUZE
}
public class HYSYSComponent : HYSYSBaseObject
{
	public class HYSYSPetrol
	{
		public List<string> AddedProperties { get; set; }

		public int nIndex { get; set; }

		public string Name { get; set; }

		public double MW { get; set; }

		public DoubleValue StdLiqDensity { get; set; }

		public DoubleValue NBP { get; set; }

		public double ACENTRIC { get; set; }

		public TypeUnitValue VC { get; set; }

		public DoubleValue TC { get; set; }

		public DoubleValue PC { get; set; }

		public double RACKETT { get; set; }

		public DoubleValue DIPOLE { get; set; }

		public DoubleValue RADIUS { get; set; }

		public double SOLUPARA { get; set; }

		public TypeUnitValue MOLVOL { get; set; }

		public TypeUnitValue HCOMBUST { get; set; }

		public HYSYSPetrol()
		{
			AddedProperties = new List<string>();
		}
	}

	public class NoLibrary
	{
		public List<string> AddedProperties { get; set; }

		public string Name { get; set; }

		public double MW { get; set; }

		public DoubleValue SPGR { get; set; }

		public DoubleValue API { get; set; }

		public DoubleValue NBP { get; set; }

		public double ACENTRIC { get; set; }

		public TypeUnitValue VC { get; set; }

		public DoubleValue TC { get; set; }

		public DoubleValue PC { get; set; }

		public double RACKETT { get; set; }

		public DoubleValue DIPOLE { get; set; }

		public DoubleValue RADIUS { get; set; }

		public double SOLUPARA { get; set; }

		public TypeUnitValue MOLVOL { get; set; }

		public DoubleValue STDDENSITY { get; set; }

		public TypeUnitValue HCOMBUST { get; set; }

		public NoLibrary()
		{
			AddedProperties = new List<string>();
		}
	}

	public class AssaySetting
	{
		public string Characterize { get; set; }

		public string MW { get; set; }

		public string Conversion { get; set; }

		public string Curvefit { get; set; }

		public string Gravity { get; set; }
	}

	public class HYSYSAssay
	{
		public AssaySetting Settings { get; set; }

		public DistillationTypeEnum DistillationType { get; set; }

		public string AssayBasis { get; set; }

		public string AssayName { get; set; }

		public string DistillationTempUnit { get; set; }

		public string StreamName { get; set; }

		public double[] AssayBoillingPercent { get; set; }

		public double[] BoilingTempValues { get; set; }

		public DoubleValue DistillationPressure { get; set; }

		public bool Cracking { get; set; }

		public DoubleValue BulkMassDensity { get; set; }

		public double[] DensityPercent { get; set; }

		public double[] DensityValues { get; set; }

		public bool IsWATSONK { get; set; }

		public LightEnd LightEndData { get; set; }

		public double MWAverage { get; set; }

		public IDictionary<double, double> MWData { get; set; }

		public HYSYSKinematicViscosity KVIS { get; set; }

		public List<HYSYSUserProperty> UserProperties { get; set; }
	}

	public class LightEnd
	{
		public bool AutoCaculate { get; set; }

		public IDictionary<int, double> HyssyComposition { get; set; }

		public double HysysPercent { get; set; }

		public LightEndsBasis HysysBasis { get; set; }

		public bool LightEndsIsConverted { get; set; }

		public IDictionary<int, double> COMPOSITION { get; set; }

		public string COMPOSITIONBasis { get; set; }

		public string COMPOSITIONUnit { get; set; }

		public QualifierValue RATE { get; set; }

		public QualifierValue FRACTION { get; set; }

		public QualifierValue PERCENT { get; set; }

		public string MATCH { get; set; }

		public string NOMATCH { get; set; }

		public string STREAM { get; set; }

		public string NORMALIZE { get; set; }

		public string StreamName { get; set; }
	}

	public enum LightEndsBasis
	{
		MolarPercent,
		WeightPercent,
		VolumPercent,
		MolarRate,
		WeightRate,
		VolumRate
	}

	public enum DistillationTypeEnum
	{
		TBP,
		D86,
		D1160,
		D2887
	}

	public class HYSYSBlend
	{
		public string BlendName { get; set; }

		public string StreamName { get; set; }

		public string AssaysName { get; set; }

		public double[] NumberOfCutsInRangeValue { get; set; }

		public double[] EndRangeTemperatureValue { get; set; }

		public bool IsUserRanges { get; set; }

		public double InitialCutPointValue { get; set; }

		public string TempUnit { get; set; }
	}

	public class HYSYSUserProperty
	{
		public string Name { get; set; }

		public string VariableType { get; set; }

		public DoubleValue Average { get; set; }

		public string Stream { get; set; }

		public IDictionary<double, double> Data { get; set; }

		public string DataUnit { get; set; }
	}

	public class HYSYSKinematicViscosity
	{
		public DoubleValue Average1 { get; set; }

		public DoubleValue Average2 { get; set; }

		public DoubleValue Temp1 { get; set; }

		public DoubleValue Temp2 { get; set; }

		public string Stream { get; set; }

		public Dictionary<double, double> DataTemp1 { get; set; }

		public Dictionary<double, double> DataTemp2 { get; set; }

		public string KinematicViscosityUnit { get; set; }
	}

	public List<string> TraditionalComponents { get; set; }

	public List<HYSYSAssay> Assays { get; set; }

	public List<HYSYSBlend> Blends { get; set; }

	public List<HYSYSPetrol> Petroleums { get; set; }

	public List<NoLibrary> NoLibraries { get; set; }

	public Dictionary<int, ReNameLibComponent> DuplicateNamedLibComp { get; set; }

	public List<string> GetNoLibAndPetrolNames()
	{
		List<string> list = new List<string>();
		if (Petroleums != null)
		{
			foreach (HYSYSPetrol petroleum in Petroleums)
			{
				list.Add(petroleum.Name);
			}
		}
		if (NoLibraries != null)
		{
			foreach (NoLibrary noLibrary in NoLibraries)
			{
				list.Add(noLibrary.Name);
			}
		}
		return list;
	}
}
public class ReNameLibComponent
{
	public int ThisIndex { get; set; }

	public int RefIndex { get; set; }

	public string P2Key { get; set; }

	public string HYSYSName { get; set; }

	public int Number { get; set; }

	public ReNameLibComponent(string key, int nIndex, int refIndex, string hysysName, int number)
	{
		P2Key = key;
		ThisIndex = nIndex;
		RefIndex = refIndex;
		HYSYSName = hysysName;
		Number = number;
	}
}
public class HYSYSComponentSplitter : HYSYSUnitOperationBase
{
	public enum ProductBasis
	{
		M,
		W,
		LV
	}

	public List<Specification> OVHDSpecs { get; set; }

	public List<Specification> BTMSSpecs { get; set; }

	public DoubleValue DUTY { get; set; }

	public List<string> OVHDStreams { get; set; }

	public List<string> BTMStreams { get; set; }

	public DoubleValue OVHDTemperature { get; set; }

	public DoubleValue OVHDPressure { get; set; }

	public DoubleValue BTMSTemperature { get; set; }

	public DoubleValue BTMSPressure { get; set; }

	public DoubleValue OVHDDP { get; set; }

	public DoubleValue OVHDDT { get; set; }

	public DoubleValue BTMSDP { get; set; }

	public DoubleValue BTMSDT { get; set; }

	public HYSYSComponentSplitter()
	{
		OVHDSpecs = new List<Specification>();
		BTMSSpecs = new List<Specification>();
		OVHDStreams = new List<string>();
		BTMStreams = new List<string>();
	}
}
public class HYSYSCompressor : HYSYSUnitOperationBase
{
	public double AdiabaticEfficiency { get; set; }

	public double PolytropicEfficiency { get; set; }

	public DoubleValue Duty { get; set; }

	public HYSYSCompressorPolytropicMethod PolytropicMethod { get; set; }

	public HYSYSCompressorOperatingMode OperationMode { get; set; }

	public HYSYSCompressorCurveInputOption CurveInputOption { get; set; }

	public DoubleValue AttachedPressure { get; set; }

	public DoubleValue AttachedDP { get; set; }

	public double AttachedPRatio { get; set; }

	public DoubleValue AttachedTemperature { get; set; }

	public double RPM { get; set; }

	public string CurveEfficiencyType { get; set; }

	public DoubleValues CurveRate { get; set; }

	public DoubleValues CurveHead { get; set; }

	public DoubleValues CurveEfficiency { get; set; }
}
public enum HYSYSCompressorPolytropicMethod
{
	Schultz,
	Huntington,
	Reference
}
public enum HYSYSCompressorOperatingMode
{
	Centrifugal,
	Reciprocating
}
public enum HYSYSCompressorCurveInputOption
{
	SingleMWCurves,
	MultipleMWCurves,
	MultipleIGVCurves
}
public class HYSYSConversionReactor : HYSYSUnitOperationBase
{
	public DoubleValue AttachedDTFEED { get; set; }

	public DoubleValue AttachedTemperature { get; set; }

	public DoubleValue AttachedPressure { get; set; }

	public DoubleValue Duty { get; set; }

	public DoubleValue DP { get; set; }

	public HYSYSReactionSet ReactionSet { get; set; }

	public string V { get; set; }

	public string L { get; set; }

	public string M { get; set; }

	public string W { get; set; }

	public string S { get; set; }
}
public class HYSYSCSTReactor : HYSYSUnitOperationBase
{
	public HYSYSReactionSet ReactionSet { get; set; }

	public string VapourOutlet { get; set; }

	public string LquidOutlet { get; set; }

	public string EnergyName { get; set; }

	public DoubleValue DeltaPresure { get; set; }

	public DoubleValue ProductPressure { get; set; }

	public DoubleValue Duty { get; set; }

	public bool IsSinglePhase { get; set; }

	public DoubleValue Volumn { get; set; }

	private double LiquidVolumnPercent = 0.5;

	public double LiquidVolumnPercent1
	{
		get
		{
			return LiquidVolumnPercent;
		}
		set
		{
			LiquidVolumnPercent = value;
		}
	}

	public DoubleValue OutletStreamTemperature { get; set; }
}
public class HYSYSCutter : HYSYSUnitOperationBase
{
	public TransferBasisEnum TransferBasis { get; set; }
}
public class HYSYSDerpessureUtility : HYSYSUnitOperationBase
{
	public class Heatflux
	{
		public HeatOperatingMode Mode { get; set; }

		public List<double> FireDataC { get; set; }

		public string FireHeatFluxUnit { get; set; }
	}

	public enum HeatOperatingMode
	{
		Fire,
		FireStephanBoltzman,
		FireAPI521,
		Adiabatic,
		UseSpreadsheet
	}

	public class ValveParameter
	{
		public DoubleValue BackPressure { get; set; }

		public VapourFlowEquation Equation { get; set; }

		public double Cd { get; set; }

		public DoubleValue Area { get; set; }

		public DoubleValue FeedMolarRate { get; set; }

		public DoubleValue Cv { get; set; }

		public DoubleValue Cf { get; set; }
	}

	public enum VapourFlowEquation
	{
		Fisher,
		Relief,
		Supersonic,
		Subsonic,
		Masoneilan,
		General
	}

	public class OperationCondition
	{
		public DoubleValue TimeStepSize { get; set; }

		public DoubleValue DepressuringTime { get; set; }
	}

	public string Feed { get; set; }

	public string MakeUpStringName { get; set; }

	public bool IsVertical { get; set; }

	public DoubleValue Height { get; set; }

	public DoubleValue Diameter { get; set; }

	public DoubleValue InitialLiquidVolumn { get; set; }

	public Heatflux HeatFlux { get; set; }

	public ValveParameter ValvePara { get; set; }

	public OperationCondition OperationConditions { get; set; }

	public HYSYSDerpessureUtility()
	{
		HeatFlux = new Heatflux();
		HeatFlux.FireDataC = new List<double>();
		ValvePara = new ValveParameter();
		OperationConditions = new OperationCondition();
	}
}
public class HYSYSEquilibriumReactor : HYSYSUnitOperationBase
{
	public DoubleValue AttachedDTFEED { get; set; }

	public DoubleValue AttachedTemperature { get; set; }

	public DoubleValue AttachedPressure { get; set; }

	public DoubleValue Duty { get; set; }

	public DoubleValue DP { get; set; }

	public HYSYSReactionSet ReactionSet { get; set; }

	public string V { get; set; }

	public string L { get; set; }

	public string M { get; set; }

	public string W { get; set; }

	public string S { get; set; }
}
public class HYSYSExpander : HYSYSUnitOperationBase
{
	public double AdiabaticEfficiency { get; set; }

	public double PolytropicEfficiency { get; set; }

	public DoubleValue Duty { get; set; }

	public HYSYSExpanderCurveInputOption CurveInputOption { get; set; }

	public DoubleValue AttachedPressure { get; set; }

	public DoubleValue AttachedDP { get; set; }

	public double AttachedPRatio { get; set; }

	public string CurveEfficiencyType { get; set; }

	public DoubleValues CurveRate { get; set; }

	public DoubleValues CurveHead { get; set; }

	public DoubleValues CurveEfficiency { get; set; }
}
public enum HYSYSExpanderCurveInputOption
{
	SingleMWCurves,
	MultipleIGVCurves
}
public class HYSYSFiredHeater : HYSYSUnitOperationBase
{
	public DoubleValue TUBESIDETOUT { get; set; }

	public List<string> TUBESIDEINLETSTREAMS { get; set; }

	public List<string> COMBSIDEINLETSTREAMS { get; set; }

	public List<string> TUBESIDEOUTLETSTREAMS { get; set; }

	public List<string> COMBSIDEOUTLETSTREAMS { get; set; }

	public List<string> AIRSIDESTREAMS { get; set; }

	public HYSYSFiredHeater()
	{
		TUBESIDEINLETSTREAMS = new List<string>();
		TUBESIDEOUTLETSTREAMS = new List<string>();
		COMBSIDEINLETSTREAMS = new List<string>();
		COMBSIDEOUTLETSTREAMS = new List<string>();
		AIRSIDESTREAMS = new List<string>();
	}
}
public class HYSYSFluidPackages : HYSYSBaseObject
{
	public List<HYSYSFluidPackage> EOSFluidPackages { get; set; }

	public List<HYSYSFluidPackage> ActivityFluidPackages { get; set; }

	public List<string> StringsForAspenPlus { get; set; }

	public bool HasAspenPlusActivityProperty { get; set; }

	public string DefaultMehodeName { get; set; }

	public List<string> AllPropertyNames { get; set; }

	public bool IsAtuoCreatedDefault { get; set; }

	public bool IsEOSUsingAspenPlus { get; set; }

	private static readonly string strFluidPackagesInDic = string.Format("FluidPackages", System.Array.Empty<object>());

	public HYSYSFluidPackages()
	{
		StringsForAspenPlus = new List<string>();
		EOSFluidPackages = new List<HYSYSFluidPackage>();
		AllPropertyNames = new List<string>();
		ActivityFluidPackages = new List<HYSYSFluidPackage>();
	}

	public static string GetMethodName(string p2Set)
	{
		string text = string.Empty;
		if (HYSYSBaseObject.g_Map[strFluidPackagesInDic] is HYSYSFluidPackages hYSYSFluidPackages)
		{
			foreach (HYSYSFluidPackage eOSFluidPackage in hYSYSFluidPackages.EOSFluidPackages)
			{
				if (eOSFluidPackage.FluidPackageName == p2Set)
				{
					text = p2Set;
					break;
				}
			}
			if (string.IsNullOrEmpty(text))
			{
				foreach (HYSYSFluidPackage activityFluidPackage in hYSYSFluidPackages.ActivityFluidPackages)
				{
					if (activityFluidPackage.FluidPackageName == p2Set)
					{
						text = p2Set;
						break;
					}
				}
			}
		}
		return text;
	}

	public static string GetThermoKeyByPackageName(string packageName)
	{
		HYSYSFluidPackages hYSYSFluidPackages = HYSYSBaseObject.g_Map[strFluidPackagesInDic] as HYSYSFluidPackages;
		string result = string.Empty;
		if (hYSYSFluidPackages == null)
		{
			return string.Empty;
		}
		foreach (HYSYSFluidPackage eOSFluidPackage in hYSYSFluidPackages.EOSFluidPackages)
		{
			if (eOSFluidPackage.FluidPackageName == packageName)
			{
				result = eOSFluidPackage.ThomoKey;
				break;
			}
		}
		return result;
	}
}
public class HYSYSFluidPackage
{
	public string FluidPackageName { get; set; }

	public bool IsIndividual { get; private set; }

	public bool IsDefault { get; set; }

	public string ThomoKey { get; private set; }

	public QualifierValue Enthalpy { get; private set; }

	public QualifierValue Density { get; private set; }

	public string Pro2Key { get; private set; }

	public List<string> ConvertNotes { get; set; }

	public HYSYSFluidPackage(string fluidPackageName, bool isIndividual, bool isDefault, string thomoKey, QualifierValue enthalpy, QualifierValue density, string pro2Key)
	{
		FluidPackageName = fluidPackageName;
		IsIndividual = isIndividual;
		IsDefault = isDefault;
		ThomoKey = thomoKey.Trim();
		Enthalpy = enthalpy;
		Density = density;
		Pro2Key = pro2Key;
		ConvertNotes = new List<string>();
	}
}
public class HYSYSGibbsReactor : HYSYSUnitOperationBase
{
	public DoubleValue AttachedTemperature { get; set; }

	public DoubleValue AttachedPressure { get; set; }

	public DoubleValue Duty { get; set; }

	public DoubleValue DP { get; set; }

	public bool IsAdiabatic { get; set; }

	public double Tolerance { get; set; }

	public int MaxIteration { get; set; }

	public int[] InertComponents { get; set; }

	public HYSYSReactionSet ReactionSet { get; set; }

	public Dictionary<int, double> CompFracSpec { get; set; }

	public Dictionary<int, DoubleValue> CompFixedSpec { get; set; }

	public string V { get; set; }

	public string L { get; set; }

	public string M { get; set; }

	public string W { get; set; }

	public string S { get; set; }

	public HYSYSGibbsReactor()
	{
		CompFixedSpec = new Dictionary<int, DoubleValue>();
		CompFracSpec = new Dictionary<int, double>();
	}
}
public class HYSYSHeatExchanger : HYSYSUnitOperationBase
{
	public bool MapForHXRIG { get; set; }

	public DoubleValue Duty { get; set; }

	public DoubleValue HotSideDeltaPressure { get; set; }

	public DoubleValue ColdSideDeltaPressure { get; set; }

	public DoubleValue HotSideOutletTemperature { get; set; }

	public DoubleValue ColdSideOutletTemperature { get; set; }

	public DoubleValue ColdSideOutletPressure { get; set; }

	public HysysHeatExchangerType ExchangerType { get; set; }

	public QualifierValue ZONES
	{
		get
		{
			return _Zones;
		}
		set
		{
			_Zones = value;
		}
	}

	private QualifierValue _Zones = new QualifierValue();

	public string PLOT { get; set; }

	public string HotSideMethod { get; set; }

	public string ColdSideMethod { get; set; }

	public string FlowDirection { get; set; }

	public int TubePasses { get; set; }

	public int ShellPasses { get; set; }

	public DoubleValue FTFactor { get; set; }

	public DoubleValue OverallUA { get; set; }

	public DoubleValue HOCI { get; set; }

	public DoubleValue HICO { get; set; }

	public DoubleValue HOCO { get; set; }

	public DoubleValue HDTBB { get; set; }

	public DoubleValue CDTBB { get; set; }

	public DoubleValue HDTAD { get; set; }

	public DoubleValue CDTAD { get; set; }

	public DoubleValue Tolerance { get; set; }

	public DoubleValue MITA { get; set; }

	public DoubleValue HLFRAC { get; set; }

	public DoubleValue CLFRAC { get; set; }

	public List<string> HotSideInletStreams { get; set; }

	public List<string> ColdSideOutletStreams { get; set; }

	public List<string> ColdSideInletStreams { get; set; }

	public List<string> HotSideOutletStreams { get; set; }

	public UtilityType UTILITYTYPE { get; set; }

	public DoubleValue TubeLength { get; set; }

	public DoubleValue TubeOD { get; set; }

	public DoubleValue TubeID { get; set; }

	public DoubleValue TubeThickness { get; set; }

	public DoubleValue TSDPSHELL { get; set; }

	public DoubleValue TSDPUNIT { get; set; }

	public int TubeNumberPerShell { get; set; }

	public TubeLayoutEnum TubeLayout { get; set; }

	public DoubleValue TubePitch { get; set; }

	public DoubleValue TubeMaterialDensity { get; set; }

	public DoubleValue TubeMaterialConductivity { get; set; }

	public DoubleValue TubeFoul { get; set; }

	public DoubleValue TubesideFilmCoeff { get; set; }

	public DoubleValue TubeAbsoluteRoughness { get; set; }

	public int FinNumber { get; set; }

	public DoubleValue FinHeight { get; set; }

	public DoubleValue FinThickness { get; set; }

	public DoubleValue FinRootDiameter { get; set; }

	public DoubleValue TSNozzleInsideDiameter { get; set; }

	public DoubleValue TSNozzleOutsideDiameter { get; set; }

	public DoubleValue ShellInnerDiameter { get; set; }

	public int ShellInSeries { get; set; }

	public int ShellInParallel { get; set; }

	public DoubleValue ShellFouling { get; set; }

	public DoubleValue ShellsideFilmCoeff { get; set; }

	public DoubleValue SSDPSHELL { get; set; }

	public DoubleValue SSDPUNIT { get; set; }

	public string ShellBaffleType { get; set; }

	public bool NoTubeInWindow { get; set; }

	public DoubleValue ShellBaffleCut { get; set; }

	public DoubleValue ShellBaffleThickness { get; set; }

	public DoubleValue ShellBaffleSpacing { get; set; }

	public DoubleValue ShellBaffleInSpacing { get; set; }

	public DoubleValue ShellBaffleOutSpacing { get; set; }

	public DoubleValue ShellNozzleInnerDiameter { get; set; }

	public DoubleValue ShellNozzleOuterDiameter { get; set; }

	public string TEMAType { get; set; }

	public string ExchangerOrientation { get; set; }

	public TubeDiameterCalEnum CalculateTube { get; set; }

	public bool bLowFinTube { get; set; }

	public bool bHotSideIsTube { get; set; }

	public bool bOutputPressureSpecified { get; set; }

	public int HcurvePlotPoint { get; set; }

	public HYSYSHeatExchanger(bool outputPressureSpecified)
	{
		bOutputPressureSpecified = outputPressureSpecified;
		ColdSideInletStreams = new List<string>();
		ColdSideOutletStreams = new List<string>();
	}

	public HYSYSHeatExchanger()
	{
		HotSideInletStreams = new List<string>();
		HotSideOutletStreams = new List<string>();
		ColdSideInletStreams = new List<string>();
		ColdSideOutletStreams = new List<string>();
	}

	public void LoadStreams()
	{
		if (ExchangerType == HysysHeatExchangerType.Cooler)
		{
			foreach (string inletStream in base.InletStreams)
			{
				HotSideInletStreams.Add(inletStream.Trim());
			}
			foreach (string outletStream in base.OutletStreams)
			{
				HotSideOutletStreams.Add(outletStream.Trim());
			}
		}
		else if (ExchangerType == HysysHeatExchangerType.Heater)
		{
			foreach (string inletStream2 in base.InletStreams)
			{
				ColdSideInletStreams.Add(inletStream2.Trim());
			}
			foreach (string outletStream2 in base.OutletStreams)
			{
				ColdSideOutletStreams.Add(outletStream2.Trim());
			}
		}
	}

	public void SetInletAndOutletStreams()
	{
		foreach (string hotSideInletStream in HotSideInletStreams)
		{
			base.InletStreams.Add(hotSideInletStream);
		}
		foreach (string coldSideInletStream in ColdSideInletStreams)
		{
			base.InletStreams.Add(coldSideInletStream);
		}
		foreach (string hotSideOutletStream in HotSideOutletStreams)
		{
			base.OutletStreams.Add(hotSideOutletStream);
		}
		foreach (string coldSideOutletStream in ColdSideOutletStreams)
		{
			base.OutletStreams.Add(coldSideOutletStream);
		}
	}
}
public enum HysysHeatExchangerType
{
	Cooler,
	Heater,
	HeatExchanger
}
public enum UtilityType
{
	Water,
	Air,
	Steam,
	HeatingMedium,
	Refrigerant
}
public enum TubeLayoutEnum
{
	Triangular,
	TriangularRotated,
	Square,
	SquareRotated
}
public enum TubeDiameterCalEnum
{
	ID,
	OD,
	NONE
}
public class HYSYSHydrateUtility : HYSYSUnitOperationBase
{
	public string StreamName { get; set; }

	public DoubleValue InitPressure { get; set; }
}
public class HYSYSLNGHeatExchanger : HYSYSHeatExchanger
{
	public bool IsHeatLeak { get; set; }

	public Dictionary<int, DoubleValue> HotSideDuties { get; set; }

	public Dictionary<int, DoubleValue> ColdSideDuties { get; set; }

	public Dictionary<int, DoubleValue> HotSideTemperatures { get; set; }

	public Dictionary<int, DoubleValue> ColdSideTemperatures { get; set; }

	public Dictionary<int, DoubleValue> HotSideDeltaPressures { get; set; }

	public Dictionary<int, DoubleValue> ColdSideDeltaPressures { get; set; }

	public Dictionary<int, string> HotSideMethods { get; set; }

	public Dictionary<int, string> ColdSideMethods { get; set; }

	public Dictionary<int, List<string>> HotSidesInletStreams { get; set; }

	public Dictionary<int, List<string>> ColdSidesInletStreams { get; set; }

	public Dictionary<int, List<string>> HotSidesOutletStreams { get; set; }

	public Dictionary<int, List<string>> ColdSidesOutletStreams { get; set; }

	public HYSYSLNGHeatExchanger()
	{
		HotSidesInletStreams = new Dictionary<int, List<string>>();
		HotSidesOutletStreams = new Dictionary<int, List<string>>();
		HotSideDuties = new Dictionary<int, DoubleValue>();
		HotSideTemperatures = new Dictionary<int, DoubleValue>();
		HotSideDeltaPressures = new Dictionary<int, DoubleValue>();
		HotSideMethods = new Dictionary<int, string>();
		ColdSidesInletStreams = new Dictionary<int, List<string>>();
		ColdSidesOutletStreams = new Dictionary<int, List<string>>();
		ColdSideDuties = new Dictionary<int, DoubleValue>();
		ColdSideTemperatures = new Dictionary<int, DoubleValue>();
		ColdSideDeltaPressures = new Dictionary<int, DoubleValue>();
		ColdSideMethods = new Dictionary<int, string>();
	}
}
public class HYSYSMixer : HYSYSUnitOperationBase
{
	public DoubleValue ATTACHED_PRESSURE { get; set; }

	public DoubleValue ATTACHED_PRESSUREDROP { get; set; }

	public bool OutletValveAdded { get; set; }
}
public class HYSYSPhaseEnvelope : HYSYSUnitOperationBase
{
	public string StreamName { get; set; }

	public int Points { get; set; }

	public bool IsHydrate { get; set; }
}
public class HYSYSPipe : HYSYSUnitOperationBase
{
	public DoubleValue DIAMETER { get; set; }

	public Dictionary<DoubleValue, int> NPS { get; set; }

	public DoubleValue LENGTH { get; set; }

	public int SEGMENTSCOUNT { get; set; }

	public DoubleValue ROUGHNESS { get; set; }

	public DoubleValue DUTY { get; set; }

	public DoubleValue HTC { get; set; }

	public DoubleValue TAMB { get; set; }

	public bool ACCEL { get; set; }

	public bool ISOTHERMAL { get; set; }

	public DoubleValue ELEVATION { get; set; }

	public bool BBDPCORR { get; set; }

	public DoubleValue DP { get; set; }

	public bool UseDP { get; set; }

	public HYSYSPipe()
	{
		NPS = new Dictionary<DoubleValue, int>();
	}
}
public class HYSYSPlugFlowReactor : HYSYSUnitOperationBase
{
	public HYSYSReactionSet ReactionSet { get; set; }

	public string Product { get; set; }

	public DoubleValue TubleLength { get; set; }

	public DoubleValue TubleDiameter { get; set; }

	public int NumberOfTubes { get; set; }

	public DoubleValue DeltaPresure { get; set; }

	public DoubleValue ProductPressure { get; set; }

	public DoubleValue Duty { get; set; }

	public bool IsEngun { get; set; }

	public DoubleValue ParticleDiameter { get; set; }

	public DoubleValue ParticleSphericity { get; set; }

	public DoubleValue PackedBedVoidFraction { get; set; }

	public string EnergyName { get; set; }

	public DoubleValue OutletStreamTemperature { get; set; }
}
public class HYSYSPropertyTableUtility : HYSYSUnitOperationBase
{
	public string COMPi { get; set; }

	public string COMPj { get; set; }

	public DoubleValue PRESSURE { get; set; }

	public DoubleValue TEMP { get; set; }

	public bool Kvalue { get; set; }

	public bool IsHCurve { get; set; }

	public DoubleValues TEMPERATUREs { get; set; }

	public DoubleValues PRESSUREs { get; set; }

	public DoubleValue DP { get; set; }

	public DoubleValue DT { get; set; }

	public double Points { get; set; }

	public string StreamID { get; set; }

	public DoubleValue VaporFraction { get; set; }

	public bool IsDewBubP { get; set; }

	public bool IsDewBubT { get; set; }
}
public class HYSYSPump : HYSYSUnitOperationBase
{
	public DoubleValue ATTACHED_PRESSURE { get; set; }

	public DoubleValue ATTACHED_PRESSUREDROP { get; set; }

	public double PRATIO { get; set; }

	public double AdiabaticEfficiency { get; set; }
}
public class HYSYSReactionSets : HYSYSBaseObject
{
	public List<HYSYSReactionSet> HYSYSRXSets { get; set; }
}
public class HYSYSReactionSet : HYSYSBaseObject
{
	public string ID { get; set; }

	public List<HYSYSReaction> HYSYSReactions { get; set; }

	public HYSYSReactionSet(string strID)
	{
		HYSYSReactions = new List<HYSYSReaction>();
		ID = strID;
	}
}
public abstract class HYSYSReaction : HYSYSBaseObject
{
	public string ID { get; set; }

	public bool IsAspenPlusProperty { get; set; }

	public IDictionary<string, double> Stoichiometry { get; set; }

	public HYSYSReaction()
	{
		Stoichiometry = new Dictionary<string, double>();
	}

	public HYSYSReaction(string strID)
	{
		ID = strID;
		Stoichiometry = new Dictionary<string, double>();
	}
}
public class HYSYSConversionReaction : HYSYSReaction
{
	public class HYSYSConversionReactionBasis
	{
		public string BaseComponent { get; set; }

		public HYSYSConversionReactionPhase ReactionPhase { get; set; }
	}

	public HYSYSConversionReactionBasis ReactionBasis { get; set; }

	public double C0 { get; set; }

	public double C1 { get; set; }

	public double C2 { get; set; }
}
public class HYSYSEquilibriumReaction : HYSYSReaction
{
	public class KeqParameters
	{
		public double A { get; set; }

		public double B { get; set; }

		public double C { get; set; }

		public double D { get; set; }

		public double E { get; set; }

		public double F { get; set; }

		public double G { get; set; }

		public double H { get; set; }
	}

	public bool IsKeqSourceLnEuqation { get; set; }

	public EquilibriumReactionBasis Basis { get; set; }

	public EquilibriumReactionPhase Phase { get; set; }

	public KeqParameters KeqParams { get; set; }

	public string BaseComponent { get; set; }

	public DoubleValue DT { get; set; }

	public double C0 { get; set; }

	public double C1 { get; set; }

	public double C2 { get; set; }
}
public class HYSYSKineticReaction : HYSYSReaction
{
	public Dictionary<string, double> FwdOrder { get; set; }

	public RXBasis Basis { get; set; }

	public string BaseComponent { get; set; }

	public string RxnPhase { get; set; }

	public double FrequencyFactor { get; set; }

	public DoubleValue ActivationEnergy { get; set; }

	public double ExtReacRateConst { get; set; }
}
public enum EquilibriumReactionBasis
{
	Activity,
	PartialPress,
	MolarConcn,
	MassConcn,
	MoleFraction,
	MassFraction
}
public enum EquilibriumReactionPhase
{
	LiquidPhase,
	VapourPhase
}
public enum HYSYSConversionReactionPhase
{
	Overall,
	VapourPhase,
	LiquidPhase,
	AqueousPhase,
	CombinedLiquid
}
public class HYSYSRecycle : HYSYSUnitOperationBase
{
	public string TargetStream { get; set; }
}
public class HYSYSSeparator : HYSYSUnitOperationBase
{
	public class HYSYSEntrainment
	{
		public string FROM { get; set; }

		public string TO { get; set; }

		public double FRACTION { get; set; }

		public TypeUnitValue RATE { get; set; }
	}

	public Specification SPEC { get; set; }

	public List<HYSYSEntrainment> Entrainments { get; set; }

	public string VapourOutletStream { get; set; }

	public string LiquidOutletStream { get; set; }

	public string HeavyLiquidtStream { get; set; }

	public string VesselFluidPackage { get; set; }

	public string EnergyStream { get; set; }

	public DoubleValue InletDeltaPressure { get; set; }

	public DoubleValue Duty { get; set; }

	public HYSYSSeparatorType SeparatorType { get; set; }

	public bool IsDew { get; set; }

	public bool IsBubble { get; set; }

	public bool IsAdiabatic { get; set; }

	public bool IsIsothermal { get; set; }

	public bool HasSpec { get; set; }

	public bool HasMixedProduct { get; set; }

	public DoubleValue OutletStreamPressure { get; set; }

	public DoubleValue OutLetStreamTemp { get; set; }
}
public enum HYSYSSeparatorType
{
	Separator,
	ThreePhaseSep,
	Tank
}
public class HYSYSSplitter : HYSYSUnitOperationBase
{
	public DoubleValue ATTACHED_PRESSURE { get; set; }

	public DoubleValue ATTACHED_PRESSUREDROP { get; set; }

	public bool InletValveAdded { get; set; }
}
public class HYSYSStream : HYSYSBaseObject
{
	public class StreamComposition
	{
		public CompostionBasisTypes Basis { get; set; }

		public string CompositionUOM { get; set; }

		public IDictionary<string, double> Data { get; set; }

		public bool IsRateSet { get; set; }

		public StreamComposition()
		{
			Data = new Dictionary<string, double>();
		}
	}

	public string Stream { get; set; }

	public string FluidPackage { get; set; }

	public bool IsAssayStream { get; set; }

	public DoubleValue Temp { get; set; }

	public DoubleValue Pressure { get; set; }

	public HYSYSUnitOperationBase Source { get; set; }

	public HYSYSUnitOperationBase Destination { get; set; }

	public StreamComposition Composition { get; set; }

	public DoubleValue VaporFrac { get; set; }

	public TypeUnitValue Rate { get; set; }

	public string RefStream { get; set; }

	public bool NeedSetRateZero { get; set; }

	public string ConvertNotes { get; set; }

	public bool IsNeedSetRateForRefStream { get; set; }

	public bool IsPseudoStreamWithNoTarget { get; set; }

	public bool bSourceIsTFlow { get; set; }

	public bool IsRateHaveBeenSet { get; set; }

	public HYSYSStream()
	{
		Composition = new StreamComposition();
		if (BaseObject._Report != null)
		{
			Report report = BaseObject._Report;
			int hYSYSStreamCount = report.HYSYSStreamCount + 1;
			report.HYSYSStreamCount = hYSYSStreamCount;
		}
	}

	public static HYSYSStream GetStreamByName(string strName)
	{
		string key = string.Format("STREAM\\{0}", strName);
		if (HYSYSBaseObject.g_Map.ContainsKey(key))
		{
			return HYSYSBaseObject.g_Map[key] as HYSYSStream;
		}
		return null;
	}

	public static HYSYSStream Clone(HYSYSStream sourceStream)
	{
		if (sourceStream != null)
		{
			HYSYSStream hYSYSStream = new HYSYSStream();
			if (sourceStream.Temp != null)
			{
				hYSYSStream.Temp = sourceStream.Temp;
			}
			if (sourceStream.Pressure != null)
			{
				hYSYSStream.Pressure = sourceStream.Pressure;
			}
			if (sourceStream.Rate != null)
			{
				hYSYSStream.Rate = sourceStream.Rate;
			}
			if (sourceStream.Composition != null)
			{
				hYSYSStream.Composition = sourceStream.Composition;
			}
			return hYSYSStream;
		}
		return null;
	}
}
public class HYSYSTitle : HYSYSBaseObject
{
	public string Dimension { get; set; }

	public List<StringValue> SpecialDefine { get; set; }
}
public class HYSYSUnitOperationBase : HYSYSBaseObject
{
	public string UID { get; set; }

	public string FluidPackage { get; set; }

	public List<string> InletStreams { get; set; }

	public List<string> OutletStreams { get; set; }

	public List<string> ConvertNotes { get; set; }

	public HYSYSUnitOperationBase()
	{
		InletStreams = new List<string>();
		OutletStreams = new List<string>();
		ConvertNotes = new List<string>();
		base.GlobalDefine = new List<DEFINE>();
		base.LocalDefine = new List<DEFINE>();
		base.GlobalSpec = new List<Specification>();
		base.LocalSpec = new List<Specification>();
		if (BaseObject._Report != null)
		{
			Report report = BaseObject._Report;
			int hYSYSEquipmentCount = report.HYSYSEquipmentCount + 1;
			report.HYSYSEquipmentCount = hYSYSEquipmentCount;
		}
	}

	public void SetCreateStreams(List<HYSYSBaseObject> objectList)
	{
		new List<HYSYSBaseObject>();
		foreach (string inletStream in InletStreams)
		{
			HYSYSStream hYSYSStream = HYSYSStream.GetStreamByName(inletStream);
			if (hYSYSStream == null)
			{
				foreach (HYSYSBaseObject @object in objectList)
				{
					if (@object.GetType() == typeof(HYSYSStream))
					{
						HYSYSStream hYSYSStream2 = @object as HYSYSStream;
						if (hYSYSStream2.Stream == inletStream)
						{
							hYSYSStream = hYSYSStream2;
							break;
						}
					}
				}
				if (hYSYSStream == null)
				{
					hYSYSStream = new HYSYSStream();
					hYSYSStream.Stream = inletStream;
					objectList.Add(hYSYSStream);
				}
			}
			hYSYSStream.Destination = this;
		}
		foreach (string outletStream in OutletStreams)
		{
			HYSYSStream hYSYSStream3 = HYSYSStream.GetStreamByName(outletStream);
			if (hYSYSStream3 == null)
			{
				foreach (HYSYSBaseObject object2 in objectList)
				{
					if (object2.GetType() == typeof(HYSYSStream))
					{
						HYSYSStream hYSYSStream4 = object2 as HYSYSStream;
						if (hYSYSStream4.Stream == outletStream)
						{
							hYSYSStream3 = hYSYSStream4;
							break;
						}
					}
				}
				if (hYSYSStream3 == null)
				{
					hYSYSStream3 = new HYSYSStream();
					hYSYSStream3.Stream = outletStream;
					objectList.Add(hYSYSStream3);
				}
			}
			hYSYSStream3.Source = this;
		}
	}

	public void SeparateDefines()
	{
		foreach (DEFINE item in base.GlobalDefine)
		{
			item.SetGlobalProperty(UID, InletStreams, OutletStreams);
			if (!item.bGlobalDefine)
			{
				base.LocalDefine.Add(item);
			}
		}
	}

	public void SeparateSpecifications()
	{
		foreach (Specification item in base.GlobalSpec)
		{
			item.SetGlobalProperty(UID, InletStreams, OutletStreams);
			if (!item.bGlobalSpec)
			{
				base.LocalSpec.Add(item);
			}
		}
	}
}
public class HYSYSValve : HYSYSUnitOperationBase
{
	public DoubleValue ATTACHED_PRESSURE { get; set; }

	public DoubleValue ATTACHED_PRESSUREDROP { get; set; }

	public DoubleValue ATTACHED_Temperature { get; set; }
}
