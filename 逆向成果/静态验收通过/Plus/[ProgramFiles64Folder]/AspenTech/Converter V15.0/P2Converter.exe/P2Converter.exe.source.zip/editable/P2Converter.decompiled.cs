using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Windows;
using System.Windows.Markup;
using Common;
using P2ConvertGUI;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("P2Converter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("P2Converter")]
[assembly: AssemblyCopyright("Copyright © 2024 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("41.0.0.0")]
[assembly: ComVisible(false)]
[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace P2Converter
{
	public class App : Application
	{
		private bool _contentLoaded;

		protected override void OnStartup(StartupEventArgs e)
		{
			string[] args = e.Args;
			foreach (string text in args)
			{
				if (text.StartsWith("/AspenPlus"))
				{
					ApplicationName.appName = "Aspen Plus";
				}
				else if (text.StartsWith("/HYSYS"))
				{
					ApplicationName.appName = "HYSYS";
				}
				else if (text.StartsWith("/V"))
				{
					HYSYSVersionNumber.versionNumber = text.Substring(1);
				}
			}
			base.OnStartup(e);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			base.StartupUri = new Uri("Window1.xaml", UriKind.Relative);
			Uri resourceLocator = new Uri("/P2Converter;component/app.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[STAThread]
		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public static void Main()
		{
			App app = new App();
			app.InitializeComponent();
			app.Run();
		}
	}
	public class Window1 : Window, IComponentConnector
	{
		private ApplicationV150 pgui = new ApplicationV150();

		internal Window1 mainwindow;

		private bool _contentLoaded;

		public Window1()
		{
			InitializeComponent();
			if (string.IsNullOrEmpty(ApplicationName.appName) || (ApplicationName.appName == "HYSYS" && string.IsNullOrEmpty(HYSYSVersionNumber.versionNumber)))
			{
				MessageBox.Show("Converter need know the target the model should be converted to, that is, Aspen Plus or Aspen HYSYS and its version number, those information should be passed to the converter if you start it from the shortcut. Please close it and try to start from the shortcut.", P2Globalization.GetString("P2Convert"), MessageBoxButton.OK, MessageBoxImage.Asterisk);
			}
			pgui.OnClose += pgui_OnClose;
			ConvertType type = ConvertType.All;
			if (ApplicationName.appName == "Aspen Plus")
			{
				type = ConvertType.AspenPlus;
			}
			else if (ApplicationName.appName == "HYSYS")
			{
				type = ConvertType.HYSYS;
			}
			pgui.Init(type);
		}

		private void pgui_OnClose()
		{
			Close();
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (_contentLoaded)
			{
				return;
			}
			_contentLoaded = true;
			Uri resourceLocator = new Uri("/P2Converter;component/window1.xaml", UriKind.Relative);
			Application.LoadComponent(this, resourceLocator);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			if (connectionId == 1)
			{
				mainwindow = (Window1)target;
			}
			else
			{
				_contentLoaded = true;
			}
		}
	}
}
namespace P2Converter.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("P2Converter.Properties.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal Resources()
		{
		}
	}
	[CompilerGenerated]
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "16.10.0.0")]
	internal sealed class Settings : ApplicationSettingsBase
	{
		private static Settings defaultInstance = (Settings)SettingsBase.Synchronized(new Settings());

		public static Settings Default => defaultInstance;
	}
}
