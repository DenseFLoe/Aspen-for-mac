using System.Collections;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text;
using Common;
using P2Objects;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("P2Converter")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("P2Converter")]
[assembly: AssemblyCopyright("Copyright © 2024 Aspen Technology, Inc.")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyFileVersion("41.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("8b7e8bd3-64b5-4370-a98b-02d544098a69")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace P2InputParser;

public class P2Parser
{
	public bool IsSupportVersion { get; set; }

	private FileStream m_fs;

	private StreamReader m_sr;

	private string m_strCurrent = "";

	private string m_strVersionNumber = string.Empty;

	private int m_nLineIndex;

	private int m_nLevel;

	private ArrayList m_arlParse;

	private ParseNode m_pnCurrent;

	private bool IsProcedure;

	public static string TrimEx(string str)
	{
		str = str.Replace('\t', ' ');
		str = str.Replace("\0", "");
		return str.Trim();
	}

	public P2Parser(string strFilePath)
	{
		m_arlParse = ParseNodesLoader.LoadParse();
		m_fs = new FileStream(strFilePath, FileMode.Open, FileAccess.Read);
		m_sr = new StreamReader(m_fs, Encoding.Default);
	}

	~P2Parser()
	{
		if (m_sr != null)
		{
			m_sr.Close();
			m_sr = null;
		}
		if (m_fs != null)
		{
			m_fs.Close();
			m_fs = null;
		}
	}

	private P2BaseObject BuildP2Object(P2BaseObject obj)
	{
		if (obj.Name.ToUpper().StartsWith(Categories.Title))
		{
			return new P2Title(obj);
		}
		if (obj.Name.ToUpper().StartsWith(Categories.Component))
		{
			return new P2Component(obj);
		}
		if (obj.Name.ToUpper().StartsWith(Categories.Thermodynamic))
		{
			return new P2ThermoDynamic(obj);
		}
		if (obj.Name.ToUpper().StartsWith(Categories.Stream))
		{
			return new P2Stream(obj);
		}
		if (obj.Name.ToUpper().StartsWith(Categories.RX))
		{
			return new P2ReactionData(obj);
		}
		if (obj.Name.ToUpper().StartsWith(Categories.Unit))
		{
			return new P2UnitOperation(obj);
		}
		if (obj.Name.ToUpper().StartsWith(Categories.Recy))
		{
			if (obj is VisualBaseNode visualBaseNode)
			{
				visualBaseNode._ConvertResult = VisualBaseNode.ConvertResult.CR_IGNORED;
				visualBaseNode.Message = obj.Name + P2Globalization.GetString("CR_IGNORED");
				if (string.Compare(ApplicationName.appName.Trim(), "HYSYS", ignoreCase: true) == 0)
				{
					DebugPrint.OutputDebugString(DebugLevel.Parse, WarningLevel.Warning, visualBaseNode.Message);
				}
			}
		}
		else
		{
			obj.Name.ToUpper().StartsWith(Categories.Case);
		}
		return null;
	}

	private bool IsBreakLine(ref string strLine)
	{
		char marker;
		for (int i = 0; i < strLine.Length; i++)
		{
			marker = strLine[i];
			if (marker == '&')
			{
				strLine = strLine.Substring(0, i).Trim();
				return true;
			}
			if (marker == '$')
			{
				strLine = strLine.Substring(0, i).Trim();
				return false;
			}
			if (marker == '*')
			{
				if (i < strLine.Length - 1)
				{
					int length = i;
					for (i++; i < strLine.Length; i++)
					{
						marker = strLine[i];
						if (marker == '\t' || marker == ' ')
							continue;
						if (marker == '$')
						{
							strLine = strLine.Substring(0, length);
							return true;
						}
						if (!IsProcedure)
						{
							strLine = strLine.Substring(0, length);
							return true;
						}
					}
				}
				else
				{
					strLine = strLine.Substring(0, i);
					return true;
				}
			}
		}
		return false;
	}

	private int GetParseLevel(ArrayList arlParses, string strHead, int nLevel, bool bGoChildren)
	{
		int i;
		for (i = 0; i < arlParses.Count; i++)
		{
			ParseNode parseNode = arlParses[i] as ParseNode;
			if (strHead.ToUpper().StartsWith(parseNode.Key))
			{
				m_pnCurrent = parseNode;
				return nLevel;
			}
		}
		if (bGoChildren)
		{
			for (i = 0; i < arlParses.Count; i++)
			{
				ParseNode parseNode2 = arlParses[i] as ParseNode;
				int parseLevel = GetParseLevel(parseNode2.Children, strHead, nLevel + 1, bGoChildren: false);
				if (parseLevel != -1)
				{
					return parseLevel;
				}
			}
		}
		return -1;
	}

	private int PreParse(string strHead)
	{
		int num;
		if (m_pnCurrent == null)
		{
			num = GetParseLevel(m_arlParse, strHead, 0, bGoChildren: true);
		}
		else
		{
			num = GetParseLevel(m_pnCurrent.Children, strHead, m_nLevel + 1, bGoChildren: true);
			ParseNode parent = m_pnCurrent.Parent;
			int num2 = m_nLevel + 1;
			while (num == -1)
			{
				if (parent == null)
				{
					num = GetParseLevel(m_arlParse, strHead, 0, bGoChildren: true);
					break;
				}
				num2--;
				num = GetParseLevel(parent.Children, strHead, num2, bGoChildren: true);
				parent = parent.Parent;
				if (num == -1 && parent == null)
				{
					num = GetParseLevel(m_arlParse, strHead, 0, bGoChildren: false);
					if (num == -1)
					{
						break;
					}
				}
			}
		}
		if (num == -1)
		{
			num = m_nLevel;
		}
		return num;
	}

	private void PerParse(ref string str)
	{
		if (str.ToUpper().Trim().StartsWith("COMP") && str.ToUpper().Trim().EndsWith("DATA"))
		{
			str = "COMPONENT DATA";
		}
		if (str.ToUpper().TrimStart().StartsWith("CMPR "))
		{
			str = str.Replace("CMPR", "COMPRESSOR");
		}
		if (str.ToUpper().Trim().StartsWith("SIDE") && !str.ToUpper().Trim().StartsWith("SIDE(") && !str.ToUpper().Trim().StartsWith("SIDESTRIPPER"))
		{
			string text = str.Substring(4).Trim();
			if (str.ToUpper().Trim().EndsWith("RECTIFIER"))
			{
				str = "SIDERECTIFIER " + text;
			}
			else
			{
				str = "SIDESTRIPPER " + text;
			}
		}
		if (str.StartsWith("PROCEDURE") && !IsProcedure)
		{
			IsProcedure = true;
		}
	}

	private void Parsed(string str)
	{
		if (str.StartsWith("RETURN") && IsProcedure)
		{
			IsProcedure = false;
		}
	}

	private bool ParseNode(ref VisualBaseNode p2bObject)
	{
		bool result = false;
		string text;
		while (true)
		{
			text = m_sr.ReadLine();
			if (text == null)
			{
				return false;
			}
			text = text.ToUpper();
			text = TrimEx(text);
			PerParse(ref text);
			while (text.StartsWith("$") || TrimEx(text).Length < 1)
			{
				RetrieveVersionNumber(text);
				text = m_sr.ReadLine();
				if (text == null)
				{
					return false;
				}
				text = text.ToUpper();
				text = TrimEx(text);
				PerParse(ref text);
			}
			if (!IsBreakLine(ref text))
			{
				break;
			}
			m_strCurrent += text;
		}
		m_strCurrent += text;
		if (m_strCurrent.ToUpper() == "END")
		{
			m_strCurrent = "";
		}
		int num = m_strCurrent.IndexOf(' ');
		if (num == -1)
		{
			num = m_strCurrent.IndexOf('\t');
		}
		string text2;
		if (num != -1)
			text2 = m_strCurrent.Substring(0, num);
		else
			text2 = m_strCurrent;
		Parsed(text2);
		int num2 = PreParse(text2);
		if (num2 == m_nLevel)
		{
			if (!string.IsNullOrEmpty(m_strCurrent))
			{
				VisualBaseNode visualBaseNode = new VisualBaseNode();
				visualBaseNode.Name = m_strCurrent;
				visualBaseNode.Parent = p2bObject;
				p2bObject.Children.Add(visualBaseNode);
			}
			m_strCurrent = "";
			ParseNode(ref p2bObject);
		}
		else if (num2 > m_nLevel)
		{
			VisualBaseNode visualBaseNode2 = new VisualBaseNode();
			visualBaseNode2.Name = m_strCurrent;
			if (p2bObject.Children.Count > 0)
			{
				VisualBaseNode p2bObject2 = (VisualBaseNode)p2bObject.Children[p2bObject.Children.Count - 1];
				visualBaseNode2.Parent = p2bObject2;
				p2bObject2.Children.Add(visualBaseNode2);
				m_nLevel = num2;
				m_strCurrent = "";
				ParseNode(ref p2bObject2);
			}
		}
		else if (num2 < m_nLevel)
		{
			for (int i = num2; i < m_nLevel; i++)
			{
				p2bObject = (VisualBaseNode)p2bObject.Parent;
			}
			if (!string.IsNullOrEmpty(m_strCurrent))
			{
				VisualBaseNode visualBaseNode3 = new VisualBaseNode();
				visualBaseNode3.Name = m_strCurrent;
				visualBaseNode3.Parent = p2bObject;
				p2bObject.Children.Add(visualBaseNode3);
			}
			m_nLevel = num2;
			m_strCurrent = "";
			ParseNode(ref p2bObject);
		}
		return result;
	}

	private void RetrieveVersionNumber(string strm)
	{
		if (!strm.StartsWith("$"))
		{
			return;
		}
		if (strm.ToUpper().IndexOf("PRO/II Keyword Generation System".ToUpper()) == -1)
		{
			return;
		}
		int num = strm.ToUpper().IndexOf("<VERSION");
		int num2 = strm.IndexOf('>');
		if (num != -1 && num2 != -1)
		{
			m_strVersionNumber = strm.Substring(num + 8).Trim();
			m_strVersionNumber = m_strVersionNumber.Substring(0, m_strVersionNumber.Length - 1);
			if (m_strVersionNumber.Length > 3)
			{
				m_strVersionNumber = m_strVersionNumber.Substring(0, 3);
			}
			m_strVersionNumber = m_strVersionNumber.Replace(',', '.');
			if (double.TryParse(m_strVersionNumber, NumberStyles.Float | NumberStyles.AllowThousands, CultureInfo.InvariantCulture, out var result))
			{
				if (result >= 8.3)
				{
					IsSupportVersion = true;
				}
				else
				{
					IsSupportVersion = false;
				}
			}
		}
	}

	public P2BaseObject Parse(out VisualBaseNode txtTree)
	{
		txtTree = new VisualBaseNode();
		txtTree.Name = "PRO/II Input File";
		ParseNode(ref txtTree);
		P2BaseObject p2BaseObject = new P2BaseObject();
		p2BaseObject.Name = "PRO/II Input File";
		if (!IsSupportVersion && !string.IsNullOrEmpty(m_strVersionNumber))
		{
			DebugPrint.OutputDebugString(DebugLevel.Parse, WarningLevel.Warning, P2Globalization.GetString("OldVersionWarning"));
		}
		foreach (VisualBaseNode child in txtTree.Children)
		{
			P2BaseObject p2BaseObject2 = BuildP2Object(child);
			if (p2BaseObject2 != null)
			{
				p2BaseObject2.VisualNode = child;
				p2BaseObject.Children.Add(p2BaseObject2);
			}
		}
		return p2BaseObject;
	}
}
public class ParseNode
{
	public string Key { get; set; }

	private ArrayList children = new ArrayList();

	public ArrayList Children => children;

	public ParseNode Parent { get; set; }

	public override string ToString()
	{
		return Key;
	}
}
public class ParseNodesLoader
{
	public static ArrayList LoadParse()
	{
		ArrayList arrayList = new ArrayList();
		ParseNode parseNode = new ParseNode();
		parseNode.Key = "TITLE";
		parseNode.Children.Add(new ParseNode
		{
			Key = "DESC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "DIME",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRINT",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "SEQU",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "CALC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "DBASE",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "TOLE",
			Parent = parseNode
		});
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "COMPONENT";
		parseNode.Children.Add(new ParseNode
		{
			Key = "CURRENT",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "LIBI",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "NONL",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PETR",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PHAS",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "ASSA",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "CUT",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "TBPC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "MW",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "SPGR",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "API",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "NBP",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "ACEN",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "VC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "TC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "ZC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "RACK",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "CNUM",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "ZNUM",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "DIPO",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "RADI",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "SOLU",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "MOLV",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "STDD",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "HCOM",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "HVAP",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "HFUS",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "NMP",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PTP",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "TTP",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "GHV",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "LHV",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "SVTB",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "SLTB",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "SLTM",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "HVTB",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "HLTB",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "HLTM",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "DENS",
			Parent = parseNode
		});
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "DATASET";
		parseNode.Children.Add(new ParseNode
		{
			Key = "SETID",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "TYPE",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "FORMAT",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "COMPONENTS",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "EXPLICIT_COMPS",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PCONST",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "TCONST",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "EXPDATA",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRVP",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRDENS",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRCP",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRENTH",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRCOND",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRVISC",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PRSURF",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "TUNIT",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "PUNIT",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "ENTHUNIT",
			Parent = parseNode
		});
		parseNode.Children.Add(new ParseNode
		{
			Key = "VOLUNIT",
			Parent = parseNode
		});
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "THERMO";
		parseNode.Children.Add(new ParseNode
		{
			Key = "TRESET",
			Parent = parseNode
		});
		ParseNode parseNode2 = new ParseNode();
		parseNode2.Key = "METHOD";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		ParseNode value = new ParseNode();
		value.Key = "KVAL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "NRTL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "WATER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "STREAM";
		parseNode2 = new ParseNode();
		parseNode2.Key = "PROP";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		value = new ParseNode();
		value.Key = "D86";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TBP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "D1160";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "D2887";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "API";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SPGR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "WATSONK";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "MW";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "LIGH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "KVIS";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "NBP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode2 = new ParseNode();
		parseNode2.Key = "NAME";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "FORM";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "RXDA";
		parseNode2 = new ParseNode();
		parseNode2.Key = "RXSE";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		value = new ParseNode();
		value.Key = "REAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		ParseNode value2 = new ParseNode();
		value2.Key = "STOI";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "HORX";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "KINE";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "KPHA";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "KBAS";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "KORD";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "EQUI";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "EPHA";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "EBAS";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "EEXP";
		value2.Parent = value;
		value.Children.Add(value2);
		parseNode.Children.Add(parseNode2);
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "UNIT";
		parseNode2 = new ParseNode();
		parseNode2.Key = "COLU";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "PARA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PSPE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRES";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COND";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HEAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SPEC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "QSPE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VARY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ESTI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TEMP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VAPO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "LIQU";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CEST";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FREE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PORD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TEFF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CEFF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "EFAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HOMO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PLOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TSIZ";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TRAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PACK";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RFPR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FZON";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DUTY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "REBO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TFLO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TOLE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VLLE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RFVL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "FURN";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "SIDE(1)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SIDE(2)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SIDE(PROC)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SIDE(COMB)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "INT(3)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "INT(CORNUM)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "AIRC";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "SIDE(1)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SIDE(2)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SIDE(TUBE)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SIDE(AIR)";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "EXPA";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CONR";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RXCA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RXST";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "REAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value2 = new ParseNode();
		value2.Key = "BASE";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "CONV";
		value2.Parent = value;
		value.Children.Add(value2);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "PLUG";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RXST";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "REAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value2 = new ParseNode();
		value2.Key = "KINE";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "KORD";
		value2.Parent = value;
		value.Children.Add(value2);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RXCA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TPRO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PPRO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPEN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PACK";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CATA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COLD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "EQUR";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RXCA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RXST";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "REAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value2 = new ParseNode();
		value2.Key = "BASE";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "EQUI";
		value2.Parent = value;
		value.Children.Add(value2);
		value2 = new ParseNode();
		value2.Key = "APPR";
		value2.Parent = value;
		value.Children.Add(value2);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "GIBB";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PARA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TRIA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ELEM";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CONV";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RXST";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "REAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value2 = new ParseNode();
		value2.Key = "APPR";
		value2.Parent = value;
		value.Children.Add(value2);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "SIDESTRIPPER";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "PARA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PSPE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRES";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COND";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HEAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SPEC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "QSPE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VARY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ESTI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TEMP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VAPO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "LIQU";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CEST";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FREE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PORD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TEFF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CEFF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "EFAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HOMO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PLOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TSIZ";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TRAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PACK";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RFPR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FZON";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DUTY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "REBO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TFLO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TOLE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VLLE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RFVL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "SIDERECTIFIER";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "PARA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PSPE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRES";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COND";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HEAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SPEC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "QSPE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VARY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ESTI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TEMP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VAPO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "LIQU";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CEST";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FREE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PORD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TEFF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CEFF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "EFAC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HOMO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PLOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TSIZ";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TRAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PACK";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RFPR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FZON";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DUTY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "REBO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TFLO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TOLE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VLLE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RFVL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "LNGHX";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "HOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COLD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "FLAS";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ADIA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ISO";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "BUBB";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ENTR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CSTR";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "COMP";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRES";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HEAD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "WORK";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "EFFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PINL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "POUT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COOL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "PUMP";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "VALV";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "PIPE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "LINE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "MIXE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "HX";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "HOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COLD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CONF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "HXRI";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "TYPE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TUBE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SHEL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "BAFF";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SNOZ";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "TNOZ";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HXCA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "SPLI";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SPEC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CALC";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "RESU";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEFI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DIME";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CONS";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SEQU";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "STCA";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OVHD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "BTMS";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FOVH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "LNGH";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "COLD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "BLEN";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "IPAR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RPAR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "RESE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CONS";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CREP";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CAPE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "PROG";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PARA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "MEMB";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RPAR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "FUEL";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RPAR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "DRYE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DESI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "RFIL";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RATE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DESI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CAKE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "FCEN";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DESI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RATE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CAKE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CONT";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "SPEC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VARY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CPAR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "MVC";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "SPEC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VARY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "MVCP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CCDE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "SLUR";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "WASH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DESI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RATE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "DISS";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DESI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RATE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "MASS";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "CRYS";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CCAL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PRIN";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DESI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RATE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "GROW";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "NUCL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "MELT";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "FREE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "FEED";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROD";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "HCUR";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "ISOT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "ADIA";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "BUBT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "BUBP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "BUBT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "BUBT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEWT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DEWP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "PROP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "METH";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "HEXT";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "GENE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "DIME";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "FILE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "OPTI";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "OBJE";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "VARY";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "CONS";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "SPEC";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPTP";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "SHOR";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "UAUO";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "PHAS";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "EVAL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "BVLE";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "EVAL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "HYDR";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "EVAL";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "DEPR";
		parseNode2.Parent = parseNode;
		value = new ParseNode();
		value.Key = "VESS";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "HEAT";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "OPER";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		value = new ParseNode();
		value.Key = "RELI";
		value.Parent = parseNode2;
		parseNode2.Children.Add(value);
		parseNode.Children.Add(parseNode2);
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "RECY";
		parseNode2 = new ParseNode();
		parseNode2.Key = "ACCE";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		parseNode2 = new ParseNode();
		parseNode2.Key = "LOOP";
		parseNode2.Parent = parseNode;
		parseNode.Children.Add(parseNode2);
		arrayList.Add(parseNode);
		parseNode = new ParseNode();
		parseNode.Key = "OUTP";
		arrayList.Add(parseNode);
		return arrayList;
	}
}
