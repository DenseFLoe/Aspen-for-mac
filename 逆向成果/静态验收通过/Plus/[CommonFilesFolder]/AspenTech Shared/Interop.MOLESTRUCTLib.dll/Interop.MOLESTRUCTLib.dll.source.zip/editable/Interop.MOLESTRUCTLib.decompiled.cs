using System;
using System.Collections;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.InteropServices.ComTypes;
using System.Threading;

[assembly: Guid("3A8F5B65-608C-4FF7-85FB-77081F0F0E08")]
[assembly: ImportedFromTypeLib("MOLESTRUCTLib")]
[assembly: TypeLibVersion(4, 0)]
[assembly: AssemblyVersion("4.0.0.0")]
namespace MOLESTRUCTLib;

[ComImport]
[TypeLibType(TypeLibTypeFlags.FHidden | TypeLibTypeFlags.FDispatchable)]
[Guid("FC31C801-A2FF-44E2-9524-C9A3E3875D65")]
[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
public interface _DMoleStruct
{
	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	bool InitializeMoleFile();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void CalculateStructure();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	bool Initialize([MarshalAs(UnmanagedType.BStr)] string Casno);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-550)]
	void Refresh();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetMoleInfo([MarshalAs(UnmanagedType.BStr)] string CompName, [MarshalAs(UnmanagedType.BStr)] string MolFilePath, [MarshalAs(UnmanagedType.BStr)] string Casno);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	bool Initialize2([MarshalAs(UnmanagedType.BStr)] string Casno, [MarshalAs(UnmanagedType.BStr)] string compAlias, [MarshalAs(UnmanagedType.BStr)] string CompName);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetMoleInfo2([MarshalAs(UnmanagedType.BStr)] string CompName, [MarshalAs(UnmanagedType.BStr)] string MolFilePath, [MarshalAs(UnmanagedType.BStr)] string Casno, [MarshalAs(UnmanagedType.BStr)] string Name, [MarshalAs(UnmanagedType.BStr)] string Alias);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void SetIncludeHydrogenInCalc(bool bIncludeHydrogen);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void GetMoleInfoFromData([MarshalAs(UnmanagedType.BStr)] string MoleInfoData);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void SetupForAped();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	void GetMoleStructFromString([MarshalAs(UnmanagedType.BStr)] string MoleString);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	bool SaveForAped();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetMoleFileString();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	void SetExportButton();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	[return: MarshalAs(UnmanagedType.BStr)]
	string GetMoleFile();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	void SetApedButtons(bool bImport, bool bExport);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	void HideAllButtons();
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FDispatchable)]
[Guid("511F140C-4225-4348-9C65-55CC3AB1EE3E")]
[InterfaceType(ComInterfaceType.InterfaceIsIDispatch)]
public interface _DMoleStructEvents
{
	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void CalcStruct(int Atom1, [MarshalAs(UnmanagedType.BStr)] string Atom1Type, int Atom2, [MarshalAs(UnmanagedType.BStr)] string Atom2Type, [MarshalAs(UnmanagedType.BStr)] string BondType);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	void CleanGenTab();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	void CleanFormulaTab();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	void FillFormula([MarshalAs(UnmanagedType.BStr)] string Atom, int noAtom);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	void AfterImportStructure([MarshalAs(UnmanagedType.BStr)] string CompName, [MarshalAs(UnmanagedType.BStr)] string MolFilePath, [MarshalAs(UnmanagedType.BStr)] string MolCompress);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	void AfterSaveStructure([MarshalAs(UnmanagedType.BStr)] string MoleFileString);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	void AfterClick();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	void DelMolStruct();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	void GetCompStructureName();
}
[TypeLibType(TypeLibTypeFlags.FHidden)]
[ComEventInterface(typeof(_DMoleStructEvents), typeof(_DMoleStructEvents_EventProvider))]
[ComVisible(false)]
public interface _DMoleStructEvents_Event
{
	event _DMoleStructEvents_CalcStructEventHandler CalcStruct;

	event _DMoleStructEvents_CleanGenTabEventHandler CleanGenTab;

	event _DMoleStructEvents_CleanFormulaTabEventHandler CleanFormulaTab;

	event _DMoleStructEvents_FillFormulaEventHandler FillFormula;

	event _DMoleStructEvents_AfterImportStructureEventHandler AfterImportStructure;

	event _DMoleStructEvents_AfterSaveStructureEventHandler AfterSaveStructure;

	event _DMoleStructEvents_AfterClickEventHandler AfterClick;

	event _DMoleStructEvents_DelMolStructEventHandler DelMolStruct;

	event _DMoleStructEvents_GetCompStructureNameEventHandler GetCompStructureName;
}
[ComImport]
[CoClass(typeof(MoleStructClass))]
[Guid("FC31C801-A2FF-44E2-9524-C9A3E3875D65")]
public interface MoleStruct : _DMoleStruct, _DMoleStructEvents_Event
{
}
[ComImport]
[TypeLibType(TypeLibTypeFlags.FCanCreate | TypeLibTypeFlags.FControl)]
[Guid("D70A8D48-3E73-4F8C-8E19-90CBA7F52A0C")]
[ComSourceInterfaces("MOLESTRUCTLib._DMoleStructEvents\0\0")]
[ClassInterface(ClassInterfaceType.None)]
public class MoleStructClass
{
	public virtual extern event _DMoleStructEvents_CalcStructEventHandler CalcStruct;

	public virtual extern event _DMoleStructEvents_CleanGenTabEventHandler CleanGenTab;

	public virtual extern event _DMoleStructEvents_CleanFormulaTabEventHandler CleanFormulaTab;

	public virtual extern event _DMoleStructEvents_FillFormulaEventHandler FillFormula;

	public virtual extern event _DMoleStructEvents_AfterImportStructureEventHandler AfterImportStructure;

	public virtual extern event _DMoleStructEvents_AfterSaveStructureEventHandler AfterSaveStructure;

	public virtual extern event _DMoleStructEvents_AfterClickEventHandler AfterClick;

	public virtual extern event _DMoleStructEvents_DelMolStructEventHandler DelMolStruct;

	public virtual extern event _DMoleStructEvents_GetCompStructureNameEventHandler GetCompStructureName;

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern bool InitializeMoleFile();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(2)]
	public virtual extern void CalculateStructure();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(3)]
	public virtual extern bool Initialize([MarshalAs(UnmanagedType.BStr)] string Casno);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(-550)]
	public virtual extern void Refresh();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(4)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string GetMoleInfo([MarshalAs(UnmanagedType.BStr)] string CompName, [MarshalAs(UnmanagedType.BStr)] string MolFilePath, [MarshalAs(UnmanagedType.BStr)] string Casno);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(5)]
	public virtual extern bool Initialize2([MarshalAs(UnmanagedType.BStr)] string Casno, [MarshalAs(UnmanagedType.BStr)] string compAlias, [MarshalAs(UnmanagedType.BStr)] string CompName);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(6)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string GetMoleInfo2([MarshalAs(UnmanagedType.BStr)] string CompName, [MarshalAs(UnmanagedType.BStr)] string MolFilePath, [MarshalAs(UnmanagedType.BStr)] string Casno, [MarshalAs(UnmanagedType.BStr)] string Name, [MarshalAs(UnmanagedType.BStr)] string Alias);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(7)]
	public virtual extern void SetIncludeHydrogenInCalc(bool bIncludeHydrogen);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(8)]
	public virtual extern void GetMoleInfoFromData([MarshalAs(UnmanagedType.BStr)] string MoleInfoData);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(9)]
	public virtual extern void SetupForAped();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(10)]
	public virtual extern void GetMoleStructFromString([MarshalAs(UnmanagedType.BStr)] string MoleString);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(11)]
	public virtual extern bool SaveForAped();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(12)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string GetMoleFileString();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(13)]
	public virtual extern void SetExportButton();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(14)]
	[return: MarshalAs(UnmanagedType.BStr)]
	public virtual extern string GetMoleFile();

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(15)]
	public virtual extern void SetApedButtons(bool bImport, bool bExport);

	[MethodImpl(MethodImplOptions.PreserveSig | MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(16)]
	public virtual extern void HideAllButtons();
}
[ComVisible(false)]
public delegate void _DMoleStructEvents_CalcStructEventHandler(int Atom1, [MarshalAs(UnmanagedType.BStr)] string Atom1Type, int Atom2, [MarshalAs(UnmanagedType.BStr)] string Atom2Type, [MarshalAs(UnmanagedType.BStr)] string BondType);
[ComVisible(false)]
public delegate void _DMoleStructEvents_CleanGenTabEventHandler();
[ComVisible(false)]
public delegate void _DMoleStructEvents_CleanFormulaTabEventHandler();
[ComVisible(false)]
public delegate void _DMoleStructEvents_FillFormulaEventHandler([MarshalAs(UnmanagedType.BStr)] string Atom, int noAtom);
[ComVisible(false)]
public delegate void _DMoleStructEvents_AfterImportStructureEventHandler([MarshalAs(UnmanagedType.BStr)] string CompName, [MarshalAs(UnmanagedType.BStr)] string MolFilePath, [MarshalAs(UnmanagedType.BStr)] string MolCompress);
[ComVisible(false)]
public delegate void _DMoleStructEvents_AfterSaveStructureEventHandler([MarshalAs(UnmanagedType.BStr)] string MoleFileString);
[ComVisible(false)]
public delegate void _DMoleStructEvents_AfterClickEventHandler();
[ComVisible(false)]
public delegate void _DMoleStructEvents_DelMolStructEventHandler();
[ComVisible(false)]
public delegate void _DMoleStructEvents_GetCompStructureNameEventHandler();
[TypeLibType(TypeLibTypeFlags.FHidden)]
[ClassInterface(ClassInterfaceType.None)]
public sealed class _DMoleStructEvents_SinkHelper : _DMoleStructEvents
{
	public _DMoleStructEvents_CalcStructEventHandler m_CalcStructDelegate;

	public _DMoleStructEvents_CleanGenTabEventHandler m_CleanGenTabDelegate;

	public _DMoleStructEvents_CleanFormulaTabEventHandler m_CleanFormulaTabDelegate;

	public _DMoleStructEvents_FillFormulaEventHandler m_FillFormulaDelegate;

	public _DMoleStructEvents_AfterImportStructureEventHandler m_AfterImportStructureDelegate;

	public _DMoleStructEvents_AfterSaveStructureEventHandler m_AfterSaveStructureDelegate;

	public _DMoleStructEvents_AfterClickEventHandler m_AfterClickDelegate;

	public _DMoleStructEvents_DelMolStructEventHandler m_DelMolStructDelegate;

	public _DMoleStructEvents_GetCompStructureNameEventHandler m_GetCompStructureNameDelegate;

	public int m_dwCookie;

	public void CalcStruct(int P_0, string P_1, int P_2, string P_3, string P_4)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_CalcStructDelegate != null)
		{
			m_CalcStructDelegate(P_0, P_1, P_2, P_3, P_4);
		}
	}

	public void CleanGenTab()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_CleanGenTabDelegate != null)
		{
			m_CleanGenTabDelegate();
		}
	}

	public void CleanFormulaTab()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_CleanFormulaTabDelegate != null)
		{
			m_CleanFormulaTabDelegate();
		}
	}

	public void FillFormula(string P_0, int P_1)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_FillFormulaDelegate != null)
		{
			m_FillFormulaDelegate(P_0, P_1);
		}
	}

	public void AfterImportStructure(string P_0, string P_1, string P_2)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_AfterImportStructureDelegate != null)
		{
			m_AfterImportStructureDelegate(P_0, P_1, P_2);
		}
	}

	public void AfterSaveStructure(string P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_AfterSaveStructureDelegate != null)
		{
			m_AfterSaveStructureDelegate(P_0);
		}
	}

	public void AfterClick()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_AfterClickDelegate != null)
		{
			m_AfterClickDelegate();
		}
	}

	public void DelMolStruct()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_DelMolStructDelegate != null)
		{
			m_DelMolStructDelegate();
		}
	}

	public void GetCompStructureName()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		if (m_GetCompStructureNameDelegate != null)
		{
			m_GetCompStructureNameDelegate();
		}
	}

	internal _DMoleStructEvents_SinkHelper()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_dwCookie = 0;
		m_CalcStructDelegate = null;
		m_CleanGenTabDelegate = null;
		m_CleanFormulaTabDelegate = null;
		m_FillFormulaDelegate = null;
		m_AfterImportStructureDelegate = null;
		m_AfterSaveStructureDelegate = null;
		m_AfterClickDelegate = null;
		m_DelMolStructDelegate = null;
		m_GetCompStructureNameDelegate = null;
	}
}
internal sealed class _DMoleStructEvents_EventProvider : IDisposable
{
	private WeakReference m_wkConnectionPointContainer;

	private ArrayList m_aEventSinkHelpers;

	private IConnectionPoint m_ConnectionPoint;

	private void Init()
	{
		IConnectionPoint ppCP = null;
		byte[] guidBytes = new byte[16];
guidBytes[0] = 12;
guidBytes[1] = 20;
guidBytes[2] = 31;
guidBytes[3] = 81;
guidBytes[4] = 37;
guidBytes[5] = 66;
guidBytes[6] = 72;
guidBytes[7] = 67;
guidBytes[8] = 156;
guidBytes[9] = 101;
guidBytes[10] = 85;
guidBytes[11] = 204;
guidBytes[12] = 58;
guidBytes[13] = 177;
guidBytes[14] = 238;
guidBytes[15] = 62;
Guid riid = new Guid(guidBytes);
		((IConnectionPointContainer)m_wkConnectionPointContainer.Target).FindConnectionPoint(ref riid, out ppCP);
		m_ConnectionPoint = ppCP;
		m_aEventSinkHelpers = new ArrayList();
	}

	public void add_CalcStruct(_DMoleStructEvents_CalcStructEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_CalcStructDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_CalcStruct(_DMoleStructEvents_CalcStructEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_CalcStructDelegate != null && ((dMoleStructEvents_SinkHelper.m_CalcStructDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_CleanGenTab(_DMoleStructEvents_CleanGenTabEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_CleanGenTabDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_CleanGenTab(_DMoleStructEvents_CleanGenTabEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_CleanGenTabDelegate != null && ((dMoleStructEvents_SinkHelper.m_CleanGenTabDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_CleanFormulaTab(_DMoleStructEvents_CleanFormulaTabEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_CleanFormulaTabDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_CleanFormulaTab(_DMoleStructEvents_CleanFormulaTabEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_CleanFormulaTabDelegate != null && ((dMoleStructEvents_SinkHelper.m_CleanFormulaTabDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_FillFormula(_DMoleStructEvents_FillFormulaEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_FillFormulaDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_FillFormula(_DMoleStructEvents_FillFormulaEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_FillFormulaDelegate != null && ((dMoleStructEvents_SinkHelper.m_FillFormulaDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_AfterImportStructure(_DMoleStructEvents_AfterImportStructureEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_AfterImportStructureDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_AfterImportStructure(_DMoleStructEvents_AfterImportStructureEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_AfterImportStructureDelegate != null && ((dMoleStructEvents_SinkHelper.m_AfterImportStructureDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_AfterSaveStructure(_DMoleStructEvents_AfterSaveStructureEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_AfterSaveStructureDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_AfterSaveStructure(_DMoleStructEvents_AfterSaveStructureEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_AfterSaveStructureDelegate != null && ((dMoleStructEvents_SinkHelper.m_AfterSaveStructureDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_AfterClick(_DMoleStructEvents_AfterClickEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_AfterClickDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_AfterClick(_DMoleStructEvents_AfterClickEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_AfterClickDelegate != null && ((dMoleStructEvents_SinkHelper.m_AfterClickDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_DelMolStruct(_DMoleStructEvents_DelMolStructEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_DelMolStructDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_DelMolStruct(_DMoleStructEvents_DelMolStructEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_DelMolStructDelegate != null && ((dMoleStructEvents_SinkHelper.m_DelMolStructDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void add_GetCompStructureName(_DMoleStructEvents_GetCompStructureNameEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint == null)
			{
				Init();
			}
			_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = new _DMoleStructEvents_SinkHelper();
			int pdwCookie = 0;
			m_ConnectionPoint.Advise(dMoleStructEvents_SinkHelper, out pdwCookie);
			dMoleStructEvents_SinkHelper.m_dwCookie = pdwCookie;
			dMoleStructEvents_SinkHelper.m_GetCompStructureNameDelegate = P_0;
			m_aEventSinkHelpers.Add(dMoleStructEvents_SinkHelper);
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void remove_GetCompStructureName(_DMoleStructEvents_GetCompStructureNameEventHandler P_0)
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_aEventSinkHelpers != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
			do
			{
				_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
				if (dMoleStructEvents_SinkHelper.m_GetCompStructureNameDelegate != null && ((dMoleStructEvents_SinkHelper.m_GetCompStructureNameDelegate.Equals(P_0) ? 1u : 0u) & 0xFFu) != 0)
				{
					m_aEventSinkHelpers.RemoveAt(num);
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					if (count <= 1)
					{
						Marshal.ReleaseComObject(m_ConnectionPoint);
						m_ConnectionPoint = null;
						m_aEventSinkHelpers = null;
					}
					break;
				}
				num++;
			}
			while (num < count);
			}
			}
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public _DMoleStructEvents_EventProvider(object P_0)
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		m_wkConnectionPointContainer = new WeakReference((IConnectionPointContainer)P_0, trackResurrection: false);
	}

	public void Finalize()
	{
		bool lockTaken = default(bool);
		try
		{
			Monitor.Enter(this, ref lockTaken);
			if (m_ConnectionPoint != null)
			{
			int count = m_aEventSinkHelpers.Count;
			int num = 0;
			if (0 < count)
			{
				do
				{
					_DMoleStructEvents_SinkHelper dMoleStructEvents_SinkHelper = (_DMoleStructEvents_SinkHelper)m_aEventSinkHelpers[num];
					m_ConnectionPoint.Unadvise(dMoleStructEvents_SinkHelper.m_dwCookie);
					num++;
				}
				while (num < count);
			}
			Marshal.ReleaseComObject(m_ConnectionPoint);
			}
		}
		catch (Exception)
		{
		}
		finally
		{
			if (lockTaken)
			{
				Monitor.Exit(this);
			}
		}
	}

	public void Dispose()
	{
		//Error decoding local variables: Signature type sequence must have at least one element.
		Finalize();
		GC.SuppressFinalize(this);
	}
}
