﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  MOLESTRUCTLib._DMoleStruct
  MOLESTRUCTLib._DMoleStructEvents
  MOLESTRUCTLib._DMoleStructEvents_Event
  MOLESTRUCTLib.MoleStruct
  MOLESTRUCTLib.MoleStructClass
  MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler
  MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler
  MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler
  MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler
  MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler
  MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler
  MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler
  MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler
  MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler
  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
  MOLESTRUCTLib._DMoleStructEvents_EventProvider
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly Interop.MOLESTRUCTLib
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 41 38 46 35 42 36 35 2D 36 30 38 43   // ..$3A8F5B65-608C
                                                                                                  2D 34 46 46 37 2D 38 35 46 42 2D 37 37 30 38 31   // -4FF7-85FB-77081
                                                                                                  46 30 46 30 45 30 38 00 00 )                      // F0F0E08..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ImportedFromTypeLibAttribute::.ctor(string) = ( 01 00 0D 4D 4F 4C 45 53 54 52 55 43 54 4C 69 62   // ...MOLESTRUCTLib
                                                                                                                 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(int32,
                                                                                                int32) = ( 01 00 04 00 00 00 00 00 00 00 00 00 ) 
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                6F 3E E5 88 66 FF AB 8E B7 56 CB 2B 21 14 5F E5   // o>..f....V.+!._.
                68 1C 6E 59 6D D1 B6 77 CC E9 B7 23 17 37 C7 8E   // h.nYm..w...#.7..
                D6 75 CE DD E2 D7 6E BB 8C F3 D7 68 D6 0F EE 51   // .u....n....h...Q
                CD CA F9 96 C1 15 04 1E AC 4B 7E 4E 66 45 D7 47   // .........K~NfE.G
                9F 9F F8 49 31 7C CA EF D4 4C B2 75 69 22 A4 63   // ...I1|...L.ui".c
                E0 7E 90 BB 02 A3 FE 56 07 74 45 BB 2B DC B3 D2   // .~.....V.tE.+...
                46 1C 79 BD 13 90 92 10 54 8E A3 42 49 09 F9 C1   // F.y.....T..BI...
                18 CD 6A AB EE 1A 34 63 CE C5 FA BA 82 15 40 AF ) // ..j...4c......@.
  .hash algorithm 0x00008004
  .ver 4:0:0:0
}
.module Interop.MOLESTRUCTLib.dll
// MVID: {208642cd-c088-4ea2-8c8b-b236b3f59832}
.imagebase 0x00400000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x000001292A5D0000


// =============== CLASS MEMBERS DECLARATION ===================

.class interface public abstract auto ansi import MOLESTRUCTLib._DMoleStruct
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 10 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 43 33 31 43 38 30 31 2D 41 32 46 46   // ..$FC31C801-A2FF
                                                                                                  2D 34 34 45 32 2D 39 35 32 34 2D 43 39 41 33 45   // -44E2-9524-C9A3E
                                                                                                  33 38 37 35 44 36 35 00 00 )                      // 3875D65..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance bool  InitializeMoleFile() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::InitializeMoleFile

  .method public hidebysig newslot abstract virtual 
          instance void  CalculateStructure() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::CalculateStructure

  .method public hidebysig newslot abstract virtual 
          instance bool  Initialize(string  marshal( bstr) Casno) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::Initialize

  .method public hidebysig newslot abstract virtual 
          instance void  Refresh() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 DA FD FF FF 00 00 ) 
  } // end of method _DMoleStruct::Refresh

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetMoleInfo(string  marshal( bstr) CompName,
                      string  marshal( bstr) MolFilePath,
                      string  marshal( bstr) Casno) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::GetMoleInfo

  .method public hidebysig newslot abstract virtual 
          instance bool  Initialize2(string  marshal( bstr) Casno,
                                     string  marshal( bstr) compAlias,
                                     string  marshal( bstr) CompName) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::Initialize2

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetMoleInfo2(string  marshal( bstr) CompName,
                       string  marshal( bstr) MolFilePath,
                       string  marshal( bstr) Casno,
                       string  marshal( bstr) Name,
                       string  marshal( bstr) Alias) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::GetMoleInfo2

  .method public hidebysig newslot abstract virtual 
          instance void  SetIncludeHydrogenInCalc(bool bIncludeHydrogen) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::SetIncludeHydrogenInCalc

  .method public hidebysig newslot abstract virtual 
          instance void  GetMoleInfoFromData(string  marshal( bstr) MoleInfoData) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::GetMoleInfoFromData

  .method public hidebysig newslot abstract virtual 
          instance void  SetupForAped() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::SetupForAped

  .method public hidebysig newslot abstract virtual 
          instance void  GetMoleStructFromString(string  marshal( bstr) MoleString) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::GetMoleStructFromString

  .method public hidebysig newslot abstract virtual 
          instance bool  SaveForAped() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::SaveForAped

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetMoleFileString() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::GetMoleFileString

  .method public hidebysig newslot abstract virtual 
          instance void  SetExportButton() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::SetExportButton

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetMoleFile() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::GetMoleFile

  .method public hidebysig newslot abstract virtual 
          instance void  SetApedButtons(bool bImport,
                                        bool bExport) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::SetApedButtons

  .method public hidebysig newslot abstract virtual 
          instance void  HideAllButtons() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 00 00 00 00 ) 
  } // end of method _DMoleStruct::HideAllButtons

} // end of class MOLESTRUCTLib._DMoleStruct

.class interface public abstract auto ansi import MOLESTRUCTLib._DMoleStructEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 00 10 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 35 31 31 46 31 34 30 43 2D 34 32 32 35   // ..$511F140C-4225
                                                                                                  2D 34 33 34 38 2D 39 43 36 35 2D 35 35 43 43 33   // -4348-9C65-55CC3
                                                                                                  41 42 31 45 45 33 45 00 00 )                      // AB1EE3E..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 02 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  CalcStruct(int32 Atom1,
                                    string  marshal( bstr) Atom1Type,
                                    int32 Atom2,
                                    string  marshal( bstr) Atom2Type,
                                    string  marshal( bstr) BondType) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::CalcStruct

  .method public hidebysig newslot abstract virtual 
          instance void  CleanGenTab() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::CleanGenTab

  .method public hidebysig newslot abstract virtual 
          instance void  CleanFormulaTab() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::CleanFormulaTab

  .method public hidebysig newslot abstract virtual 
          instance void  FillFormula(string  marshal( bstr) Atom,
                                     int32 noAtom) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::FillFormula

  .method public hidebysig newslot abstract virtual 
          instance void  AfterImportStructure(string  marshal( bstr) CompName,
                                              string  marshal( bstr) MolFilePath,
                                              string  marshal( bstr) MolCompress) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::AfterImportStructure

  .method public hidebysig newslot abstract virtual 
          instance void  AfterSaveStructure(string  marshal( bstr) MoleFileString) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::AfterSaveStructure

  .method public hidebysig newslot abstract virtual 
          instance void  AfterClick() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::AfterClick

  .method public hidebysig newslot abstract virtual 
          instance void  DelMolStruct() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::DelMolStruct

  .method public hidebysig newslot abstract virtual 
          instance void  GetCompStructureName() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 00 00 00 00 ) 
  } // end of method _DMoleStructEvents::GetCompStructureName

} // end of class MOLESTRUCTLib._DMoleStructEvents

.class interface public abstract auto ansi MOLESTRUCTLib._DMoleStructEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComEventInterfaceAttribute::.ctor(class [mscorlib]System.Type,
                                                                                                   class [mscorlib]System.Type) = ( 01 00 20 4D 4F 4C 45 53 54 52 55 43 54 4C 69 62   // .. MOLESTRUCTLib
                                                                                                                                    2E 5F 44 4D 6F 6C 65 53 74 72 75 63 74 45 76 65   // ._DMoleStructEve
                                                                                                                                    6E 74 73 2E 4D 4F 4C 45 53 54 52 55 43 54 4C 69   // nts.MOLESTRUCTLi
                                                                                                                                    62 2E 5F 44 4D 6F 6C 65 53 74 72 75 63 74 45 76   // b._DMoleStructEv
                                                                                                                                    65 6E 74 73 5F 45 76 65 6E 74 50 72 6F 76 69 64   // ents_EventProvid
                                                                                                                                    65 72 00 00 )                                     // er..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  add_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_CalcStruct

  .method public hidebysig newslot abstract virtual 
          instance void  remove_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_CalcStruct

  .method public hidebysig newslot abstract virtual 
          instance void  add_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_CleanGenTab

  .method public hidebysig newslot abstract virtual 
          instance void  remove_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_CleanGenTab

  .method public hidebysig newslot abstract virtual 
          instance void  add_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_CleanFormulaTab

  .method public hidebysig newslot abstract virtual 
          instance void  remove_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_CleanFormulaTab

  .method public hidebysig newslot abstract virtual 
          instance void  add_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_FillFormula

  .method public hidebysig newslot abstract virtual 
          instance void  remove_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_FillFormula

  .method public hidebysig newslot abstract virtual 
          instance void  add_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_AfterImportStructure

  .method public hidebysig newslot abstract virtual 
          instance void  remove_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_AfterImportStructure

  .method public hidebysig newslot abstract virtual 
          instance void  add_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_AfterSaveStructure

  .method public hidebysig newslot abstract virtual 
          instance void  remove_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_AfterSaveStructure

  .method public hidebysig newslot abstract virtual 
          instance void  add_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_AfterClick

  .method public hidebysig newslot abstract virtual 
          instance void  remove_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_AfterClick

  .method public hidebysig newslot abstract virtual 
          instance void  add_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_DelMolStruct

  .method public hidebysig newslot abstract virtual 
          instance void  remove_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_DelMolStruct

  .method public hidebysig newslot abstract virtual 
          instance void  add_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::add_GetCompStructureName

  .method public hidebysig newslot abstract virtual 
          instance void  remove_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler A_1) runtime managed internalcall
  {
  } // end of method _DMoleStructEvents_Event::remove_GetCompStructureName

  .event MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler CalcStruct
  {
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler)
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler)
  } // end of event _DMoleStructEvents_Event::CalcStruct
  .event MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler CleanGenTab
  {
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler)
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler)
  } // end of event _DMoleStructEvents_Event::CleanGenTab
  .event MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler CleanFormulaTab
  {
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler)
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler)
  } // end of event _DMoleStructEvents_Event::CleanFormulaTab
  .event MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler FillFormula
  {
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler)
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler)
  } // end of event _DMoleStructEvents_Event::FillFormula
  .event MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AfterImportStructure
  {
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler)
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler)
  } // end of event _DMoleStructEvents_Event::AfterImportStructure
  .event MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AfterSaveStructure
  {
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler)
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler)
  } // end of event _DMoleStructEvents_Event::AfterSaveStructure
  .event MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler AfterClick
  {
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler)
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler)
  } // end of event _DMoleStructEvents_Event::AfterClick
  .event MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler DelMolStruct
  {
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler)
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler)
  } // end of event _DMoleStructEvents_Event::DelMolStruct
  .event MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler GetCompStructureName
  {
    .removeon instance void MOLESTRUCTLib._DMoleStructEvents_Event::remove_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler)
    .addon instance void MOLESTRUCTLib._DMoleStructEvents_Event::add_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler)
  } // end of event _DMoleStructEvents_Event::GetCompStructureName
} // end of class MOLESTRUCTLib._DMoleStructEvents_Event

.class interface public abstract auto ansi import MOLESTRUCTLib.MoleStruct
       implements MOLESTRUCTLib._DMoleStruct,
                  MOLESTRUCTLib._DMoleStructEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 1D 4D 4F 4C 45 53 54 52 55 43 54 4C 69 62   // ...MOLESTRUCTLib
                                                                                                                          2E 4D 6F 6C 65 53 74 72 75 63 74 43 6C 61 73 73   // .MoleStructClass
                                                                                                                          00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 43 33 31 43 38 30 31 2D 41 32 46 46   // ..$FC31C801-A2FF
                                                                                                  2D 34 34 45 32 2D 39 35 32 34 2D 43 39 41 33 45   // -44E2-9524-C9A3E
                                                                                                  33 38 37 35 44 36 35 00 00 )                      // 3875D65..
} // end of class MOLESTRUCTLib.MoleStruct

.class public auto ansi import MOLESTRUCTLib.MoleStructClass
       extends [mscorlib]System.Object
       implements MOLESTRUCTLib._DMoleStruct,
                  MOLESTRUCTLib.MoleStruct,
                  MOLESTRUCTLib._DMoleStructEvents_Event
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 22 00 00 00 00 00 )                         // ..".....
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 44 37 30 41 38 44 34 38 2D 33 45 37 33   // ..$D70A8D48-3E73
                                                                                                  2D 34 46 38 43 2D 38 45 31 39 2D 39 30 43 42 41   // -4F8C-8E19-90CBA
                                                                                                  37 46 35 32 41 30 43 00 00 )                      // 7F52A0C..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComSourceInterfacesAttribute::.ctor(string) = ( 01 00 22 4D 4F 4C 45 53 54 52 55 43 54 4C 69 62   // .."MOLESTRUCTLib
                                                                                                                 2E 5F 44 4D 6F 6C 65 53 74 72 75 63 74 45 76 65   // ._DMoleStructEve
                                                                                                                 6E 74 73 00 00 00 00 )                            // nts....
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method MoleStructClass::.ctor

  .method public hidebysig newslot virtual 
          instance bool  InitializeMoleFile() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::InitializeMoleFile
  } // end of method MoleStructClass::InitializeMoleFile

  .method public hidebysig newslot virtual 
          instance void  CalculateStructure() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::CalculateStructure
  } // end of method MoleStructClass::CalculateStructure

  .method public hidebysig newslot virtual 
          instance bool  Initialize(string  marshal( bstr) Casno) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::Initialize
  } // end of method MoleStructClass::Initialize

  .method public hidebysig newslot virtual 
          instance void  Refresh() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 DA FD FF FF 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::Refresh
  } // end of method MoleStructClass::Refresh

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetMoleInfo(string  marshal( bstr) CompName,
                      string  marshal( bstr) MolFilePath,
                      string  marshal( bstr) Casno) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::GetMoleInfo
  } // end of method MoleStructClass::GetMoleInfo

  .method public hidebysig newslot virtual 
          instance bool  Initialize2(string  marshal( bstr) Casno,
                                     string  marshal( bstr) compAlias,
                                     string  marshal( bstr) CompName) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::Initialize2
  } // end of method MoleStructClass::Initialize2

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetMoleInfo2(string  marshal( bstr) CompName,
                       string  marshal( bstr) MolFilePath,
                       string  marshal( bstr) Casno,
                       string  marshal( bstr) Name,
                       string  marshal( bstr) Alias) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::GetMoleInfo2
  } // end of method MoleStructClass::GetMoleInfo2

  .method public hidebysig newslot virtual 
          instance void  SetIncludeHydrogenInCalc(bool bIncludeHydrogen) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 07 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::SetIncludeHydrogenInCalc
  } // end of method MoleStructClass::SetIncludeHydrogenInCalc

  .method public hidebysig newslot virtual 
          instance void  GetMoleInfoFromData(string  marshal( bstr) MoleInfoData) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::GetMoleInfoFromData
  } // end of method MoleStructClass::GetMoleInfoFromData

  .method public hidebysig newslot virtual 
          instance void  SetupForAped() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 09 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::SetupForAped
  } // end of method MoleStructClass::SetupForAped

  .method public hidebysig newslot virtual 
          instance void  GetMoleStructFromString(string  marshal( bstr) MoleString) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0A 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::GetMoleStructFromString
  } // end of method MoleStructClass::GetMoleStructFromString

  .method public hidebysig newslot virtual 
          instance bool  SaveForAped() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0B 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::SaveForAped
  } // end of method MoleStructClass::SaveForAped

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetMoleFileString() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0C 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::GetMoleFileString
  } // end of method MoleStructClass::GetMoleFileString

  .method public hidebysig newslot virtual 
          instance void  SetExportButton() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0D 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::SetExportButton
  } // end of method MoleStructClass::SetExportButton

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetMoleFile() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0E 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::GetMoleFile
  } // end of method MoleStructClass::GetMoleFile

  .method public hidebysig newslot virtual 
          instance void  SetApedButtons(bool bImport,
                                        bool bExport) runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 0F 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::SetApedButtons
  } // end of method MoleStructClass::SetApedButtons

  .method public hidebysig newslot virtual 
          instance void  HideAllButtons() runtime managed preservesig internalcall
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 10 00 00 00 00 00 ) 
    .override MOLESTRUCTLib._DMoleStruct::HideAllButtons
  } // end of method MoleStructClass::HideAllButtons

  .method public hidebysig newslot virtual 
          instance void  add_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_CalcStruct
  } // end of method MoleStructClass::add_CalcStruct

  .method public hidebysig newslot virtual 
          instance void  remove_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_CalcStruct
  } // end of method MoleStructClass::remove_CalcStruct

  .method public hidebysig newslot virtual 
          instance void  add_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_CleanGenTab
  } // end of method MoleStructClass::add_CleanGenTab

  .method public hidebysig newslot virtual 
          instance void  remove_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_CleanGenTab
  } // end of method MoleStructClass::remove_CleanGenTab

  .method public hidebysig newslot virtual 
          instance void  add_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_CleanFormulaTab
  } // end of method MoleStructClass::add_CleanFormulaTab

  .method public hidebysig newslot virtual 
          instance void  remove_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_CleanFormulaTab
  } // end of method MoleStructClass::remove_CleanFormulaTab

  .method public hidebysig newslot virtual 
          instance void  add_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_FillFormula
  } // end of method MoleStructClass::add_FillFormula

  .method public hidebysig newslot virtual 
          instance void  remove_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_FillFormula
  } // end of method MoleStructClass::remove_FillFormula

  .method public hidebysig newslot virtual 
          instance void  add_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_AfterImportStructure
  } // end of method MoleStructClass::add_AfterImportStructure

  .method public hidebysig newslot virtual 
          instance void  remove_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_AfterImportStructure
  } // end of method MoleStructClass::remove_AfterImportStructure

  .method public hidebysig newslot virtual 
          instance void  add_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_AfterSaveStructure
  } // end of method MoleStructClass::add_AfterSaveStructure

  .method public hidebysig newslot virtual 
          instance void  remove_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_AfterSaveStructure
  } // end of method MoleStructClass::remove_AfterSaveStructure

  .method public hidebysig newslot virtual 
          instance void  add_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_AfterClick
  } // end of method MoleStructClass::add_AfterClick

  .method public hidebysig newslot virtual 
          instance void  remove_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_AfterClick
  } // end of method MoleStructClass::remove_AfterClick

  .method public hidebysig newslot virtual 
          instance void  add_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_DelMolStruct
  } // end of method MoleStructClass::add_DelMolStruct

  .method public hidebysig newslot virtual 
          instance void  remove_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_DelMolStruct
  } // end of method MoleStructClass::remove_DelMolStruct

  .method public hidebysig newslot virtual 
          instance void  add_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::add_GetCompStructureName
  } // end of method MoleStructClass::add_GetCompStructureName

  .method public hidebysig newslot virtual 
          instance void  remove_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler A_1) runtime managed internalcall
  {
    .override MOLESTRUCTLib._DMoleStructEvents_Event::remove_GetCompStructureName
  } // end of method MoleStructClass::remove_GetCompStructureName

  .event MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler CalcStruct
  {
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler)
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler)
  } // end of event MoleStructClass::CalcStruct
  .event MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler CleanGenTab
  {
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler)
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler)
  } // end of event MoleStructClass::CleanGenTab
  .event MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler CleanFormulaTab
  {
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler)
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler)
  } // end of event MoleStructClass::CleanFormulaTab
  .event MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler FillFormula
  {
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler)
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler)
  } // end of event MoleStructClass::FillFormula
  .event MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AfterImportStructure
  {
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler)
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler)
  } // end of event MoleStructClass::AfterImportStructure
  .event MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AfterSaveStructure
  {
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler)
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler)
  } // end of event MoleStructClass::AfterSaveStructure
  .event MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler AfterClick
  {
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler)
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler)
  } // end of event MoleStructClass::AfterClick
  .event MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler DelMolStruct
  {
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler)
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler)
  } // end of event MoleStructClass::DelMolStruct
  .event MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler GetCompStructureName
  {
    .addon instance void MOLESTRUCTLib.MoleStructClass::add_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler)
    .removeon instance void MOLESTRUCTLib.MoleStructClass::remove_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler)
  } // end of event MoleStructClass::GetCompStructureName
} // end of class MOLESTRUCTLib.MoleStructClass

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_CalcStructEventHandler::.ctor

  .method public virtual instance void  Invoke(int32 Atom1,
                                               string  marshal( bstr) Atom1Type,
                                               int32 Atom2,
                                               string  marshal( bstr) Atom2Type,
                                               string  marshal( bstr) BondType) runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_CalcStructEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_CleanGenTabEventHandler::.ctor

  .method public virtual instance void  Invoke() runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_CleanGenTabEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_CleanFormulaTabEventHandler::.ctor

  .method public virtual instance void  Invoke() runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_CleanFormulaTabEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_FillFormulaEventHandler::.ctor

  .method public virtual instance void  Invoke(string  marshal( bstr) Atom,
                                               int32 noAtom) runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_FillFormulaEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_AfterImportStructureEventHandler::.ctor

  .method public virtual instance void  Invoke(string  marshal( bstr) CompName,
                                               string  marshal( bstr) MolFilePath,
                                               string  marshal( bstr) MolCompress) runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_AfterImportStructureEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_AfterSaveStructureEventHandler::.ctor

  .method public virtual instance void  Invoke(string  marshal( bstr) MoleFileString) runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_AfterSaveStructureEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_AfterClickEventHandler::.ctor

  .method public virtual instance void  Invoke() runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_AfterClickEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_DelMolStructEventHandler::.ctor

  .method public virtual instance void  Invoke() runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_DelMolStructEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ComVisibleAttribute::.ctor(bool) = ( 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor(object A_1,
                               native uint A_2) runtime managed
  {
  } // end of method _DMoleStructEvents_GetCompStructureNameEventHandler::.ctor

  .method public virtual instance void  Invoke() runtime managed preservesig
  {
  } // end of method _DMoleStructEvents_GetCompStructureNameEventHandler::Invoke

} // end of class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler

.class public auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_SinkHelper
       extends [mscorlib]System.Object
       implements MOLESTRUCTLib._DMoleStructEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .field public class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler m_CalcStructDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler m_CleanGenTabDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler m_CleanFormulaTabDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler m_FillFormulaDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler m_AfterImportStructureDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler m_AfterSaveStructureDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler m_AfterClickDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler m_DelMolStructDelegate
  .field public class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler m_GetCompStructureNameDelegate
  .field public int32 m_dwCookie
  .method public virtual instance void  CalcStruct(int32 A_1,
                                                   string A_2,
                                                   int32 A_3,
                                                   string A_4,
                                                   string A_5) cil managed
  {
    // Code size       50 (0x32)
    .maxstack  6
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CalcStructDelegate
    IL_0009:  brfalse    IL_0031

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CalcStructDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  ldarg      A_2
    IL_001f:  ldarg      A_3
    IL_0023:  ldarg      A_4
    IL_0027:  ldarg      A_5
    IL_002b:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler::Invoke(int32,
                                                                                                       string,
                                                                                                       int32,
                                                                                                       string,
                                                                                                       string)
    IL_0030:  ret

    IL_0031:  ret
  } // end of method _DMoleStructEvents_SinkHelper::CalcStruct

  .method public virtual instance void  CleanGenTab() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  1
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanGenTabDelegate
    IL_0009:  brfalse    IL_001d

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanGenTabDelegate
    IL_0017:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler::Invoke()
    IL_001c:  ret

    IL_001d:  ret
  } // end of method _DMoleStructEvents_SinkHelper::CleanGenTab

  .method public virtual instance void  CleanFormulaTab() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  1
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanFormulaTabDelegate
    IL_0009:  brfalse    IL_001d

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanFormulaTabDelegate
    IL_0017:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler::Invoke()
    IL_001c:  ret

    IL_001d:  ret
  } // end of method _DMoleStructEvents_SinkHelper::CleanFormulaTab

  .method public virtual instance void  FillFormula(string A_1,
                                                    int32 A_2) cil managed
  {
    // Code size       38 (0x26)
    .maxstack  3
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_FillFormulaDelegate
    IL_0009:  brfalse    IL_0025

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_FillFormulaDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  ldarg      A_2
    IL_001f:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler::Invoke(string,
                                                                                                        int32)
    IL_0024:  ret

    IL_0025:  ret
  } // end of method _DMoleStructEvents_SinkHelper::FillFormula

  .method public virtual instance void  AfterImportStructure(string A_1,
                                                             string A_2,
                                                             string A_3) cil managed
  {
    // Code size       42 (0x2a)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterImportStructureDelegate
    IL_0009:  brfalse    IL_0029

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterImportStructureDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  ldarg      A_2
    IL_001f:  ldarg      A_3
    IL_0023:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler::Invoke(string,
                                                                                                                 string,
                                                                                                                 string)
    IL_0028:  ret

    IL_0029:  ret
  } // end of method _DMoleStructEvents_SinkHelper::AfterImportStructure

  .method public virtual instance void  AfterSaveStructure(string A_1) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterSaveStructureDelegate
    IL_0009:  brfalse    IL_0021

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterSaveStructureDelegate
    IL_0017:  ldarg      A_1
    IL_001b:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler::Invoke(string)
    IL_0020:  ret

    IL_0021:  ret
  } // end of method _DMoleStructEvents_SinkHelper::AfterSaveStructure

  .method public virtual instance void  AfterClick() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  1
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterClickDelegate
    IL_0009:  brfalse    IL_001d

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterClickDelegate
    IL_0017:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler::Invoke()
    IL_001c:  ret

    IL_001d:  ret
  } // end of method _DMoleStructEvents_SinkHelper::AfterClick

  .method public virtual instance void  DelMolStruct() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  1
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_DelMolStructDelegate
    IL_0009:  brfalse    IL_001d

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_DelMolStructDelegate
    IL_0017:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler::Invoke()
    IL_001c:  ret

    IL_001d:  ret
  } // end of method _DMoleStructEvents_SinkHelper::DelMolStruct

  .method public virtual instance void  GetCompStructureName() cil managed
  {
    // Code size       30 (0x1e)
    .maxstack  1
    IL_0000:  ldarg      0
    IL_0004:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_GetCompStructureNameDelegate
    IL_0009:  brfalse    IL_001d

    IL_000e:  ldarg      0
    IL_0012:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_GetCompStructureNameDelegate
    IL_0017:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler::Invoke()
    IL_001c:  ret

    IL_001d:  ret
  } // end of method _DMoleStructEvents_SinkHelper::GetCompStructureName

  .method assembly specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       114 (0x72)
    .maxstack  4
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldc.i4     0x0
    IL_0012:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
    IL_0017:  ldarg      0
    IL_001b:  ldnull
    IL_001c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CalcStructDelegate
    IL_0021:  ldarg      0
    IL_0025:  ldnull
    IL_0026:  stfld      class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanGenTabDelegate
    IL_002b:  ldarg      0
    IL_002f:  ldnull
    IL_0030:  stfld      class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanFormulaTabDelegate
    IL_0035:  ldarg      0
    IL_0039:  ldnull
    IL_003a:  stfld      class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_FillFormulaDelegate
    IL_003f:  ldarg      0
    IL_0043:  ldnull
    IL_0044:  stfld      class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterImportStructureDelegate
    IL_0049:  ldarg      0
    IL_004d:  ldnull
    IL_004e:  stfld      class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterSaveStructureDelegate
    IL_0053:  ldarg      0
    IL_0057:  ldnull
    IL_0058:  stfld      class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterClickDelegate
    IL_005d:  ldarg      0
    IL_0061:  ldnull
    IL_0062:  stfld      class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_DelMolStructDelegate
    IL_0067:  ldarg      0
    IL_006b:  ldnull
    IL_006c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_GetCompStructureNameDelegate
    IL_0071:  ret
  } // end of method _DMoleStructEvents_SinkHelper::.ctor

} // end of class MOLESTRUCTLib._DMoleStructEvents_SinkHelper

.class private auto ansi sealed MOLESTRUCTLib._DMoleStructEvents_EventProvider
       extends [mscorlib]System.Object
       implements MOLESTRUCTLib._DMoleStructEvents_Event,
                  [mscorlib]System.IDisposable
{
  .field private class [mscorlib]System.WeakReference m_wkConnectionPointContainer
  .field private class [mscorlib]System.Collections.ArrayList m_aEventSinkHelpers
  .field private class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint m_ConnectionPoint
  .method private instance void  Init() cil managed
  {
    // Code size       271 (0x10f)
    .maxstack  5
    .locals init (class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint V_0,
             valuetype [mscorlib]System.Guid V_1,
             uint8[] V_2)
    IL_0000:  ldnull
    IL_0001:  stloc.0
    IL_0002:  ldc.i4     0x10
    IL_0007:  newarr     [mscorlib]System.Byte
    IL_000c:  stloc.2
    IL_000d:  ldloc.2
    IL_000e:  ldc.i4     0x0
    IL_0013:  ldc.i4     0xc
    IL_0018:  stelem.i1
    IL_0019:  ldloc.2
    IL_001a:  ldc.i4     0x1
    IL_001f:  ldc.i4     0x14
    IL_0024:  stelem.i1
    IL_0025:  ldloc.2
    IL_0026:  ldc.i4     0x2
    IL_002b:  ldc.i4     0x1f
    IL_0030:  stelem.i1
    IL_0031:  ldloc.2
    IL_0032:  ldc.i4     0x3
    IL_0037:  ldc.i4     0x51
    IL_003c:  stelem.i1
    IL_003d:  ldloc.2
    IL_003e:  ldc.i4     0x4
    IL_0043:  ldc.i4     0x25
    IL_0048:  stelem.i1
    IL_0049:  ldloc.2
    IL_004a:  ldc.i4     0x5
    IL_004f:  ldc.i4     0x42
    IL_0054:  stelem.i1
    IL_0055:  ldloc.2
    IL_0056:  ldc.i4     0x6
    IL_005b:  ldc.i4     0x48
    IL_0060:  stelem.i1
    IL_0061:  ldloc.2
    IL_0062:  ldc.i4     0x7
    IL_0067:  ldc.i4     0x43
    IL_006c:  stelem.i1
    IL_006d:  ldloc.2
    IL_006e:  ldc.i4     0x8
    IL_0073:  ldc.i4     0x9c
    IL_0078:  stelem.i1
    IL_0079:  ldloc.2
    IL_007a:  ldc.i4     0x9
    IL_007f:  ldc.i4     0x65
    IL_0084:  stelem.i1
    IL_0085:  ldloc.2
    IL_0086:  ldc.i4     0xa
    IL_008b:  ldc.i4     0x55
    IL_0090:  stelem.i1
    IL_0091:  ldloc.2
    IL_0092:  ldc.i4     0xb
    IL_0097:  ldc.i4     0xcc
    IL_009c:  stelem.i1
    IL_009d:  ldloc.2
    IL_009e:  ldc.i4     0xc
    IL_00a3:  ldc.i4     0x3a
    IL_00a8:  stelem.i1
    IL_00a9:  ldloc.2
    IL_00aa:  ldc.i4     0xd
    IL_00af:  ldc.i4     0xb1
    IL_00b4:  stelem.i1
    IL_00b5:  ldloc.2
    IL_00b6:  ldc.i4     0xe
    IL_00bb:  ldc.i4     0xee
    IL_00c0:  stelem.i1
    IL_00c1:  ldloc.2
    IL_00c2:  ldc.i4     0xf
    IL_00c7:  ldc.i4     0x3e
    IL_00cc:  stelem.i1
    IL_00cd:  ldloca.s   V_1
    IL_00cf:  ldloc.2
    IL_00d0:  call       instance void [mscorlib]System.Guid::.ctor(uint8[])
    IL_00d5:  ldarg      0
    IL_00d9:  ldfld      class [mscorlib]System.WeakReference MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_wkConnectionPointContainer
    IL_00de:  callvirt   instance object [mscorlib]System.WeakReference::get_Target()
    IL_00e3:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_00e8:  ldloca.s   V_1
    IL_00ea:  ldloca.s   V_0
    IL_00ec:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer::FindConnectionPoint(valuetype [mscorlib]System.Guid&,
                                                                                                                                        class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint&)
    IL_00f1:  ldarg      0
    IL_00f5:  ldloc.0
    IL_00f6:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint
    IL_00fb:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
    IL_0100:  ldarg      0
    IL_0104:  newobj     instance void [mscorlib]System.Collections.ArrayList::.ctor()
    IL_0109:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
    IL_010e:  ret
  } // end of method _DMoleStructEvents_EventProvider::Init

  .method public virtual instance void  add_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CalcStructDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_CalcStruct

  .method public virtual instance void  remove_CalcStruct(class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CalcStructDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CalcStructDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_CalcStruct

  .method public virtual instance void  add_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanGenTabDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_CleanGenTab

  .method public virtual instance void  remove_CleanGenTab(class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanGenTabDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanGenTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanGenTabDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_CleanGenTab

  .method public virtual instance void  add_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanFormulaTabDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_CleanFormulaTab

  .method public virtual instance void  remove_CleanFormulaTab(class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanFormulaTabDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_CleanFormulaTabEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_CleanFormulaTabDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_CleanFormulaTab

  .method public virtual instance void  add_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_FillFormulaDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_FillFormula

  .method public virtual instance void  remove_FillFormula(class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_FillFormulaDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_FillFormulaDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_FillFormula

  .method public virtual instance void  add_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterImportStructureDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_AfterImportStructure

  .method public virtual instance void  remove_AfterImportStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterImportStructureDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterImportStructureDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_AfterImportStructure

  .method public virtual instance void  add_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterSaveStructureDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_AfterSaveStructure

  .method public virtual instance void  remove_AfterSaveStructure(class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterSaveStructureDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterSaveStructureDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_AfterSaveStructure

  .method public virtual instance void  add_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterClickDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_AfterClick

  .method public virtual instance void  remove_AfterClick(class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterClickDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_AfterClickEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_AfterClickDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_AfterClick

  .method public virtual instance void  add_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_DelMolStructDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_DelMolStruct

  .method public virtual instance void  remove_DelMolStruct(class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_DelMolStructDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_DelMolStructEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_DelMolStructDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_DelMolStruct

  .method public virtual instance void  add_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler A_1) cil managed
  {
    // Code size       121 (0x79)
    .maxstack  6
    .locals init (class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_0,
             int32 V_1,
             bool V_2)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_2
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0014:  brtrue     IL_0022

      IL_0019:  ldarg      0
      IL_001d:  call       instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Init()
      IL_0022:  newobj     instance void MOLESTRUCTLib._DMoleStructEvents_SinkHelper::.ctor()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4.0
      IL_0029:  stloc.1
      IL_002a:  ldarg      0
      IL_002e:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0033:  ldloc.0
      IL_0034:  castclass  [mscorlib]System.Object
      IL_0039:  ldloca.s   V_1
      IL_003b:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Advise(object,
                                                                                                                    int32&)
      IL_0040:  ldloc.0
      IL_0041:  ldloc.1
      IL_0042:  stfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_0047:  ldloc.0
      IL_0048:  ldarg      A_1
      IL_004c:  stfld      class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_GetCompStructureNameDelegate
      IL_0051:  ldarg      0
      IL_0055:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_005a:  ldloc.0
      IL_005b:  castclass  [mscorlib]System.Object
      IL_0060:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::Add(object)
      IL_0065:  pop
      IL_0066:  leave      IL_0078

    }  // end .try
    finally
    {
      IL_006b:  ldloc.2
      IL_006c:  brfalse.s  IL_0077

      IL_006e:  ldarg      0
      IL_0072:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_0077:  endfinally
    }  // end handler
    IL_0078:  ret
  } // end of method _DMoleStructEvents_EventProvider::add_GetCompStructureName

  .method public virtual instance void  remove_GetCompStructureName(class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler A_1) cil managed
  {
    // Code size       246 (0xf6)
    .maxstack  6
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      IL_0000:  ldarg      0
      IL_0004:  ldloca.s   V_3
      IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                          bool&)
      IL_000b:  ldarg      0
      IL_000f:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0014:  brfalse    IL_00e3

      IL_0019:  ldarg      0
      IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
      IL_0027:  stloc.0
      IL_0028:  ldc.i4     0x0
      IL_002d:  stloc.1
      IL_002e:  ldc.i4     0x0
      IL_0033:  ldloc.0
      IL_0034:  bge        IL_00e3

      IL_0039:  ldarg      0
      IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0042:  ldloc.1
      IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
      IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
      IL_004d:  stloc.2
      IL_004e:  ldloc.2
      IL_004f:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_GetCompStructureNameDelegate
      IL_0054:  ldnull
      IL_0055:  beq        IL_00d4

      IL_005a:  ldloc.2
      IL_005b:  ldfld      class MOLESTRUCTLib._DMoleStructEvents_GetCompStructureNameEventHandler MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_GetCompStructureNameDelegate
      IL_0060:  ldarg      A_1
      IL_0064:  castclass  [mscorlib]System.Object
      IL_0069:  callvirt   instance bool [mscorlib]System.Delegate::Equals(object)
      IL_006e:  ldc.i4     0xff
      IL_0073:  and
      IL_0074:  ldc.i4     0x0
      IL_0079:  beq        IL_00d4

      IL_007e:  ldarg      0
      IL_0082:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_0087:  ldloc.1
      IL_0088:  callvirt   instance void [mscorlib]System.Collections.ArrayList::RemoveAt(int32)
      IL_008d:  ldarg      0
      IL_0091:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_0096:  ldloc.2
      IL_0097:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
      IL_009c:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
      IL_00a1:  ldloc.0
      IL_00a2:  ldc.i4     0x1
      IL_00a7:  bgt        IL_00e3

      IL_00ac:  ldarg      0
      IL_00b0:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00b5:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
      IL_00ba:  pop
      IL_00bb:  ldarg      0
      IL_00bf:  ldnull
      IL_00c0:  stfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
      IL_00c5:  ldarg      0
      IL_00c9:  ldnull
      IL_00ca:  stfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
      IL_00cf:  br         IL_00e3

      IL_00d4:  ldloc.1
      IL_00d5:  ldc.i4     0x1
      IL_00da:  add
      IL_00db:  stloc.1
      IL_00dc:  ldloc.1
      IL_00dd:  ldloc.0
      IL_00de:  blt        IL_0039

      IL_00e3:  leave      IL_00f5

    }  // end .try
    finally
    {
      IL_00e8:  ldloc.3
      IL_00e9:  brfalse.s  IL_00f4

      IL_00eb:  ldarg      0
      IL_00ef:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_00f4:  endfinally
    }  // end handler
    IL_00f5:  ret
  } // end of method _DMoleStructEvents_EventProvider::remove_GetCompStructureName

  .method public specialname rtspecialname 
          instance void  .ctor(object A_1) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  6
    IL_0000:  ldarg      0
    IL_0004:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0009:  ldarg      0
    IL_000d:  ldarg      A_1
    IL_0011:  castclass  [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPointContainer
    IL_0016:  ldc.i4.0
    IL_0017:  newobj     instance void [mscorlib]System.WeakReference::.ctor(object,
                                                                             bool)
    IL_001c:  stfld      class [mscorlib]System.WeakReference MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_wkConnectionPointContainer
    IL_0021:  ret
  } // end of method _DMoleStructEvents_EventProvider::.ctor

  .method public virtual instance void  Finalize() cil managed
  {
    // Code size       158 (0x9e)
    .maxstack  5
    .locals init (int32 V_0,
             int32 V_1,
             class MOLESTRUCTLib._DMoleStructEvents_SinkHelper V_2,
             bool V_3)
    .try
    {
      .try
      {
        IL_0000:  ldarg      0
        IL_0004:  ldloca.s   V_3
        IL_0006:  call       void [mscorlib]System.Threading.Monitor::Enter(object,
                                                                            bool&)
        IL_000b:  ldarg      0
        IL_000f:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
        IL_0014:  brfalse    IL_0080

        IL_0019:  ldarg      0
        IL_001d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
        IL_0022:  callvirt   instance int32 [mscorlib]System.Collections.ArrayList::get_Count()
        IL_0027:  stloc.0
        IL_0028:  ldc.i4     0x0
        IL_002d:  stloc.1
        IL_002e:  ldc.i4     0x0
        IL_0033:  ldloc.0
        IL_0034:  bge        IL_0071

        IL_0039:  ldarg      0
        IL_003d:  ldfld      class [mscorlib]System.Collections.ArrayList MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_aEventSinkHelpers
        IL_0042:  ldloc.1
        IL_0043:  callvirt   instance object [mscorlib]System.Collections.ArrayList::get_Item(int32)
        IL_0048:  castclass  MOLESTRUCTLib._DMoleStructEvents_SinkHelper
        IL_004d:  stloc.2
        IL_004e:  ldarg      0
        IL_0052:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
        IL_0057:  ldloc.2
        IL_0058:  ldfld      int32 MOLESTRUCTLib._DMoleStructEvents_SinkHelper::m_dwCookie
        IL_005d:  callvirt   instance void [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint::Unadvise(int32)
        IL_0062:  ldloc.1
        IL_0063:  ldc.i4     0x1
        IL_0068:  add
        IL_0069:  stloc.1
        IL_006a:  ldloc.1
        IL_006b:  ldloc.0
        IL_006c:  blt        IL_0039

        IL_0071:  ldarg      0
        IL_0075:  ldfld      class [mscorlib]System.Runtime.InteropServices.ComTypes.IConnectionPoint MOLESTRUCTLib._DMoleStructEvents_EventProvider::m_ConnectionPoint
        IL_007a:  call       int32 [mscorlib]System.Runtime.InteropServices.Marshal::ReleaseComObject(object)
        IL_007f:  pop
        IL_0080:  leave      IL_008b

      }  // end .try
      catch [mscorlib]System.Exception 
      {
        IL_0085:  pop
        IL_0086:  leave      IL_008b

      }  // end handler
      IL_008b:  leave      IL_009d

    }  // end .try
    finally
    {
      IL_0090:  ldloc.3
      IL_0091:  brfalse.s  IL_009c

      IL_0093:  ldarg      0
      IL_0097:  call       void [mscorlib]System.Threading.Monitor::Exit(object)
      IL_009c:  endfinally
    }  // end handler
    IL_009d:  ret
  } // end of method _DMoleStructEvents_EventProvider::Finalize

  .method public virtual instance void  Dispose() cil managed
  {
    // Code size       19 (0x13)
    .maxstack  2
    IL_0000:  ldarg      0
    IL_0004:  callvirt   instance void MOLESTRUCTLib._DMoleStructEvents_EventProvider::Finalize()
    IL_0009:  ldarg      0
    IL_000d:  call       void [mscorlib]System.GC::SuppressFinalize(object)
    IL_0012:  ret
  } // end of method _DMoleStructEvents_EventProvider::Dispose

} // end of class MOLESTRUCTLib._DMoleStructEvents_EventProvider


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file C:\Users\Administrator\Desktop\Aspen 逆向\.local\batch-roundtrip-20261125\work-il\clr-ln0nfvuh\editable\source.res
