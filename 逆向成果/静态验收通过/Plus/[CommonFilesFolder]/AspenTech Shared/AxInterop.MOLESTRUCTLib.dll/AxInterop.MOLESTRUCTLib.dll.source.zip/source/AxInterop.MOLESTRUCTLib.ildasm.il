﻿
//  .NET IL Disassembler.  Version 9.0.23




.typelist 
{
  AxMOLESTRUCTLib.AxMoleStruct
  AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler
  AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent
  AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler
  AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent
  AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler
  AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent
  AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler
  AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent
  AxMOLESTRUCTLib.AxMoleStructEventMulticaster
}

// Metadata version: v4.0.30319
.assembly extern System.Windows.Forms
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly extern Interop.MOLESTRUCTLib
{
  .publickeytoken = (D9 4C A7 B0 3D 16 02 C9 )                         // .L..=...
  .ver 4:0:0:0
}
.assembly extern System
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly AxInterop.MOLESTRUCTLib
{
  .custom instance void [mscorlib]System.Runtime.CompilerServices.CompilationRelaxationsAttribute::.ctor(int32) = ( 01 00 08 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.CompilerServices.RuntimeCompatibilityAttribute::.ctor() = ( 01 00 01 00 54 02 16 57 72 61 70 4E 6F 6E 45 78   // ....T..WrapNonEx
                                                                                                             63 65 70 74 69 6F 6E 54 68 72 6F 77 73 01 )       // ceptionThrows.
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/TypeLibraryTimeStampAttribute::.ctor(string) = ( 01 00 13 30 34 2F 31 31 2F 32 30 32 31 20 31 37   // ...04/11/2021 17
                                                                                                                           3A 34 32 3A 32 32 00 00 )                         // :42:22..
  .custom instance void [mscorlib]System.Reflection.AssemblyKeyFileAttribute::.ctor(string) = ( 01 00 08 61 70 65 64 2E 73 6E 6B 00 00 )          // ...aped.snk..
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                6F 3E E5 88 66 FF AB 8E B7 56 CB 2B 21 14 5F E5   // o>..f....V.+!._.
                68 1C 6E 59 6D D1 B6 77 CC E9 B7 23 17 37 C7 8E   // h.nYm..w...#.7..
                D6 75 CE DD E2 D7 6E BB 8C F3 D7 68 D6 0F EE 51   // .u....n....h...Q
                CD CA F9 96 C1 15 04 1E AC 4B 7E 4E 66 45 D7 47   // .........K~NfE.G
                9F 9F F8 49 31 7C CA EF D4 4C B2 75 69 22 A4 63   // ...I1|...L.ui".c
                E0 7E 90 BB 02 A3 FE 56 07 74 45 BB 2B DC B3 D2   // .~.....V.tE.+...
                46 1C 79 BD 13 90 92 10 54 8E A3 42 49 09 F9 C1   // F.y.....T..BI...
                18 CD 6A AB EE 1A 34 63 CE C5 FA BA 82 15 40 AF ) // ..j...4c......@.
  .hash algorithm 0x00008004
  .ver 4:0:0:0
}
.module AxInterop.MOLESTRUCTLib.dll
// MVID: {3a9150da-d05f-4783-944b-2a76097a28e3}
.imagebase 0x10000000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY
// Image base: 0x0000025F27340000


// =============== CLASS MEMBERS DECLARATION ===================

.class public auto ansi beforefieldinit AxMOLESTRUCTLib.AxMoleStruct
       extends [System.Windows.Forms]System.Windows.Forms.AxHost
{
  .custom instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ClsidAttribute::.ctor(string) = ( 01 00 26 7B 64 37 30 61 38 64 34 38 2D 33 65 37   // ..&{d70a8d48-3e7
                                                                                                            33 2D 34 66 38 63 2D 38 65 31 39 2D 39 30 63 62   // 3-4f8c-8e19-90cb
                                                                                                            61 37 66 35 32 61 30 63 7D 00 00 )                // a7f52a0c}..
  .custom instance void [System]System.ComponentModel.DesignTimeVisibleAttribute::.ctor(bool) = ( 01 00 01 00 00 ) 
  .custom instance void [System]System.ComponentModel.DefaultEventAttribute::.ctor(string) = ( 01 00 0A 43 61 6C 63 53 74 72 75 63 74 00 00 )    // ...CalcStruct..
  .field private class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct ocx
  .field private class AxMOLESTRUCTLib.AxMoleStructEventMulticaster eventMulticaster
  .field private class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie cookie
  .field private class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler CalcStruct
  .field private class [mscorlib]System.EventHandler CleanGenTab
  .field private class [mscorlib]System.EventHandler CleanFormulaTab
  .field private class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler FillFormula
  .field private class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AfterImportStructure
  .field private class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AfterSaveStructure
  .field private class [mscorlib]System.EventHandler AfterClick
  .field private class [mscorlib]System.EventHandler DelMolStruct
  .field private class [mscorlib]System.EventHandler GetCompStructureName
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor() cil managed
  {
    // Code size       12 (0xc)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldstr      "d70a8d48-3e73-4f8c-8e19-90cba7f52a0c"
    IL_0006:  call       instance void [System.Windows.Forms]System.Windows.Forms.AxHost::.ctor(string)
    IL_000b:  ret
  } // end of method AxMoleStruct::.ctor

  .method public hidebysig specialname instance void 
          add_CalcStruct(class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler AxMOLESTRUCTLib.AxMoleStruct::CalcStruct
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler AxMOLESTRUCTLib.AxMoleStruct::CalcStruct
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler>(!!0&,
                                                                                                                                                      !!0,
                                                                                                                                                      !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_CalcStruct

  .method public hidebysig specialname instance void 
          remove_CalcStruct(class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler AxMOLESTRUCTLib.AxMoleStruct::CalcStruct
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler AxMOLESTRUCTLib.AxMoleStruct::CalcStruct
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler>(!!0&,
                                                                                                                                                      !!0,
                                                                                                                                                      !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_CalcStruct

  .method public hidebysig specialname instance void 
          add_CleanGenTab(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanGenTab
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanGenTab
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_CleanGenTab

  .method public hidebysig specialname instance void 
          remove_CleanGenTab(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanGenTab
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanGenTab
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_CleanGenTab

  .method public hidebysig specialname instance void 
          add_CleanFormulaTab(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanFormulaTab
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanFormulaTab
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_CleanFormulaTab

  .method public hidebysig specialname instance void 
          remove_CleanFormulaTab(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanFormulaTab
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanFormulaTab
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_CleanFormulaTab

  .method public hidebysig specialname instance void 
          add_FillFormula(class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler AxMOLESTRUCTLib.AxMoleStruct::FillFormula
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler AxMOLESTRUCTLib.AxMoleStruct::FillFormula
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler>(!!0&,
                                                                                                                                                       !!0,
                                                                                                                                                       !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_FillFormula

  .method public hidebysig specialname instance void 
          remove_FillFormula(class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler AxMOLESTRUCTLib.AxMoleStruct::FillFormula
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler AxMOLESTRUCTLib.AxMoleStruct::FillFormula
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler>(!!0&,
                                                                                                                                                       !!0,
                                                                                                                                                       !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_FillFormula

  .method public hidebysig specialname instance void 
          add_AfterImportStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterImportStructure
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterImportStructure
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler>(!!0&,
                                                                                                                                                                !!0,
                                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_AfterImportStructure

  .method public hidebysig specialname instance void 
          remove_AfterImportStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterImportStructure
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterImportStructure
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler>(!!0&,
                                                                                                                                                                !!0,
                                                                                                                                                                !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_AfterImportStructure

  .method public hidebysig specialname instance void 
          add_AfterSaveStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterSaveStructure
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterSaveStructure
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler>(!!0&,
                                                                                                                                                              !!0,
                                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_AfterSaveStructure

  .method public hidebysig specialname instance void 
          remove_AfterSaveStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler V_0,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler V_1,
             class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterSaveStructure
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterSaveStructure
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler>(!!0&,
                                                                                                                                                              !!0,
                                                                                                                                                              !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_AfterSaveStructure

  .method public hidebysig specialname instance void 
          add_AfterClick(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_AfterClick

  .method public hidebysig specialname instance void 
          remove_AfterClick(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterClick
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterClick
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_AfterClick

  .method public hidebysig specialname instance void 
          add_DelMolStruct(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::DelMolStruct
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::DelMolStruct
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_DelMolStruct

  .method public hidebysig specialname instance void 
          remove_DelMolStruct(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::DelMolStruct
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::DelMolStruct
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_DelMolStruct

  .method public hidebysig specialname instance void 
          add_GetCompStructureName(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::GetCompStructureName
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Combine(class [mscorlib]System.Delegate,
                                                                                            class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::GetCompStructureName
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::add_GetCompStructureName

  .method public hidebysig specialname instance void 
          remove_GetCompStructureName(class [mscorlib]System.EventHandler 'value') cil managed
  {
    // Code size       41 (0x29)
    .maxstack  3
    .locals init (class [mscorlib]System.EventHandler V_0,
             class [mscorlib]System.EventHandler V_1,
             class [mscorlib]System.EventHandler V_2)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::GetCompStructureName
    IL_0006:  stloc.0
    IL_0007:  ldloc.0
    IL_0008:  stloc.1
    IL_0009:  ldloc.1
    IL_000a:  ldarg.1
    IL_000b:  call       class [mscorlib]System.Delegate [mscorlib]System.Delegate::Remove(class [mscorlib]System.Delegate,
                                                                                           class [mscorlib]System.Delegate)
    IL_0010:  castclass  [mscorlib]System.EventHandler
    IL_0015:  stloc.2
    IL_0016:  ldarg.0
    IL_0017:  ldflda     class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::GetCompStructureName
    IL_001c:  ldloc.2
    IL_001d:  ldloc.1
    IL_001e:  call       !!0 [mscorlib]System.Threading.Interlocked::CompareExchange<class [mscorlib]System.EventHandler>(!!0&,
                                                                                                                          !!0,
                                                                                                                          !!0)
    IL_0023:  stloc.0
    IL_0024:  ldloc.0
    IL_0025:  ldloc.1
    IL_0026:  bne.un.s   IL_0007

    IL_0028:  ret
  } // end of method AxMoleStruct::remove_GetCompStructureName

  .method public hidebysig newslot virtual 
          instance bool  InitializeMoleFile() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "InitializeMoleFile"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance bool [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::InitializeMoleFile()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxMoleStruct::InitializeMoleFile

  .method public hidebysig newslot virtual 
          instance void  CalculateStructure() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "CalculateStructure"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::CalculateStructure()
    IL_001f:  ret
  } // end of method AxMoleStruct::CalculateStructure

  .method public hidebysig newslot virtual 
          instance bool  Initialize(string casno) cil managed
  {
    // Code size       35 (0x23)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Initialize"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance bool [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::Initialize(string)
    IL_0020:  stloc.0
    IL_0021:  ldloc.0
    IL_0022:  ret
  } // end of method AxMoleStruct::Initialize

  .method public hidebysig newslot virtual 
          instance void  Refresh() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Refresh"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::Refresh()
    IL_001f:  ret
  } // end of method AxMoleStruct::Refresh

  .method public hidebysig newslot virtual 
          instance string  GetMoleInfo(string compName,
                                       string molFilePath,
                                       string casno) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  4
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMoleInfo"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance string [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::GetMoleInfo(string,
                                                                                                        string,
                                                                                                        string)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ret
  } // end of method AxMoleStruct::GetMoleInfo

  .method public hidebysig newslot virtual 
          instance bool  Initialize2(string casno,
                                     string compAlias,
                                     string compName) cil managed
  {
    // Code size       37 (0x25)
    .maxstack  4
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "Initialize2"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  callvirt   instance bool [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::Initialize2(string,
                                                                                                      string,
                                                                                                      string)
    IL_0022:  stloc.0
    IL_0023:  ldloc.0
    IL_0024:  ret
  } // end of method AxMoleStruct::Initialize2

  .method public hidebysig newslot virtual 
          instance string  GetMoleInfo2(string compName,
                                        string molFilePath,
                                        string casno,
                                        string name,
                                        string alias) cil managed
  {
    // Code size       41 (0x29)
    .maxstack  6
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMoleInfo2"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  ldarg.3
    IL_001d:  ldarg.s    name
    IL_001f:  ldarg.s    alias
    IL_0021:  callvirt   instance string [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::GetMoleInfo2(string,
                                                                                                         string,
                                                                                                         string,
                                                                                                         string,
                                                                                                         string)
    IL_0026:  stloc.0
    IL_0027:  ldloc.0
    IL_0028:  ret
  } // end of method AxMoleStruct::GetMoleInfo2

  .method public hidebysig newslot virtual 
          instance void  SetIncludeHydrogenInCalc(bool bIncludeHydrogen) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetIncludeHydrogenInCalc"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::SetIncludeHydrogenInCalc(bool)
    IL_0020:  ret
  } // end of method AxMoleStruct::SetIncludeHydrogenInCalc

  .method public hidebysig newslot virtual 
          instance void  GetMoleInfoFromData(string moleInfoData) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMoleInfoFromData"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::GetMoleInfoFromData(string)
    IL_0020:  ret
  } // end of method AxMoleStruct::GetMoleInfoFromData

  .method public hidebysig newslot virtual 
          instance void  SetupForAped() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetupForAped"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::SetupForAped()
    IL_001f:  ret
  } // end of method AxMoleStruct::SetupForAped

  .method public hidebysig newslot virtual 
          instance void  GetMoleStructFromString(string moleString) cil managed
  {
    // Code size       33 (0x21)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMoleStructFromString"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::GetMoleStructFromString(string)
    IL_0020:  ret
  } // end of method AxMoleStruct::GetMoleStructFromString

  .method public hidebysig newslot virtual 
          instance bool  SaveForAped() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (bool V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SaveForAped"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance bool [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::SaveForAped()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxMoleStruct::SaveForAped

  .method public hidebysig newslot virtual 
          instance string  GetMoleFileString() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMoleFileString"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance string [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::GetMoleFileString()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxMoleStruct::GetMoleFileString

  .method public hidebysig newslot virtual 
          instance void  SetExportButton() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetExportButton"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::SetExportButton()
    IL_001f:  ret
  } // end of method AxMoleStruct::SetExportButton

  .method public hidebysig newslot virtual 
          instance string  GetMoleFile() cil managed
  {
    // Code size       34 (0x22)
    .maxstack  2
    .locals init (string V_0)
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "GetMoleFile"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance string [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::GetMoleFile()
    IL_001f:  stloc.0
    IL_0020:  ldloc.0
    IL_0021:  ret
  } // end of method AxMoleStruct::GetMoleFile

  .method public hidebysig newslot virtual 
          instance void  SetApedButtons(bool bImport,
                                        bool bExport) cil managed
  {
    // Code size       34 (0x22)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "SetApedButtons"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  ldarg.1
    IL_001b:  ldarg.2
    IL_001c:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::SetApedButtons(bool,
                                                                                                         bool)
    IL_0021:  ret
  } // end of method AxMoleStruct::SetApedButtons

  .method public hidebysig newslot virtual 
          instance void  HideAllButtons() cil managed
  {
    // Code size       32 (0x20)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_0006:  brtrue.s   IL_0014

    IL_0008:  ldstr      "HideAllButtons"
    IL_000d:  ldc.i4.0
    IL_000e:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/InvalidActiveXStateException::.ctor(string,
                                                                                                                             valuetype [System.Windows.Forms]System.Windows.Forms.AxHost/ActiveXInvokeKind)
    IL_0013:  throw

    IL_0014:  ldarg.0
    IL_0015:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
    IL_001a:  callvirt   instance void [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct::HideAllButtons()
    IL_001f:  ret
  } // end of method AxMoleStruct::HideAllButtons

  .method family hidebysig virtual instance void 
          CreateSink() cil managed
  {
    // Code size       51 (0x33)
    .maxstack  4
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  newobj     instance void AxMOLESTRUCTLib.AxMoleStructEventMulticaster::.ctor(class AxMOLESTRUCTLib.AxMoleStruct)
      IL_0007:  stfld      class AxMOLESTRUCTLib.AxMoleStructEventMulticaster AxMOLESTRUCTLib.AxMoleStruct::eventMulticaster
      IL_000c:  ldarg.0
      IL_000d:  ldarg.0
      IL_000e:  ldfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
      IL_0013:  ldarg.0
      IL_0014:  ldfld      class AxMOLESTRUCTLib.AxMoleStructEventMulticaster AxMOLESTRUCTLib.AxMoleStruct::eventMulticaster
      IL_0019:  ldtoken    [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStructEvents
      IL_001e:  call       class [mscorlib]System.Type [mscorlib]System.Type::GetTypeFromHandle(valuetype [mscorlib]System.RuntimeTypeHandle)
      IL_0023:  newobj     instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::.ctor(object,
                                                                                                                        object,
                                                                                                                        class [mscorlib]System.Type)
      IL_0028:  stfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxMOLESTRUCTLib.AxMoleStruct::cookie
      IL_002d:  leave.s    IL_0032

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_002f:  pop
      IL_0030:  leave.s    IL_0032

    }  // end handler
    IL_0032:  ret
  } // end of method AxMoleStruct::CreateSink

  .method family hidebysig virtual instance void 
          DetachSink() cil managed
  {
    // Code size       17 (0x11)
    .maxstack  1
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldfld      class [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie AxMOLESTRUCTLib.AxMoleStruct::cookie
      IL_0006:  callvirt   instance void [System.Windows.Forms]System.Windows.Forms.AxHost/ConnectionPointCookie::Disconnect()
      IL_000b:  leave.s    IL_0010

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_000d:  pop
      IL_000e:  leave.s    IL_0010

    }  // end handler
    IL_0010:  ret
  } // end of method AxMoleStruct::DetachSink

  .method family hidebysig virtual instance void 
          AttachInterfaces() cil managed
  {
    // Code size       23 (0x17)
    .maxstack  2
    .try
    {
      IL_0000:  ldarg.0
      IL_0001:  ldarg.0
      IL_0002:  call       instance object [System.Windows.Forms]System.Windows.Forms.AxHost::GetOcx()
      IL_0007:  castclass  [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct
      IL_000c:  stfld      class [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStruct AxMOLESTRUCTLib.AxMoleStruct::ocx
      IL_0011:  leave.s    IL_0016

    }  // end .try
    catch [mscorlib]System.Exception 
    {
      IL_0013:  pop
      IL_0014:  leave.s    IL_0016

    }  // end handler
    IL_0016:  ret
  } // end of method AxMoleStruct::AttachInterfaces

  .method assembly hidebysig instance void 
          RaiseOnCalcStruct(object sender,
                            class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler AxMOLESTRUCTLib.AxMoleStruct::CalcStruct
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler AxMOLESTRUCTLib.AxMoleStruct::CalcStruct
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler::Invoke(object,
                                                                                                         class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnCalcStruct

  .method assembly hidebysig instance void 
          RaiseOnCleanGenTab(object sender,
                             class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanGenTab
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanGenTab
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnCleanGenTab

  .method assembly hidebysig instance void 
          RaiseOnCleanFormulaTab(object sender,
                                 class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanFormulaTab
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::CleanFormulaTab
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnCleanFormulaTab

  .method assembly hidebysig instance void 
          RaiseOnFillFormula(object sender,
                             class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler AxMOLESTRUCTLib.AxMoleStruct::FillFormula
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler AxMOLESTRUCTLib.AxMoleStruct::FillFormula
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler::Invoke(object,
                                                                                                          class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnFillFormula

  .method assembly hidebysig instance void 
          RaiseOnAfterImportStructure(object sender,
                                      class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterImportStructure
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterImportStructure
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler::Invoke(object,
                                                                                                                   class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnAfterImportStructure

  .method assembly hidebysig instance void 
          RaiseOnAfterSaveStructure(object sender,
                                    class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterSaveStructure
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterSaveStructure
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler::Invoke(object,
                                                                                                                 class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnAfterSaveStructure

  .method assembly hidebysig instance void 
          RaiseOnAfterClick(object sender,
                            class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterClick
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::AfterClick
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnAfterClick

  .method assembly hidebysig instance void 
          RaiseOnDelMolStruct(object sender,
                              class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::DelMolStruct
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::DelMolStruct
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnDelMolStruct

  .method assembly hidebysig instance void 
          RaiseOnGetCompStructureName(object sender,
                                      class [mscorlib]System.EventArgs e) cil managed
  {
    // Code size       22 (0x16)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::GetCompStructureName
    IL_0006:  brfalse.s  IL_0015

    IL_0008:  ldarg.0
    IL_0009:  ldfld      class [mscorlib]System.EventHandler AxMOLESTRUCTLib.AxMoleStruct::GetCompStructureName
    IL_000e:  ldarg.1
    IL_000f:  ldarg.2
    IL_0010:  callvirt   instance void [mscorlib]System.EventHandler::Invoke(object,
                                                                             class [mscorlib]System.EventArgs)
    IL_0015:  ret
  } // end of method AxMoleStruct::RaiseOnGetCompStructureName

  .event AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler CalcStruct
  {
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_CalcStruct(class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler)
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_CalcStruct(class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler)
  } // end of event AxMoleStruct::CalcStruct
  .event [mscorlib]System.EventHandler CleanGenTab
  {
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_CleanGenTab(class [mscorlib]System.EventHandler)
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_CleanGenTab(class [mscorlib]System.EventHandler)
  } // end of event AxMoleStruct::CleanGenTab
  .event [mscorlib]System.EventHandler CleanFormulaTab
  {
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_CleanFormulaTab(class [mscorlib]System.EventHandler)
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_CleanFormulaTab(class [mscorlib]System.EventHandler)
  } // end of event AxMoleStruct::CleanFormulaTab
  .event AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler FillFormula
  {
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_FillFormula(class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler)
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_FillFormula(class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler)
  } // end of event AxMoleStruct::FillFormula
  .event AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler AfterImportStructure
  {
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_AfterImportStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler)
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_AfterImportStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler)
  } // end of event AxMoleStruct::AfterImportStructure
  .event AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler AfterSaveStructure
  {
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_AfterSaveStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler)
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_AfterSaveStructure(class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler)
  } // end of event AxMoleStruct::AfterSaveStructure
  .event [mscorlib]System.EventHandler AfterClick
  {
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_AfterClick(class [mscorlib]System.EventHandler)
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_AfterClick(class [mscorlib]System.EventHandler)
  } // end of event AxMoleStruct::AfterClick
  .event [mscorlib]System.EventHandler DelMolStruct
  {
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_DelMolStruct(class [mscorlib]System.EventHandler)
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_DelMolStruct(class [mscorlib]System.EventHandler)
  } // end of event AxMoleStruct::DelMolStruct
  .event [mscorlib]System.EventHandler GetCompStructureName
  {
    .addon instance void AxMOLESTRUCTLib.AxMoleStruct::add_GetCompStructureName(class [mscorlib]System.EventHandler)
    .removeon instance void AxMOLESTRUCTLib.AxMoleStruct::remove_GetCompStructureName(class [mscorlib]System.EventHandler)
  } // end of event AxMoleStruct::GetCompStructureName
} // end of class AxMOLESTRUCTLib.AxMoleStruct

.class public auto ansi sealed AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DMoleStructEvents_CalcStructEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent e) runtime managed
  {
  } // end of method _DMoleStructEvents_CalcStructEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DMoleStructEvents_CalcStructEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DMoleStructEvents_CalcStructEventHandler::EndInvoke

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEventHandler

.class public auto ansi beforefieldinit AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent
       extends [mscorlib]System.Object
{
  .field public int32 atom1
  .field public string atom1Type
  .field public int32 atom2
  .field public string atom2Type
  .field public string bondType
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(int32 atom1,
                               string atom1Type,
                               int32 atom2,
                               string atom2Type,
                               string bondType) cil managed
  {
    // Code size       44 (0x2c)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      int32 AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent::atom1
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent::atom1Type
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      int32 AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent::atom2
    IL_001b:  ldarg.0
    IL_001c:  ldarg.s    atom2Type
    IL_001e:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent::atom2Type
    IL_0023:  ldarg.0
    IL_0024:  ldarg.s    bondType
    IL_0026:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent::bondType
    IL_002b:  ret
  } // end of method _DMoleStructEvents_CalcStructEvent::.ctor

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent

.class public auto ansi sealed AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DMoleStructEvents_FillFormulaEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent e) runtime managed
  {
  } // end of method _DMoleStructEvents_FillFormulaEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DMoleStructEvents_FillFormulaEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DMoleStructEvents_FillFormulaEventHandler::EndInvoke

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEventHandler

.class public auto ansi beforefieldinit AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent
       extends [mscorlib]System.Object
{
  .field public string atom
  .field public int32 noAtom
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string atom,
                               int32 noAtom) cil managed
  {
    // Code size       21 (0x15)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent::atom
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      int32 AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent::noAtom
    IL_0014:  ret
  } // end of method _DMoleStructEvents_FillFormulaEvent::.ctor

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent

.class public auto ansi sealed AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DMoleStructEvents_AfterImportStructureEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent e) runtime managed
  {
  } // end of method _DMoleStructEvents_AfterImportStructureEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DMoleStructEvents_AfterImportStructureEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DMoleStructEvents_AfterImportStructureEventHandler::EndInvoke

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEventHandler

.class public auto ansi beforefieldinit AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent
       extends [mscorlib]System.Object
{
  .field public string compName
  .field public string molFilePath
  .field public string molCompress
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string compName,
                               string molFilePath,
                               string molCompress) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent::compName
    IL_000d:  ldarg.0
    IL_000e:  ldarg.2
    IL_000f:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent::molFilePath
    IL_0014:  ldarg.0
    IL_0015:  ldarg.3
    IL_0016:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent::molCompress
    IL_001b:  ret
  } // end of method _DMoleStructEvents_AfterImportStructureEvent::.ctor

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent

.class public auto ansi sealed AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler
       extends [mscorlib]System.MulticastDelegate
{
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(object 'object',
                               native int 'method') runtime managed
  {
  } // end of method _DMoleStructEvents_AfterSaveStructureEventHandler::.ctor

  .method public hidebysig newslot virtual 
          instance void  Invoke(object sender,
                                class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent e) runtime managed
  {
  } // end of method _DMoleStructEvents_AfterSaveStructureEventHandler::Invoke

  .method public hidebysig newslot virtual 
          instance class [mscorlib]System.IAsyncResult 
          BeginInvoke(object sender,
                      class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent e,
                      class [mscorlib]System.AsyncCallback callback,
                      object 'object') runtime managed
  {
  } // end of method _DMoleStructEvents_AfterSaveStructureEventHandler::BeginInvoke

  .method public hidebysig newslot virtual 
          instance void  EndInvoke(class [mscorlib]System.IAsyncResult result) runtime managed
  {
  } // end of method _DMoleStructEvents_AfterSaveStructureEventHandler::EndInvoke

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEventHandler

.class public auto ansi beforefieldinit AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent
       extends [mscorlib]System.Object
{
  .field public string moleFileString
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(string moleFileString) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      string AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent::moleFileString
    IL_000d:  ret
  } // end of method _DMoleStructEvents_AfterSaveStructureEvent::.ctor

} // end of class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent

.class public auto ansi beforefieldinit AxMOLESTRUCTLib.AxMoleStructEventMulticaster
       extends [mscorlib]System.Object
       implements [Interop.MOLESTRUCTLib]MOLESTRUCTLib._DMoleStructEvents
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .field private class AxMOLESTRUCTLib.AxMoleStruct parent
  .method public hidebysig specialname rtspecialname 
          instance void  .ctor(class AxMOLESTRUCTLib.AxMoleStruct parent) cil managed
  {
    // Code size       14 (0xe)
    .maxstack  8
    IL_0000:  ldarg.0
    IL_0001:  call       instance void [mscorlib]System.Object::.ctor()
    IL_0006:  ldarg.0
    IL_0007:  ldarg.1
    IL_0008:  stfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000d:  ret
  } // end of method AxMoleStructEventMulticaster::.ctor

  .method public hidebysig newslot virtual 
          instance void  CalcStruct(int32 atom1,
                                    string atom1Type,
                                    int32 atom2,
                                    string atom2Type,
                                    string bondType) cil managed
  {
    // Code size       32 (0x20)
    .maxstack  5
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  ldarg.s    atom2Type
    IL_0005:  ldarg.s    bondType
    IL_0007:  newobj     instance void AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent::.ctor(int32,
                                                                                                 string,
                                                                                                 int32,
                                                                                                 string,
                                                                                                 string)
    IL_000c:  stloc.0
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0013:  ldarg.0
    IL_0014:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0019:  ldloc.0
    IL_001a:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnCalcStruct(object,
                                                                                       class AxMOLESTRUCTLib._DMoleStructEvents_CalcStructEvent)
    IL_001f:  ret
  } // end of method AxMoleStructEventMulticaster::CalcStruct

  .method public hidebysig newslot virtual 
          instance void  CleanGenTab() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnCleanGenTab(object,
                                                                                        class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxMoleStructEventMulticaster::CleanGenTab

  .method public hidebysig newslot virtual 
          instance void  CleanFormulaTab() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnCleanFormulaTab(object,
                                                                                            class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxMoleStructEventMulticaster::CleanFormulaTab

  .method public hidebysig newslot virtual 
          instance void  FillFormula(string atom,
                                     int32 noAtom) cil managed
  {
    // Code size       27 (0x1b)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  newobj     instance void AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent::.ctor(string,
                                                                                                  int32)
    IL_0007:  stloc.0
    IL_0008:  ldarg.0
    IL_0009:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000e:  ldarg.0
    IL_000f:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0014:  ldloc.0
    IL_0015:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnFillFormula(object,
                                                                                        class AxMOLESTRUCTLib._DMoleStructEvents_FillFormulaEvent)
    IL_001a:  ret
  } // end of method AxMoleStructEventMulticaster::FillFormula

  .method public hidebysig newslot virtual 
          instance void  AfterImportStructure(string compName,
                                              string molFilePath,
                                              string molCompress) cil managed
  {
    // Code size       28 (0x1c)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  ldarg.2
    IL_0002:  ldarg.3
    IL_0003:  newobj     instance void AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent::.ctor(string,
                                                                                                           string,
                                                                                                           string)
    IL_0008:  stloc.0
    IL_0009:  ldarg.0
    IL_000a:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000f:  ldarg.0
    IL_0010:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0015:  ldloc.0
    IL_0016:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnAfterImportStructure(object,
                                                                                                 class AxMOLESTRUCTLib._DMoleStructEvents_AfterImportStructureEvent)
    IL_001b:  ret
  } // end of method AxMoleStructEventMulticaster::AfterImportStructure

  .method public hidebysig newslot virtual 
          instance void  AfterSaveStructure(string moleFileString) cil managed
  {
    // Code size       26 (0x1a)
    .maxstack  3
    .locals init (class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent V_0)
    IL_0000:  ldarg.1
    IL_0001:  newobj     instance void AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent::.ctor(string)
    IL_0006:  stloc.0
    IL_0007:  ldarg.0
    IL_0008:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000d:  ldarg.0
    IL_000e:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0013:  ldloc.0
    IL_0014:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnAfterSaveStructure(object,
                                                                                               class AxMOLESTRUCTLib._DMoleStructEvents_AfterSaveStructureEvent)
    IL_0019:  ret
  } // end of method AxMoleStructEventMulticaster::AfterSaveStructure

  .method public hidebysig newslot virtual 
          instance void  AfterClick() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnAfterClick(object,
                                                                                       class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxMoleStructEventMulticaster::AfterClick

  .method public hidebysig newslot virtual 
          instance void  DelMolStruct() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnDelMolStruct(object,
                                                                                         class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxMoleStructEventMulticaster::DelMolStruct

  .method public hidebysig newslot virtual 
          instance void  GetCompStructureName() cil managed
  {
    // Code size       25 (0x19)
    .maxstack  3
    .locals init (class [mscorlib]System.EventArgs V_0)
    IL_0000:  newobj     instance void [mscorlib]System.EventArgs::.ctor()
    IL_0005:  stloc.0
    IL_0006:  ldarg.0
    IL_0007:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_000c:  ldarg.0
    IL_000d:  ldfld      class AxMOLESTRUCTLib.AxMoleStruct AxMOLESTRUCTLib.AxMoleStructEventMulticaster::parent
    IL_0012:  ldloc.0
    IL_0013:  callvirt   instance void AxMOLESTRUCTLib.AxMoleStruct::RaiseOnGetCompStructureName(object,
                                                                                                 class [mscorlib]System.EventArgs)
    IL_0018:  ret
  } // end of method AxMoleStructEventMulticaster::GetCompStructureName

} // end of class AxMOLESTRUCTLib.AxMoleStructEventMulticaster


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
// WARNING: Created Win32 resource file C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125\router\work\m-near-partial\axil\df5c39b2\orig.ildasm.res
