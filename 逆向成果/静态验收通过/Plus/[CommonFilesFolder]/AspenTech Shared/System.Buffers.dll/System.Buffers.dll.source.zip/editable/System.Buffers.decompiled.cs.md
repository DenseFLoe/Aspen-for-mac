# System.Buffers.decompiled.cs

Source: editable/System.Buffers.decompiled.cs

Source SHA-256: e08cf366a4cb13226b90bd54e4411ba4142f73c7905418cf5d82b28b1a6ef28c
