# System.Data.SqlClient.decompiled.cs

Source: editable/System.Data.SqlClient.decompiled.cs

Source SHA-256: 426ff5910fcd03562a72976af040f387f7839a2133a3d48524a5287d82eb469c
