# System.Security.Principal.Windows.decompiled.cs

Source: editable/System.Security.Principal.Windows.decompiled.cs

Source SHA-256: 6f29748714c21f64277f5a32d12f7cf823c43c5b24443786497482c7c6d88b68
