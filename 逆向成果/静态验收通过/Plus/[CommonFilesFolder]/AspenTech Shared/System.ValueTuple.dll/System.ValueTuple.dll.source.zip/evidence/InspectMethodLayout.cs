using System;
using System.IO;
using System.Linq;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Reflection.PortableExecutable;
using System.Text.Json;

using var file = File.OpenRead(args.Single());
using var image = new PEReader(file);
var metadata = image.GetMetadataReader();
var methods = metadata.MethodDefinitions.Select(handle =>
{
    var definition = metadata.GetMethodDefinition(handle);
    var rva = definition.RelativeVirtualAddress;
    var body = rva == 0 ? null : image.GetMethodBody(rva);
    return new
    {
        Token = MetadataTokens.GetToken(handle).ToString("X8"),
        Name = metadata.GetString(definition.Name),
        Rva = rva,
        Size = body?.Size ?? 0,
        CodeSize = body?.GetILBytes()?.Length ?? 0,
        LocalSignature = body == null ? 0 : MetadataTokens.GetToken(body.LocalSignature),
        Exceptions = body?.ExceptionRegions.Select(region => new
        {
            Code = (int)region.Kind,
            region.TryOffset,
            region.TryLength,
            region.HandlerOffset,
            region.HandlerLength,
            region.FilterOffset,
            CatchToken = MetadataTokens.GetToken(region.CatchType),
        }).ToArray(),
    };
}).ToArray();
var typeReferences = metadata.TypeReferences.Select(handle =>
{
    var reference = metadata.GetTypeReference(handle);
    return new { Token = MetadataTokens.GetToken(handle), Namespace = metadata.GetString(reference.Namespace), Name = metadata.GetString(reference.Name) };
}).ToArray();
var typeSpecifications = Enumerable.Range(1, metadata.GetTableRowCount(TableIndex.TypeSpec)).Select(row =>
{
    var handle = MetadataTokens.TypeSpecificationHandle(row);
    return new { Token = MetadataTokens.GetToken(handle), Signature = Convert.ToHexString(metadata.GetBlobBytes(metadata.GetTypeSpecification(handle).Signature)) };
}).ToArray();
Console.WriteLine(JsonSerializer.Serialize(new { Methods = methods, TypeReferences = typeReferences, TypeSpecifications = typeSpecifications }));
