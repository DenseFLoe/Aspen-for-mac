"""Compile C# code and rebind its resolved tokens to a preserved CLR metadata layout."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import struct
import zipfile

from pe_layout import bootstrap, finish_image, identified_image, move_bootstrap, names
from replay import build


def reproduce(compiled, recipe, metadata, debug, certificate, strong_name):
    if (sha256(compiled).hexdigest() != recipe["compiler_output_sha256"]
            or sha256(metadata).hexdigest() != recipe["original_metadata_sha256"]
            or sha256(debug).hexdigest() != recipe["debug_sha256"]):
        raise ValueError("Compiled C#, declared metadata layout, or debug record differs from the pinned inputs; signature not applied")
    pe, emitted = identified_image(compiled)
    text = names(pe)[".text"]
    text_start = text.PointerToRawData
    md_start = pe.get_offset_from_rva(emitted["rva"])
    if emitted["rva"] != recipe["metadata_rva"] or not text_start < md_start:
        raise ValueError("Compiler-generated code is outside the verified metadata boundary")
    body_region = bytearray(compiled[text_start:md_start])
    used = set()
    for method in recipe["verified_methods"]:
        at = pe.get_offset_from_rva(method["candidate_rva"]) - text_start
        width = method["bytes"]
        if not 0 <= at <= len(body_region) - width:
            raise ValueError("A managed method extends outside the verified code-and-resource prefix")
        code = bytearray(body_region[at:at + width])
        for field in method["remapped_tokens"]:
            offset = field["method_offset"]
            if not 0 <= offset <= width - 4 or struct.unpack_from("<I", code, offset)[0] != field["candidate_token"]:
                raise ValueError("Compiler-generated method token differs from its independently resolved binding")
            struct.pack_into("<I", code, offset, field["original_token"])
        if sha256(code).hexdigest() != method["body_sha256"]:
            raise ValueError("The re-emitted method body did not match the original logical target layout")
        destination = method["original_rva"] - text.VirtualAddress
        region = set(range(destination, destination + width))
        if not region.isdisjoint(used) or not 0 <= destination <= len(body_region) - width:
            raise ValueError("Original managed method extents overlap or are outside the emitted region")
        used.update(region)
        body_region[destination:destination + width] = code
    before, after = bootstrap(pe), recipe["x86_bootstrap"]
    iat = pe.get_offset_from_rva(before["iat"]) - text_start
    struct.pack_into("<I", body_region, iat, after["hint"])
    cli = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress) - text_start
    resources = recipe["managed_resources"]
    previous_resource_rva, previous_resource_size = struct.unpack_from("<II", body_region, cli + 24)
    resource_data = pe.get_data(previous_resource_rva, previous_resource_size)
    if previous_resource_size != resources["bytes"] or sha256(resource_data).hexdigest() != resources["sha256"]:
        raise ValueError("Compiler-emitted managed resources differ from the recorded original")
    struct.pack_into("<I", body_region, cli + 12, len(metadata))
    struct.pack_into("<II", body_region, cli + 24, resources["rva"], resources["bytes"])
    struct.pack_into("<II", body_region, cli + 32, recipe["strong_name_rva"], recipe["strong_name"]["width"])
    if sha256(body_region).hexdigest() != recipe["original_pre_metadata_sha256"]:
        raise ValueError("Compiler-derived CLR code or local managed resources differ from the original pre-metadata region")
    body_region += metadata
    resource_relative = resources["rva"] - text.VirtualAddress
    if len(body_region) > resource_relative:
        raise ValueError("Original metadata overlaps the managed resource directory")
    body_region = body_region.ljust(resource_relative, b"\0") + resource_data
    strong_relative = recipe["strong_name"]["file_offset"] - text_start
    debug_relative = recipe["debug_rva"] - text.VirtualAddress
    if not len(body_region) <= strong_relative < strong_relative + recipe["strong_name"]["width"] <= debug_relative:
        raise ValueError("Signature or debug overlaps the declared CLR metadata layout")
    body_region = body_region.ljust(debug_relative, b"\0") + debug + move_bootstrap(pe, before, after)
    return finish_image(compiled, pe, recipe, body_region, certificate, strong_name)


def rebuild_tokens(package_path, work):
    compiled = build(package_path, work)
    with zipfile.ZipFile(package_path) as package:
        recipe = json.loads(package.read("layout-recipe.json"))
        data = reproduce(compiled.read_bytes(), recipe, package.read("original-build/clr-metadata.bin"),
                         package.read("original-build/debug-record.bin"), package.read("original-build/certificate-table.bin"),
                         package.read("original-build/strong-name.bin"))
    dest = work / "exact"
    dest.mkdir()
    artifact = dest / compiled.name
    artifact.write_bytes(data)
    return artifact


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("archive", type=Path)
    cli.add_argument("new_output_directory", type=Path)
    args = cli.parse_args()
    print(rebuild_tokens(args.archive, args.new_output_directory))
