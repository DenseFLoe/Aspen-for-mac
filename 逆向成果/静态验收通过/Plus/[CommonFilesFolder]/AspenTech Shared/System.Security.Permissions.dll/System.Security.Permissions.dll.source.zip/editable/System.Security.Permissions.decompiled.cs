using System;
using System.Configuration;
using System.Data.Common;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Diagnostics;
using System.DirectoryServices;
using System.Drawing.Printing;
using System.Net;
using System.Net.Mail;
using System.Net.NetworkInformation;
using System.Net.PeerToPeer;
using System.Net.PeerToPeer.Collaboration;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using System.Security.Policy;
using System.ServiceProcess;
using System.Transactions;
using System.Web;
using FxResources.System.Security.Permissions;
using Microsoft.CodeAnalysis;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: TargetFramework(".NETFramework,Version=v4.6.2", FrameworkDisplayName = ".NET Framework 4.6.2")]
[assembly: AssemblyMetadata("Serviceable", "True")]
[assembly: AssemblyMetadata("PreferInbox", "True")]
[assembly: AssemblyDefaultAlias("System.Security.Permissions")]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: CLSCompliant(true)]
[assembly: AssemblyMetadata("IsTrimmable", "True")]
[assembly: DefaultDllImportSearchPaths(DllImportSearchPath.System32 | DllImportSearchPath.AssemblyDirectory)]
[assembly: AssemblyCompany("Microsoft Corporation")]
[assembly: AssemblyCopyright("© Microsoft Corporation. All rights reserved.")]
[assembly: AssemblyDescription("Provides types supporting Code Access Security (CAS).")]
[assembly: AssemblyFileVersion("8.0.23.53103")]
[assembly: AssemblyInformationalVersion("8.0.0+5535e31a712343a63f5d7d796cd874e563e5ac14")]
[assembly: AssemblyProduct("Microsoft® .NET")]
[assembly: AssemblyTitle("System.Security.Permissions")]
[assembly: AssemblyMetadata("RepositoryUrl", "https://github.com/dotnet/runtime")]
[assembly: AssemblyVersion("8.0.0.0")]
[assembly: TypeForwardedTo(typeof(ApplicationIdentity))]
[assembly: TypeForwardedTo(typeof(ConfigurationPermission))]
[assembly: TypeForwardedTo(typeof(ConfigurationPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(DBDataPermission))]
[assembly: TypeForwardedTo(typeof(DBDataPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(OdbcPermission))]
[assembly: TypeForwardedTo(typeof(OdbcPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(OleDbPermission))]
[assembly: TypeForwardedTo(typeof(OleDbPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(OraclePermission))]
[assembly: TypeForwardedTo(typeof(OraclePermissionAttribute))]
[assembly: TypeForwardedTo(typeof(SqlClientPermission))]
[assembly: TypeForwardedTo(typeof(SqlClientPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(EventLogPermission))]
[assembly: TypeForwardedTo(typeof(EventLogPermissionAccess))]
[assembly: TypeForwardedTo(typeof(EventLogPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(EventLogPermissionEntry))]
[assembly: TypeForwardedTo(typeof(EventLogPermissionEntryCollection))]
[assembly: TypeForwardedTo(typeof(PerformanceCounterPermission))]
[assembly: TypeForwardedTo(typeof(PerformanceCounterPermissionAccess))]
[assembly: TypeForwardedTo(typeof(PerformanceCounterPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(PerformanceCounterPermissionEntry))]
[assembly: TypeForwardedTo(typeof(PerformanceCounterPermissionEntryCollection))]
[assembly: TypeForwardedTo(typeof(DirectoryServicesPermission))]
[assembly: TypeForwardedTo(typeof(DirectoryServicesPermissionAccess))]
[assembly: TypeForwardedTo(typeof(DirectoryServicesPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(DirectoryServicesPermissionEntry))]
[assembly: TypeForwardedTo(typeof(DirectoryServicesPermissionEntryCollection))]
[assembly: TypeForwardedTo(typeof(PrintingPermission))]
[assembly: TypeForwardedTo(typeof(PrintingPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(PrintingPermissionLevel))]
[assembly: TypeForwardedTo(typeof(DnsPermission))]
[assembly: TypeForwardedTo(typeof(DnsPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(EndpointPermission))]
[assembly: TypeForwardedTo(typeof(SmtpAccess))]
[assembly: TypeForwardedTo(typeof(SmtpPermission))]
[assembly: TypeForwardedTo(typeof(SmtpPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(NetworkAccess))]
[assembly: TypeForwardedTo(typeof(NetworkInformationAccess))]
[assembly: TypeForwardedTo(typeof(NetworkInformationPermission))]
[assembly: TypeForwardedTo(typeof(NetworkInformationPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(PeerCollaborationPermission))]
[assembly: TypeForwardedTo(typeof(PeerCollaborationPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(PnrpPermission))]
[assembly: TypeForwardedTo(typeof(PnrpPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(PnrpScope))]
[assembly: TypeForwardedTo(typeof(SocketPermission))]
[assembly: TypeForwardedTo(typeof(SocketPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(TransportType))]
[assembly: TypeForwardedTo(typeof(WebPermission))]
[assembly: TypeForwardedTo(typeof(WebPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(CodeAccessPermission))]
[assembly: TypeForwardedTo(typeof(HostProtectionException))]
[assembly: TypeForwardedTo(typeof(HostSecurityManager))]
[assembly: TypeForwardedTo(typeof(HostSecurityManagerOptions))]
[assembly: TypeForwardedTo(typeof(IEvidenceFactory))]
[assembly: TypeForwardedTo(typeof(IPermission))]
[assembly: TypeForwardedTo(typeof(ISecurityEncodable))]
[assembly: TypeForwardedTo(typeof(ISecurityPolicyEncodable))]
[assembly: TypeForwardedTo(typeof(IStackWalk))]
[assembly: TypeForwardedTo(typeof(NamedPermissionSet))]
[assembly: TypeForwardedTo(typeof(CodeAccessSecurityAttribute))]
[assembly: TypeForwardedTo(typeof(DataProtectionPermission))]
[assembly: TypeForwardedTo(typeof(DataProtectionPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(DataProtectionPermissionFlags))]
[assembly: TypeForwardedTo(typeof(EnvironmentPermission))]
[assembly: TypeForwardedTo(typeof(EnvironmentPermissionAccess))]
[assembly: TypeForwardedTo(typeof(EnvironmentPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(FileDialogPermission))]
[assembly: TypeForwardedTo(typeof(FileDialogPermissionAccess))]
[assembly: TypeForwardedTo(typeof(FileDialogPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(FileIOPermission))]
[assembly: TypeForwardedTo(typeof(FileIOPermissionAccess))]
[assembly: TypeForwardedTo(typeof(FileIOPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(GacIdentityPermission))]
[assembly: TypeForwardedTo(typeof(GacIdentityPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(HostProtectionAttribute))]
[assembly: TypeForwardedTo(typeof(HostProtectionResource))]
[assembly: TypeForwardedTo(typeof(IsolatedStorageContainment))]
[assembly: TypeForwardedTo(typeof(IsolatedStorageFilePermission))]
[assembly: TypeForwardedTo(typeof(IsolatedStorageFilePermissionAttribute))]
[assembly: TypeForwardedTo(typeof(IsolatedStoragePermission))]
[assembly: TypeForwardedTo(typeof(IsolatedStoragePermissionAttribute))]
[assembly: TypeForwardedTo(typeof(IUnrestrictedPermission))]
[assembly: TypeForwardedTo(typeof(KeyContainerPermission))]
[assembly: TypeForwardedTo(typeof(KeyContainerPermissionAccessEntry))]
[assembly: TypeForwardedTo(typeof(KeyContainerPermissionAccessEntryCollection))]
[assembly: TypeForwardedTo(typeof(KeyContainerPermissionAccessEntryEnumerator))]
[assembly: TypeForwardedTo(typeof(KeyContainerPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(KeyContainerPermissionFlags))]
[assembly: TypeForwardedTo(typeof(MediaPermission))]
[assembly: TypeForwardedTo(typeof(MediaPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(MediaPermissionAudio))]
[assembly: TypeForwardedTo(typeof(MediaPermissionImage))]
[assembly: TypeForwardedTo(typeof(MediaPermissionVideo))]
[assembly: TypeForwardedTo(typeof(PermissionSetAttribute))]
[assembly: TypeForwardedTo(typeof(PermissionState))]
[assembly: TypeForwardedTo(typeof(PrincipalPermission))]
[assembly: TypeForwardedTo(typeof(PrincipalPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(PublisherIdentityPermission))]
[assembly: TypeForwardedTo(typeof(PublisherIdentityPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(ReflectionPermission))]
[assembly: TypeForwardedTo(typeof(ReflectionPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(ReflectionPermissionFlag))]
[assembly: TypeForwardedTo(typeof(RegistryPermission))]
[assembly: TypeForwardedTo(typeof(RegistryPermissionAccess))]
[assembly: TypeForwardedTo(typeof(RegistryPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(ResourcePermissionBase))]
[assembly: TypeForwardedTo(typeof(ResourcePermissionBaseEntry))]
[assembly: TypeForwardedTo(typeof(SecurityAction))]
[assembly: TypeForwardedTo(typeof(SecurityAttribute))]
[assembly: TypeForwardedTo(typeof(SecurityPermission))]
[assembly: TypeForwardedTo(typeof(SecurityPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(SecurityPermissionFlag))]
[assembly: TypeForwardedTo(typeof(SiteIdentityPermission))]
[assembly: TypeForwardedTo(typeof(SiteIdentityPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(StorePermission))]
[assembly: TypeForwardedTo(typeof(StorePermissionAttribute))]
[assembly: TypeForwardedTo(typeof(StorePermissionFlags))]
[assembly: TypeForwardedTo(typeof(StrongNameIdentityPermission))]
[assembly: TypeForwardedTo(typeof(StrongNameIdentityPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(StrongNamePublicKeyBlob))]
[assembly: TypeForwardedTo(typeof(TypeDescriptorPermission))]
[assembly: TypeForwardedTo(typeof(TypeDescriptorPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(TypeDescriptorPermissionFlags))]
[assembly: TypeForwardedTo(typeof(UIPermission))]
[assembly: TypeForwardedTo(typeof(UIPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(UIPermissionClipboard))]
[assembly: TypeForwardedTo(typeof(UIPermissionWindow))]
[assembly: TypeForwardedTo(typeof(UrlIdentityPermission))]
[assembly: TypeForwardedTo(typeof(UrlIdentityPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(WebBrowserPermission))]
[assembly: TypeForwardedTo(typeof(WebBrowserPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(WebBrowserPermissionLevel))]
[assembly: TypeForwardedTo(typeof(ZoneIdentityPermission))]
[assembly: TypeForwardedTo(typeof(ZoneIdentityPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(PermissionSet))]
[assembly: TypeForwardedTo(typeof(AllMembershipCondition))]
[assembly: TypeForwardedTo(typeof(ApplicationDirectory))]
[assembly: TypeForwardedTo(typeof(ApplicationDirectoryMembershipCondition))]
[assembly: TypeForwardedTo(typeof(ApplicationTrust))]
[assembly: TypeForwardedTo(typeof(ApplicationTrustCollection))]
[assembly: TypeForwardedTo(typeof(ApplicationTrustEnumerator))]
[assembly: TypeForwardedTo(typeof(ApplicationVersionMatch))]
[assembly: TypeForwardedTo(typeof(CodeConnectAccess))]
[assembly: TypeForwardedTo(typeof(CodeGroup))]
[assembly: TypeForwardedTo(typeof(Evidence))]
[assembly: TypeForwardedTo(typeof(EvidenceBase))]
[assembly: TypeForwardedTo(typeof(FileCodeGroup))]
[assembly: TypeForwardedTo(typeof(FirstMatchCodeGroup))]
[assembly: TypeForwardedTo(typeof(GacInstalled))]
[assembly: TypeForwardedTo(typeof(GacMembershipCondition))]
[assembly: TypeForwardedTo(typeof(Hash))]
[assembly: TypeForwardedTo(typeof(HashMembershipCondition))]
[assembly: TypeForwardedTo(typeof(IIdentityPermissionFactory))]
[assembly: TypeForwardedTo(typeof(IMembershipCondition))]
[assembly: TypeForwardedTo(typeof(NetCodeGroup))]
[assembly: TypeForwardedTo(typeof(PermissionRequestEvidence))]
[assembly: TypeForwardedTo(typeof(PolicyException))]
[assembly: TypeForwardedTo(typeof(PolicyLevel))]
[assembly: TypeForwardedTo(typeof(PolicyStatement))]
[assembly: TypeForwardedTo(typeof(PolicyStatementAttribute))]
[assembly: TypeForwardedTo(typeof(Publisher))]
[assembly: TypeForwardedTo(typeof(PublisherMembershipCondition))]
[assembly: TypeForwardedTo(typeof(Site))]
[assembly: TypeForwardedTo(typeof(SiteMembershipCondition))]
[assembly: TypeForwardedTo(typeof(StrongName))]
[assembly: TypeForwardedTo(typeof(StrongNameMembershipCondition))]
[assembly: TypeForwardedTo(typeof(TrustManagerContext))]
[assembly: TypeForwardedTo(typeof(TrustManagerUIContext))]
[assembly: TypeForwardedTo(typeof(UnionCodeGroup))]
[assembly: TypeForwardedTo(typeof(Url))]
[assembly: TypeForwardedTo(typeof(UrlMembershipCondition))]
[assembly: TypeForwardedTo(typeof(Zone))]
[assembly: TypeForwardedTo(typeof(ZoneMembershipCondition))]
[assembly: TypeForwardedTo(typeof(PolicyLevelType))]
[assembly: TypeForwardedTo(typeof(SecurityContext))]
[assembly: TypeForwardedTo(typeof(SecurityContextSource))]
[assembly: TypeForwardedTo(typeof(SecurityElement))]
[assembly: TypeForwardedTo(typeof(SecurityManager))]
[assembly: TypeForwardedTo(typeof(SecurityState))]
[assembly: TypeForwardedTo(typeof(SecurityZone))]
[assembly: TypeForwardedTo(typeof(XmlSyntaxException))]
[assembly: TypeForwardedTo(typeof(ServiceControllerPermission))]
[assembly: TypeForwardedTo(typeof(ServiceControllerPermissionAccess))]
[assembly: TypeForwardedTo(typeof(ServiceControllerPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(ServiceControllerPermissionEntry))]
[assembly: TypeForwardedTo(typeof(ServiceControllerPermissionEntryCollection))]
[assembly: TypeForwardedTo(typeof(DistributedTransactionPermission))]
[assembly: TypeForwardedTo(typeof(DistributedTransactionPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(AspNetHostingPermission))]
[assembly: TypeForwardedTo(typeof(AspNetHostingPermissionAttribute))]
[assembly: TypeForwardedTo(typeof(AspNetHostingPermissionLevel))]

namespace Microsoft.CodeAnalysis
{
	[CompilerGenerated]
	[Embedded]
	internal sealed class EmbeddedAttribute : Attribute
	{
	}
}
namespace System.Runtime.CompilerServices
{
	[CompilerGenerated]
	[Embedded]
	[AttributeUsage(AttributeTargets.Module, AllowMultiple = false, Inherited = false)]
	internal sealed class RefSafetyRulesAttribute : Attribute
	{
		public readonly int Version;

		public RefSafetyRulesAttribute(int version)
		{
			Version = version;
		}
	}
}
namespace FxResources.System.Security.Permissions
{
	internal static class SR
	{
	}
}
namespace System
{
	internal static class SR
	{
		private static readonly bool s_usingResourceKeys = AppContext.TryGetSwitch("System.Resources.UseSystemResourceKeys", out var isEnabled) ? isEnabled : false;

		private static ResourceManager s_resourceManager;

		internal static ResourceManager ResourceManager => s_resourceManager ?? (s_resourceManager = new ResourceManager(typeof(global::FxResources.System.Security.Permissions.SR)));

		internal static string Argument_InvalidPermissionState => GetResourceString("Argument_InvalidPermissionState");

		internal static string Argument_NotAPermissionElement => GetResourceString("Argument_NotAPermissionElement");

		internal static string Argument_InvalidXMLBadVersion => GetResourceString("Argument_InvalidXMLBadVersion");

		internal static string Argument_WrongType => GetResourceString("Argument_WrongType");

		internal static string HostProtection_ProtectedResources => GetResourceString("HostProtection_ProtectedResources");

		internal static string HostProtection_DemandedResources => GetResourceString("HostProtection_DemandedResources");

		internal static string Security_PrincipalPermission => GetResourceString("Security_PrincipalPermission");

		internal static string PlatformNotSupported_CAS => GetResourceString("PlatformNotSupported_CAS");

		internal static bool UsingResourceKeys()
		{
			return s_usingResourceKeys;
		}

		private static string GetResourceString(string resourceKey)
		{
			if (UsingResourceKeys())
			{
				return resourceKey;
			}
			string result = null;
			try
			{
				result = ResourceManager.GetString(resourceKey);
			}
			catch (MissingManifestResourceException)
			{
			}
			return result;
		}

		private static string GetResourceString(string resourceKey, string defaultString)
		{
			string resourceString = GetResourceString(resourceKey);
			if (!(resourceKey == resourceString) && resourceString != null)
			{
				return resourceString;
			}
			return defaultString;
		}

		internal static string Format(string resourceFormat, object p1)
		{
			if (UsingResourceKeys())
			{
				return string.Join(", ", resourceFormat, p1);
			}
			return string.Format(resourceFormat, p1);
		}

		internal static string Format(string resourceFormat, object p1, object p2)
		{
			if (UsingResourceKeys())
			{
				return string.Join(", ", resourceFormat, p1, p2);
			}
			return string.Format(resourceFormat, p1, p2);
		}

		internal static string Format(string resourceFormat, object p1, object p2, object p3)
		{
			if (UsingResourceKeys())
			{
				return string.Join(", ", resourceFormat, p1, p2, p3);
			}
			return string.Format(resourceFormat, p1, p2, p3);
		}

		internal static string Format(string resourceFormat, params object[] args)
		{
			if (args != null)
			{
				if (UsingResourceKeys())
				{
					return resourceFormat + ", " + string.Join(", ", args);
				}
				return string.Format(resourceFormat, args);
			}
			return resourceFormat;
		}

		internal static string Format(IFormatProvider provider, string resourceFormat, object p1)
		{
			if (UsingResourceKeys())
			{
				return string.Join(", ", resourceFormat, p1);
			}
			return string.Format(provider, resourceFormat, p1);
		}

		internal static string Format(IFormatProvider provider, string resourceFormat, object p1, object p2)
		{
			if (UsingResourceKeys())
			{
				return string.Join(", ", resourceFormat, p1, p2);
			}
			return string.Format(provider, resourceFormat, p1, p2);
		}

		internal static string Format(IFormatProvider provider, string resourceFormat, object p1, object p2, object p3)
		{
			if (UsingResourceKeys())
			{
				return string.Join(", ", resourceFormat, p1, p2, p3);
			}
			return string.Format(provider, resourceFormat, p1, p2, p3);
		}

		internal static string Format(IFormatProvider provider, string resourceFormat, params object[] args)
		{
			if (args != null)
			{
				if (UsingResourceKeys())
				{
					return resourceFormat + ", " + string.Join(", ", args);
				}
				return string.Format(provider, resourceFormat, args);
			}
			return resourceFormat;
		}
	}
	[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Constructor | AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Event | AttributeTargets.Interface | AttributeTargets.Delegate, Inherited = false)]
	internal sealed class ObsoleteAttribute : Attribute
	{
		public string Message { get; }

		public bool IsError { get; }

		public string DiagnosticId { get; set; }

		public string UrlFormat { get; set; }

		public ObsoleteAttribute()
		{
		}

		public ObsoleteAttribute(string message)
		{
			Message = message;
		}

		public ObsoleteAttribute(string message, bool error)
		{
			Message = message;
			IsError = error;
		}
	}
}
namespace System.Runtime.Versioning
{
	internal abstract class OSPlatformAttribute : Attribute
	{
		public string PlatformName { get; }

		private protected OSPlatformAttribute(string platformName)
		{
			PlatformName = platformName;
		}
	}
	[AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false, Inherited = false)]
	internal sealed class TargetPlatformAttribute : OSPlatformAttribute
	{
		public TargetPlatformAttribute(string platformName)
			: base(platformName)
		{
		}
	}
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Module | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Constructor | AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Event | AttributeTargets.Interface, AllowMultiple = true, Inherited = false)]
	internal sealed class SupportedOSPlatformAttribute : OSPlatformAttribute
	{
		public SupportedOSPlatformAttribute(string platformName)
			: base(platformName)
		{
		}
	}
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Module | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Constructor | AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Event | AttributeTargets.Interface, AllowMultiple = true, Inherited = false)]
	internal sealed class UnsupportedOSPlatformAttribute : OSPlatformAttribute
	{
		public string Message { get; }

		public UnsupportedOSPlatformAttribute(string platformName)
			: base(platformName)
		{
		}

		public UnsupportedOSPlatformAttribute(string platformName, string message)
			: base(platformName)
		{
			Message = message;
		}
	}
	[AttributeUsage(AttributeTargets.Assembly | AttributeTargets.Module | AttributeTargets.Class | AttributeTargets.Struct | AttributeTargets.Enum | AttributeTargets.Constructor | AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Event | AttributeTargets.Interface, AllowMultiple = true, Inherited = false)]
	internal sealed class ObsoletedOSPlatformAttribute : OSPlatformAttribute
	{
		public string Message { get; }

		public string Url { get; set; }

		public ObsoletedOSPlatformAttribute(string platformName)
			: base(platformName)
		{
		}

		public ObsoletedOSPlatformAttribute(string platformName, string message)
			: base(platformName)
		{
			Message = message;
		}
	}
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true, Inherited = false)]
	internal sealed class SupportedOSPlatformGuardAttribute : OSPlatformAttribute
	{
		public SupportedOSPlatformGuardAttribute(string platformName)
			: base(platformName)
		{
		}
	}
	[AttributeUsage(AttributeTargets.Method | AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = true, Inherited = false)]
	internal sealed class UnsupportedOSPlatformGuardAttribute : OSPlatformAttribute
	{
		public UnsupportedOSPlatformGuardAttribute(string platformName)
			: base(platformName)
		{
		}
	}
}
namespace System.Runtime.InteropServices
{
	[AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
	internal sealed class LibraryImportAttribute : Attribute
	{
		public string LibraryName { get; }

		public string EntryPoint { get; set; }

		public StringMarshalling StringMarshalling { get; set; }

		public Type StringMarshallingCustomType { get; set; }

		public bool SetLastError { get; set; }

		public LibraryImportAttribute(string libraryName)
		{
			LibraryName = libraryName;
		}
	}
	internal enum StringMarshalling
	{
		Custom,
		Utf8,
		Utf16
	}
}
