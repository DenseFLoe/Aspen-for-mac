# System.Security.Permissions.decompiled.cs

Source: editable/System.Security.Permissions.decompiled.cs

Source SHA-256: 654d3a7d516dfe31add09678e4b54b8ae871798726cd1873db3e330b0f2733bc
