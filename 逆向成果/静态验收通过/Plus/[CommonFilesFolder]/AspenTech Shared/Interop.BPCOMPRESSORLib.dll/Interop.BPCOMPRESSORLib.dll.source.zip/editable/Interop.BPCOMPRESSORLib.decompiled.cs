using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: ImportedFromTypeLib("BPCOMPRESSORLib")]
[assembly: TypeLibVersion(1, 0)]
[assembly: Guid("c890dade-eedf-11d3-837d-00c04f5e694f")]
[assembly: AssemblyVersion("1.0.0.0")]
namespace BPCOMPRESSORLib;

[ComImport]
[Guid("C890DAEC-EEDF-11D3-837D-00C04F5E694F")]
[TypeLibType(2)]
[ClassInterface((short)0)]
public class CompressorClass : ICompressor, Compressor
{
	[DispId(1)]
	public virtual extern string CompressedString
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(2)]
	public virtual extern string DecompressedString
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}
}
[ComImport]
[CoClass(typeof(CompressorClass))]
[Guid("C890DAEB-EEDF-11D3-837D-00C04F5E694F")]
public interface Compressor : ICompressor
{
}
[ComImport]
[TypeLibType(4160)]
[Guid("C890DAEB-EEDF-11D3-837D-00C04F5E694F")]
public interface ICompressor
{
	[DispId(1)]
	string CompressedString
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(1)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}

	[DispId(2)]
	string DecompressedString
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[return: MarshalAs(UnmanagedType.BStr)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[DispId(2)]
		[param: In]
		[param: MarshalAs(UnmanagedType.BStr)]
		set;
	}
}
