"""Recompile declaration-only COM imports and replay their legacy x86 PE envelope."""

from argparse import ArgumentParser
from hashlib import sha256
import json
from pathlib import Path
import struct
import zipfile

from pe_layout import bootstrap, finish_image, identified_image, names
from replay import build


def digest(data):
    return sha256(data).hexdigest()


def legacy_bootstrap(pe, prior, expected):
    if (prior["iat"] != expected["iat"] or prior["reloc_rva"] != expected["reloc_rva"]
            or prior["thunk"] - prior["start"] != expected["thunk"] - expected["start"]):
        raise ValueError("Legacy x86 import anchors differ")
    first = pe.get_data(prior["start"], prior["thunk"] - prior["start"])
    first = bytearray(first)
    struct.pack_into("<I", first, 0, expected["thunk"])
    struct.pack_into("<I", first, 12, expected["module_name"])
    thunk = bytearray(pe.get_data(prior["thunk"], prior["hint"] - prior["thunk"]))
    struct.pack_into("<I", thunk, 0, expected["hint"])
    thunk_width = expected["hint"] - expected["thunk"]
    if thunk_width < 8 or thunk_width - len(thunk) not in (-4,0,4,8) or any(thunk[4:]):
        raise ValueError("Unsupported legacy alignment before the import hint/name")
    thunk = thunk[:thunk_width].ljust(thunk_width, b"\0")
    strings = pe.get_data(prior["hint"], prior["data_length"] - (prior["hint"] - prior["start"]))
    if (strings != b"\0\0_CorDllMain\0mscoree.dll\0"
            or expected["module_name"] - expected["hint"] != len(b"\0\0_CorDllMain\0")
            or expected["import_size"] != expected["data_length"] + 1):
        raise ValueError("Legacy bootstrap no longer references the compiler's CLR DLL entry point")
    content = first + thunk + strings
    if len(content) != expected["data_length"] or not 0 <= expected["entry"] - expected["start"] - len(content) <= 8:
        raise ValueError("Legacy bootstrap alignment changed")
    return content.ljust(expected["entry"] - expected["start"], b"\0") + pe.get_data(prior["entry"], 6)


def reproduce(compiled, recipe, metadata, debug, certificate, strong_name):
    if (digest(compiled) != recipe["compiler_output_sha256"] or digest(metadata) != recipe["original_metadata_sha256"]
            or digest(debug) != recipe["debug_sha256"] or debug):
        raise ValueError("The compiler output, CLR layout or debug record changed; signature not applied")
    pe, info = identified_image(compiled)
    boot, old = bootstrap(pe), recipe["x86_bootstrap"]
    text = names(pe)[".text"]
    cli_dir = pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    cli_rel = cli_dir.VirtualAddress - text.VirtualAddress
    prefix = bytearray(pe.get_data(text.VirtualAddress, info["rva"] - text.VirtualAddress))
    if (len(prefix) != cli_rel + 72 or cli_rel != 8 or recipe["managed_resources"]["bytes"]
            or any(prefix[cli_rel+20:cli_rel+32]) or recipe["verified_methods"]):
        raise ValueError("Compiler emitted unexpected managed code, entry or resource data")
    strong = recipe["strong_name"]
    if (not strong or info["strong_name_bytes"] != strong["width"]
            or strong["file_offset"] != text.PointerToRawData + len(prefix)
            or recipe["strong_name_rva"] != text.VirtualAddress + len(prefix)
            or recipe["metadata_rva"] != recipe["strong_name_rva"] + strong["width"]
            or any(pe.get_data(info["strong_name_rva"], info["strong_name_bytes"]))):
        raise ValueError("Legacy strong-name alignment changed before replay")
    struct.pack_into("<I", prefix, 0, old["hint"])
    struct.pack_into("<II", prefix, cli_rel + 8, recipe["metadata_rva"], len(metadata))
    struct.pack_into("<II", prefix, cli_rel + 32, recipe["strong_name_rva"], strong["width"])
    prefix += bytes(strong["width"])
    if digest(prefix) != recipe["legacy"]["masked_prefix_sha256"]:
        raise ValueError("Replayed CLR prefix differs from the original; signature not applied")
    body = prefix + metadata
    legacy = legacy_bootstrap(pe, boot, old)
    padding = old["start"] - text.VirtualAddress - len(body)
    if not 0 <= padding <= 8:
        raise ValueError("Legacy imports overlap the modeled CLR declaration layout")
    body += bytes(padding) + legacy
    # Normalize the old 32-bit linker convention and the zero-only Resource directory tail.
    normalized = bytearray(compiled)
    coff = pe.FILE_HEADER
    old_chars = recipe["legacy"]["coff_characteristics"]
    if coff.Characteristics ^ old_chars != 0x120 or old_chars & 0x120 != 0x100:
        raise ValueError("Unrecognized old/new PE COFF32 characteristic convention")
    struct.pack_into("<H", normalized, coff.get_field_absolute_offset("Characteristics"), old_chars)
    resource = names(pe)[".rsrc"]
    old_resource_size = recipe["sections"][".rsrc"]["virtual_bytes"]
    dd = pe.OPTIONAL_HEADER.DATA_DIRECTORY[2]
    if (resource.Misc_VirtualSize != dd.Size or resource.VirtualAddress != dd.VirtualAddress
            or resource.Misc_VirtualSize - old_resource_size not in (0,4)
            or any(pe.get_data(dd.VirtualAddress + old_resource_size, dd.Size - old_resource_size))):
        raise ValueError("Unrecognized old/new Win32 resource alignment")
    if digest(pe.get_data(resource.VirtualAddress,resource.SizeOfRawData)) != recipe["legacy"]["rsrc_sha256"]:
        raise ValueError("Compiled Win32 resource section differs; signature not applied")
    struct.pack_into("<I", normalized, resource.get_field_absolute_offset("Misc_VirtualSize"), old_resource_size)
    struct.pack_into("<II", normalized, dd.get_file_offset(), dd.VirtualAddress, old_resource_size)
    pe, _ = identified_image(bytes(normalized))
    return finish_image(bytes(normalized), pe, recipe, body, certificate, strong_name)


def rebuild_tokens(package_path, work):
    compiled = build(package_path, work)
    with zipfile.ZipFile(package_path) as package:
        recipe = json.loads(package.read("layout-recipe.json"))
        data = reproduce(compiled.read_bytes(), recipe, package.read("original-build/clr-metadata.bin"),
                         package.read("original-build/debug-record.bin"), package.read("original-build/certificate-table.bin"),
                         package.read("original-build/strong-name.bin"))
    destination = work / "exact"
    destination.mkdir()
    result = destination / compiled.name
    result.write_bytes(data)
    return result


if __name__ == "__main__":
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("archive",type=Path)
    parser.add_argument("new_output_directory",type=Path)
    args = parser.parse_args()
    print(rebuild_tokens(args.archive,args.new_output_directory))
