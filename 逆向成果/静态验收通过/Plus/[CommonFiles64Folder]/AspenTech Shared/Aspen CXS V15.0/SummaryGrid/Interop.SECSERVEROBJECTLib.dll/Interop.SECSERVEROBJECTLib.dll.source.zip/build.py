"""Build using the editable IL declarations and VERSIONINFO JSON, without an original DLL."""
import argparse
import hashlib
import json
import os
import struct
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from image import FORMATS, Image, blob, string, tables, u16, u32

PACKAGE = Path(__file__).resolve().parent
NAME = 'Interop.SECSERVEROBJECTLib.dll'
RETURN_MARKER = '.custom instance void [mscorlib]System.Object::.ctor() = (01 00 00 00)'
MARSHAL_MARKER = ('.custom instance void [mscorlib]System.Runtime.InteropServices.MarshalAsAttribute'
                  '::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.UnmanagedType)'
                  ' = (01 00 00 00 00 00 00 00)')


def align4(data):
    return data + bytes((-len(data)) % 4)


def wide(text):
    return (text+'\0').encode('utf-16le')


def version_block(key, kind=1, value=b'', children=()):
    contents = align4(bytes(6) + wide(key)) + value
    for child in children:
        contents = align4(contents) + child
    if children:
        contents = align4(contents)
    return struct.pack('<HHH', len(contents), len(value)//(2 if kind else 1), kind) + contents[6:]


def version_resource(spec):
    f = spec['fixed']
    def parts(version):
        a,b,c,d = version
        return (a<<16)|b, (c<<16)|d
    fixed = struct.pack('<13I',int(f['signature'],0),int(f['structureVersion'],0),
                        *parts(f['fileVersion']),*parts(f['productVersion']),
                        *(f[k] for k in ('fileFlagsMask','fileFlags','fileOS','fileType',
                                         'fileSubtype','dateMS','dateLS')))
    table = version_block(spec['stringTable'],children=[
        version_block(k, value=wide(v)) for k,v in spec['strings'].items()])
    trans = version_block('Translation', 0, struct.pack('<HH', *spec['translation']))
    payload = version_block('VS_VERSION_INFO', 0, fixed, [
        version_block('StringFileInfo', children=[table]), version_block('VarFileInfo', children=[trans])])
    def header(length, typ, name, lang):
        return struct.pack('<II4HIHHII', length,32,0xffff,typ,0xffff,name,0,0,lang,0,0)
    return header(0,0,0,0) + header(len(payload),spec['type'],spec['id'],spec['language']) + payload


def finalize(data, spec, null_returns, unnamed, marshal_markers, safearray_element_only):
    """Resolve the explicit IL extension markers and deterministic build fields."""
    img = Image(data)
    t = tables(img)
    markers = {}
    for rid, (parent, name, _) in enumerate(t[10],1):
        if parent & 7 != 1 or string(img,name) != '.ctor':
            continue
        _, type_name, namespace = t[1][(parent>>3)-1]
        markers[rid] = string(img,namespace)+'.'+string(img,type_name)
    retained = []
    removed_returns = removed_marshal = 0
    for parent, constructor, value in t[12]:
        target = markers.get(constructor>>3) if constructor & 7 == 3 else None
        if target == 'System.Object' and parent & 31 == 4:
            param = t[8][(parent>>5)-1]
            if param[:2] != (0,0):
                raise ValueError('Return-row marker is attached to a nonempty parameter')
            removed_returns += 1
        elif target == 'System.Runtime.InteropServices.MarshalAsAttribute' and parent & 31 == 14:
            removed_marshal += 1
        else:
            retained.append((parent,constructor,value))
    # ILAsm may consume MarshalAs as a pseudo attribute while retaining its constructor.
    if (removed_returns != null_returns or removed_marshal > marshal_markers or
        (marshal_markers and 'System.Runtime.InteropServices.MarshalAsAttribute' not in markers.values())):
        raise ValueError('ILAsm marker attributes do not correspond to source annotations')
    t[12] = retained
    found_unnamed = 0
    for i,(flags,sequence,name) in enumerate(t[8]):
        if string(img,name) == '__unnamed_cli_parameter__':
            t[8][i] = (flags,sequence,0)
            found_unnamed += 1
    if found_unnamed != unnamed:
        raise ValueError('ILAsm parameter names do not correspond to source annotations')

    # ILAsm emits an extra empty SerString for an omitted user-defined SAFEARRAY
    # element type. This source explicitly uses the element-type-only encoding.
    if safearray_element_only:
        other_blobs = {r[c] for table,columns in
                       {4:(2,), 6:(4,), 10:(2,), 11:(2,), 12:(2,), 23:(2,),
                        32:(6,), 35:(5,8)}.items() for r in t[table] for c in columns}
        for index in {index for _,index in t[13]}:
            value = blob(img,index)
            if len(value)==3 and value[0]==0x1d and value[-1]==0:
                if index in other_blobs:
                    raise ValueError('Marshaller descriptor is shared with another metadata kind')
                start = img.streams['#Blob'][0] + index
                data[start] = 2  # 2-byte descriptor; the last zero is now an empty heap entry

    start,size = img.streams['#~']
    payload = bytearray(data[start:start+24])
    payload.extend(b''.join(struct.pack('<I',len(rows)) for rows in t.values()))
    for table,rows in t.items():
        row_format = struct.Struct('<' + FORMATS[table])
        for row in rows:
            payload.extend(row_format.pack(*row))
    payload = align4(payload)
    if len(payload) > size:
        raise ValueError('Insufficient original assembler table space')
    data[start:start+size] = payload + bytes(size-len(payload))
    cur = img.metadata + 16 + u32(data,img.metadata+12)
    count = u16(data,cur+2)
    cur += 4
    for _ in range(count):
        end = data.index(0,cur+8)
        if data[cur+8:end] == b'#~':
            struct.pack_into('<I', data, cur+4, len(payload))
        cur = (end+4)&~3

    # A .res header has no PE resource CodePage field.
    base = img.file_offset(u32(data,img.directories+16))
    directory = base
    for id_ in (spec['type'],spec['id'],spec['language']):
        if u16(data,directory+12) != 0 or u16(data,directory+14) != 1:
            raise ValueError('Expected one numeric VERSIONINFO resource leaf')
        actual, target = struct.unpack_from('<II',data,directory+16)
        if actual != id_:
            raise ValueError('Resource identifier differs from the editable resource')
        directory = base + (target&0x7fffffff)
    if target & 0x80000000:
        raise ValueError('Missing resource data entry')
    struct.pack_into('<I',data,directory+8,spec['codepage'])

    # Derive a repeatable module ID from the new image; only this assembler's time and
    # MVID are normalized. No part of the original signed image is used.
    struct.pack_into('<I',data,img.pe+8,0)
    guid_start,guid_size = img.streams['#GUID']
    mvid = t[0][0][2]
    if guid_size != 16 or mvid != 1:
        raise ValueError('Unexpected GUID heap shape')
    data[guid_start:guid_start+16] = bytes(16)
    guid = bytearray(hashlib.sha256(data).digest()[:16])
    guid[7] = (guid[7]&0x0f)|0x80
    guid[8] = (guid[8]&0x3f)|0x80
    data[guid_start:guid_start+16] = guid
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True, help='new or empty build directory')
    parser.add_argument('--ilasm',type=Path, default=Path(os.environ['WINDIR'])/'Microsoft.NET/Framework/v4.0.30319/ilasm.exe')
    args = parser.parse_args()
    output = args.out.resolve()
    output.mkdir(parents=True,exist_ok=True)
    if any(output.iterdir()):
        parser.error('--out must be empty')
    sources = (PACKAGE/'Interop.SECSERVEROBJECTLib.dll.il').read_text(encoding='utf-8-sig')
    spec = json.loads((PACKAGE/'version.json').read_text(encoding='utf-8'))
    (output/'version.res').write_bytes(version_resource(spec))
    temporary = sources.replace('// @emit-empty-param',RETURN_MARKER).replace(
        '// @retain-marshaling-reference',MARSHAL_MARKER)
    (output/'assembly.il').write_text(temporary,encoding='utf-8-sig')
    subprocess.run([str(args.ilasm.resolve()), 'assembly.il','/dll','/quiet','/resource=version.res',
                    '/output='+NAME],cwd=output,check=True)
    output_path = output/NAME
    result = finalize(bytearray(output_path.read_bytes()),spec,sources.count('// @emit-empty-param'),
                      sources.count('__unnamed_cli_parameter__'), sources.count('// @retain-marshaling-reference'),
                      '// @safearray-encoding element-type-only' in sources)
    output_path.write_bytes(result)
    print(hashlib.sha256(result).hexdigest(), NAME)


if __name__ == '__main__':
    main()

