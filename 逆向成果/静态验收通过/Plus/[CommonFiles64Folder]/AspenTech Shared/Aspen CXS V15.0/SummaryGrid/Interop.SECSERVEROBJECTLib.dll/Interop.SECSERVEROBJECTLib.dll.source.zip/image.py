"""PE/CLI structural support for this declaration-only assembly."""
import struct
from pathlib import Path


def u16(buf, offset):
    return struct.unpack_from('<H', buf, offset)[0]


def u32(buf, offset):
    return struct.unpack_from('<I', buf, offset)[0]


class Image:
    def __init__(self, data):
        self.data = data
        self.pe = pe = u32(data, 60)
        if data[pe:pe+4] != b'PE\0\0':
            raise ValueError('Invalid PE signature')
        opt = pe + 24
        sec = opt + u16(data, pe + 20)
        self.sections = [struct.unpack_from('<IIII', data, sec + i*40 + 8)
                         for i in range(u16(data, pe + 6))]
        self.directories = opt + (112 if u16(data, opt) == 0x20b else 96)
        self.cli = self.file_offset(u32(data, self.directories + 14*8))
        self.metadata = md = self.file_offset(u32(data, self.cli + 8))
        if data[md:md+4] != b'BSJB':
            raise ValueError('Invalid CLI metadata')
        cur = md + 16 + u32(data, md + 12)
        stream_count = u16(data, cur + 2)
        cur += 4
        self.streams = {}
        for i in range(stream_count):
            offset, size = struct.unpack_from('<II', data, cur)
            end = data.index(0, cur+8)
            name = data[cur+8:end].decode()
            self.streams[name] = (md + offset, size)
            cur = (end + 4) & ~3

    def file_offset(self, rva):
        for _, addr, size, start in self.sections:
            if addr <= rva < addr + size:
                return start + rva - addr
        raise ValueError(f'Unmapped RVA {rva:x}')

    def resources(self):
        root = self.file_offset(u32(self.data, self.directories + 16))
        items = {}
        def walk(offset, path):
            p = root + offset
            n = u16(self.data, p+12) + u16(self.data, p+14)
            for i in range(n):
                name, entry = struct.unpack_from('<II', self.data, p+16+i*8)
                if name & 0x80000000:
                    label = root + (name & 0x7fffffff)
                    name = self.data[label+2:label+2+u16(self.data,label)*2].decode('utf-16le')
                key = path + [str(name)]
                if entry & 0x80000000:
                    walk(entry & 0x7fffffff, key)
                else:
                    rva, size, codepage, reserved = struct.unpack_from('<IIII',self.data,root+entry)
                    start = self.file_offset(rva)
                    items['/'.join(key)] = (self.data[start:start+size], codepage, reserved)
        walk(0, [])
        return items


# ECMA-335 II.22 table layouts; this input uses two-byte heap, table and coded indexes.
FORMATS = {0:'HHHHH', 1:'HHH', 2:'IHHHHH', 4:'HHH', 6:'IHHHHH', 8:'HHH',
           9:'HH', 10:'HHH', 11:'HHH', 12:'HHH', 13:'HH', 21:'HH', 23:'HHH',
           24:'HHH', 25:'HHH', 32:'IHHHHIHHH', 35:'HHHHIHHHH'}


def tables(img):
    data = img.data
    start, size = img.streams['#~']
    mask = struct.unpack_from('<Q', data, start+8)[0]
    if data[start+6] & 7:
        raise ValueError('Wide metadata heaps are outside this inspection scope')
    ids = [t for t in range(64) if mask & (1<<t)]
    p = start + 24
    counts = {}
    for t in ids:
        counts[t] = u32(data, p)
        p += 4
    if max(counts.values()) >= 2048:
        raise ValueError('Wide table or coded indexes require a different inspection scope')
    result = {}
    for t in ids:
        fmt = struct.Struct('<' + FORMATS[t])
        result[t] = list(fmt.iter_unpack(data[p:p+fmt.size*counts[t]]))
        p += fmt.size*counts[t]
    if not (0 <= (start+size-p) <= 4):
        raise ValueError('Metadata table size mismatch')
    return result


def string(img, index):
    o = img.streams['#Strings'][0] + index
    return img.data[o:img.data.index(0,o)].decode()


def compressed(data, p):
    a = data[p]
    if a < 128:
        return a, p+1
    if a < 192:
        return ((a & 63)<<8) | data[p+1], p+2
    if a < 224:
        return int.from_bytes(data[p:p+4], 'big') & 0x1fffffff, p+4
    raise ValueError('Invalid compressed integer')


def blob(img, index):
    length, start = compressed(img.data, img.streams['#Blob'][0]+index)
    return img.data[start:start+length]

