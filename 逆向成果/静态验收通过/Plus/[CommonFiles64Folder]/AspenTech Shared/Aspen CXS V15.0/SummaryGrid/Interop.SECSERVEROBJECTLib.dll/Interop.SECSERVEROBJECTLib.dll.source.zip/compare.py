"""Read-only static comparison. Compares every row of each populated CLI table and PE resources."""
import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

sys.dont_write_bytecode = True
from image import Image, blob, compressed, string, tables, u16, u32

def sha(data):
    return hashlib.sha256(data).hexdigest()

def digest(rows):
    return sha(json.dumps(rows, separators=(',',':'), ensure_ascii=False).encode())

def inspect(path):
    img = Image(path.read_bytes())
    t = tables(img)
    txt = lambda n: string(img,n)
    val = lambda n: blob(img,n).hex()
    def ctor(sig, refs, types):
        # MemberRefs in this assembly consist only of instance constructors with primitive,
        # CLASS and VALUETYPE parameter types. Reject other signatures explicitly.
        if sig[0] != 0x20:
            raise ValueError('Unexpected MemberRef calling convention')
        count,cursor = compressed(sig,1)
        result = []
        for _ in range(count+1):  # return type, then formal parameters
            kind = sig[cursor]
            cursor += 1
            if kind in (0x11,0x12):
                coded,cursor = compressed(sig,cursor)
                result.append((kind, target(coded, refs, types)))
            elif kind in (0x01,0x08,0x0e):
                result.append(kind)
            else:
                raise ValueError('Unexpected constructor parameter encoding')
        if cursor != len(sig):
            raise ValueError('Trailing bytes in constructor signature')
        return (sig[0],count,result)

    def target(coded,refs,types):
        if not coded: return None
        if coded & 3 == 0: return ('TypeDef',types[(coded>>2)-1])
        if coded & 3 == 1: return ('TypeRef',refs[(coded>>2)-1])
        raise ValueError('Unexpected TypeDefOrRef scope')

    def sorted_rows(rows):
        return sorted(rows, key=lambda row:json.dumps(row,ensure_ascii=False))

    assembly_refs = [(a,b,c,d,flags,val(key),txt(name),txt(culture),val(h))
        for a,b,c,d,flags,key,name,culture,h in t[35]]
    refs = []
    for scope,name,ns in t[1]:
        if scope & 3 != 2: raise ValueError('Unexpected TypeRef scope')
        refs.append((assembly_refs[(scope>>2)-1],txt(ns),txt(name)))
    types = [(txt(x[2]),txt(x[1])) for x in t[2]]
    memberrefs = []
    for parent,name,sig in t[10]:
        if parent & 7 != 1: raise ValueError('Unexpected MemberRef parent')
        memberrefs.append((refs[(parent>>3)-1],txt(name),ctor(blob(img,sig),refs,types)))
    ca = []
    for parent,method,attrval in t[12]:
        if method & 7 != 3 or (parent&31) not in (3,4,9,14):
            raise ValueError('Unexpected custom attribute owner or constructor')
        ca.append((parent,memberrefs[(method>>3)-1],val(attrval)))
    modules = [(gen,txt(name),enc,base) for gen,name,mvid,enc,base in t[0]]
    typedefs = [(flags,txt(name),txt(ns),target(extends,refs,types),firstfield,firstmeth)
        for flags,name,ns,extends,firstfield,firstmeth in t[2]]
    methods = [(rva,impl,flags,txt(name),val(sig),p0) for rva,impl,flags,name,sig,p0 in t[6]]
    scoped = {
        'Module': modules, 'TypeRef':sorted_rows(refs), 'TypeDef':typedefs,
        'Field':[(flags,txt(name),val(sig)) for flags,name,sig in t[4]],
        'MethodDef':methods,'Param':[(f,seq,txt(n)) for f,seq,n in t[8]],
        'InterfaceImpl':[(owner,target(iface,refs,types)) for owner,iface in t[9]],
        'MemberRef':sorted_rows(memberrefs),'Constant':[(kind,parent,val(v)) for kind,parent,v in t[11]],
        'CustomAttribute':sorted_rows(ca), 'FieldMarshal':[(owner,val(v)) for owner,v in t[13]],
        'PropertyMap':t[21], 'Property':[(f,txt(n),val(s)) for f,n,s in t[23]],
        'MethodSemantics':t[24], 'MethodImpl':t[25],
        'Assembly':[(h,x,y,z,w,f,val(k),txt(n),txt(c)) for h,x,y,z,w,f,k,n,c in t[32]],
        'AssemblyRef':assembly_refs}
    if len(scoped) != len(t): raise ValueError('Uncompared metadata table')
    inventory = []
    identities = {}
    for i,typ in enumerate(t[2]):
        end = t[2][i+1][-1] if i+1 < len(t[2]) else len(methods)+1
        for rid in range(typ[-1],end):
            rva,impl,flags,name,sig,first = methods[rid-1]
            identities[rid] = '.'.join(filter(None,types[i]))+'::'+name+' '+sig
            inventory.append({'token':f'0x{0x06000000+rid:08X}', 'identity':identities[rid],
                              'rva':rva,'flags':hex(flags),'impl_flags':hex(impl)})
    bindings = []
    for owner,body,decl in t[25]:
        if body & 1 or decl & 1:
            raise ValueError('Unexpected non-MethodDef binding')
        bindings.append({'class':'.'.join(types[owner-1]),'body':identities[body>>1],
                         'declaration':identities[decl>>1]})
    resources = {k:{'size':len(d),'sha256':sha(d),'codepage':cp,'reserved':res}
                 for k,(d,cp,res) in img.resources().items()}
    api = {'machine':hex(u16(img.data,img.pe+4)),'characteristics':hex(u16(img.data,img.pe+22)),
           'optional_header_magic':hex(u16(img.data,img.pe+24)),
           'subsystem':u16(img.data,img.pe+24+68),'dll_characteristics':hex(u16(img.data,img.pe+24+70)),
           'clr_flags_except_strong_name':hex(u32(img.data,img.cli+16)&~8),
           'native_resources':resources,'managed_resources_bytes':u32(img.data,img.cli+28),
           'public_key_sha256':sha(blob(img,t[32][0][6]))}
    cert_off,cert_len = struct.unpack_from('<II',img.data,img.directories+32)
    sn_rva,sn_len = struct.unpack_from('<II',img.data,img.cli+32)
    sn = img.data[img.file_offset(sn_rva):img.file_offset(sn_rva)+sn_len] if sn_len else b''
    guid,size = img.streams['#GUID']
    details = {'file_sha256':sha(img.data),'bytes':len(img.data),'clr_flags':hex(u32(img.data,img.cli+16)),
               'certificate_bytes':cert_len,'certificate_sha256':sha(img.data[cert_off:cert_off+cert_len]) if cert_len else None,
               'strong_name_region_bytes':sn_len,'strong_name_sha256':sha(sn),'strong_name_nonzero':any(sn),
               'coff_timestamp':u32(img.data,img.pe+8),'module_guid_bytes':img.data[guid:guid+size].hex(),
               'metadata_sha256':sha(img.data[img.metadata:img.metadata+u32(img.data,img.cli+12)])}
    return scoped, inventory, bindings, api, details


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original',type=Path)
    parser.add_argument('rebuilt',type=Path)
    parser.add_argument('report',type=Path)
    args = parser.parse_args()
    a, ma, ba, apia, oa = inspect(args.original)
    b, mb, bb, apib, ob = inspect(args.rebuilt)
    checks = {k:{'original_count':len(v),'rebuilt_count':len(b[k]),'original_digest':digest(v),
                 'rebuilt_digest':digest(b[k]),'equal':v==b[k]} for k,v in a.items()}
    # Definition, Param, Field, Property and Assembly RIDs have their original order.
    # The signature bytes are verified alongside a separately resolved ILDasm listing.
    ok = a==b and ma==mb and ba==bb and apia==apib and all(x['rva']==0 for x in ma+mb)
    report = {'equal_in_static_scope':ok,'original':oa,'rebuilt':ob,'tables':checks,
              'original_platform_resources':apia,'rebuilt_platform_resources':apib,
              'method_bodies_and_exception_regions':0 if all(x['rva']==0 for x in ma+mb) else None,
              'original_assembly_refs':a['AssemblyRef'],'methoddef_inventory_equal':ma==mb,
              'original_methoddefs':ma,'methodimpl_endpoints_equal':ba==bb,'original_methodimpl':ba,
              'comparison':'CLI table rows with resolved strings, blobs and TypeRef/MemberRef identities. Custom attributes grouped by parent, resolved constructor and exact value. Referenced MethodDef, Param, Field and Property RIDs are compared in original definition order.'}
    args.report.write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
    print('All structural comparisons equal:',ok)
    if not ok:
        print('Differing tables:',[k for k,v in checks.items() if not v['equal']]); sys.exit(1)

if __name__ == '__main__':
    main()

