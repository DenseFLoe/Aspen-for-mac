"""Additional independent disassembly of the two inputs using Microsoft ILDasm."""
import argparse
import hashlib
import itertools
import json
import re
import subprocess
from pathlib import Path


def normalized(lines):
    keep = [line for line in lines if not line.startswith(
        ('// MVID:', '// Image base:', '// WARNING: Created Win32 resource file', '.corflags'))]
    def collapse(match):
        value = re.sub(r'//[^\n]*','',match.group())
        return '~' + re.sub(r'\s+',' ',value).strip() + '\n'
    text = re.sub(r'(?m)^([ \t]*\.custom [^\n]*(?:\n[ \t]{20,}[^\n]*)*)',
                  collapse, '\n'.join(keep))
    lines = [line for line in text.splitlines() if line.strip()]
    return [line for is_attr,group in itertools.groupby(lines,lambda line:line.startswith('~'))
            for line in (sorted(group) if is_attr else group)]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('ildasm','original','rebuilt','out'):
        parser.add_argument(name,type=Path)
    args = parser.parse_args()
    work = args.out.resolve()
    work.mkdir(parents=True,exist_ok=True)
    if any(work.iterdir()):
        parser.error('out must be empty')
    results = []
    for name,file in [('original',args.original),('rebuilt',args.rebuilt)]:
        subprocess.run([str(args.ildasm.resolve()),str(file.resolve()),'/utf8','/typelist',
                        '/out='+name+'.il'],cwd=work,check=True)
        listing = (work/(name+'.il')).read_text(encoding='utf-8-sig').splitlines()
        results.append(normalized(listing))
    def fingerprint(lines):
        return hashlib.sha256('\n'.join(lines).encode()).hexdigest()
    report = {'equal':results[0]==results[1],'records':[len(rows) for rows in results],
              'digests':[fingerprint(rows) for rows in results],
              'ildasm_sha256':hashlib.sha256(args.ildasm.read_bytes()).hexdigest(),
              'normalization':'Preserve declaration order and binding context. Join multiline custom attributes and sort contiguous attributes within each owner, ignoring formatting and comments inside their blobs. Omit timestamp-independent disassembler comments for MVID, mapped address, .res output location and the separately checked .corflags line.'}
    (work/'listing-check.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(report))
    if not report['equal']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()

