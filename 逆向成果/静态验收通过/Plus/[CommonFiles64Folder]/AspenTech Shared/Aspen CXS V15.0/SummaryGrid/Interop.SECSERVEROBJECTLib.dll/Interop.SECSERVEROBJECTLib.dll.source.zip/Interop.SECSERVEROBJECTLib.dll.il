﻿
//  .NET IL Disassembler.  Version 9.0.23




// @safearray-encoding element-type-only
.typelist 
{
  Interop.SECSERVEROBJECTLib._ISecServer
  Interop.SECSERVEROBJECTLib.ISecServer2
  Interop.SECSERVEROBJECTLib.ISecServer3
  Interop.SECSERVEROBJECTLib.ISecServer4
  Interop.SECSERVEROBJECTLib.ISecServer
  Interop.SECSERVEROBJECTLib.SecServer
  Interop.SECSERVEROBJECTLib.ICSSUtility
  Interop.SECSERVEROBJECTLib.ICSSCommute
  Interop.SECSERVEROBJECTLib.ISLMUsageLog
  Interop.SECSERVEROBJECTLib.ISLMUsageLog2
  Interop.SECSERVEROBJECTLib.ISMID
  Interop.SECSERVEROBJECTLib.ISLMUtility
  Interop.SECSERVEROBJECTLib.ISLMUtility2
  Interop.SECSERVEROBJECTLib.ISLMUtility3
  Interop.SECSERVEROBJECTLib.ISLMLicenseVersion
  Interop.SECSERVEROBJECTLib.ISLMSoftUtility
  Interop.SECSERVEROBJECTLib.IComponentVersionString
  Interop.SECSERVEROBJECTLib.ISLMIdleTime
  Interop.SECSERVEROBJECTLib.IStochastic
  Interop.SECSERVEROBJECTLib.ITimedLicense
  Interop.SECSERVEROBJECTLib.ISLMInstalltime
  Interop.SECSERVEROBJECTLib.SecServerClass
  Interop.SECSERVEROBJECTLib.ISecCallback
  Interop.SECSERVEROBJECTLib.LicenseImportance_enum
  Interop.SECSERVEROBJECTLib.LicenseStatus_enum
  Interop.SECSERVEROBJECTLib.ICSSAuthenticate
  Interop.SECSERVEROBJECTLib.GraceState_enum
  Interop.SECSERVEROBJECTLib.LicenseType_enum
  Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005
  Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0002
  Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0003
  Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0006
  Interop.SECSERVEROBJECTLib.LicenseMode_enum
  Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004
  Interop.SECSERVEROBJECTLib.ISLMIdleTimeCallback
}

// Metadata version: v4.0.30319
.assembly extern mscorlib
{
  .publickeytoken = (B7 7A 5C 56 19 34 E0 89 )                         // .z\V.4..
  .ver 4:0:0:0
}
.assembly Interop.SECSERVEROBJECTLib
{
  // @retain-marshaling-reference
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 30 46 44 42 33 2D 37 35 32 42   // ..$1460FDB3-752B
                                                                                                  2D 31 31 44 34 2D 42 30 36 37 2D 30 30 39 30 32   // -11D4-B067-00902
                                                                                                  37 31 43 46 33 38 33 00 00 )                      // 71CF383..
  .custom instance void [mscorlib]System.Runtime.InteropServices.PrimaryInteropAssemblyAttribute::.ctor(int32,
                                                                                                        int32) = ( 01 00 04 00 00 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.ImportedFromTypeLibAttribute::.ctor(string) = ( 01 00 12 53 45 43 53 45 52 56 45 52 4F 42 4A 45   // ...SECSERVEROBJE
                                                                                                                 43 54 4C 69 62 00 00 )                            // CTLib..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibVersionAttribute::.ctor(int32,
                                                                                                int32) = ( 01 00 04 00 00 00 00 00 00 00 00 00 ) 
  .publickey = (00 24 00 00 04 80 00 00 94 00 00 00 06 02 00 00   // .$..............
                00 24 00 00 52 53 41 31 00 04 00 00 01 00 01 00   // .$..RSA1........
                67 BA F3 09 16 64 2D D0 BF 58 D4 86 5F 03 72 0F   // g....d-..X.._.r.
                3E 1E 5A 9E 2D C8 9C D8 32 DA AA 08 1F 54 57 60   // >.Z.-...2....TW`
                78 39 48 FE 05 3F 63 7C CF 2E EB EC 54 04 84 4B   // x9H..?c|....T..K
                E8 11 FD D3 AF AF 88 7A 4E F6 F5 DD 22 3E E0 CC   // .......zN...">..
                3D F2 90 54 CA 3F 4B B1 8D 8E 79 FC E0 56 DD B7   // =..T.?K...y..V..
                D2 3B E4 D8 1E 26 79 E3 7C 5A E0 56 50 01 59 3B   // .;...&y.|Z.VP.Y;
                7F C8 FB BE 3D 6E 31 2D E2 BA D0 37 30 AD 80 8E   // ....=n1-...70...
                FE A6 9C 33 8D 80 A4 C8 1F 2E 88 D8 84 C2 FC C2 ) // ...3............
  .hash algorithm 0x00008004
  .ver 4:0:0:0
}
.module Interop.SECSERVEROBJECTLib.dll
.imagebase 0x00400000
.file alignment 0x00000200
.stackreserve 0x00100000
.subsystem 0x0003       // WINDOWS_CUI
.corflags 0x00000009    //  ILONLY


// =============== CLASS MEMBERS DECLARATION ===================

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib._ISecServer
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 30 46 44 42 35 2D 37 35 32 42   // ..$1460FDB5-752B
                                                                                                  2D 31 31 44 34 2D 42 30 36 37 2D 30 30 39 30 32   // -11D4-B067-00902
                                                                                                  37 31 43 46 33 38 33 00 00 )                      // 71CF383..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicense([in] string  marshal( bstr) license,
                          [in] string  marshal( bstr) licversion,
                          [out] int32& cookie,
                          [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                          [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method _ISecServer::CheckoutLicense

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                 [in] string  marshal( bstr) licversion,
                                                 [out] int32& cookie,
                                                 [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                 [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method _ISecServer::CheckoutLicenseDeferred

  .method public hidebysig newslot abstract virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ValidateLicense([in] int32 cookie,
                          [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
  } // end of method _ISecServer::ValidateLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
  } // end of method _ISecServer::ReleaseLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          InfoString([in] int32 cookie,
                     [out] int32& infover) runtime managed internalcall
  {
  } // end of method _ISecServer::InfoString

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetErrorString([in] int32 errcode) runtime managed internalcall
  {
  } // end of method _ISecServer::GetErrorString

  .method public hidebysig newslot abstract virtual 
          instance void  StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                   [out] int32& authcookie) runtime managed internalcall
  {
  } // end of method _ISecServer::StartAuth

  .method public hidebysig newslot abstract virtual 
          instance void  StopAuth([in] int32 authcookie) runtime managed internalcall
  {
  } // end of method _ISecServer::StopAuth

  .method public hidebysig newslot abstract virtual 
          instance void  RegisterSoftLicense([in] string  marshal( bstr) license,
                                             [in] string  marshal( bstr) versionInfo,
                                             [in] int32 versionNumber,
                                             [in] int32 referencecookie,
                                             [out] int32& softCookie) runtime managed internalcall
  {
  } // end of method _ISecServer::RegisterSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
  } // end of method _ISecServer::RevokeSoftLicense

} // end of class Interop.SECSERVEROBJECTLib._ISecServer

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISecServer2
       implements Interop.SECSERVEROBJECTLib._ISecServer
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 36 39 43 34 42 43 31 31 2D 45 39 36 38   // ..$69C4BC11-E968
                                                                                                  2D 34 31 39 30 2D 41 36 37 34 2D 46 31 45 30 39   // -4190-A674-F1E09
                                                                                                  32 38 43 36 33 46 30 00 00 )                      // 28C63F0..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicense([in] string  marshal( bstr) license,
                          [in] string  marshal( bstr) licversion,
                          [out] int32& cookie,
                          [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                          [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer2::CheckoutLicense

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                 [in] string  marshal( bstr) licversion,
                                                 [out] int32& cookie,
                                                 [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                 [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer2::CheckoutLicenseDeferred

  .method public hidebysig newslot abstract virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ValidateLicense([in] int32 cookie,
                          [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
  } // end of method ISecServer2::ValidateLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISecServer2::ReleaseLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          InfoString([in] int32 cookie,
                     [out] int32& infover) runtime managed internalcall
  {
  } // end of method ISecServer2::InfoString

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetErrorString([in] int32 errcode) runtime managed internalcall
  {
  } // end of method ISecServer2::GetErrorString

  .method public hidebysig newslot abstract virtual 
          instance void  StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                   [out] int32& authcookie) runtime managed internalcall
  {
  } // end of method ISecServer2::StartAuth

  .method public hidebysig newslot abstract virtual 
          instance void  StopAuth([in] int32 authcookie) runtime managed internalcall
  {
  } // end of method ISecServer2::StopAuth

  .method public hidebysig newslot abstract virtual 
          instance void  RegisterSoftLicense([in] string  marshal( bstr) license,
                                             [in] string  marshal( bstr) versionInfo,
                                             [in] int32 versionNumber,
                                             [in] int32 referencecookie,
                                             [out] int32& softCookie) runtime managed internalcall
  {
  } // end of method ISecServer2::RegisterSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
  } // end of method ISecServer2::RevokeSoftLicense

} // end of class Interop.SECSERVEROBJECTLib.ISecServer2

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISecServer3
       implements Interop.SECSERVEROBJECTLib.ISecServer2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 41 30 39 33 37 37 44 41 2D 33 34 30 42   // ..$A09377DA-340B
                                                                                                  2D 34 42 42 43 2D 38 44 46 35 2D 46 38 41 31 30   // -4BBC-8DF5-F8A10
                                                                                                  30 30 35 35 44 44 39 00 00 )                      // 0055DD9..
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicense([in] string  marshal( bstr) license,
                          [in] string  marshal( bstr) licversion,
                          [out] int32& cookie,
                          [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                          [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer3::CheckoutLicense

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                 [in] string  marshal( bstr) licversion,
                                                 [out] int32& cookie,
                                                 [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                 [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer3::CheckoutLicenseDeferred

  .method public hidebysig newslot abstract virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ValidateLicense([in] int32 cookie,
                          [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
  } // end of method ISecServer3::ValidateLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISecServer3::ReleaseLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          InfoString([in] int32 cookie,
                     [out] int32& infover) runtime managed internalcall
  {
  } // end of method ISecServer3::InfoString

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetErrorString([in] int32 errcode) runtime managed internalcall
  {
  } // end of method ISecServer3::GetErrorString

  .method public hidebysig newslot abstract virtual 
          instance void  StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                   [out] int32& authcookie) runtime managed internalcall
  {
  } // end of method ISecServer3::StartAuth

  .method public hidebysig newslot abstract virtual 
          instance void  StopAuth([in] int32 authcookie) runtime managed internalcall
  {
  } // end of method ISecServer3::StopAuth

  .method public hidebysig newslot abstract virtual 
          instance void  RegisterSoftLicense([in] string  marshal( bstr) license,
                                             [in] string  marshal( bstr) versionInfo,
                                             [in] int32 versionNumber,
                                             [in] int32 referencecookie,
                                             [out] int32& softCookie) runtime managed internalcall
  {
  } // end of method ISecServer3::RegisterSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
  } // end of method ISecServer3::RevokeSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense2([in] int32 cookie,
                                         [in] int32 sync) runtime managed internalcall
  {
  } // end of method ISecServer3::ReleaseLicense2

} // end of class Interop.SECSERVEROBJECTLib.ISecServer3

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISecServer4
       implements Interop.SECSERVEROBJECTLib.ISecServer3
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 41 45 39 34 32 44 35 41 2D 31 32 45 31   // ..$AE942D5A-12E1
                                                                                                  2D 34 32 46 39 2D 41 41 39 35 2D 42 37 37 36 33   // -42F9-AA95-B7763
                                                                                                  31 41 34 46 36 44 45 00 00 )                      // 1A4F6DE..
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicense([in] string  marshal( bstr) license,
                          [in] string  marshal( bstr) licversion,
                          [out] int32& cookie,
                          [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                          [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer4::CheckoutLicense

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                 [in] string  marshal( bstr) licversion,
                                                 [out] int32& cookie,
                                                 [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                 [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer4::CheckoutLicenseDeferred

  .method public hidebysig newslot abstract virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ValidateLicense([in] int32 cookie,
                          [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
  } // end of method ISecServer4::ValidateLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISecServer4::ReleaseLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          InfoString([in] int32 cookie,
                     [out] int32& infover) runtime managed internalcall
  {
  } // end of method ISecServer4::InfoString

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetErrorString([in] int32 errcode) runtime managed internalcall
  {
  } // end of method ISecServer4::GetErrorString

  .method public hidebysig newslot abstract virtual 
          instance void  StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                   [out] int32& authcookie) runtime managed internalcall
  {
  } // end of method ISecServer4::StartAuth

  .method public hidebysig newslot abstract virtual 
          instance void  StopAuth([in] int32 authcookie) runtime managed internalcall
  {
  } // end of method ISecServer4::StopAuth

  .method public hidebysig newslot abstract virtual 
          instance void  RegisterSoftLicense([in] string  marshal( bstr) license,
                                             [in] string  marshal( bstr) versionInfo,
                                             [in] int32 versionNumber,
                                             [in] int32 referencecookie,
                                             [out] int32& softCookie) runtime managed internalcall
  {
  } // end of method ISecServer4::RegisterSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
  } // end of method ISecServer4::RevokeSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense2([in] int32 cookie,
                                         [in] int32 sync) runtime managed internalcall
  {
  } // end of method ISecServer4::ReleaseLicense2

  .method public hidebysig newslot abstract virtual 
          instance void  BatchCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                       [out] int32[]&  marshal( safearray int32) cookies,
                                       [out] string[]&  marshal( safearray bstr) errors) runtime managed internalcall
  {
  } // end of method ISecServer4::BatchCheckout

  .method public hidebysig newslot abstract virtual 
          instance void  BatchCheckin(int32[]  marshal( safearray int32) cookies,
                                      [in] int32 sync) runtime managed internalcall
  {
  } // end of method ISecServer4::BatchCheckin

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicenseMulti([in] string  marshal( bstr) license,
                               [in] string  marshal( bstr) licversion,
                               [in] int32 units,
                               [in] bool waitonit,
                               [out] int32& cookie,
                               [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                               [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [7]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer4::CheckoutLicenseMulti

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckLicenseExpiration([in] string  marshal( bstr) license,
                                 [in] string  marshal( bstr) licversion,
                                 [out] int32& expirationDate,
                                 [out] string&  marshal( bstr) location,
                                 [out] bool& needreminder) runtime managed internalcall
  {
  } // end of method ISecServer4::CheckLicenseExpiration

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutLicenseMultiDeferred([in] string  marshal( bstr) license,
                                                      [in] string  marshal( bstr) licversion,
                                                      [in] int32 units,
                                                      [out] int32& cookie,
                                                      [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                      [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer4::CheckoutLicenseMultiDeferred

  .method public hidebysig newslot abstract virtual 
          instance void  GetLicenseExpirationInfo([in] string  marshal( bstr) licensenames,
                                                  [out] string&  marshal( bstr) expiryInfo,
                                                  [out] string&  marshal( bstr) errrorstring) runtime managed internalcall
  {
  } // end of method ISecServer4::GetLicenseExpirationInfo

  .method public hidebysig newslot abstract virtual 
          instance void  GetLicenseInUse([in] string  marshal( bstr) license,
                                         [in] string  marshal( bstr) username,
                                         [in] string  marshal( bstr) hostname,
                                         [out] int32& num_lics) runtime managed internalcall
  {
  } // end of method ISecServer4::GetLicenseInUse

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutGraceLicense([in] string  marshal( bstr) license,
                                              [in] string  marshal( bstr) application,
                                              [in] string  marshal( bstr) clientId,
                                              [in] int32 units,
                                              [in] bool waitonit,
                                              [in] uint32 gracePeriod,
                                              [out] int32& cookie,
                                              [out] valuetype Interop.SECSERVEROBJECTLib.GraceState_enum& valid,
                                              [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) graceLicenseCallback,
                                              [out] string&  marshal( bstr) errorstring) runtime managed internalcall
  {
    .param [8]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2A 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..*Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 47 72   // RVEROBJECTLib.Gr
                                                                                                            61 63 65 53 74 61 74 65 5F 65 6E 75 6D 00 00 )    // aceState_enum..
  } // end of method ISecServer4::CheckoutGraceLicense

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutEngLicense([in] string  marshal( bstr) license,
                                            [in] int32 units,
                                            [in] bool waitonit,
                                            [out] int32& cookie,
                                            [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                            [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance,
                                            [out] string&  marshal( bstr) errstring) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer4::CheckoutEngLicense

  .method public hidebysig newslot abstract virtual 
          instance void  GroupCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                       [in] valuetype Interop.SECSERVEROBJECTLib.LicenseType_enum lictype,
                                       bool waitonit,
                                       [out] int32[]&  marshal( safearray int) cookies,
                                       [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                       [out] string&  marshal( bstr) 'error') runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 54 79 70 65 5F 65 6E 75 6D 00 00 ) // censeType_enum..
  } // end of method ISecServer4::GroupCheckout

  .method public hidebysig newslot abstract virtual 
          instance void  GroupCheckin([in] int32[]  marshal( safearray int32) cookies) runtime managed internalcall
  {
  } // end of method ISecServer4::GroupCheckin

  .method public hidebysig newslot abstract virtual 
          instance void  GroupValidate([in] int32[]  marshal( safearray int32) cookies,
                                       [in] bool waitonit,
                                       [out] int32[]&  marshal( safearray int) statuses) runtime managed internalcall
  {
  } // end of method ISecServer4::GroupValidate

} // end of class Interop.SECSERVEROBJECTLib.ISecServer4

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISecServer
       implements Interop.SECSERVEROBJECTLib.ISecServer4
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 41 36 31 44 33 34 45 37 2D 39 34 33 43   // ..$A61D34E7-943C
                                                                                                  2D 34 42 39 31 2D 41 37 43 42 2D 45 46 45 43 35   // -4B91-A7CB-EFEC5
                                                                                                  39 39 45 44 39 31 39 00 00 )                      // 99ED919..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicense([in] string  marshal( bstr) license,
                          [in] string  marshal( bstr) licversion,
                          [out] int32& cookie,
                          [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                          [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer::CheckoutLicense

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                 [in] string  marshal( bstr) licversion,
                                                 [out] int32& cookie,
                                                 [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                 [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer::CheckoutLicenseDeferred

  .method public hidebysig newslot abstract virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ValidateLicense([in] int32 cookie,
                          [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
  } // end of method ISecServer::ValidateLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISecServer::ReleaseLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          InfoString([in] int32 cookie,
                     [out] int32& infover) runtime managed internalcall
  {
  } // end of method ISecServer::InfoString

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetErrorString([in] int32 errcode) runtime managed internalcall
  {
  } // end of method ISecServer::GetErrorString

  .method public hidebysig newslot abstract virtual 
          instance void  StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                   [out] int32& authcookie) runtime managed internalcall
  {
  } // end of method ISecServer::StartAuth

  .method public hidebysig newslot abstract virtual 
          instance void  StopAuth([in] int32 authcookie) runtime managed internalcall
  {
  } // end of method ISecServer::StopAuth

  .method public hidebysig newslot abstract virtual 
          instance void  RegisterSoftLicense([in] string  marshal( bstr) license,
                                             [in] string  marshal( bstr) versionInfo,
                                             [in] int32 versionNumber,
                                             [in] int32 referencecookie,
                                             [out] int32& softCookie) runtime managed internalcall
  {
  } // end of method ISecServer::RegisterSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
  } // end of method ISecServer::RevokeSoftLicense

  .method public hidebysig newslot abstract virtual 
          instance void  ReleaseLicense2([in] int32 cookie,
                                         [in] int32 sync) runtime managed internalcall
  {
  } // end of method ISecServer::ReleaseLicense2

  .method public hidebysig newslot abstract virtual 
          instance void  BatchCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                       [out] int32[]&  marshal( safearray int32) cookies,
                                       [out] string[]&  marshal( safearray bstr) errors) runtime managed internalcall
  {
  } // end of method ISecServer::BatchCheckout

  .method public hidebysig newslot abstract virtual 
          instance void  BatchCheckin(int32[]  marshal( safearray int32) cookies,
                                      [in] int32 sync) runtime managed internalcall
  {
  } // end of method ISecServer::BatchCheckin

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicenseMulti([in] string  marshal( bstr) license,
                               [in] string  marshal( bstr) licversion,
                               [in] int32 units,
                               [in] bool waitonit,
                               [out] int32& cookie,
                               [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                               [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [7]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer::CheckoutLicenseMulti

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckLicenseExpiration([in] string  marshal( bstr) license,
                                 [in] string  marshal( bstr) licversion,
                                 [out] int32& expirationDate,
                                 [out] string&  marshal( bstr) location,
                                 [out] bool& needreminder) runtime managed internalcall
  {
  } // end of method ISecServer::CheckLicenseExpiration

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutLicenseMultiDeferred([in] string  marshal( bstr) license,
                                                      [in] string  marshal( bstr) licversion,
                                                      [in] int32 units,
                                                      [out] int32& cookie,
                                                      [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                      [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer::CheckoutLicenseMultiDeferred

  .method public hidebysig newslot abstract virtual 
          instance void  GetLicenseExpirationInfo([in] string  marshal( bstr) licensenames,
                                                  [out] string&  marshal( bstr) expiryInfo,
                                                  [out] string&  marshal( bstr) errrorstring) runtime managed internalcall
  {
  } // end of method ISecServer::GetLicenseExpirationInfo

  .method public hidebysig newslot abstract virtual 
          instance void  GetLicenseInUse([in] string  marshal( bstr) license,
                                         [in] string  marshal( bstr) username,
                                         [in] string  marshal( bstr) hostname,
                                         [out] int32& num_lics) runtime managed internalcall
  {
  } // end of method ISecServer::GetLicenseInUse

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutGraceLicense([in] string  marshal( bstr) license,
                                              [in] string  marshal( bstr) application,
                                              [in] string  marshal( bstr) clientId,
                                              [in] int32 units,
                                              [in] bool waitonit,
                                              [in] uint32 gracePeriod,
                                              [out] int32& cookie,
                                              [out] valuetype Interop.SECSERVEROBJECTLib.GraceState_enum& valid,
                                              [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) graceLicenseCallback,
                                              [out] string&  marshal( bstr) errorstring) runtime managed internalcall
  {
    .param [8]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2A 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..*Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 47 72   // RVEROBJECTLib.Gr
                                                                                                            61 63 65 53 74 61 74 65 5F 65 6E 75 6D 00 00 )    // aceState_enum..
  } // end of method ISecServer::CheckoutGraceLicense

  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutEngLicense([in] string  marshal( bstr) license,
                                            [in] int32 units,
                                            [in] bool waitonit,
                                            [out] int32& cookie,
                                            [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                            [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance,
                                            [out] string&  marshal( bstr) errstring) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
  } // end of method ISecServer::CheckoutEngLicense

  .method public hidebysig newslot abstract virtual 
          instance void  GroupCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                       [in] valuetype Interop.SECSERVEROBJECTLib.LicenseType_enum lictype,
                                       bool waitonit,
                                       [out] int32[]&  marshal( safearray int) cookies,
                                       [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                       [out] string&  marshal( bstr) 'error') runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 54 79 70 65 5F 65 6E 75 6D 00 00 ) // censeType_enum..
  } // end of method ISecServer::GroupCheckout

  .method public hidebysig newslot abstract virtual 
          instance void  GroupCheckin([in] int32[]  marshal( safearray int32) cookies) runtime managed internalcall
  {
  } // end of method ISecServer::GroupCheckin

  .method public hidebysig newslot abstract virtual 
          instance void  GroupValidate([in] int32[]  marshal( safearray int32) cookies,
                                       [in] bool waitonit,
                                       [out] int32[]&  marshal( safearray int) statuses) runtime managed internalcall
  {
  } // end of method ISecServer::GroupValidate

  .method public hidebysig newslot abstract virtual 
          instance void  InitStandaloneSystem(string  marshal( bstr) LicenseName,
                                              string  marshal( bstr) LicenseVersion,
                                              string&  marshal( bstr) errstring) runtime managed internalcall
  {
  } // end of method ISecServer::InitStandaloneSystem

} // end of class Interop.SECSERVEROBJECTLib.ISecServer

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.SecServer
       implements Interop.SECSERVEROBJECTLib.ISecServer
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.CoClassAttribute::.ctor(class [mscorlib]System.Type) = ( 01 00 29 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..)Interop.SECSE
                                                                                                                          52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 53 65   // RVEROBJECTLib.Se
                                                                                                                          63 53 65 72 76 65 72 43 6C 61 73 73 00 00 )       // cServerClass..
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 41 36 31 44 33 34 45 37 2D 39 34 33 43   // ..$A61D34E7-943C
                                                                                                  2D 34 42 39 31 2D 41 37 43 42 2D 45 46 45 43 35   // -4B91-A7CB-EFEC5
                                                                                                  39 39 45 44 39 31 39 00 00 )                      // 99ED919..
} // end of class Interop.SECSERVEROBJECTLib.SecServer

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ICSSUtility
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 30 46 44 42 38 2D 37 35 32 42   // ..$1460FDB8-752B
                                                                                                  2D 31 31 44 34 2D 42 30 36 37 2D 30 30 39 30 32   // -11D4-B067-00902
                                                                                                  37 31 43 46 33 38 33 00 00 )                      // 71CF383..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          Fingerprint([in] int32 refresh,
                      [in][out] int32& licCriteria,
                      [out] int32& lockcode,
                      [out] string&  marshal( bstr) machineIDstr) runtime managed internalcall
  {
  } // end of method ICSSUtility::Fingerprint

} // end of class Interop.SECSERVEROBJECTLib.ICSSUtility

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ICSSCommute
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 30 46 44 42 39 2D 37 35 32 42   // ..$1460FDB9-752B
                                                                                                  2D 31 31 44 34 2D 42 30 36 37 2D 30 30 39 30 32   // -11D4-B067-00902
                                                                                                  37 31 43 46 33 38 33 00 00 )                      // 71CF383..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          Commute([in] string  marshal( bstr) server,
                  [in] string  marshal( bstr) licenses,
                  [in] int32 days,
                  [in] valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum tokenMode) runtime managed internalcall
  {
    .param [4]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
  } // end of method ICSSCommute::Commute

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          Uncommute([in] string  marshal( bstr) server,
                    [in] string  marshal( bstr) licenses,
                    [in] valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum tokenMode) runtime managed internalcall
  {
    .param [3]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
  } // end of method ICSSCommute::Uncommute

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetBroadcastServerList() runtime managed internalcall
  {
  } // end of method ICSSCommute::GetBroadcastServerList

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetConfiguredServerList([out] string&  marshal( bstr) forceServers) runtime managed internalcall
  {
  } // end of method ICSSCommute::GetConfiguredServerList

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetServerLicenseList([in] string  marshal( bstr) server) runtime managed internalcall
  {
  } // end of method ICSSCommute::GetServerLicenseList

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetCommutedLicenseList() runtime managed internalcall
  {
  } // end of method ICSSCommute::GetCommutedLicenseList

  .method public hidebysig newslot specialname abstract virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum 
          get_ClientLicenseMode() runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
  } // end of method ICSSCommute::get_ClientLicenseMode

  .method public hidebysig newslot abstract virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum 
          GetServerLicenseMode([in] string  marshal( bstr) server) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
  } // end of method ICSSCommute::GetServerLicenseMode

  .method public hidebysig newslot abstract virtual 
          instance bool  LicenseIsCommutable([in] string  marshal( bstr) server,
                                             [in] string  marshal( bstr) license) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ICSSCommute::LicenseIsCommutable

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetServerLockCode([in] string  marshal( bstr) server) runtime managed internalcall
  {
  } // end of method ICSSCommute::GetServerLockCode

  .method public hidebysig newslot abstract virtual 
          instance int32  WriteToRegistry([in] int32 what) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ICSSCommute::WriteToRegistry

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CommuteLicenses([in] string  marshal( bstr) server,
                          [in] string  marshal( bstr) licenses,
                          [in] int32 days) runtime managed internalcall
  {
  } // end of method ICSSCommute::CommuteLicenses

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          UnCommuteLicenses([in] string  marshal( bstr) server,
                            [in] string  marshal( bstr) licenses) runtime managed internalcall
  {
  } // end of method ICSSCommute::UnCommuteLicenses

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetCommutedLicenses() runtime managed internalcall
  {
  } // end of method ICSSCommute::GetCommutedLicenses

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetCommuterLicensesOnServer([in] string  marshal( bstr) server,
                                      [out] string&  marshal( bstr) licenses) runtime managed internalcall
  {
  } // end of method ICSSCommute::GetCommuterLicensesOnServer

  .method public hidebysig newslot abstract virtual 
          instance bool  IsInsideVirtualMachine() runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ICSSCommute::IsInsideVirtualMachine

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CommuteLicensesByTokens([in] string  marshal( bstr) server,
                                  [in] string  marshal( bstr) licenses,
                                  [in] int32 tokens,
                                  [in] int32 days) runtime managed internalcall
  {
  } // end of method ICSSCommute::CommuteLicensesByTokens

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetBucketListOnServer([in] string  marshal( bstr) server,
                                [out] string&  marshal( bstr) buckets) runtime managed internalcall
  {
  } // end of method ICSSCommute::GetBucketListOnServer

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetRedunServers([in] string  marshal( bstr) server,
                          [out] string&  marshal( bstr) leaderServer,
                          [out] string&  marshal( bstr) redundservers) runtime managed internalcall
  {
  } // end of method ICSSCommute::GetRedunServers

  .property callconv(8) valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum
          ClientLicenseMode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 06 00 01 60 00 00 )                         // .....`..
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
    .get instance valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum Interop.SECSERVEROBJECTLib.ICSSCommute::get_ClientLicenseMode()
  } // end of property ICSSCommute::ClientLicenseMode
} // end of class Interop.SECSERVEROBJECTLib.ICSSCommute

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMUsageLog
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 33 45 36 43 34 32 34 37 2D 42 44 34 31   // ..$3E6C4247-BD41
                                                                                                  2D 34 33 38 45 2D 41 36 39 42 2D 45 31 46 31 30   // -438E-A69B-E1F10
                                                                                                  34 33 45 38 43 46 39 00 00 )                      // 43E8CF9..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Job([in] int32 __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMUsageLog::set_Job

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Department([in] int32 __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMUsageLog::set_Department

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_location([in] int32 __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMUsageLog::set_location

  .property callconv(8) int32 Job()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMUsageLog::set_Job(int32)
  } // end of property ISLMUsageLog::Job
  .property callconv(8) int32 Department()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMUsageLog::set_Department(int32)
  } // end of property ISLMUsageLog::Department
  .property callconv(8) int32 location()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMUsageLog::set_location(int32)
  } // end of property ISLMUsageLog::location
} // end of class Interop.SECSERVEROBJECTLib.ISLMUsageLog

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMUsageLog2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 46 37 46 45 39 44 44 39 2D 33 33 43 32   // ..$F7FE9DD9-33C2
                                                                                                  2D 34 43 38 34 2D 39 42 44 41 2D 43 30 38 34 44   // -4C84-9BDA-C084D
                                                                                                  43 32 35 45 31 44 33 00 00 )                      // C25E1D3..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Job([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMUsageLog2::set_Job

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Department([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMUsageLog2::set_Department

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_location([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMUsageLog2::set_location

  .method public hidebysig newslot abstract virtual 
          instance void  SetLanguage([in] string  marshal( bstr) langName) runtime managed internalcall
  {
  } // end of method ISLMUsageLog2::SetLanguage

  .method public hidebysig newslot abstract virtual 
          instance void  SetProductVersion([in] string  marshal( bstr) bstrShortProdName,
                                           [in] string  marshal( bstr) bstrVersion) runtime managed internalcall
  {
  } // end of method ISLMUsageLog2::SetProductVersion

  .property callconv(8) string Job()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMUsageLog2::set_Job(string)
  } // end of property ISLMUsageLog2::Job
  .property callconv(8) string Department()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMUsageLog2::set_Department(string)
  } // end of property ISLMUsageLog2::Department
  .property callconv(8) string location()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMUsageLog2::set_location(string)
  } // end of property ISLMUsageLog2::location
} // end of class Interop.SECSERVEROBJECTLib.ISLMUsageLog2

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISMID
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 30 37 33 33 33 32 43 43 2D 43 35 31 41   // ..$073332CC-C51A
                                                                                                  2D 34 37 42 42 2D 38 38 35 37 2D 43 41 44 34 31   // -47BB-8857-CAD41
                                                                                                  41 31 41 45 43 33 36 00 00 )                      // A1AEC36..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          SMID([in] string  marshal( bstr) x) runtime managed internalcall
  {
  } // end of method ISMID::SMID

  .method public hidebysig newslot abstract virtual 
          instance uint32  Register([in] class Interop.SECSERVEROBJECTLib.ISMID  marshal( interface ) peer) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISMID::Register

  .method public hidebysig newslot abstract virtual 
          instance void  UnRegister([in] uint32 cookie) runtime managed internalcall
  {
  } // end of method ISMID::UnRegister

} // end of class Interop.SECSERVEROBJECTLib.ISMID

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMUtility
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 39 38 38 31 37 42 30 2D 44 38 33 33   // ..$198817B0-D833
                                                                                                  2D 34 30 41 41 2D 39 43 43 46 2D 31 37 34 45 46   // -40AA-9CCF-174EF
                                                                                                  36 43 31 39 35 37 43 00 00 )                      // 6C1957C..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance bool  CheckLicense([in] string  marshal( bstr) license,
                                      [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMUtility::CheckLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetLicenseLocation([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMUtility::GetLicenseLocation

} // end of class Interop.SECSERVEROBJECTLib.ISLMUtility

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMUtility2
       implements Interop.SECSERVEROBJECTLib.ISLMUtility
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 44 33 34 31 34 46 32 42 2D 45 36 33 46   // ..$D3414F2B-E63F
                                                                                                  2D 34 32 41 39 2D 39 38 31 45 2D 36 32 38 33 37   // -42A9-981E-62837
                                                                                                  46 45 35 32 32 42 42 00 00 )                      // FE522BB..
  .method public hidebysig newslot abstract virtual 
          instance bool  CheckLicense([in] string  marshal( bstr) license,
                                      [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMUtility2::CheckLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetLicenseLocation([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMUtility2::GetLicenseLocation

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GenerateAuthCode([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMUtility2::GenerateAuthCode

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetCurrentCookies([in] int8 wholeprocess,
                            [in] int8 softcookies) runtime managed internalcall
  {
  } // end of method ISLMUtility2::GetCurrentCookies

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetLicenseName([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMUtility2::GetLicenseName

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GenerateErrorMessageFromLastError([in] string  marshal( bstr) 'error') runtime managed internalcall
  {
  } // end of method ISLMUtility2::GenerateErrorMessageFromLastError

} // end of class Interop.SECSERVEROBJECTLib.ISLMUtility2

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMUtility3
       implements Interop.SECSERVEROBJECTLib.ISLMUtility2
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 32 43 39 44 32 46 39 30 2D 35 42 32 36   // ..$2C9D2F90-5B26
                                                                                                  2D 34 39 38 45 2D 42 45 44 30 2D 33 34 37 31 35   // -498E-BED0-34715
                                                                                                  39 37 39 31 44 45 38 00 00 )                      // 9791DE8..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance bool  CheckLicense([in] string  marshal( bstr) license,
                                      [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMUtility3::CheckLicense

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetLicenseLocation([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMUtility3::GetLicenseLocation

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GenerateAuthCode([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMUtility3::GenerateAuthCode

  .method public hidebysig newslot abstract virtual 
          instance object 
          marshal( struct) 
          GetCurrentCookies([in] int8 wholeprocess,
                            [in] int8 softcookies) runtime managed internalcall
  {
  } // end of method ISLMUtility3::GetCurrentCookies

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetLicenseName([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMUtility3::GetLicenseName

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GenerateErrorMessageFromLastError([in] string  marshal( bstr) 'error') runtime managed internalcall
  {
  } // end of method ISLMUtility3::GenerateErrorMessageFromLastError

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetLockingInformation() runtime managed internalcall
  {
  } // end of method ISLMUtility3::GetLockingInformation

  .method public hidebysig newslot abstract virtual 
          instance uint32  GetLicenseExpirationDate([in] int32 cookie) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMUtility3::GetLicenseExpirationDate

  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          GetDebugInformation() runtime managed internalcall
  {
  } // end of method ISLMUtility3::GetDebugInformation

  .method public hidebysig newslot abstract virtual 
          instance uint32  VerifyInstalledConfiguration([in] uint32 state) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMUtility3::VerifyInstalledConfiguration

  .method public hidebysig newslot abstract virtual 
          instance int32  GetCustomLock([in] int32 lockmask) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMUtility3::GetCustomLock

} // end of class Interop.SECSERVEROBJECTLib.ISLMUtility3

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMLicenseVersion
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 45 31 39 45 39 42 42 36 2D 42 36 42 46   // ..$E19E9BB6-B6BF
                                                                                                  2D 34 35 43 35 2D 42 38 34 36 2D 41 39 39 41 36   // -45C5-B846-A99A6
                                                                                                  34 31 35 36 31 42 42 00 00 )                      // 41561BB..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  GetLicensedVersions([in] int32 cookie,
                                             [out] int32& maxMajor,
                                             [out] int32& maxMinor,
                                             [out] int32& maxPL,
                                             [out] int32& minMajor,
                                             [out] int32& minMinor,
                                             [out] int32& minPL) runtime managed internalcall
  {
  } // end of method ISLMLicenseVersion::GetLicensedVersions

} // end of class Interop.SECSERVEROBJECTLib.ISLMLicenseVersion

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMSoftUtility
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 45 34 31 35 44 41 37 35 2D 43 39 42 42   // ..$E415DA75-C9BB
                                                                                                  2D 34 30 30 34 2D 42 39 32 31 2D 33 34 45 30 34   // -4004-B921-34E04
                                                                                                  46 45 44 44 39 30 37 00 00 )                      // FEDD907..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance bool  ISC([in] int32 cookie) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMSoftUtility::ISC

  .method public hidebysig newslot abstract virtual 
          instance bool  CreateSoftLicense([in] string  marshal( bstr) license,
                                           [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ISLMSoftUtility::CreateSoftLicense

} // end of class Interop.SECSERVEROBJECTLib.ISLMSoftUtility

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.IComponentVersionString
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 38 37 36 35 38 46 36 46 2D 36 41 39 31   // ..$87658F6F-6A91
                                                                                                  2D 34 33 44 34 2D 39 33 39 35 2D 36 41 31 31 32   // -43D4-9395-6A112
                                                                                                  33 36 30 44 31 35 44 00 00 )                      // 360D15D..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot specialname abstract virtual 
          instance string 
          marshal( bstr) 
          get_VersionString() runtime managed internalcall
  {
  } // end of method IComponentVersionString::get_VersionString

  .property callconv(8) string VersionString()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .get instance string Interop.SECSERVEROBJECTLib.IComponentVersionString::get_VersionString()
  } // end of property IComponentVersionString::VersionString
} // end of class Interop.SECSERVEROBJECTLib.IComponentVersionString

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMIdleTime
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 44 35 41 42 32 45 31 30 2D 42 37 34 36   // ..$D5AB2E10-B746
                                                                                                  2D 34 33 31 32 2D 39 45 35 41 2D 41 32 39 35 35   // -4312-9E5A-A2955
                                                                                                  41 32 31 46 44 30 31 00 00 )                      // A21FD01..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  SetIdleTime([in] int32 minutes,
                                     [in] class Interop.SECSERVEROBJECTLib.ISLMIdleTimeCallback  marshal( interface ) idleCallback,
                                     [out] int32& idleCookie) runtime managed internalcall
  {
  } // end of method ISLMIdleTime::SetIdleTime

  .method public hidebysig newslot abstract virtual 
          instance void  StopIdle([in] int32 idleCookie) runtime managed internalcall
  {
  } // end of method ISLMIdleTime::StopIdle

  .method public hidebysig newslot abstract virtual 
          instance void  Heartbeat([in] int32 idleCookie) runtime managed internalcall
  {
  } // end of method ISLMIdleTime::Heartbeat

} // end of class Interop.SECSERVEROBJECTLib.ISLMIdleTime

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.IStochastic
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 34 45 34 42 32 30 34 36 2D 46 41 33 44   // ..$4E4B2046-FA3D
                                                                                                  2D 34 35 46 33 2D 38 34 36 42 2D 36 41 42 32 44   // -45F3-846B-6AB2D
                                                                                                  35 32 44 30 31 39 35 00 00 )                      // 52D0195..
  .method public hidebysig newslot abstract virtual 
          instance float64  Random([in][out] int32& seed) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method IStochastic::Random

} // end of class Interop.SECSERVEROBJECTLib.IStochastic

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ITimedLicense
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 34 38 42 33 46 44 37 42 2D 33 44 35 46   // ..$48B3FD7B-3D5F
                                                                                                  2D 34 44 46 34 2D 42 34 35 42 2D 42 45 33 35 31   // -4DF4-B45B-BE351
                                                                                                  43 43 39 43 45 46 45 00 00 )                      // CC9CEFE..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance string 
          marshal( bstr) 
          CheckoutTimedLicense([in] string  marshal( bstr) license,
                               [in] int32 timeoutMinutes,
                               [out] int32& cookie) runtime managed internalcall
  {
  } // end of method ITimedLicense::CheckoutTimedLicense

  .method public hidebysig newslot abstract virtual 
          instance void  HeartbeatTimedLicense([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ITimedLicense::HeartbeatTimedLicense

  .method public hidebysig newslot abstract virtual 
          instance void  TimedLicenseState([in] int32 cookie,
                                           [out] string&  marshal( bstr) name,
                                           [out] int32& timeout,
                                           [out] int32& timeleft,
                                           [out] valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum& state) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
  } // end of method ITimedLicense::TimedLicenseState

} // end of class Interop.SECSERVEROBJECTLib.ITimedLicense

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMInstalltime
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 45 34 30 32 32 38 44 34 2D 38 44 37 32   // ..$E40228D4-8D72
                                                                                                  2D 34 46 46 44 2D 38 35 42 36 2D 41 41 38 37 35   // -4FFD-85B6-AA875
                                                                                                  44 44 35 46 43 36 35 00 00 )                      // DD5FC65..
  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Loveisnotall([in] uint8 __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMInstalltime::set_Loveisnotall

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_itisnotmeatnordrink([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMInstalltime::set_itisnotmeatnordrink

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Norslumber([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMInstalltime::set_Norslumber

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_noraroofagainsttherain([in] uint32 __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMInstalltime::set_noraroofagainsttherain

  .method public hidebysig newslot specialname abstract virtual 
          instance void  set_Noryetafloatingspartomenthatsink([in] uint8 __unnamed_cli_parameter__) runtime managed internalcall
  {
  } // end of method ISLMInstalltime::set_Noryetafloatingspartomenthatsink

  .method public hidebysig newslot abstract virtual 
          instance void  Andriseandsink() runtime managed internalcall
  {
  } // end of method ISLMInstalltime::Andriseandsink

  .property callconv(8) uint8 Loveisnotall()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 01 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_Loveisnotall(uint8)
  } // end of property ISLMInstalltime::Loveisnotall
  .property callconv(8) string itisnotmeatnordrink()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 02 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_itisnotmeatnordrink(string)
  } // end of property ISLMInstalltime::itisnotmeatnordrink
  .property callconv(8) string Norslumber()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 03 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_Norslumber(string)
  } // end of property ISLMInstalltime::Norslumber
  .property callconv(8) uint32 noraroofagainsttherain()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 04 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_noraroofagainsttherain(uint32)
  } // end of property ISLMInstalltime::noraroofagainsttherain
  .property callconv(8) uint8 Noryetafloatingspartomenthatsink()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = ( 01 00 05 00 00 00 00 00 ) 
    .set instance void Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_Noryetafloatingspartomenthatsink(uint8)
  } // end of property ISLMInstalltime::Noryetafloatingspartomenthatsink
} // end of class Interop.SECSERVEROBJECTLib.ISLMInstalltime

.class public auto ansi import Interop.SECSERVEROBJECTLib.SecServerClass
       extends [mscorlib]System.Object
       implements Interop.SECSERVEROBJECTLib.ISecServer,
                  Interop.SECSERVEROBJECTLib.SecServer,
                  Interop.SECSERVEROBJECTLib.ISecServer2,
                  Interop.SECSERVEROBJECTLib.ISecServer3,
                  Interop.SECSERVEROBJECTLib.ISecServer4,
                  Interop.SECSERVEROBJECTLib.ICSSUtility,
                  Interop.SECSERVEROBJECTLib.ICSSCommute,
                  Interop.SECSERVEROBJECTLib.ISLMUsageLog,
                  Interop.SECSERVEROBJECTLib.ISLMUsageLog2,
                  Interop.SECSERVEROBJECTLib.ISMID,
                  Interop.SECSERVEROBJECTLib.ISLMUtility,
                  Interop.SECSERVEROBJECTLib.ISLMUtility2,
                  Interop.SECSERVEROBJECTLib.ISLMUtility3,
                  Interop.SECSERVEROBJECTLib.ISLMLicenseVersion,
                  Interop.SECSERVEROBJECTLib.ISLMSoftUtility,
                  Interop.SECSERVEROBJECTLib.IComponentVersionString,
                  Interop.SECSERVEROBJECTLib.ISLMIdleTime,
                  Interop.SECSERVEROBJECTLib.IStochastic,
                  Interop.SECSERVEROBJECTLib.ITimedLicense,
                  Interop.SECSERVEROBJECTLib.ISLMInstalltime
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 30 46 44 42 34 2D 37 35 32 42   // ..$1460FDB4-752B
                                                                                                  2D 31 31 44 34 2D 42 30 36 37 2D 30 30 39 30 32   // -11D4-B067-00902
                                                                                                  37 31 43 46 33 38 33 00 00 )                      // 71CF383..
  .custom instance void [mscorlib]System.Runtime.InteropServices.ClassInterfaceAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ClassInterfaceType) = ( 01 00 00 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 02 00 00 00 00 00 ) 
  .method public specialname rtspecialname 
          instance void  .ctor() runtime managed internalcall
  {
  } // end of method SecServerClass::.ctor

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicense([in] string  marshal( bstr) license,
                          [in] string  marshal( bstr) licversion,
                          [out] int32& cookie,
                          [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                          [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer::CheckoutLicense
  } // end of method SecServerClass::CheckoutLicense

  .method public hidebysig newslot virtual 
          instance void  CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                 [in] string  marshal( bstr) licversion,
                                                 [out] int32& cookie,
                                                 [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                 [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer::CheckoutLicenseDeferred
  } // end of method SecServerClass::CheckoutLicenseDeferred

  .method public hidebysig newslot virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ValidateLicense([in] int32 cookie,
                          [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
    .override Interop.SECSERVEROBJECTLib.ISecServer::ValidateLicense
  } // end of method SecServerClass::ValidateLicense

  .method public hidebysig newslot virtual 
          instance void  ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::ReleaseLicense
  } // end of method SecServerClass::ReleaseLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          InfoString([in] int32 cookie,
                     [out] int32& infover) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::InfoString
  } // end of method SecServerClass::InfoString

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetErrorString([in] int32 errcode) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::GetErrorString
  } // end of method SecServerClass::GetErrorString

  .method public hidebysig newslot virtual 
          instance void  StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                   [out] int32& authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::StartAuth
  } // end of method SecServerClass::StartAuth

  .method public hidebysig newslot virtual 
          instance void  StopAuth([in] int32 authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::StopAuth
  } // end of method SecServerClass::StopAuth

  .method public hidebysig newslot virtual 
          instance void  RegisterSoftLicense([in] string  marshal( bstr) license,
                                             [in] string  marshal( bstr) versionInfo,
                                             [in] int32 versionNumber,
                                             [in] int32 referencecookie,
                                             [out] int32& softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::RegisterSoftLicense
  } // end of method SecServerClass::RegisterSoftLicense

  .method public hidebysig newslot virtual 
          instance void  RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::RevokeSoftLicense
  } // end of method SecServerClass::RevokeSoftLicense

  .method public hidebysig newslot virtual 
          instance void  ReleaseLicense2([in] int32 cookie,
                                         [in] int32 sync) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::ReleaseLicense2
  } // end of method SecServerClass::ReleaseLicense2

  .method public hidebysig newslot virtual 
          instance void  BatchCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                       [out] int32[]&  marshal( safearray int32) cookies,
                                       [out] string[]&  marshal( safearray bstr) errors) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::BatchCheckout
  } // end of method SecServerClass::BatchCheckout

  .method public hidebysig newslot virtual 
          instance void  BatchCheckin(int32[]  marshal( safearray int32) cookies,
                                      [in] int32 sync) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::BatchCheckin
  } // end of method SecServerClass::BatchCheckin

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          CheckoutLicenseMulti([in] string  marshal( bstr) license,
                               [in] string  marshal( bstr) licversion,
                               [in] int32 units,
                               [in] bool waitonit,
                               [out] int32& cookie,
                               [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                               [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [7]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer::CheckoutLicenseMulti
  } // end of method SecServerClass::CheckoutLicenseMulti

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          CheckLicenseExpiration([in] string  marshal( bstr) license,
                                 [in] string  marshal( bstr) licversion,
                                 [out] int32& expirationDate,
                                 [out] string&  marshal( bstr) location,
                                 [out] bool& needreminder) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::CheckLicenseExpiration
  } // end of method SecServerClass::CheckLicenseExpiration

  .method public hidebysig newslot virtual 
          instance void  CheckoutLicenseMultiDeferred([in] string  marshal( bstr) license,
                                                      [in] string  marshal( bstr) licversion,
                                                      [in] int32 units,
                                                      [out] int32& cookie,
                                                      [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                      [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer::CheckoutLicenseMultiDeferred
  } // end of method SecServerClass::CheckoutLicenseMultiDeferred

  .method public hidebysig newslot virtual 
          instance void  GetLicenseExpirationInfo([in] string  marshal( bstr) licensenames,
                                                  [out] string&  marshal( bstr) expiryInfo,
                                                  [out] string&  marshal( bstr) errrorstring) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::GetLicenseExpirationInfo
  } // end of method SecServerClass::GetLicenseExpirationInfo

  .method public hidebysig newslot virtual 
          instance void  GetLicenseInUse([in] string  marshal( bstr) license,
                                         [in] string  marshal( bstr) username,
                                         [in] string  marshal( bstr) hostname,
                                         [out] int32& num_lics) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::GetLicenseInUse
  } // end of method SecServerClass::GetLicenseInUse

  .method public hidebysig newslot virtual 
          instance void  CheckoutGraceLicense([in] string  marshal( bstr) license,
                                              [in] string  marshal( bstr) application,
                                              [in] string  marshal( bstr) clientId,
                                              [in] int32 units,
                                              [in] bool waitonit,
                                              [in] uint32 gracePeriod,
                                              [out] int32& cookie,
                                              [out] valuetype Interop.SECSERVEROBJECTLib.GraceState_enum& valid,
                                              [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) graceLicenseCallback,
                                              [out] string&  marshal( bstr) errorstring) runtime managed internalcall
  {
    .param [8]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2A 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..*Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 47 72   // RVEROBJECTLib.Gr
                                                                                                            61 63 65 53 74 61 74 65 5F 65 6E 75 6D 00 00 )    // aceState_enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer::CheckoutGraceLicense
  } // end of method SecServerClass::CheckoutGraceLicense

  .method public hidebysig newslot virtual 
          instance void  CheckoutEngLicense([in] string  marshal( bstr) license,
                                            [in] int32 units,
                                            [in] bool waitonit,
                                            [out] int32& cookie,
                                            [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                            [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance,
                                            [out] string&  marshal( bstr) errstring) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer::CheckoutEngLicense
  } // end of method SecServerClass::CheckoutEngLicense

  .method public hidebysig newslot virtual 
          instance void  GroupCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                       [in] valuetype Interop.SECSERVEROBJECTLib.LicenseType_enum lictype,
                                       bool waitonit,
                                       [out] int32[]&  marshal( safearray int) cookies,
                                       [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                       [out] string&  marshal( bstr) 'error') runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 54 79 70 65 5F 65 6E 75 6D 00 00 ) // censeType_enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer::GroupCheckout
  } // end of method SecServerClass::GroupCheckout

  .method public hidebysig newslot virtual 
          instance void  GroupCheckin([in] int32[]  marshal( safearray int32) cookies) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::GroupCheckin
  } // end of method SecServerClass::GroupCheckin

  .method public hidebysig newslot virtual 
          instance void  GroupValidate([in] int32[]  marshal( safearray int32) cookies,
                                       [in] bool waitonit,
                                       [out] int32[]&  marshal( safearray int) statuses) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::GroupValidate
  } // end of method SecServerClass::GroupValidate

  .method public hidebysig newslot virtual 
          instance void  InitStandaloneSystem(string  marshal( bstr) LicenseName,
                                              string  marshal( bstr) LicenseVersion,
                                              string&  marshal( bstr) errstring) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer::InitStandaloneSystem
  } // end of method SecServerClass::InitStandaloneSystem

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer2_CheckoutLicense([in] string  marshal( bstr) license,
                                      [in] string  marshal( bstr) licversion,
                                      [out] int32& cookie,
                                      [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                      [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer2::CheckoutLicense
  } // end of method SecServerClass::ISecServer2_CheckoutLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer2_CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                             [in] string  marshal( bstr) licversion,
                                                             [out] int32& cookie,
                                                             [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                             [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer2::CheckoutLicenseDeferred
  } // end of method SecServerClass::ISecServer2_CheckoutLicenseDeferred

  .method public hidebysig newslot virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ISecServer2_ValidateLicense([in] int32 cookie,
                                      [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
    .override Interop.SECSERVEROBJECTLib.ISecServer2::ValidateLicense
  } // end of method SecServerClass::ISecServer2_ValidateLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer2_ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer2::ReleaseLicense
  } // end of method SecServerClass::ISecServer2_ReleaseLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer2_InfoString([in] int32 cookie,
                                 [out] int32& infover) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer2::InfoString
  } // end of method SecServerClass::ISecServer2_InfoString

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer2_GetErrorString([in] int32 errcode) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer2::GetErrorString
  } // end of method SecServerClass::ISecServer2_GetErrorString

  .method public hidebysig newslot virtual 
          instance void  ISecServer2_StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                               [out] int32& authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer2::StartAuth
  } // end of method SecServerClass::ISecServer2_StartAuth

  .method public hidebysig newslot virtual 
          instance void  ISecServer2_StopAuth([in] int32 authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer2::StopAuth
  } // end of method SecServerClass::ISecServer2_StopAuth

  .method public hidebysig newslot virtual 
          instance void  ISecServer2_RegisterSoftLicense([in] string  marshal( bstr) license,
                                                         [in] string  marshal( bstr) versionInfo,
                                                         [in] int32 versionNumber,
                                                         [in] int32 referencecookie,
                                                         [out] int32& softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer2::RegisterSoftLicense
  } // end of method SecServerClass::ISecServer2_RegisterSoftLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer2_RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer2::RevokeSoftLicense
  } // end of method SecServerClass::ISecServer2_RevokeSoftLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer3_CheckoutLicense([in] string  marshal( bstr) license,
                                      [in] string  marshal( bstr) licversion,
                                      [out] int32& cookie,
                                      [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                      [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer3::CheckoutLicense
  } // end of method SecServerClass::ISecServer3_CheckoutLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer3_CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                             [in] string  marshal( bstr) licversion,
                                                             [out] int32& cookie,
                                                             [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                             [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer3::CheckoutLicenseDeferred
  } // end of method SecServerClass::ISecServer3_CheckoutLicenseDeferred

  .method public hidebysig newslot virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ISecServer3_ValidateLicense([in] int32 cookie,
                                      [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
    .override Interop.SECSERVEROBJECTLib.ISecServer3::ValidateLicense
  } // end of method SecServerClass::ISecServer3_ValidateLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer3_ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::ReleaseLicense
  } // end of method SecServerClass::ISecServer3_ReleaseLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer3_InfoString([in] int32 cookie,
                                 [out] int32& infover) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::InfoString
  } // end of method SecServerClass::ISecServer3_InfoString

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer3_GetErrorString([in] int32 errcode) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::GetErrorString
  } // end of method SecServerClass::ISecServer3_GetErrorString

  .method public hidebysig newslot virtual 
          instance void  ISecServer3_StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                               [out] int32& authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::StartAuth
  } // end of method SecServerClass::ISecServer3_StartAuth

  .method public hidebysig newslot virtual 
          instance void  ISecServer3_StopAuth([in] int32 authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::StopAuth
  } // end of method SecServerClass::ISecServer3_StopAuth

  .method public hidebysig newslot virtual 
          instance void  ISecServer3_RegisterSoftLicense([in] string  marshal( bstr) license,
                                                         [in] string  marshal( bstr) versionInfo,
                                                         [in] int32 versionNumber,
                                                         [in] int32 referencecookie,
                                                         [out] int32& softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::RegisterSoftLicense
  } // end of method SecServerClass::ISecServer3_RegisterSoftLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer3_RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::RevokeSoftLicense
  } // end of method SecServerClass::ISecServer3_RevokeSoftLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer3_ReleaseLicense2([in] int32 cookie,
                                                     [in] int32 sync) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer3::ReleaseLicense2
  } // end of method SecServerClass::ISecServer3_ReleaseLicense2

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer4_CheckoutLicense([in] string  marshal( bstr) license,
                                      [in] string  marshal( bstr) licversion,
                                      [out] int32& cookie,
                                      [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                      [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer4::CheckoutLicense
  } // end of method SecServerClass::ISecServer4_CheckoutLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_CheckoutLicenseDeferred([in] string  marshal( bstr) license,
                                                             [in] string  marshal( bstr) licversion,
                                                             [out] int32& cookie,
                                                             [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                             [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer4::CheckoutLicenseDeferred
  } // end of method SecServerClass::ISecServer4_CheckoutLicenseDeferred

  .method public hidebysig newslot virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum 
          ISecServer4_ValidateLicense([in] int32 cookie,
                                      [in] int32 waitforit) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
    .override Interop.SECSERVEROBJECTLib.ISecServer4::ValidateLicense
  } // end of method SecServerClass::ISecServer4_ValidateLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_ReleaseLicense([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::ReleaseLicense
  } // end of method SecServerClass::ISecServer4_ReleaseLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer4_InfoString([in] int32 cookie,
                                 [out] int32& infover) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::InfoString
  } // end of method SecServerClass::ISecServer4_InfoString

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer4_GetErrorString([in] int32 errcode) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::GetErrorString
  } // end of method SecServerClass::ISecServer4_GetErrorString

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_StartAuth([in] class Interop.SECSERVEROBJECTLib.ICSSAuthenticate  marshal( interface ) auth,
                                               [out] int32& authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::StartAuth
  } // end of method SecServerClass::ISecServer4_StartAuth

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_StopAuth([in] int32 authcookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::StopAuth
  } // end of method SecServerClass::ISecServer4_StopAuth

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_RegisterSoftLicense([in] string  marshal( bstr) license,
                                                         [in] string  marshal( bstr) versionInfo,
                                                         [in] int32 versionNumber,
                                                         [in] int32 referencecookie,
                                                         [out] int32& softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::RegisterSoftLicense
  } // end of method SecServerClass::ISecServer4_RegisterSoftLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_RevokeSoftLicense([in] int32 softCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::RevokeSoftLicense
  } // end of method SecServerClass::ISecServer4_RevokeSoftLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_ReleaseLicense2([in] int32 cookie,
                                                     [in] int32 sync) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::ReleaseLicense2
  } // end of method SecServerClass::ISecServer4_ReleaseLicense2

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_BatchCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                                   [out] int32[]&  marshal( safearray int32) cookies,
                                                   [out] string[]&  marshal( safearray bstr) errors) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::BatchCheckout
  } // end of method SecServerClass::ISecServer4_BatchCheckout

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_BatchCheckin(int32[]  marshal( safearray int32) cookies,
                                                  [in] int32 sync) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::BatchCheckin
  } // end of method SecServerClass::ISecServer4_BatchCheckin

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer4_CheckoutLicenseMulti([in] string  marshal( bstr) license,
                                           [in] string  marshal( bstr) licversion,
                                           [in] int32 units,
                                           [in] bool waitonit,
                                           [out] int32& cookie,
                                           [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                           [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [7]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer4::CheckoutLicenseMulti
  } // end of method SecServerClass::ISecServer4_CheckoutLicenseMulti

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISecServer4_CheckLicenseExpiration([in] string  marshal( bstr) license,
                                             [in] string  marshal( bstr) licversion,
                                             [out] int32& expirationDate,
                                             [out] string&  marshal( bstr) location,
                                             [out] bool& needreminder) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::CheckLicenseExpiration
  } // end of method SecServerClass::ISecServer4_CheckLicenseExpiration

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_CheckoutLicenseMultiDeferred([in] string  marshal( bstr) license,
                                                                  [in] string  marshal( bstr) licversion,
                                                                  [in] int32 units,
                                                                  [out] int32& cookie,
                                                                  [in][opt] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                                  [in][opt] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer4::CheckoutLicenseMultiDeferred
  } // end of method SecServerClass::ISecServer4_CheckoutLicenseMultiDeferred

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_GetLicenseExpirationInfo([in] string  marshal( bstr) licensenames,
                                                              [out] string&  marshal( bstr) expiryInfo,
                                                              [out] string&  marshal( bstr) errrorstring) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::GetLicenseExpirationInfo
  } // end of method SecServerClass::ISecServer4_GetLicenseExpirationInfo

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_GetLicenseInUse([in] string  marshal( bstr) license,
                                                     [in] string  marshal( bstr) username,
                                                     [in] string  marshal( bstr) hostname,
                                                     [out] int32& num_lics) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::GetLicenseInUse
  } // end of method SecServerClass::ISecServer4_GetLicenseInUse

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_CheckoutGraceLicense([in] string  marshal( bstr) license,
                                                          [in] string  marshal( bstr) application,
                                                          [in] string  marshal( bstr) clientId,
                                                          [in] int32 units,
                                                          [in] bool waitonit,
                                                          [in] uint32 gracePeriod,
                                                          [out] int32& cookie,
                                                          [out] valuetype Interop.SECSERVEROBJECTLib.GraceState_enum& valid,
                                                          [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) graceLicenseCallback,
                                                          [out] string&  marshal( bstr) errorstring) runtime managed internalcall
  {
    .param [8]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2A 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..*Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 47 72   // RVEROBJECTLib.Gr
                                                                                                            61 63 65 53 74 61 74 65 5F 65 6E 75 6D 00 00 )    // aceState_enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer4::CheckoutGraceLicense
  } // end of method SecServerClass::ISecServer4_CheckoutGraceLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_CheckoutEngLicense([in] string  marshal( bstr) license,
                                                        [in] int32 units,
                                                        [in] bool waitonit,
                                                        [out] int32& cookie,
                                                        [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                        [in] valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum importance,
                                                        [out] string&  marshal( bstr) errstring) runtime managed internalcall
  {
    .param [6]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 31 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..1Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 49 6D 70 6F 72 74 61 6E 63 65 5F   // censeImportance_
                                                                                                            65 6E 75 6D 00 00 )                               // enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer4::CheckoutEngLicense
  } // end of method SecServerClass::ISecServer4_CheckoutEngLicense

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_GroupCheckout([in] string[]  marshal( safearray bstr) licensenames,
                                                   [in] valuetype Interop.SECSERVEROBJECTLib.LicenseType_enum lictype,
                                                   bool waitonit,
                                                   [out] int32[]&  marshal( safearray int) cookies,
                                                   [in] class Interop.SECSERVEROBJECTLib.ISecCallback  marshal( interface ) lostLicenseCallback,
                                                   [out] string&  marshal( bstr) 'error') runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 54 79 70 65 5F 65 6E 75 6D 00 00 ) // censeType_enum..
    .override Interop.SECSERVEROBJECTLib.ISecServer4::GroupCheckout
  } // end of method SecServerClass::ISecServer4_GroupCheckout

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_GroupCheckin([in] int32[]  marshal( safearray int32) cookies) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::GroupCheckin
  } // end of method SecServerClass::ISecServer4_GroupCheckin

  .method public hidebysig newslot virtual 
          instance void  ISecServer4_GroupValidate([in] int32[]  marshal( safearray int32) cookies,
                                                   [in] bool waitonit,
                                                   [out] int32[]&  marshal( safearray int) statuses) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISecServer4::GroupValidate
  } // end of method SecServerClass::ISecServer4_GroupValidate

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          Fingerprint([in] int32 refresh,
                      [in][out] int32& licCriteria,
                      [out] int32& lockcode,
                      [out] string&  marshal( bstr) machineIDstr) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSUtility::Fingerprint
  } // end of method SecServerClass::Fingerprint

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          Commute([in] string  marshal( bstr) server,
                  [in] string  marshal( bstr) licenses,
                  [in] int32 days,
                  [in] valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum tokenMode) runtime managed internalcall
  {
    .param [4]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::Commute
  } // end of method SecServerClass::Commute

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          Uncommute([in] string  marshal( bstr) server,
                    [in] string  marshal( bstr) licenses,
                    [in] valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum tokenMode) runtime managed internalcall
  {
    .param [3]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::Uncommute
  } // end of method SecServerClass::Uncommute

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetBroadcastServerList() runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetBroadcastServerList
  } // end of method SecServerClass::GetBroadcastServerList

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetConfiguredServerList([out] string&  marshal( bstr) forceServers) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetConfiguredServerList
  } // end of method SecServerClass::GetConfiguredServerList

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetServerLicenseList([in] string  marshal( bstr) server) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetServerLicenseList
  } // end of method SecServerClass::GetServerLicenseList

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetCommutedLicenseList() runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetCommutedLicenseList
  } // end of method SecServerClass::GetCommutedLicenseList

  .method public hidebysig newslot specialname virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum 
          get_ClientLicenseMode() runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::get_ClientLicenseMode
  } // end of method SecServerClass::get_ClientLicenseMode

  .method public hidebysig newslot virtual 
          instance valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum 
          GetServerLicenseMode([in] string  marshal( bstr) server) runtime managed internalcall
  {
    .param [0]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetServerLicenseMode
  } // end of method SecServerClass::GetServerLicenseMode

  .method public hidebysig newslot virtual 
          instance bool  LicenseIsCommutable([in] string  marshal( bstr) server,
                                             [in] string  marshal( bstr) license) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::LicenseIsCommutable
  } // end of method SecServerClass::LicenseIsCommutable

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetServerLockCode([in] string  marshal( bstr) server) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetServerLockCode
  } // end of method SecServerClass::GetServerLockCode

  .method public hidebysig newslot virtual 
          instance int32  WriteToRegistry([in] int32 what) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::WriteToRegistry
  } // end of method SecServerClass::WriteToRegistry

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          CommuteLicenses([in] string  marshal( bstr) server,
                          [in] string  marshal( bstr) licenses,
                          [in] int32 days) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::CommuteLicenses
  } // end of method SecServerClass::CommuteLicenses

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          UnCommuteLicenses([in] string  marshal( bstr) server,
                            [in] string  marshal( bstr) licenses) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::UnCommuteLicenses
  } // end of method SecServerClass::UnCommuteLicenses

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetCommutedLicenses() runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetCommutedLicenses
  } // end of method SecServerClass::GetCommutedLicenses

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetCommuterLicensesOnServer([in] string  marshal( bstr) server,
                                      [out] string&  marshal( bstr) licenses) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetCommuterLicensesOnServer
  } // end of method SecServerClass::GetCommuterLicensesOnServer

  .method public hidebysig newslot virtual 
          instance bool  IsInsideVirtualMachine() runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::IsInsideVirtualMachine
  } // end of method SecServerClass::IsInsideVirtualMachine

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          CommuteLicensesByTokens([in] string  marshal( bstr) server,
                                  [in] string  marshal( bstr) licenses,
                                  [in] int32 tokens,
                                  [in] int32 days) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::CommuteLicensesByTokens
  } // end of method SecServerClass::CommuteLicensesByTokens

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetBucketListOnServer([in] string  marshal( bstr) server,
                                [out] string&  marshal( bstr) buckets) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetBucketListOnServer
  } // end of method SecServerClass::GetBucketListOnServer

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetRedunServers([in] string  marshal( bstr) server,
                          [out] string&  marshal( bstr) leaderServer,
                          [out] string&  marshal( bstr) redundservers) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ICSSCommute::GetRedunServers
  } // end of method SecServerClass::GetRedunServers

  .method public hidebysig newslot specialname virtual 
          instance void  set_Job([in] int32 __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog::set_Job
  } // end of method SecServerClass::set_Job

  .method public hidebysig newslot specialname virtual 
          instance void  set_Department([in] int32 __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog::set_Department
  } // end of method SecServerClass::set_Department

  .method public hidebysig newslot specialname virtual 
          instance void  set_location([in] int32 __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog::set_location
  } // end of method SecServerClass::set_location

  .method public hidebysig newslot specialname virtual 
          instance void  set_Job([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog2::set_Job
  } // end of method SecServerClass::set_Job

  .method public hidebysig newslot specialname virtual 
          instance void  set_Department([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog2::set_Department
  } // end of method SecServerClass::set_Department

  .method public hidebysig newslot specialname virtual 
          instance void  set_location([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog2::set_location
  } // end of method SecServerClass::set_location

  .method public hidebysig newslot virtual 
          instance void  SetLanguage([in] string  marshal( bstr) langName) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog2::SetLanguage
  } // end of method SecServerClass::SetLanguage

  .method public hidebysig newslot virtual 
          instance void  SetProductVersion([in] string  marshal( bstr) bstrShortProdName,
                                           [in] string  marshal( bstr) bstrVersion) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUsageLog2::SetProductVersion
  } // end of method SecServerClass::SetProductVersion

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          SMID([in] string  marshal( bstr) x) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISMID::SMID
  } // end of method SecServerClass::SMID

  .method public hidebysig newslot virtual 
          instance uint32  Register([in] class Interop.SECSERVEROBJECTLib.ISMID  marshal( interface ) peer) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISMID::Register
  } // end of method SecServerClass::Register

  .method public hidebysig newslot virtual 
          instance void  UnRegister([in] uint32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISMID::UnRegister
  } // end of method SecServerClass::UnRegister

  .method public hidebysig newslot virtual 
          instance bool  CheckLicense([in] string  marshal( bstr) license,
                                      [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMUtility::CheckLicense
  } // end of method SecServerClass::CheckLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetLicenseLocation([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility::GetLicenseLocation
  } // end of method SecServerClass::GetLicenseLocation

  .method public hidebysig newslot virtual 
          instance bool  ISLMUtility2_CheckLicense([in] string  marshal( bstr) license,
                                                   [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMUtility2::CheckLicense
  } // end of method SecServerClass::ISLMUtility2_CheckLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISLMUtility2_GetLicenseLocation([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility2::GetLicenseLocation
  } // end of method SecServerClass::ISLMUtility2_GetLicenseLocation

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GenerateAuthCode([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility2::GenerateAuthCode
  } // end of method SecServerClass::GenerateAuthCode

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          GetCurrentCookies([in] int8 wholeprocess,
                            [in] int8 softcookies) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility2::GetCurrentCookies
  } // end of method SecServerClass::GetCurrentCookies

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetLicenseName([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility2::GetLicenseName
  } // end of method SecServerClass::GetLicenseName

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GenerateErrorMessageFromLastError([in] string  marshal( bstr) 'error') runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility2::GenerateErrorMessageFromLastError
  } // end of method SecServerClass::GenerateErrorMessageFromLastError

  .method public hidebysig newslot virtual 
          instance bool  ISLMUtility3_CheckLicense([in] string  marshal( bstr) license,
                                                   [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::CheckLicense
  } // end of method SecServerClass::ISLMUtility3_CheckLicense

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISLMUtility3_GetLicenseLocation([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GetLicenseLocation
  } // end of method SecServerClass::ISLMUtility3_GetLicenseLocation

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISLMUtility3_GenerateAuthCode([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GenerateAuthCode
  } // end of method SecServerClass::ISLMUtility3_GenerateAuthCode

  .method public hidebysig newslot virtual 
          instance object 
          marshal( struct) 
          ISLMUtility3_GetCurrentCookies([in] int8 wholeprocess,
                                         [in] int8 softcookies) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GetCurrentCookies
  } // end of method SecServerClass::ISLMUtility3_GetCurrentCookies

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISLMUtility3_GetLicenseName([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GetLicenseName
  } // end of method SecServerClass::ISLMUtility3_GetLicenseName

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          ISLMUtility3_GenerateErrorMessageFromLastError([in] string  marshal( bstr) 'error') runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GenerateErrorMessageFromLastError
  } // end of method SecServerClass::ISLMUtility3_GenerateErrorMessageFromLastError

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetLockingInformation() runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GetLockingInformation
  } // end of method SecServerClass::GetLockingInformation

  .method public hidebysig newslot virtual 
          instance uint32  GetLicenseExpirationDate([in] int32 cookie) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GetLicenseExpirationDate
  } // end of method SecServerClass::GetLicenseExpirationDate

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          GetDebugInformation() runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GetDebugInformation
  } // end of method SecServerClass::GetDebugInformation

  .method public hidebysig newslot virtual 
          instance uint32  VerifyInstalledConfiguration([in] uint32 state) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::VerifyInstalledConfiguration
  } // end of method SecServerClass::VerifyInstalledConfiguration

  .method public hidebysig newslot virtual 
          instance int32  GetCustomLock([in] int32 lockmask) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMUtility3::GetCustomLock
  } // end of method SecServerClass::GetCustomLock

  .method public hidebysig newslot virtual 
          instance void  GetLicensedVersions([in] int32 cookie,
                                             [out] int32& maxMajor,
                                             [out] int32& maxMinor,
                                             [out] int32& maxPL,
                                             [out] int32& minMajor,
                                             [out] int32& minMinor,
                                             [out] int32& minPL) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMLicenseVersion::GetLicensedVersions
  } // end of method SecServerClass::GetLicensedVersions

  .method public hidebysig newslot virtual 
          instance bool  ISC([in] int32 cookie) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMSoftUtility::ISC
  } // end of method SecServerClass::ISC

  .method public hidebysig newslot virtual 
          instance bool  CreateSoftLicense([in] string  marshal( bstr) license,
                                           [in] string  marshal( bstr) licversion) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.ISLMSoftUtility::CreateSoftLicense
  } // end of method SecServerClass::CreateSoftLicense

  .method public hidebysig newslot specialname virtual 
          instance string 
          marshal( bstr) 
          get_VersionString() runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.IComponentVersionString::get_VersionString
  } // end of method SecServerClass::get_VersionString

  .method public hidebysig newslot virtual 
          instance void  SetIdleTime([in] int32 minutes,
                                     [in] class Interop.SECSERVEROBJECTLib.ISLMIdleTimeCallback  marshal( interface ) idleCallback,
                                     [out] int32& idleCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMIdleTime::SetIdleTime
  } // end of method SecServerClass::SetIdleTime

  .method public hidebysig newslot virtual 
          instance void  StopIdle([in] int32 idleCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMIdleTime::StopIdle
  } // end of method SecServerClass::StopIdle

  .method public hidebysig newslot virtual 
          instance void  Heartbeat([in] int32 idleCookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMIdleTime::Heartbeat
  } // end of method SecServerClass::Heartbeat

  .method public hidebysig newslot virtual 
          instance float64  Random([in][out] int32& seed) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
    .override Interop.SECSERVEROBJECTLib.IStochastic::Random
  } // end of method SecServerClass::Random

  .method public hidebysig newslot virtual 
          instance string 
          marshal( bstr) 
          CheckoutTimedLicense([in] string  marshal( bstr) license,
                               [in] int32 timeoutMinutes,
                               [out] int32& cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ITimedLicense::CheckoutTimedLicense
  } // end of method SecServerClass::CheckoutTimedLicense

  .method public hidebysig newslot virtual 
          instance void  HeartbeatTimedLicense([in] int32 cookie) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ITimedLicense::HeartbeatTimedLicense
  } // end of method SecServerClass::HeartbeatTimedLicense

  .method public hidebysig newslot virtual 
          instance void  TimedLicenseState([in] int32 cookie,
                                           [out] string&  marshal( bstr) name,
                                           [out] int32& timeout,
                                           [out] int32& timeleft,
                                           [out] valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum& state) runtime managed internalcall
  {
    .param [5]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2D 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..-Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 53 74 61 74 75 73 5F 65 6E 75 6D   // censeStatus_enum
                                                                                                            00 00 ) 
    .override Interop.SECSERVEROBJECTLib.ITimedLicense::TimedLicenseState
  } // end of method SecServerClass::TimedLicenseState

  .method public hidebysig newslot specialname virtual 
          instance void  set_Loveisnotall([in] uint8 __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_Loveisnotall
  } // end of method SecServerClass::set_Loveisnotall

  .method public hidebysig newslot specialname virtual 
          instance void  set_itisnotmeatnordrink([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_itisnotmeatnordrink
  } // end of method SecServerClass::set_itisnotmeatnordrink

  .method public hidebysig newslot specialname virtual 
          instance void  set_Norslumber([in] string  marshal( bstr) __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_Norslumber
  } // end of method SecServerClass::set_Norslumber

  .method public hidebysig newslot specialname virtual 
          instance void  set_noraroofagainsttherain([in] uint32 __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_noraroofagainsttherain
  } // end of method SecServerClass::set_noraroofagainsttherain

  .method public hidebysig newslot specialname virtual 
          instance void  set_Noryetafloatingspartomenthatsink([in] uint8 __unnamed_cli_parameter__) runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMInstalltime::set_Noryetafloatingspartomenthatsink
  } // end of method SecServerClass::set_Noryetafloatingspartomenthatsink

  .method public hidebysig newslot virtual 
          instance void  Andriseandsink() runtime managed internalcall
  {
    .override Interop.SECSERVEROBJECTLib.ISLMInstalltime::Andriseandsink
  } // end of method SecServerClass::Andriseandsink

  .property callconv(8) valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum
          ClientLicenseMode()
  {
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2B 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..+Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 4C 69   // RVEROBJECTLib.Li
                                                                                                            63 65 6E 73 65 4D 6F 64 65 5F 65 6E 75 6D 00 00 ) // censeMode_enum..
    .get instance valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum Interop.SECSERVEROBJECTLib.SecServerClass::get_ClientLicenseMode()
  } // end of property SecServerClass::ClientLicenseMode
  .property callconv(8) int32 Job()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_Job(int32)
  } // end of property SecServerClass::Job
  .property callconv(8) int32 Department()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_Department(int32)
  } // end of property SecServerClass::Department
  .property callconv(8) int32 location()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_location(int32)
  } // end of property SecServerClass::location
  .property callconv(8) string ISLMUsageLog2_Job()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_Job(string)
  } // end of property SecServerClass::ISLMUsageLog2_Job
  .property callconv(8) string ISLMUsageLog2_Department()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_Department(string)
  } // end of property SecServerClass::ISLMUsageLog2_Department
  .property callconv(8) string ISLMUsageLog2_location()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_location(string)
  } // end of property SecServerClass::ISLMUsageLog2_location
  .property callconv(8) string VersionString()
  {
    .get instance string Interop.SECSERVEROBJECTLib.SecServerClass::get_VersionString()
  } // end of property SecServerClass::VersionString
  .property callconv(8) uint8 Loveisnotall()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_Loveisnotall(uint8)
  } // end of property SecServerClass::Loveisnotall
  .property callconv(8) string itisnotmeatnordrink()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_itisnotmeatnordrink(string)
  } // end of property SecServerClass::itisnotmeatnordrink
  .property callconv(8) string Norslumber()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_Norslumber(string)
  } // end of property SecServerClass::Norslumber
  .property callconv(8) uint32 noraroofagainsttherain()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_noraroofagainsttherain(uint32)
  } // end of property SecServerClass::noraroofagainsttherain
  .property callconv(8) uint8 Noryetafloatingspartomenthatsink()
  {
    .set instance void Interop.SECSERVEROBJECTLib.SecServerClass::set_Noryetafloatingspartomenthatsink(uint8)
  } // end of property SecServerClass::Noryetafloatingspartomenthatsink
} // end of class Interop.SECSERVEROBJECTLib.SecServerClass

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISecCallback
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 30 46 44 42 36 2D 37 35 32 42   // ..$1460FDB6-752B
                                                                                                  2D 31 31 44 34 2D 42 30 36 37 2D 30 30 39 30 32   // -11D4-B067-00902
                                                                                                  37 31 43 46 33 38 33 00 00 )                      // 71CF383..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  CheckoutFail([in] int32 cookie,
                                      [in] string  marshal( bstr) errstring) runtime managed internalcall
  {
  } // end of method ISecCallback::CheckoutFail

  .method public hidebysig newslot abstract virtual 
          instance void  LicenseFail([in] int32 cookie,
                                     [in] string  marshal( bstr) errstring) runtime managed internalcall
  {
  } // end of method ISecCallback::LicenseFail

  .method public hidebysig newslot abstract virtual 
          instance void  GraceLicenseState([in] string  marshal( bstr) clientId,
                                           [in] valuetype Interop.SECSERVEROBJECTLib.GraceState_enum& state,
                                           [in] int32 cookie,
                                           [in] int32 minutesRemaining,
                                           [in] string  marshal( bstr) 'error') runtime managed internalcall
  {
    .param [2]
    .custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = ( 01 00 2A 49 6E 74 65 72 6F 70 2E 53 45 43 53 45   // ..*Interop.SECSE
                                                                                                            52 56 45 52 4F 42 4A 45 43 54 4C 69 62 2E 47 72   // RVEROBJECTLib.Gr
                                                                                                            61 63 65 53 74 61 74 65 5F 65 6E 75 6D 00 00 )    // aceState_enum..
  } // end of method ISecCallback::GraceLicenseState

} // end of class Interop.SECSERVEROBJECTLib.ISecCallback

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.LicenseImportance_enum
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum liNotCritical = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseImportance_enum liCritical = int32(0x00000001)
} // end of class Interop.SECSERVEROBJECTLib.LicenseImportance_enum

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.LicenseStatus_enum
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum ls_NOLIC = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum ls_Pending = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseStatus_enum ls_OK = int32(0x00000002)
} // end of class Interop.SECSERVEROBJECTLib.LicenseStatus_enum

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ICSSAuthenticate
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 31 34 36 30 46 44 42 37 2D 37 35 32 42   // ..$1460FDB7-752B
                                                                                                  2D 31 31 44 34 2D 42 30 36 37 2D 30 30 39 30 32   // -11D4-B067-00902
                                                                                                  37 31 43 46 33 38 33 00 00 )                      // 71CF383..
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance int32  Authenticate() runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ICSSAuthenticate::Authenticate

  .method public hidebysig newslot abstract virtual 
          instance int32  mA([in] int32 inValue) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ICSSAuthenticate::mA

  .method public hidebysig newslot abstract virtual 
          instance int32  mB([in] int32 inValue) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ICSSAuthenticate::mB

  .method public hidebysig newslot abstract virtual 
          instance int32  mC([in] int32 inValue) runtime managed internalcall
  {
    .param [0]
    // @emit-empty-param
  } // end of method ICSSAuthenticate::mC

} // end of class Interop.SECSERVEROBJECTLib.ICSSAuthenticate

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.GraceState_enum
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.GraceState_enum gs_Normal = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.GraceState_enum gs_Timeout = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.GraceState_enum gs_Grace = int32(0x00000002)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.GraceState_enum gs_Unlicensed = int32(0x00000003)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.GraceState_enum gs_NonActivated = int32(0x00000004)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.GraceState_enum gs_Unknown = int32(0x00000005)
} // end of class Interop.SECSERVEROBJECTLib.GraceState_enum

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.LicenseType_enum
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseType_enum lt_NoToken = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseType_enum lt_Mixed = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseType_enum lt_Token = int32(0x00000002)
} // end of class Interop.SECSERVEROBJECTLib.LicenseType_enum

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005 gs_Normal = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005 gs_Timeout = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005 gs_Grace = int32(0x00000002)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005 gs_Unlicensed = int32(0x00000003)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005 gs_NonActivated = int32(0x00000004)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005 gs_Unknown = int32(0x00000005)
} // end of class Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0005

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0002
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0002 liNotCritical = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0002 liCritical = int32(0x00000001)
} // end of class Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0002

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0003
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0003 ls_NOLIC = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0003 ls_Pending = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0003 ls_OK = int32(0x00000002)
} // end of class Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0003

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0006
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0006 lt_NoToken = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0006 lt_Mixed = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0006 lt_Token = int32(0x00000002)
} // end of class Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0006

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.LicenseMode_enum
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum lm_Auto = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum lm_Standard = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum lm_Token = int32(0x00000002)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum lm_Unified = int32(0x00000003)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.LicenseMode_enum lm_Net = int32(0x00000004)
} // end of class Interop.SECSERVEROBJECTLib.LicenseMode_enum

.class public auto ansi sealed Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004
       extends [mscorlib]System.Enum
{
  .field public specialname rtspecialname int32 value__
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004 lm_Auto = int32(0x00000000)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004 lm_Standard = int32(0x00000001)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004 lm_Token = int32(0x00000002)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004 lm_Unified = int32(0x00000003)
  .field public static literal valuetype Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004 lm_Net = int32(0x00000004)
} // end of class Interop.SECSERVEROBJECTLib.__MIDL___MIDL_itf_SecServerObject_0000_0000_0004

.class interface public abstract auto ansi import Interop.SECSERVEROBJECTLib.ISLMIdleTimeCallback
{
  .custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = ( 01 00 24 43 43 43 38 45 30 30 43 2D 41 35 39 45   // ..$CCC8E00C-A59E
                                                                                                  2D 34 37 46 31 2D 39 36 34 30 2D 46 41 42 42 43   // -47F1-9640-FABBC
                                                                                                  30 36 38 34 41 30 36 00 00 )                      // 0684A06..
  .custom instance void [mscorlib]System.Runtime.InteropServices.TypeLibTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.TypeLibTypeFlags) = ( 01 00 10 01 00 00 00 00 ) 
  .custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = ( 01 00 01 00 00 00 00 00 ) 
  .method public hidebysig newslot abstract virtual 
          instance void  IdleTimeExceeded([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMIdleTimeCallback::IdleTimeExceeded

  .method public hidebysig newslot abstract virtual 
          instance void  IdleTimeWarning([in] int32 cookie) runtime managed internalcall
  {
  } // end of method ISLMIdleTimeCallback::IdleTimeWarning

} // end of class Interop.SECSERVEROBJECTLib.ISLMIdleTimeCallback


// =============================================================

// *********** DISASSEMBLY COMPLETE ***********************
