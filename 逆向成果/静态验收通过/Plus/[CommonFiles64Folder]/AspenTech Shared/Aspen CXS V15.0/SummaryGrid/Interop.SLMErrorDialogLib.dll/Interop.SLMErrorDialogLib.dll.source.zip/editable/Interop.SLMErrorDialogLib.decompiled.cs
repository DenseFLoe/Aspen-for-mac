using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: TypeLibVersion(1, 0)]
[assembly: Guid("2691b034-4628-47f4-b100-daf1eaab19af")]
[assembly: ImportedFromTypeLib("SLMCommonErrorDialogLib")]
[assembly: AssemblyVersion("2012.0.0.0")]
namespace Interop.SLMErrorDialogLib;

[ComImport]
[Guid("65D9AFBE-931B-4C25-826D-21777D5D29E5")]
[ClassInterface((short)0)]
[TypeLibType(2)]
public class SLMCommonErrorDialogObjectClass : ISLMCommonErrorDialogObject, SLMCommonErrorDialogObject
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void Display([In][MarshalAs(UnmanagedType.BStr)] string LicenseName, [In][MarshalAs(UnmanagedType.BStr)] string SLMErrorCode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	public virtual extern void ParseSLMErrorCode([In][MarshalAs(UnmanagedType.BStr)] string SLMErrorCode, [MarshalAs(UnmanagedType.BStr)] out string SLMParsedErrorMessage);

	[DispId(1610678274)]
	public virtual extern short InformationFlag
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}
}
[ComImport]
[Guid("3516F511-3E8D-4EE9-8DCC-60F98399E13E")]
[CoClass(typeof(SLMCommonErrorDialogObjectClass))]
public interface SLMCommonErrorDialogObject : ISLMCommonErrorDialogObject
{
}
[ComImport]
[Guid("3516F511-3E8D-4EE9-8DCC-60F98399E13E")]
[InterfaceType(1)]
public interface ISLMCommonErrorDialogObject
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void Display([In][MarshalAs(UnmanagedType.BStr)] string LicenseName, [In][MarshalAs(UnmanagedType.BStr)] string SLMErrorCode);

	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	void ParseSLMErrorCode([In][MarshalAs(UnmanagedType.BStr)] string SLMErrorCode, [MarshalAs(UnmanagedType.BStr)] out string SLMParsedErrorMessage);

	[DispId(1610678274)]
	short InformationFlag
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		get;
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[param: In]
		set;
	}
}
