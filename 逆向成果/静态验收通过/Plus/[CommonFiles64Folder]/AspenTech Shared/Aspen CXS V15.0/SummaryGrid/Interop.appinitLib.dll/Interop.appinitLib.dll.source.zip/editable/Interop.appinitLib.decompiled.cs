using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: TypeLibVersion(1, 0)]
[assembly: PrimaryInteropAssembly(1, 0)]
[assembly: Guid("1f93cc28-a2ae-4aed-81bc-06d827969d7c")]
[assembly: ImportedFromTypeLib("appinitLib")]
[assembly: AssemblyVersion("2012.0.0.0")]
namespace Interop.AppInitLib;

[ComImport]
[ClassInterface((short)0)]
[Guid("6B68DC8F-4D15-4A9C-A3B9-97B8EB54D1BA")]
[TypeLibType(2)]
public class AppDataInitObjectClass : IAppDataInitObject, AppDataInitObject
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	public virtual extern void appdatainit([In][MarshalAs(UnmanagedType.BStr)] string license, out bool binit, [MarshalAs(UnmanagedType.BStr)] out string errorstring);
}
[ComImport]
[CoClass(typeof(AppDataInitObjectClass))]
[Guid("E6CB1593-1B57-40F9-BC7B-45BB85F2A70E")]
public interface AppDataInitObject : IAppDataInitObject
{
}
[ComImport]
[Guid("E6CB1593-1B57-40F9-BC7B-45BB85F2A70E")]
[TypeLibType(4288)]
public interface IAppDataInitObject
{
	[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
	[DispId(1)]
	void appdatainit([In][MarshalAs(UnmanagedType.BStr)] string license, out bool binit, [MarshalAs(UnmanagedType.BStr)] out string errorstring);
}
