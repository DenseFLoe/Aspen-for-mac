# Interop.appinitLib.decompiled.cs

Source: editable/Interop.appinitLib.decompiled.cs

Source SHA-256: 33aa36364c37a1b0ce1eb03b86f3e038b697e094a5cab2c10dc8627e1fec7660
