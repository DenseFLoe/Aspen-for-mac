using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;
using System.Xml;
using AspenTech.Adb.Acs;
using AspenTech.Adb.AdsAccessor;
using AspenTech.Adb.Interfaces;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("CompareAds")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("336eba5f-264e-4b5b-b147-7634bbfb1077")]
[assembly: AssemblyCompany("AspenTech Corporation")]
[assembly: AssemblyProduct("Aspen Data Share")]
[assembly: AssemblyCopyright("Copyright © AspenTech Corporation 2025")]
[assembly: AssemblyFileVersion("41.0.0.2")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace CompareAds;

public class Comparer
{
	private readonly Rule _rule;

	private readonly int _columns;

	private readonly string[] _files;

	private readonly IAdbTop[] _adbTops;

	private readonly IAccessor[] _accessors;

	private readonly AcsTopRecord[] _adbTopRecs;

	private XmlDocument _doc;

	private string _basePath;

	private readonly HashSet<string>[] _visited;

	private readonly List<XmlNode> _referenceNodes;

	private readonly bool _deleteIdentical;

	private int _scanned;

	private readonly List<string> _referencePaths;

	public string Result
	{
		get
		{
			if (_doc == null)
			{
				return "";
			}
			return _doc.OuterXml;
		}
	}

	public int ResultCode { get; set; }

	public XmlDocument Document => _doc;

	public Comparer(int columns, string ruleFile, out bool ruleParseError, bool keepIdenticalNodes = false)
	{
		ruleParseError = false;
		if (columns > 5)
		{
			columns = 5;
		}
		_columns = columns;
		_files = new string[columns];
		_adbTops = new IAdbTop[columns];
		_adbTopRecs = new AcsTopRecord[columns];
		_accessors = new IAccessor[columns];
		_visited = new HashSet<string>[columns];
		for (int i = 0; i < columns; i++)
		{
			_visited[i] = new HashSet<string>();
		}
		_referenceNodes = new List<XmlNode>();
		_deleteIdentical = !keepIdenticalNodes;
		if (!string.IsNullOrEmpty(ruleFile))
		{
			try
			{
				_rule = new Rule();
				_rule.Parse(ruleFile);
			}
			catch
			{
				ruleParseError = true;
				_rule = null;
			}
		}
		_referencePaths = new List<string>();
	}

	public void Clear()
	{
		for (int i = 0; i < _columns; i++)
		{
			_adbTopRecs[i] = null;
			_accessors[i] = null;
			if (_adbTops[i] != null)
			{
				_adbTops[i].PurgeCache();
				_adbTops[i].PurgeClassTypes();
			}
			_adbTops[i] = null;
			_visited[i] = null;
		}
		_referenceNodes.Clear();
		_doc = null;
	}

	public bool CompareFiles(bool interactive, string[] files, out string error, ref int scanned, ref int processed)
	{
		error = "";
		for (int i = 0; i < _columns; i++)
		{
			_files[i] = files[i];
			string fileName = Path.GetFileName(files[i]);
		}
		if (_rule != null)
		{
			_rule.MatchFileName(files[0]);
		}
		for (int j = 0; j < _columns; j++)
		{
			_adbTops[j] = OpenAds(files[j], out var error2);
			if (_adbTops[j] == null)
			{
				error = "OpenAds failure : " + error2;
				return false;
			}
			_accessors[j] = new Accessor();
			if (!_accessors[j].Attach(_adbTops[j]))
			{
				error = "Accessor Attach AdbTop failure";
				return false;
			}
			_adbTopRecs[j] = new AcsTopRecord(_adbTops[j]);
		}
		if (interactive)
		{
			processed += 10;
			ScanSize();
			processed += 10;
			scanned = _scanned + processed;
		}
		return Compare(sameFile: true, ref processed);
	}

	private bool Compare(bool sameFile, ref int processed)
	{
		_basePath = "appModel.SharedData";
		_doc = new XmlDocument();
		_doc.LoadXml("<AdsComparer></AdsComparer>");
		for (int i = 0; i < _columns; i++)
		{
			XmlAttribute xmlAttribute = _doc.CreateAttribute("File" + (i + 1));
			xmlAttribute.Value = _files[i];
			_doc.DocumentElement.Attributes.Append(xmlAttribute);
		}
		for (int j = 0; j < _columns; j++)
		{
			LoadObject(j, _accessors[j], _doc.DocumentElement, _adbTopRecs[j], null, ref processed);
		}
		while (_referenceNodes.Count > 0)
		{
			XmlNode xmlNode = _referenceNodes[0];
			string value = xmlNode.Attributes["path"].Value;
			if (_rule != null && _rule.MatchXXNode(value))
			{
				if (_deleteIdentical && xmlNode.ParentNode != null)
				{
					xmlNode.ParentNode.RemoveChild(xmlNode);
				}
			}
			else
			{
				ExpandNode(xmlNode, !sameFile, ref processed);
			}
			_referenceNodes.Remove(xmlNode);
		}
		if (_deleteIdentical)
		{
			DeleteNodes(_doc.DocumentElement);
			CompressNodes(_doc.DocumentElement);
		}
		ResultCode = 0;
		if (!_doc.DocumentElement.HasChildNodes)
		{
			XmlElement xmlElement = _doc.CreateElement("Variable");
			XmlAttribute xmlAttribute2 = _doc.CreateAttribute("name");
			xmlAttribute2.Value = "Identical";
			xmlElement.Attributes.Append(xmlAttribute2);
			xmlAttribute2 = _doc.CreateAttribute("type");
			xmlAttribute2.Value = "f";
			xmlElement.Attributes.Append(xmlAttribute2);
			_doc.DocumentElement.AppendChild(xmlElement);
			ResultCode = 1;
		}
		if (_rule != null)
		{
			_rule.SaveStatistics(_doc);
		}
		if (ResultCode == 1)
		{
			return true;
		}
		XmlElement xmlElement2 = _doc.CreateElement("Variable");
		XmlAttribute xmlAttribute3 = _doc.CreateAttribute("name");
		xmlAttribute3.Value = "Folder";
		xmlElement2.Attributes.Append(xmlAttribute3);
		xmlAttribute3 = _doc.CreateAttribute("type");
		xmlAttribute3.Value = "l";
		xmlElement2.Attributes.Append(xmlAttribute3);
		xmlAttribute3 = _doc.CreateAttribute("columns");
		xmlAttribute3.Value = _columns.ToString();
		xmlElement2.Attributes.Append(xmlAttribute3);
		for (int k = 0; k < _columns; k++)
		{
			string directoryName = Path.GetDirectoryName(_files[k]);
			int num = directoryName.LastIndexOf('\\');
			string value2 = directoryName.Substring(num + 1);
			XmlAttribute xmlAttribute4 = _doc.CreateAttribute((k == 0) ? "value" : ("value" + (k + 1)));
			xmlAttribute4.Value = value2;
			xmlElement2.Attributes.Append(xmlAttribute4);
		}
		_doc.DocumentElement.InsertBefore(xmlElement2, _doc.DocumentElement.FirstChild);
		return false;
	}

	private void ScanSize()
	{
		_basePath = "appModel.SharedData";
		_scanned = 0;
		ScanObject(_accessors[0], _adbTopRecs[0], null);
		while (_referencePaths.Count > 0)
		{
			string text = _referencePaths[0];
			AccessorElement accessorElement = _accessors[0].ObjectAtPath(null, text.Substring(1));
			if (accessorElement.type != null && accessorElement.type.Name.StartsWith("Adb"))
			{
				AcsBase acsbase = (AcsBase)accessorElement.value;
				ScanObject(_accessors[0], acsbase, accessorElement);
			}
			_referencePaths.RemoveAt(0);
		}
		_visited[0].Clear();
	}

	private void ScanObject(IAccessor accessor, AcsBase acsbase, AccessorElement acElement)
	{
		if (acsbase == null)
		{
			return;
		}
		string item = acsbase.Record.RecordGuid();
		if (_visited[0].Contains(item))
		{
			return;
		}
		_visited[0].Add(item);
		int num = acsbase.NumberOfVariables();
		_scanned += num;
		for (int i = 0; i < num; i++)
		{
			object obj = acsbase.ValueAtLocation(i);
			string text = acsbase.IDAtLocation(i);
			string text2 = acsbase.VariableTypeAtLocation(i);
			if (text2 == "f")
			{
				AccessorElement accessorElement = accessor.ObjectAtPath(acElement, text);
				string text3 = "";
				if (!string.IsNullOrEmpty(_basePath))
				{
					text3 = accessorElement.cxsPath.Substring(_basePath.Length);
				}
				if (obj != null)
				{
					if (text3.StartsWith("appModel.SharedData"))
					{
						text3 = text3.Substring("appModel.SharedData".Length);
					}
					_referencePaths.Add(text3);
				}
			}
			else if (text2.StartsWith("a") && obj != null)
			{
				ScanArray(accessor, text, acElement);
			}
		}
	}

	private void ScanArray(IAccessor accessor, string name, AccessorElement acElement)
	{
		AccessorElement accessorElement = accessor.ObjectAtPath(acElement, name);
		int num = accessor.NumberOfChildren(accessorElement);
		for (int i = 0; i < num; i++)
		{
			AccessorElement accessorElement2 = accessor.ObjectAtPath(accessorElement, "#" + i);
			if (accessorElement2.type != null && accessorElement2.type.Name.StartsWith("Adb") && accessorElement2.value != null)
			{
				string text = accessorElement2.cxsPath.Substring(_basePath.Length);
				if (text.StartsWith("appModel.SharedData"))
				{
					text = text.Substring("appModel.SharedData".Length);
				}
				_referencePaths.Add(text);
			}
		}
	}

	private void LoadObject(int index, IAccessor accessor, XmlNode root, AcsBase acsbase, AccessorElement acElement, ref int processed, bool manually = false)
	{
		if (acsbase == null)
		{
			return;
		}
		if (!manually && root.Name != "AdsComparer")
		{
			for (int i = 0; i < _columns; i++)
			{
				string name = ((i == 0) ? "value" : ("value" + (i + 1)));
				if (root.Attributes[name] == null)
				{
					return;
				}
			}
		}
		if (!manually)
		{
			string item = acsbase.Record.RecordGuid();
			if (_visited[index].Contains(item))
			{
				return;
			}
			_visited[index].Add(item);
		}
		string text = "";
		if (!string.IsNullOrEmpty(_basePath) && acElement != null)
		{
			text = acElement.cxsPath.Substring(_basePath.Length);
		}
		int num = acsbase.NumberOfVariables();
		if (index == 0)
		{
			processed += num;
		}
		for (int j = 0; j < num; j++)
		{
			string text2 = acsbase.IDAtLocation(j);
			string text3 = acsbase.VariableTypeAtLocation(j);
			object obj = null;
			try
			{
				obj = acsbase.ValueAtLocation(j);
			}
			catch
			{
			}
			if (text3 == "c" || text3 == "i" || text3 == "r" || text3 == "b")
			{
				XmlNode xmlNode;
				if (index == 0)
				{
					xmlNode = AddVariable(root, text2, j, text3, text + "." + text2);
				}
				else
				{
					xmlNode = SearchVariable(root, text2);
					if (xmlNode == null)
					{
						xmlNode = AddVariable(root, text2, j, text3, text + "." + text2);
					}
				}
				if (obj != null)
				{
					XmlAttribute xmlAttribute = _doc.CreateAttribute((index == 0) ? "value" : ("value" + (index + 1)));
					if (text3 == "c")
					{
						xmlAttribute.Value = (string)obj;
					}
					else if (text3 == "i")
					{
						xmlAttribute.Value = ((int)obj).ToString();
					}
					else if (text3 == "r")
					{
						xmlAttribute.Value = ((double)obj).ToString(CultureInfo.InvariantCulture.NumberFormat);
					}
					else if (text3 == "b")
					{
						xmlAttribute.Value = ((bool)obj).ToString();
					}
					xmlNode.Attributes.Append(xmlAttribute);
				}
				if (index == _columns - 1 && _deleteIdentical)
				{
					RemoveNode(xmlNode);
				}
				continue;
			}
			else if (text3 == "f")
			{
				AccessorElement accessorElement = accessor.ObjectAtPath(acElement, text2);
				XmlNode xmlNode2 = null;
				string path = "";
				if (!string.IsNullOrEmpty(_basePath))
				{
					path = accessorElement.cxsPath.Substring(_basePath.Length);
				}
				if (index == 0)
				{
					xmlNode2 = AddVariable(root, text2, j, text3, path, obj != null);
				}
				else if (obj != null)
				{
					xmlNode2 = SearchVariable(root, text2);
					if (xmlNode2 == null)
					{
						xmlNode2 = AddVariable(root, text2, j, text3, path, obj != null);
					}
					else if (!_referenceNodes.Contains(xmlNode2) && xmlNode2.Attributes["color2"].Value != "Red")
					{
						xmlNode2.Attributes["color2"].Value = "Red";
						_referenceNodes.Add(xmlNode2);
					}
				}
				if (obj != null && xmlNode2 != null)
				{
					string value = ((AcsBase)accessorElement.value).Record.RecordGuid();
					XmlAttribute xmlAttribute2 = _doc.CreateAttribute((index == 0) ? "value" : ("value" + (index + 1)));
					xmlAttribute2.Value = value;
					xmlNode2.Attributes.Append(xmlAttribute2);
				}
				if (index != 0 && _deleteIdentical && obj == null)
				{
					XmlNode xmlNode3 = SearchVariable(root, text2);
					if (xmlNode3 != null && xmlNode3.Attributes["color2"].Value != "Red")
					{
						root.RemoveChild(xmlNode3);
					}
				}
				continue;
			}
			else if (text3.StartsWith("a"))
			{
				XmlNode xmlNode4;
				if (index == 0)
				{
					xmlNode4 = AddVariable(root, text2, j, "a", text + "." + text2);
				}
				else
				{
					xmlNode4 = SearchVariable(root, text2);
					if (xmlNode4 == null)
					{
						xmlNode4 = AddVariable(root, text2, j, "a", text + "." + text2);
					}
				}
				if (obj != null)
				{
					LoadArray(index, accessor, xmlNode4, text2, acElement);
				}
				if (!manually && index != 0 && _deleteIdentical && (obj == null || !xmlNode4.HasChildNodes))
				{
					root.RemoveChild(xmlNode4);
				}
			}
		}
		if (index != 0 && _deleteIdentical && !root.HasChildNodes && root.ParentNode != null)
		{
			root.ParentNode.RemoveChild(root);
		}
	}

	private void LoadArray(int index, IAccessor accessor, XmlNode root, string name, AccessorElement acElement)
	{
		AccessorElement accessorElement = accessor.ObjectAtPath(acElement, name);
		int num = accessor.NumberOfChildren(accessorElement);
		for (int i = 0; i < num; i++)
		{
			AccessorElement accessorElement2 = accessor.ObjectAtPath(accessorElement, "#" + i);
			if (!(accessorElement2.type != null))
			{
				continue;
			}
			string name2 = accessorElement2.type.Name;
			if (name2 == "Double" || name2 == "String")
			{
				string text = accessorElement.cxsPath.Substring(_basePath.Length);
				string attribute = accessorElement2.attribute;
				XmlNode xmlNode;
				if (index == 0)
				{
					xmlNode = AddVariable(root, attribute, i, (name2 == "Double") ? "ar" : "ac", text + "." + attribute);
				}
				else
				{
					xmlNode = SearchVariable(root, attribute);
					if (xmlNode == null)
					{
						xmlNode = AddVariable(root, attribute, i, (name2 == "Double") ? "ar" : "ac", text + "." + attribute);
					}
				}
				XmlAttribute xmlAttribute = _doc.CreateAttribute((index == 0) ? "value" : ("value" + (index + 1)));
				if (name2 == "Double")
				{
					double numericValue = (double)accessorElement2.value;
					xmlAttribute.Value = numericValue.ToString(CultureInfo.InvariantCulture.NumberFormat);
				}
				else if (name2 == "String")
				{
					xmlAttribute.Value = (string)accessorElement2.value;
				}
				xmlNode.Attributes.Append(xmlAttribute);
				if (index == _columns - 1 && _deleteIdentical)
				{
					RemoveNode(xmlNode);
				}
			}
			else
			{
				if (!name2.StartsWith("Adb"))
				{
					continue;
				}
				string path = accessorElement2.cxsPath.Substring(_basePath.Length);
				string attribute2 = accessorElement2.attribute;
				XmlNode xmlNode2 = null;
				if (index == 0)
				{
					xmlNode2 = AddVariable(root, attribute2, i, "f", path, accessorElement2.value != null);
				}
				else if (accessorElement2.value != null)
				{
					xmlNode2 = SearchVariable(root, attribute2);
					if (xmlNode2 == null)
					{
						xmlNode2 = AddVariable(root, attribute2, i, "f", path, accessorElement2.value != null);
					}
				}
				if (accessorElement2.value != null && xmlNode2 != null)
				{
					string value = ((AcsBase)accessorElement2.value).Record.RecordGuid();
					XmlAttribute xmlAttribute2 = _doc.CreateAttribute((index == 0) ? "value" : ("value" + (index + 1)));
					xmlAttribute2.Value = value;
					xmlNode2.Attributes.Append(xmlAttribute2);
				}
			}
		}
	}

	private void RemoveNode(XmlNode elem)
	{
		if (elem == null)
		{
			return;
		}
		string value = elem.Attributes["path"].Value;
		string text = ((elem.Attributes["value"] != null) ? elem.Attributes["value"].Value : "");
		for (int i = 1; i < _columns; i++)
		{
			string name = "value" + (i + 1);
			string text2 = ((elem.Attributes[name] != null) ? elem.Attributes[name].Value : "");
			if (_rule != null && _rule.HasExactRules && !_rule.MatchExactRule(value, text, text2, elem))
			{
				return;
			}
			if (text2 != text && (_rule == null || !_rule.MatchNode(value, text, text2, elem)))
			{
				return;
			}
		}
		elem.ParentNode.RemoveChild(elem);
	}

	public void ExpandNode(XmlNode node, bool sameObjectOnly, ref int processed, bool manually = false)
	{
		if (sameObjectOnly)
		{
			string text = ((node.Attributes["value"] != null) ? node.Attributes["value"].Value : "");
			if (text != "")
			{
				for (int i = 1; i < _columns; i++)
				{
					string name = "value" + (i + 1);
					string text2 = ((node.Attributes[name] != null) ? node.Attributes[name].Value : "");
					if (text2 != "" && text2 != text)
					{
						return;
					}
				}
			}
		}
		for (int j = 0; j < _columns; j++)
		{
			ExpandReference(j, _accessors[j], node, ref processed, manually);
		}
	}

	private void ExpandReference(int index, IAccessor accessor, XmlNode node, ref int processed, bool manually = false)
	{
		if (index == 0 && node.HasChildNodes)
		{
			return;
		}
		if (index != 0)
		{
			node.Attributes["color2"].Value = "Black";
		}
		string value = node.Attributes["path"].Value;
		AccessorElement accessorElement = null;
		if (string.IsNullOrEmpty(value))
		{
			value = node.Attributes["name"].Value;
			accessorElement = accessor.ObjectAtPath(null, value);
		}
		else if (accessor != null)
		{
			accessorElement = accessor.ObjectAtPath(null, value.Substring(1));
		}
		if (accessorElement != null && accessorElement.type != null && accessorElement.type.Name.StartsWith("Adb"))
		{
			try
			{
				AcsBase acsbase = (AcsBase)accessorElement.value;
				LoadObject(index, accessor, node, acsbase, accessorElement, ref processed, manually);
			}
			catch
			{
			}
		}
	}

	private void DeleteNodes(XmlNode root)
	{
		for (int num = root.ChildNodes.Count - 1; num >= 0; num--)
		{
			XmlNode xmlNode = root.ChildNodes[num];
			string value = xmlNode.Attributes["type"].Value;
			if (value == "f" && NullExists(xmlNode))
			{
				for (int num2 = xmlNode.ChildNodes.Count - 1; num2 >= 0; num2--)
				{
					XmlNode oldChild = xmlNode.ChildNodes[num2];
					xmlNode.RemoveChild(oldChild);
				}
				for (int i = 0; i < _columns; i++)
				{
					string name = ((i == 0) ? "value" : ("value" + (i + 1)));
					if (xmlNode.Attributes[name] == null)
					{
						XmlAttribute xmlAttribute = _doc.CreateAttribute(name);
						xmlAttribute.Value = "(null)";
						xmlNode.Attributes.Append(xmlAttribute);
					}
				}
			}
			else if (value == "a" || value == "f")
			{
				if (xmlNode.HasChildNodes)
				{
					DeleteNodes(xmlNode);
				}
				if (!xmlNode.HasChildNodes)
				{
					root.RemoveChild(xmlNode);
				}
				else
				{
					for (int j = 0; j < _columns; j++)
					{
						string name2 = ((j == 0) ? "value" : ("value" + (j + 1)));
						if (xmlNode.Attributes[name2] != null)
						{
							xmlNode.Attributes[name2].Value = "";
						}
					}
				}
			}
		}
	}

	private bool NullExists(XmlNode node)
	{
		for (int i = 0; i < _columns; i++)
		{
			string name = ((i == 0) ? "value" : ("value" + (i + 1)));
			if (node.Attributes[name] == null)
			{
				return true;
			}
		}
		return false;
	}

	private bool AllNullOrSame(XmlNode node)
	{
		string text = ((node.Attributes["value"] != null) ? node.Attributes["value"].Value : "");
		for (int i = 1; i < _columns; i++)
		{
			string name = "value" + (i + 1);
			if (((node.Attributes[name] != null) ? node.Attributes[name].Value : "") != text)
			{
				return false;
			}
		}
		return true;
	}

	private void CompressNodes(XmlNode root)
	{
		XmlNodeList xmlNodeList = root.SelectNodes("Variable");
		for (int num = xmlNodeList.Count - 1; num >= 0; num--)
		{
			XmlNode root2 = xmlNodeList[num];
			CompressNodes(root2);
		}
		if (root.Name != "AdsComparer" && root.ChildNodes.Count == 1)
		{
			XmlNode firstChild = root.FirstChild;
			firstChild.Attributes["name"].Value = root.Attributes["name"].Value + " . " + firstChild.Attributes["name"].Value;
			root.RemoveChild(firstChild);
			XmlNode parentNode = root.ParentNode;
			parentNode.InsertBefore(firstChild, parentNode.FirstChild);
			parentNode.RemoveChild(root);
		}
	}

	private XmlNode AddVariable(XmlNode root, string name, int index, string type, string path, bool referenceExist = false)
	{
		XmlElement xmlElement = _doc.CreateElement("Variable");
		XmlAttribute xmlAttribute = _doc.CreateAttribute("name");
		xmlAttribute.Value = name;
		xmlElement.Attributes.Append(xmlAttribute);
		if (index >= 0)
		{
			XmlAttribute xmlAttribute2 = _doc.CreateAttribute("index");
			xmlAttribute2.Value = index.ToString();
			xmlElement.Attributes.Append(xmlAttribute2);
		}
		XmlAttribute xmlAttribute3 = _doc.CreateAttribute("type");
		xmlAttribute3.Value = type;
		xmlElement.Attributes.Append(xmlAttribute3);
		if (path.StartsWith("appModel.SharedData"))
		{
			path = path.Substring("appModel.SharedData".Length);
		}
		XmlAttribute xmlAttribute4 = _doc.CreateAttribute("path");
		xmlAttribute4.Value = path;
		xmlElement.Attributes.Append(xmlAttribute4);
		XmlAttribute xmlAttribute5 = _doc.CreateAttribute("color2");
		xmlAttribute5.Value = (referenceExist ? "Red" : "Black");
		xmlElement.Attributes.Append(xmlAttribute5);
		XmlAttribute xmlAttribute6 = _doc.CreateAttribute("columns");
		xmlAttribute6.Value = _columns.ToString();
		xmlElement.Attributes.Append(xmlAttribute6);
		XmlAttribute xmlAttribute7 = _doc.CreateAttribute("note");
		xmlAttribute7.Value = "";
		xmlElement.Attributes.Append(xmlAttribute7);
		root.AppendChild(xmlElement);
		if (referenceExist)
		{
			_referenceNodes.Add(xmlElement);
		}
		return xmlElement;
	}

	private XmlNode SearchVariable(XmlNode root, string name)
	{
		return root.SelectSingleNode("Variable[@name='" + name + "']");
	}

	private IAdbTop OpenAds(string fileName, out string error)
	{
		error = "";
		IAdbTop result = null;
		switch (Path.GetExtension(fileName).ToLower())
		{
		case ".ads":
		case ".hsc":
		case ".bkp":
		{
			IAdbManager adbManager = AcsFactory.Manager();
			if (adbManager == null)
			{
				error = "IAdbManager creation error";
				return null;
			}
			result = adbManager.OpenDatabase(fileName, createIfNecessary: false);
			break;
		}
		}
		return result;
	}
}
public class Rule
{
	private RuleItem[] _rules;

	private List<RuleItem> _exactRules;

	private List<RuleItem> _xxRules;

	public bool HasExactRules => _exactRules.Count > 0;

	public void Parse(string fileName)
	{
		using (StreamReader streamReader = new StreamReader(fileName))
		{
			JavaScriptSerializer javaScriptSerializer = new JavaScriptSerializer();
			string input = streamReader.ReadToEnd();
			_rules = javaScriptSerializer.Deserialize<RuleItem[]>(input);
		}
		_exactRules = new List<RuleItem>();
		_xxRules = new List<RuleItem>();
		bool flag = false;
		RuleItem[] rules = _rules;
		foreach (RuleItem ruleItem in rules)
		{
			if (ruleItem.Type == "~~")
			{
				flag = true;
			}
			else if (ruleItem.Type == "==" || ruleItem.Type == "!=")
			{
				_exactRules.Add(ruleItem);
				ruleItem.ExactRule = true;
			}
			else if (ruleItem.Type == "xx")
			{
				_xxRules.Add(ruleItem);
			}
		}
		if (flag)
		{
			ArrayList arrayList = new ArrayList();
			rules = _rules;
			foreach (RuleItem value in rules)
			{
				arrayList.Add(value);
			}
			IComparer comparer = new ItemComparer();
			arrayList.Sort(comparer);
			for (int j = 0; j < arrayList.Count; j++)
			{
				_rules[j] = (RuleItem)arrayList[j];
			}
		}
	}

	public void MatchFileName(string path)
	{
		string fileName = Path.GetFileName(path);
		for (int i = 0; i < _rules.Length; i++)
		{
			Regex regex = new Regex(_rules[i].FileName);
			if (regex.IsMatch(fileName))
			{
				_rules[i].Enabled = true;
				_rules[i].PassCount = 0;
				_rules[i].FailCount = 0;
			}
		}
	}

	public bool MatchXXNode(string nodeName)
	{
		for (int i = 0; i < _xxRules.Count; i++)
		{
			if (_xxRules[i].Enabled)
			{
				string text = _xxRules[i].Node;
				if (_xxRules[i].Detail.Contains("\\w"))
				{
					text += _xxRules[i].Detail;
				}
				Regex regex = new Regex(text);
				if (regex.IsMatch(nodeName))
				{
					_xxRules[i].PassCount++;
					return true;
				}
			}
		}
		return false;
	}

	public bool MatchNode(string nodeName, string aValue, string bValue, XmlNode node)
	{
		for (int i = 0; i < _rules.Length; i++)
		{
			if (!_rules[i].Enabled || _rules[i].ExactRule)
			{
				continue;
			}
			string text = _rules[i].Node;
			if (_rules[i].Type == "xx" && _rules[i].Detail.Contains("\\w"))
			{
				text += _rules[i].Detail;
			}
			Regex regex = new Regex(text);
			if (regex.IsMatch(nodeName))
			{
				if (node.Attributes["note"] != null)
				{
					node.Attributes["note"].Value = _rules[i].Note;
				}
				bool num = MatchValue(_rules[i].Type, _rules[i].Detail, aValue, bValue, node);
				if (num)
				{
					_rules[i].PassCount++;
				}
				else
				{
					_rules[i].FailCount++;
				}
				return num;
			}
		}
		return false;
	}

	public bool MatchExactRule(string nodeName, string aValue, string bValue, XmlNode node)
	{
		foreach (RuleItem exactRule in _exactRules)
		{
			Regex regex = new Regex(exactRule.Node);
			if (regex.IsMatch(nodeName))
			{
				if (node.Attributes["note"] != null)
				{
					node.Attributes["note"].Value = exactRule.Note;
				}
				bool flag = MatchValue(exactRule.Type, exactRule.Detail, "", bValue, node);
				if (flag)
				{
					exactRule.PassCount++;
				}
				else
				{
					exactRule.FailCount++;
				}
				if (exactRule.Type == "!=" && aValue == bValue)
				{
					flag = true;
				}
				return flag;
			}
		}
		return true;
	}

	private bool MatchValue(string matchType, string detail, string aValue, string bValue, XmlNode node)
	{
		switch (matchType)
		{
		case "==":
		case "!=":
			if (matchType == "==")
			{
				return bValue == detail;
			}
			return bValue != detail;
		case "~=":
		case "~~":
		case "~A=":
		case "~A<=":
		case "~A>=":
		case "0=":
		{
			if (string.IsNullOrEmpty(aValue) || string.IsNullOrEmpty(bValue))
			{
				return false;
			}
			if (!double.TryParse(aValue, NumberStyles.Number | NumberStyles.AllowExponent, CultureInfo.InvariantCulture.NumberFormat, out var result) || !double.TryParse(bValue, NumberStyles.Number | NumberStyles.AllowExponent, CultureInfo.InvariantCulture.NumberFormat, out var result2))
			{
				return false;
			}
			double num = double.Parse(detail, CultureInfo.InvariantCulture.NumberFormat);
			double num2;
			bool flag;
			if (matchType == "0=")
			{
				if (result < num)
				{
					result = 0.0;
				}
				if (result2 < num)
				{
					result2 = 0.0;
				}
				return result == result2;
			}
			if (matchType == "~=" || matchType == "~~")
			{
				num2 = Math.Abs(result - result2) / Math.Abs(result);
				flag = num2 < num;
			}
			else if (matchType == "~A=")
			{
				num2 = Math.Abs(result - result2) / (Math.Abs(result + result2) / 2.0);
				flag = num2 < num;
			}
			else
			{
				num2 = (result - result2) / (Math.Abs(result + result2) / 2.0);
				flag = ((matchType == "~A<=") ? (num2 < num) : (num2 > num));
			}
			if (!flag && node.Attributes["note"] != null)
			{
				string value3 = node.Attributes["note"].Value;
				if (value3.Contains("%DIFF%"))
				{
					node.Attributes["note"].Value = value3.Replace("%DIFF%", (num2 * 100.0).ToString("G3") + "%");
				}
			}
			return flag;
		}
		case "xx":
			return true;
		case "x=":
		{
			Regex regex = new Regex(detail);
			string value = regex.Match(aValue).Value;
			string value2 = regex.Match(bValue).Value;
			return value == value2;
		}
		default:
			return false;
		}
	}

	public void SaveStatistics(XmlDocument doc)
	{
		XmlElement xmlElement = doc.CreateElement("RuleStatistics");
		for (int i = 0; i < _rules.Length; i++)
		{
			if (_rules[i].Enabled && (_rules[i].PassCount > 0 || _rules[i].FailCount > 0))
			{
				XmlElement xmlElement2 = doc.CreateElement("Rule");
				XmlAttribute xmlAttribute = doc.CreateAttribute("node");
				xmlAttribute.Value = _rules[i].Node;
				xmlElement2.Attributes.Append(xmlAttribute);
				xmlAttribute = doc.CreateAttribute("passed");
				xmlAttribute.Value = _rules[i].PassCount.ToString();
				xmlElement2.Attributes.Append(xmlAttribute);
				xmlAttribute = doc.CreateAttribute("failed");
				xmlAttribute.Value = _rules[i].FailCount.ToString();
				xmlElement2.Attributes.Append(xmlAttribute);
				xmlAttribute = doc.CreateAttribute("note");
				xmlAttribute.Value = _rules[i].Note;
				xmlElement2.Attributes.Append(xmlAttribute);
				xmlElement.AppendChild(xmlElement2);
			}
		}
		doc.DocumentElement.AppendChild(xmlElement);
	}
}
internal class RuleItem
{
	public string FileName { get; set; }

	public string Node { get; set; }

	public string Type { get; set; }

	public string Detail { get; set; }

	public string Note { get; set; }

	public bool Enabled { get; set; }

	public bool ExactRule { get; set; }

	public int PassCount { get; set; }

	public int FailCount { get; set; }
}
public sealed class ItemComparer : IComparer
{
	int IComparer.Compare(object x, object y)
	{
		if (((RuleItem)x).Type == "~~" && ((RuleItem)y).Type != "~~")
		{
			return 1;
		}
		if (((RuleItem)x).Type != "~~" && ((RuleItem)y).Type == "~~")
		{
			return -1;
		}
		return 0;
	}
}
