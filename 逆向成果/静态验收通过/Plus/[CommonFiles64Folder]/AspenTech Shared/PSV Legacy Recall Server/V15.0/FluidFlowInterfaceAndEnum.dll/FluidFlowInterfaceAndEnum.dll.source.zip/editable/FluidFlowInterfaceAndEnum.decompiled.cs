using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using AspenTech.Hydraulics.Data;
using AspenTech.Hydraulics.PropertyUtilities;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("Aspen Hydraulics")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2024")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\..\\..\\packages\\AspenTech.StrongName.SNK.1.0.0\\content\\AspenTech.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyFileVersion("41.0.0.97")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace AspenTech.Hydraulics.FluidFlowInterfaceAndEnum;

public interface IFluidFlow
{
	IFlowStream FlowStream { get; set; }

	IPhysicalPropertyPackage PPPOfFluid { get; set; }
}
public interface IPipeFlow : IFluidFlow
{
	RealProperty Diameter { get; set; }

	RealProperty InclinedAngle { get; set; }

	RealProperty Roughness { get; set; }

	RealProperty VoidFraction { get; }

	RealProperty PGradient { get; }

	BooleanProperty IsChoked { get; set; }

	FlowRegimeEnum FlowRegime { get; }

	FlowRegimeMethodEnum FlowRegimeMethod { get; set; }

	VoidFractionMethodEnum VoidFractionMethod { get; set; }

	PressureGradientMethodEnum PressureGradientMethod { get; set; }

	double CalculateVoidFraction(IFlowStream stream, double diam, double inclinedAngle, double roughness, VoidFractionMethodEnum method);

	double CalculateDP_DLInPipe(IFlowStream stream, double diam, double inclinedAngle, double roughness, VoidFractionMethodEnum method, PressureGradientMethodEnum pgcor, ref bool isChoked);

	FlowRegimeEnum EstimateFlowPattern(IFlowStream stream, double diam, double inclinedAngle, FlowRegimeMethodEnum method);
}
public enum FlowRegimeEnum
{
	Vapour = -2,
	Liquid,
	DispersedBubble,
	ElongatedBubble,
	Bubble,
	Plug,
	Slug,
	Churn,
	Stratified,
	Wavy,
	Annular,
	AnnularMist,
	Mist,
	Intermittent,
	Segregated,
	Distributed,
	Transition,
	Unknown
}
public enum FlowRegimeMethodEnum
{
	None = -32767,
	Default = -1,
	BeggsAndBrill = 0,
	DunsAndRos = 1,
	AzizGovierFogarasi = 2,
	Orkiszewski = 3,
	Mandhane = 4,
	TulsaUnified2P = 5,
	TulsaUnified3P = 6
}
public enum VoidFractionMethodEnum
{
	None = -32767,
	Default = -1,
	Homogeneous = 0,
	HTFS = 1,
	DunsAndRos = 2,
	HagedornAndBrown = 3,
	BeggsAndBrill = 4
}
public enum PressureGradientMethodEnum
{
	None = -32767,
	Default = -1,
	Homogeneous = 0,
	DunsAndRos = 1,
	HagedornAndBrown = 2,
	BeggsAndBrill = 3,
	Crane = 4,
	HTFS = 5,
	AzizGovierFogarasi = 6,
	Orkiszewski = 7,
	LockhartMartinelli = 8,
	GregoryAzizMandane = 9,
	Dukler = 10,
	TulsaUnified2P = 11,
	TulsaUnified3P = 12
}
public enum LiquidHoldUpMethodEnum
{
	None = -32767,
	Homogeneous = 0,
	HTFS = 1,
	DunsAndRos = 2,
	HagedornAndBrown = 3,
	BeggsAndBrill = 4,
	AzizGovierFogarasi = 5,
	Orkiszewski = 6,
	Dukler = 7,
	Martinelli = 8,
	CraneFitting = 9,
	TulsaUnified2P = 10,
	TulsaUnified3P = 11,
	Flanagan = 12
}
public enum FrictionFactorMethodEnum
{
	Chen,
	Churchill,
	Round,
	Moody
}
public enum StaticHeadContributionEnum
{
	Include,
	IgnoreDownhill,
	Ignore
}
public enum AccelerationPressureMethodEnum
{
	Ignore,
	Include,
	Homogeneous
}
public interface IPressureGradientCorrelation
{
	double UsedFrictionFactor { get; }

	double UsedReynoldsNumber { get; }

	double Diameter { set; }

	double PipeLength { set; }

	double InclinedAngle { set; }

	double Roughness { set; }

	IFlowStream FlowStream { set; }

	double CalculateFrictionPressureGradient(ILiquidHoldUpCorrelation liqHoldCorr, IFlowRegimeCorrelation flowRegCorr);

	double CalculateFrictionPressureGradient(ILiquidHoldUpCorrelation liqHoldCorr, FlowRegimeEnum pattern);

	double CalculateGravitationalPressureGradient(ILiquidHoldUpCorrelation liqHoldCorr, IFlowRegimeCorrelation flowRegCorr);

	double CalculateGravitationalPressureGradient(ILiquidHoldUpCorrelation liqHoldCorr, FlowRegimeEnum pattern);

	double CalculateAccelerationPressureGradient(ILiquidHoldUpCorrelation liqHoldCorr, IFlowRegimeCorrelation flowRegCorr);

	double CalculateAccelerationPressureGradient(ILiquidHoldUpCorrelation liqHoldCorr, FlowRegimeEnum pattern);

	bool AccountsForAcceleration();
}
public interface ILiquidHoldUpCorrelation
{
	double Diameter { set; }

	double PipeLength { set; }

	double InclinedAngle { set; }

	double Roughness { set; }

	IFlowStream FlowStream { set; }

	double CalculateLiquidHoldUp(IFlowRegimeCorrelation flowRegCorr);

	double CalculateLiquidHoldUp(FlowRegimeEnum pattern);

	double CalculateWaterHoldUp();

	double CalculateOverallDensity(IFlowRegimeCorrelation flowRegCorr);

	double CalculateOverallDensity(FlowRegimeEnum pattern);

	double CalculateEquivalentDensity(IFlowRegimeCorrelation flowRegCorr);

	double CalculateEquivalentDensity(FlowRegimeEnum pattern);
}
public interface IFlowRegimeCorrelation
{
	double Diameter { set; }

	double PipeLength { set; }

	double InclinedAngle { set; }

	double Roughness { set; }

	IFlowStream FlowStream { set; }

	FlowRegimeEnum EstimateFlowPattern();

	FlowRegimeEnum EstimateWaterFlowPattern();
}
public interface IFrictionFactorCorrelation
{
	double CalculateKFactor();
}
public interface IEquivalentLengthCorrelation
{
	double CalculateEquivalentLength();
}
public interface ICorrelationManager
{
	IFlowStream FlowStream { set; }

	double CalculatePressureGradient();

	double CalculateFrictionalPressureGradient();

	double CalculateGravitationalPressureGradient();

	double CalculateAccelerationPressureGradient();

	double CalculateOverallDensity();

	double CalculateEquivalentDensity();

	bool PressureGradientAccountsForAcceleration();
}
public interface IPipeFlowCorrelation
{
	string Name { get; }

	IFlowRegimeCorrelation FlowRegimeCorrelation { get; }

	ILiquidHoldUpCorrelation LiquidHoldUpCorrelation { get; }

	IPressureGradientCorrelation PressureGradientCorrelation { get; }
}
public interface IHeatTransferCoeffCorrelation
{
	double CalculateHTC();
}
