using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using AHResources;
using AspenTech.Hydraulics.FluidFlowInterfaceAndEnum;
using AspenTech.Hydraulics.HTFSMethodLib;
using AspenTech.Hydraulics.PropertyUtilities;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyCompany("Aspen Technology, Inc.")]
[assembly: AssemblyProduct("Aspen Hydraulics")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology, Inc. 2024")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\..\\..\\packages\\AspenTech.StrongName.SNK.1.0.0\\content\\AspenTech.snk")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyFileVersion("41.0.0.97")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace AspenTech.Hydraulics.PipeFlowMethodLib;

public class PipeFlow
{
	public static double FrictionFactorOfFanning(double Re, double RelativeRoughness)
	{
		double num = 3.6;
		double num2 = 6.9;
		double num3 = 3.7;
		double y = 1.11;
		double num4 = 0.0;
		try
		{
			num4 = num * Math.Log10(num2 / Re + Math.Pow(RelativeRoughness / num3, y));
			return 1.0 / (num4 * num4);
		}
		catch (Exception innerException)
		{
			throw new Exception(string.Format(Resources.MethodFailed, "FrictionFactorOfFanning"), innerException);
		}
	}

	public static double FrictionFactorOfMoody(double Re, double RelativeRoughness)
	{
		double v0;
		double v1;
		double v2;
		double v3;
		try
		{
			if (Re != 0.0) goto Step001c;
			return 0.0;
			Step001c:
			v0 = (16.0 / Re);
			ref double spill0027 = ref v0;
			v1 = (((5.68e-09 * Re) * Re) * 0.25);
			ref double spill003f = ref v1;
			v2 = Math.Pow((1.73736 * Math.Log((1.0 / (Math.Pow((7.0 / Re), 0.9) + (0.27 * RelativeRoughness))))), -2.0);
			ref double spill008c = ref v2;
			v3 = Math.Pow((Math.Pow(Math.Pow((Math.Pow(v1, -8.0) + Math.Pow(v2, -8.0)), -0.125), 12.0) + Math.Pow(v0, 12.0)), 0.08333333333333333);
			ref double spill00e6 = ref v3;
			return v3;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "FrictionFactorOfMoody"), innerException);
		}
	}

	public static double DPaDzCorrection(double MeanVelocity, double Vsg, double density, double pressure)
	{
		double num = 0.0;
		try
		{
			num = MeanVelocity * Vsg * density / pressure;
			if (num >= 1.0)
			{
				return RealValue.FEMPTY;
			}
			return 1.0 - num;
		}
		catch (Exception innerException)
		{
			throw new Exception(string.Format(Resources.MethodFailed, "DPaDzCorrection"), innerException);
		}
	}

	public static double VoidFactionOfHomogeneousFlow(IFlowStream stream)
	{
		try
		{
			if (stream.NumberOfPhases == 1)
			{
				if (stream.GetPhaseByID(1).PhaseType == PhaseType.Liquid)
				{
					return 0.0;
				}
				return 1.0;
			}
			return TwoPhaseFlow.VoidFractionInPipe(stream.CombinedLiquidPhase.Density.Value, stream.GetPhaseByType(PhaseType.Vapour).Density.Value, stream.GetPhaseByType(PhaseType.Vapour).MassFraction.Value, 1.0);
		}
		catch (Exception innerException)
		{
			throw new Exception(string.Format(Resources.MethodFailed, "VoidFractionOfHomogeneousFlow"), innerException);
		}
	}

	public static double VoidFactionOfHTFS(IFlowStream stream, double diam, double angle)
	{
		double v0;
		double v1;
		IPhase v2;
		IPhase v3;
		double v4;
		v0 = 0.0;
		ref double spill0009 = ref v0;
		v1 = 0.0;
		ref double spill0013 = ref v1;
		v2 = null;
		ref IPhase spill0015 = ref v2;
		v3 = null;
		ref IPhase spill0017 = ref v3;
		v4 = 0.0;
		ref double spill0021 = ref v4;
		try
		{
			if (stream.NumberOfPhases != 1) goto Step005b;
			if (stream.GetPhaseByID(1).PhaseType != (PhaseType)4) goto Step004b;
			return 0.0;
			Step004b:
			return 1.0;
			Step005b:
			v0 = HTFSUtility.FlowArea(diam);
			ref double spill0061 = ref v0;
			v1 = HTFSUtility.CalculateMassFlux(stream.MassFlowrate.Value, v0);
			ref double spill0073 = ref v1;
			v2 = stream.CombinedLiquidPhase;
			ref IPhase spill007a = ref v2;
			v3 = stream.GetPhaseByType((PhaseType)3);
			ref IPhase spill0082 = ref v3;
			v4 = TwoPhaseFlow.HTFSVoidFraction(v1, v3.MassFraction.Value, v2.Density.Value, v3.Density.Value, v2.Viscosity.Value, v3.Viscosity.Value, angle);
			ref double spill00c1 = ref v4;
			return v4;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "VoidFractionOfHTFS"), innerException);
		}
	}

	internal double DunsAndRosL1Fun(double pnd)
	{
		double v0;
		double v1;
		double v2;
		double v3;
		double v4;
		v0 = 30.0;
		ref double spill0009 = ref v0;
		v1 = 62.0;
		ref double spill0013 = ref v1;
		v2 = 1.01;
		ref double spill001d = ref v2;
		v3 = 1.99;
		ref double spill0027 = ref v3;
		v4 = 0.0;
		ref double spill0031 = ref v4;
		try
		{
			if (!(pnd < v0)) goto Step003c;
			v4 = v3;
			ref double spill0038 = ref v4;
			goto Step005e;
			Step003c:
			if (!(pnd > v1)) goto Step0045;
			v4 = v2;
			ref double spill0041 = ref v4;
			goto Step005e;
			Step0045:
			v4 = (v2 + ((Math.Log10((v1 / pnd)) * (v3 - v2)) / Math.Log10((v1 / v0))));
			ref double spill005c = ref v4;
			Step005e:
			return v4;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "DunsAndRosL1Fun"), innerException);
		}
	}

	internal double DunsAndRosL2Fun(double pnd)
	{
		double v0;
		double v1;
		double v2;
		double v3;
		double v4;
		v0 = 62.0;
		ref double spill0009 = ref v0;
		v1 = 1.1;
		ref double spill0013 = ref v1;
		v2 = 0.2;
		ref double spill001d = ref v2;
		v3 = 0.96;
		ref double spill0027 = ref v3;
		v4 = 0.0;
		ref double spill0031 = ref v4;
		try
		{
			if (!(pnd > v0)) goto Step003c;
			v4 = v1;
			ref double spill0038 = ref v4;
			goto Step0054;
			Step003c:
			v4 = (v1 + (v3 * Math.Log10((pnd / v0))));
			ref double spill0048 = ref v4;
			v4 = Math.Max(v2, v4);
			ref double spill0052 = ref v4;
			Step0054:
			return v4;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "DunsAndRosL2Fun"), innerException);
		}
	}

	internal double DunsAndRosL3Fun(double pnle)
	{
		double v0;
		double v1;
		double v2;
		double v3;
		double v4;
		double v5;
		double v6;
		v0 = 3.0;
		ref double spill0009 = ref v0;
		v1 = -2.69;
		ref double spill0013 = ref v1;
		v2 = -0.096;
		ref double spill001d = ref v2;
		v3 = 0.662;
		ref double spill0027 = ref v3;
		try
		{
			v4 = Math.Log10(pnle);
			ref double spill002e = ref v4;
			v5 = (v2 + ((v3 - v2) * Math.Exp(((-v0) * (v4 - v1)))));
			ref double spill0042 = ref v5;
			v6 = Math.Pow(10.0, v5);
			ref double spill0054 = ref v6;
			return v6;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "DunsAndRosL3Fun"), innerException);
		}
	}

	internal double DunsAndRosL4Fun(double pnd)
	{
		double v0;
		double v1;
		double v2;
		double v3;
		double v4;
		double v5;
		double v6;
		double v7;
		v0 = -2.55;
		ref double spill0009 = ref v0;
		v1 = 5.43;
		ref double spill0013 = ref v1;
		v2 = -1.79;
		ref double spill001d = ref v2;
		v3 = ((-0.5 * v1) / v0);
		ref double spill002b = ref v3;
		v4 = 1.61;
		ref double spill0035 = ref v4;
		try
		{
			v5 = Math.Log10(pnd);
			ref double spill003d = ref v5;
			v5 = Math.Min(v4, Math.Max(v3, v5));
			ref double spill004e = ref v5;
			v6 = (v2 + (v5 * (v1 + (v5 * v0))));
			ref double spill005b = ref v6;
			v7 = Math.Pow(10.0, v6);
			ref double spill006d = ref v7;
			return v7;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "DunsAndRosL4Fun"), innerException);
		}
	}

	public static FlowRegimeEnum FlowRegimeOfBeggsAndBrill(IFlowStream stream, double diam, out double volumeFractionL, out double Fr, out double vm)
	{
		FlowRegimeEnum v0;
		double v1;
		double v2;
		double v3;
		double v4;
		double v5;
		double v6;
		IPhase v7;
		IPhase v8;
		v0 = (FlowRegimeEnum)(-1);
		ref FlowRegimeEnum spill0001 = ref v0;
		v5 = 0.0;
		ref double spill000b = ref v5;
		v6 = 0.0;
		ref double spill0016 = ref v6;
		v7 = null;
		ref IPhase spill0019 = ref v7;
		v8 = null;
		ref IPhase spill001c = ref v8;
		Fr = 0.0;
		volumeFractionL = 0.0;
		vm = 0.0;
		try
		{
			if (stream.NumberOfPhases >= 2) goto Step0067;
			if (stream.GetPhaseByID(1).PhaseType != (PhaseType)3) goto Step0060;
			v0 = (FlowRegimeEnum)(-2);
			ref FlowRegimeEnum spill005a = ref v0;
			goto Step01cf;
			Step0060:
			v0 = (FlowRegimeEnum)(-1);
			ref FlowRegimeEnum spill0061 = ref v0;
			goto Step01cf;
			Step0067:
			v7 = stream.CombinedLiquidPhase;
			ref IPhase spill006d = ref v7;
			v8 = stream.GetPhaseByType((PhaseType)3);
			ref IPhase spill0076 = ref v8;
			v5 = ((stream.MassFlowrate.Value * (1.0 - v8.MassFraction.Value)) / v7.Density.Value);
			ref double spill00a7 = ref v5;
			v6 = ((stream.MassFlowrate.Value * v8.MassFraction.Value) / v8.Density.Value);
			ref double spill00ce = ref v6;
			volumeFractionL = (v5 / (v5 + v6));
			vm = ((v5 + v6) / (((3.141592653589793 * diam) * diam) * 0.25));
			Fr = ((vm * vm) / (9.80665 * diam));
			PipeFlow.LConstantsOfBeggsAndBrill(volumeFractionL, out v1, out v2, out v3, out v4);
			if (!(volumeFractionL < 0.01)) goto Step0130;
			if (Fr < v1) goto Step0142;
			Step0130:
			if (!(volumeFractionL >= 0.01)) goto Step014a;
			if (!(Fr < v2)) goto Step014a;
			Step0142:
			v0 = (FlowRegimeEnum)(12);
			ref FlowRegimeEnum spill0144 = ref v0;
			goto Step01cf;
			Step014a:
			if (!(volumeFractionL >= 0.01)) goto Step0166;
			if (!(v2 <= Fr)) goto Step0166;
			if (!(Fr <= v3)) goto Step0166;
			v0 = (FlowRegimeEnum)(14);
			ref FlowRegimeEnum spill0163 = ref v0;
			goto Step01cf;
			Step0166:
			if (!(0.01 <= volumeFractionL)) goto Step018a;
			if (!(volumeFractionL < 0.4)) goto Step018a;
			if (!(v3 < Fr)) goto Step018a;
			if (Fr <= v1) goto Step01a2;
			Step018a:
			if (!(volumeFractionL >= 0.4)) goto Step01a7;
			if (!(v3 < Fr)) goto Step01a7;
			if (!(Fr <= v4)) goto Step01a7;
			Step01a2:
			v0 = (FlowRegimeEnum)(11);
			ref FlowRegimeEnum spill01a4 = ref v0;
			goto Step01cf;
			Step01a7:
			if (!(volumeFractionL < 0.4)) goto Step01b9;
			if (Fr >= v1) goto Step01cc;
			Step01b9:
			if (!(volumeFractionL >= 0.4)) goto Step01cf;
			if (!(Fr > v4)) goto Step01cf;
			Step01cc:
			v0 = (FlowRegimeEnum)(13);
			ref FlowRegimeEnum spill01ce = ref v0;
			Step01cf:
			return v0;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "FlowRegimeOfBeggsAndBrill"), innerException);
		}
	}

	internal static void LConstantsOfBeggsAndBrill(double volumeFractionL, out double L1, out double L2, out double L3, out double L4)
	{
		L1 = 316.0 * Math.Pow(volumeFractionL, 0.302);
		L2 = 0.000925 * Math.Pow(volumeFractionL, -2.468);
		L3 = 0.1 * Math.Pow(volumeFractionL, -1.452);
		L4 = 0.5 * Math.Pow(volumeFractionL, -6.738);
	}

	internal static double CConstanOfBeggsAndBrill(double volumeFractionL, double Nlv, double Fr, FlowRegimeEnum pattern, double angle)
	{
		double v0;
		v0 = 0.0;
		ref double spill0009 = ref v0;
		try
		{
			if (!(angle >= 0.0)) goto Step0106;
			switch (pattern)
			{
				case (FlowRegimeEnum)0: goto Step00fa;
				case (FlowRegimeEnum)1: goto Step00fa;
				case (FlowRegimeEnum)2: goto Step00fa;
				case (FlowRegimeEnum)3: goto Step00ad;
				case (FlowRegimeEnum)4: goto Step00ad;
				case (FlowRegimeEnum)5: goto Step00fa;
				case (FlowRegimeEnum)6: goto Step005d;
				case (FlowRegimeEnum)7: goto Step005d;
				case (FlowRegimeEnum)8: goto Step005d;
				case (FlowRegimeEnum)9: goto Step00fa;
				case (FlowRegimeEnum)10: goto Step00fa;
				case (FlowRegimeEnum)11: goto Step00ad;
				case (FlowRegimeEnum)12: goto Step005d;
				case (FlowRegimeEnum)13: goto Step00fa;
			}
			goto Step00fa;
			Step005d:
			v0 = ((1.0 - volumeFractionL) * Math.Log((((0.011 * Math.Pow(volumeFractionL, -3.768)) * Math.Pow(Nlv, 3.539)) * Math.Pow(Fr, -1.614))));
			ref double spill00a7 = ref v0;
			goto Step0151;
			Step00ad:
			v0 = ((1.0 - volumeFractionL) * Math.Log((((2.96 * Math.Pow(volumeFractionL, 0.305)) * Math.Pow(Nlv, -0.4473)) * Math.Pow(Fr, 0.0978))));
			ref double spill00f7 = ref v0;
			goto Step0151;
			Step00fa:
			v0 = 0.0;
			ref double spill0103 = ref v0;
			goto Step0151;
			Step0106:
			v0 = ((1.0 - volumeFractionL) * Math.Log((((4.7 * Math.Pow(volumeFractionL, -0.3692)) * Math.Pow(Nlv, 0.1244)) * Math.Pow(Fr, -0.5056))));
			ref double spill0150 = ref v0;
			Step0151:
			if (!(v0 < 0.0)) goto Step0167;
			v0 = 0.0;
			ref double spill0166 = ref v0;
			Step0167:
			return v0;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "CConstantOfBeggsAndBrill"), innerException);
		}
	}

	internal static double HoldupOfBeggsAndBrillForHorizontalPipe(double volumeFractionL, double Fr, FlowRegimeEnum pattern)
	{
		double v0;
		try
		{
			switch (pattern)
			{
				case (FlowRegimeEnum)0: goto Step0098;
				case (FlowRegimeEnum)1: goto Step0098;
				case (FlowRegimeEnum)2: goto Step0098;
				case (FlowRegimeEnum)3: goto Step006c;
				case (FlowRegimeEnum)4: goto Step006c;
				case (FlowRegimeEnum)5: goto Step0098;
				case (FlowRegimeEnum)6: goto Step0040;
				case (FlowRegimeEnum)7: goto Step0040;
				case (FlowRegimeEnum)8: goto Step0040;
				case (FlowRegimeEnum)9: goto Step0098;
				case (FlowRegimeEnum)10: goto Step0098;
				case (FlowRegimeEnum)11: goto Step006c;
				case (FlowRegimeEnum)12: goto Step0040;
				case (FlowRegimeEnum)13: goto Step0098;
			}
			goto Step0098;
			Step0040:
			v0 = ((0.98 * Math.Pow(volumeFractionL, 0.4846)) / Math.Pow(Fr, 0.0868));
			ref double spill0069 = ref v0;
			goto Step00c2;
			Step006c:
			v0 = ((0.845 * Math.Pow(volumeFractionL, 0.5351)) / Math.Pow(Fr, 0.0173));
			ref double spill0095 = ref v0;
			goto Step00c2;
			Step0098:
			v0 = ((1.065 * Math.Pow(volumeFractionL, 0.5824)) / Math.Pow(Fr, 0.0609));
			ref double spill00c1 = ref v0;
			Step00c2:
			return v0;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "HoldupOfBeggsAndBrillForHorizontalPipe"), innerException);
		}
	}

	public static double VoidFractionOfBeggsAndBrill(IFlowStream stream, double diam, double angle)
	{
		double v0;
		double v1;
		double v2;
		double v3;
		double v4;
		double v5;
		double v6;
		FlowRegimeEnum v7;
		IPhase v8;
		IPhase v9;
		double v10;
		double v11;
		double v12;
		double v13;
		double v14;
		double v15;
		double v16;
		double v17;
		double v18;
		double v19;
		double v20;
		v8 = null;
		ref IPhase spill0001 = ref v8;
		v9 = null;
		ref IPhase spill0004 = ref v9;
		v10 = 0.0;
		ref double spill000f = ref v10;
		v11 = 0.0;
		ref double spill001a = ref v11;
		v12 = 0.0;
		ref double spill0025 = ref v12;
		v13 = 0.0;
		ref double spill0030 = ref v13;
		v14 = 0.0;
		ref double spill003b = ref v14;
		try
		{
			if (stream.NumberOfPhases >= 2) goto Step0075;
			if (stream.GetPhaseByID(1).PhaseType != (PhaseType)3) goto Step0065;
			v10 = 1.0;
			ref double spill005e = ref v10;
			goto Step02e1;
			Step0065:
			v10 = 0.0;
			ref double spill006e = ref v10;
			goto Step02e1;
			Step0075:
			v8 = stream.CombinedLiquidPhase;
			ref IPhase spill007b = ref v8;
			v9 = stream.GetPhaseByType((PhaseType)3);
			ref IPhase spill0084 = ref v9;
			v14 = (((stream.MassFlowrate.Value * (1.0 - v9.MassFraction.Value)) / v8.Density.Value) / ((0.7853981633974483 * diam) * diam));
			ref double spill00c3 = ref v14;
			v13 = (v14 * Math.Pow((v8.Density.Value / (9.80665 * v8.SurfaceTension.Value)), 0.25));
			ref double spill00f9 = ref v13;
			v7 = PipeFlow.FlowRegimeOfBeggsAndBrill(stream, diam, out v5, out v4, out v6);
			ref FlowRegimeEnum spill0108 = ref v7;
			PipeFlow.LConstantsOfBeggsAndBrill(v5, out v0, out v1, out v2, out v3);
			v15 = ((v2 - v4) / (v2 - v1));
			ref double spill0121 = ref v15;
			if (v7 != (FlowRegimeEnum)14) goto Step0221;
			v16 = PipeFlow.CConstanOfBeggsAndBrill(v5, v13, v4, (FlowRegimeEnum)12, angle);
			ref double spill013a = ref v16;
			v17 = PipeFlow.HoldupOfBeggsAndBrillForHorizontalPipe(v5, v4, (FlowRegimeEnum)12);
			ref double spill0147 = ref v17;
			v18 = PipeFlow.CConstanOfBeggsAndBrill(v5, v13, v4, (FlowRegimeEnum)11, angle);
			ref double spill0157 = ref v18;
			v19 = PipeFlow.HoldupOfBeggsAndBrillForHorizontalPipe(v5, v4, (FlowRegimeEnum)11);
			ref double spill0164 = ref v19;
			v12 = (((v15 * v17) * (1.0 + (v16 * (Math.Sin(HTFSUtility.DegreesToRads((1.8 * angle))) - (0.333 * Math.Pow(Math.Sin(HTFSUtility.DegreesToRads((1.8 * angle))), 3.0)))))) + (((1.0 - v15) * v19) * (1.0 + (v18 * (Math.Sin(HTFSUtility.DegreesToRads((1.8 * angle))) - (0.333 * Math.Pow(Math.Sin(HTFSUtility.DegreesToRads((1.8 * angle))), 3.0)))))));
			ref double spill021d = ref v12;
			goto Step0293;
			Step0221:
			v11 = PipeFlow.HoldupOfBeggsAndBrillForHorizontalPipe(v5, v4, v7);
			ref double spill022c = ref v11;
			v20 = PipeFlow.CConstanOfBeggsAndBrill(v5, v13, v4, v7, angle);
			ref double spill023c = ref v20;
			v12 = (v11 * (1.0 + (v20 * (Math.Sin(HTFSUtility.DegreesToRads((1.8 * angle))) - (0.333 * Math.Pow(Math.Sin(HTFSUtility.DegreesToRads((1.8 * angle))), 3.0))))));
			ref double spill0291 = ref v12;
			Step0293:
			if (!(angle > 0.0)) goto Step02b9;
			v12 = (v12 * 0.924);
			ref double spill02ab = ref v12;
			if (!(v12 < v5)) goto Step02d3;
			v12 = v5;
			ref double spill02b5 = ref v12;
			goto Step02d3;
			Step02b9:
			if (!(angle < 0.0)) goto Step02d3;
			v12 = (v12 * 0.685);
			ref double spill02d1 = ref v12;
			Step02d3:
			v10 = (1.0 - v12);
			ref double spill02df = ref v10;
			Step02e1:
			return v10;
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "VoidFractionOfBeggsAndBrill"), innerException);
		}
	}

	public static double PressreGradientOfBeggsAndBrill(IFlowStream stream, double diam, double angle, double roughness)
	{
		double v0;
		FlowRegimeEnum v1;
		double v2;
		double v3;
		double v4;
		IPhase v5;
		IPhase v6;
		double v7;
		double v8;
		double v9;
		double v10;
		double v11;
		double v12;
		double v13;
		double v14;
		double v15;
		double v16;
		double v17;
		double v18;
		double v19;
		v0 = 0.0;
		ref double spill0009 = ref v0;
		v5 = null;
		ref IPhase spill000b = ref v5;
		v6 = null;
		ref IPhase spill000e = ref v6;
		v7 = 0.0;
		ref double spill0019 = ref v7;
		v8 = 0.0;
		ref double spill0024 = ref v8;
		v9 = 0.0;
		ref double spill002f = ref v9;
		v10 = 0.0;
		ref double spill003a = ref v10;
		v11 = 0.0;
		ref double spill0045 = ref v11;
		v12 = 0.0;
		ref double spill0050 = ref v12;
		v13 = 0.0;
		ref double spill005b = ref v13;
		v14 = 0.0;
		ref double spill0066 = ref v14;
		v15 = 0.0;
		ref double spill0071 = ref v15;
		v16 = 0.0;
		ref double spill007c = ref v16;
		v17 = 0.0;
		ref double spill0087 = ref v17;
		v18 = 0.0;
		ref double spill0092 = ref v18;
		try
		{
			v1 = PipeFlow.FlowRegimeOfBeggsAndBrill(stream, diam, out v3, out v2, out v4);
			ref FlowRegimeEnum spill00a1 = ref v1;
			v0 = (1.0 - PipeFlow.VoidFractionOfBeggsAndBrill(stream, diam, angle));
			ref double spill00b4 = ref v0;
			v9 = (v3 / (v0 * v0));
			ref double spill00ba = ref v9;
			if (v9 != 1.0) goto Step00d9;
			v14 = 0.0;
			ref double spill00d2 = ref v14;
			goto Step0161;
			Step00d9:
			if (!(v9 > 1.0)) goto Step0112;
			if (!(v9 < 1.2)) goto Step0112;
			v14 = Math.Log(((2.2 * v9) - 1.2));
			ref double spill010e = ref v14;
			goto Step0161;
			Step0112:
			v19 = Math.Log(v9);
			ref double spill0119 = ref v19;
			v14 = (v19 / (((-0.0523 + (3.182 * v19)) - ((0.8725 * v19) * v19)) + (0.01853 * Math.Pow(v19, 4.0))));
			ref double spill015f = ref v14;
			Step0161:
			v13 = Math.Exp(v14);
			ref double spill0168 = ref v13;
			v5 = stream.CombinedLiquidPhase;
			ref IPhase spill0170 = ref v5;
			v6 = stream.GetPhaseByType((PhaseType)3);
			ref IPhase spill0179 = ref v6;
			v7 = ((v5.Density.Value * v3) + (v6.Density.Value * (1.0 - v3)));
			ref double spill01a2 = ref v7;
			v8 = ((v5.Density.Value * v0) + (v6.Density.Value * (1.0 - v0)));
			ref double spill01cb = ref v8;
			v16 = ((v5.Viscosity.Value * v3) + (v6.Viscosity.Value * (1.0 - v3)));
			ref double spill01f4 = ref v16;
			v10 = (((v7 * v4) * diam) / v16);
			ref double spill0200 = ref v10;
			v12 = PipeFlow.FrictionFactorOfMoody(v10, (roughness / diam));
			ref double spill020c = ref v12;
			v11 = (v12 * v13);
			ref double spill0213 = ref v11;
			v17 = ((stream.MassFlowrate.Value * v6.MassFraction.Value) / ((((v6.Density.Value * 0.25) * 3.141592653589793) * diam) * diam));
			ref double spill0252 = ref v17;
			v15 = (((v4 * v17) * v7) / v5.Pressure.Value);
			ref double spill0269 = ref v15;
			v18 = (((((((2.0 * v11) * v7) * v4) * v4) / diam) + ((v8 * 9.80665) * Math.Sin(HTFSUtility.DegreesToRads(angle)))) / (1.0 - v15));
			ref double spill02a8 = ref v18;
			return (-v18);
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "PressureGradientOfBeggsAndBrill"), innerException);
		}
	}

	public static double PressreGradientOfSinglePhaseFlow(IFlowStream stream, double diam, double angle, double roughness)
	{
		IPhase v0;
		double v1;
		double v2;
		double v3;
		double v4;
		v0 = null;
		ref IPhase spill0001 = ref v0;
		v1 = 0.0;
		ref double spill000b = ref v1;
		v2 = 0.0;
		ref double spill0015 = ref v2;
		v3 = 0.0;
		ref double spill001f = ref v3;
		v4 = 0.0;
		ref double spill0029 = ref v4;
		try
		{
			v0 = stream.GetPhaseByID(1);
			ref IPhase spill0032 = ref v0;
			v1 = (stream.MassFlowrate.Value / HTFSUtility.FlowArea(diam));
			ref double spill0045 = ref v1;
			v2 = SinglePhaseFlow.ReynoldsNumber(v1, diam, v0.Viscosity.Value);
			ref double spill0058 = ref v2;
			v3 = PipeFlow.FrictionfactorOfChurchill(v2, (roughness / diam));
			ref double spill0062 = ref v3;
			v4 = (((((2.0 * v3) * v1) * v1) / (v0.Density.Value * diam)) + ((v0.Density.Value * 9.80665) * Math.Sin(HTFSUtility.DegreesToRads(angle))));
			ref double spill00a2 = ref v4;
			return (-v4);
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "PressreGradientOfSinglePhaseFlow"), innerException);
		}
	}

	public static double FrictionPressureGradientOfSinglePhaseFlow(IFlowStream stream, double diam, double roughness)
	{
		IPhase v0;
		double v1;
		double v2;
		double v3;
		double v4;
		v0 = null;
		ref IPhase spill0001 = ref v0;
		v1 = 0.0;
		ref double spill000b = ref v1;
		v2 = 0.0;
		ref double spill0015 = ref v2;
		v3 = 0.0;
		ref double spill001f = ref v3;
		v4 = 0.0;
		ref double spill0029 = ref v4;
		try
		{
			v0 = stream.GetPhaseByID(1);
			ref IPhase spill0032 = ref v0;
			v1 = (stream.MassFlowrate.Value / HTFSUtility.FlowArea(diam));
			ref double spill0045 = ref v1;
			v2 = SinglePhaseFlow.ReynoldsNumber(v1, diam, v0.Viscosity.Value);
			ref double spill0058 = ref v2;
			v3 = PipeFlow.FrictionfactorOfChurchill(v2, (roughness / diam));
			ref double spill0062 = ref v3;
			v3 = PipeFlow.FrictionFactorOfMoody(v2, (roughness / diam));
			ref double spill006c = ref v3;
			v4 = ((((2.0 * v3) * v1) * v1) / (v0.Density.Value * diam));
			ref double spill008a = ref v4;
			return (-v4);
		}
		catch (Exception innerException)
		{
			throw new Exception(String.Format(Resources.MethodFailed, "FrictionPressureGradientOfSinglePhaseFlow"), innerException);
		}
	}

	public static double FrictionfactorOfChurchill(double Re, double ed)
	{
		double y = 16.0;
		double num = 12.0;
		try
		{
			double num2 = Math.Pow(7.0 / Re, 0.9) + 0.27 * ed;
			double num3 = Math.Pow(37530.0 / Re, y);
			double num4 = Math.Pow(2.457 * Math.Log(1.0 / num2), y);
			double x = Math.Pow(8.0 / Re, num) + Math.Pow(num4 + num3, -1.5);
			return 2.0 * Math.Pow(x, 1.0 / num);
		}
		catch (Exception innerException)
		{
			throw new Exception(Resources.ChurchillCorrFailed, innerException);
		}
	}

	public static double aDPDZcorrection(double velocity, double density, double pressure)
	{
		double num = velocity * velocity * density / pressure;
		if (num >= 1.0 || num < 0.0)
		{
			return RealValue.FEMPTY;
		}
		return 1.0 - num;
	}

	public static void GetSupVelocities(IFlowStream stream, double diameter, ref double vsg, ref double vsl, ref double vm)
	{
		IPhase phaseByType = stream.GetPhaseByType(PhaseType.Vapour);
		IPhase combinedLiquidPhase = stream.CombinedLiquidPhase;
		double num = stream.MassFlowrate.Value / HTFSUtility.FlowArea(diameter);
		vsg = num * phaseByType.MassFraction.Value / phaseByType.Density.Value;
		vsl = num * combinedLiquidPhase.MassFraction.Value / combinedLiquidPhase.Density.Value;
		vm = vsg + vsl;
	}

	public static double GetWallisBubbleVelocity(IFlowStream stream, double diameter)
	{
		double v0;
		IPhase v1;
		IPhase v2;
		double v3;
		double v4;
		double v5;
		double v6;
		double v7;
		double v8;
		double v9;
		double v10;
		v0 = RealValue.FEMPTY;
		ref double spill0005 = ref v0;
		v1 = stream.CombinedLiquidPhase;
		ref IPhase spill000c = ref v1;
		v2 = stream.GetPhaseByType((PhaseType)3);
		ref IPhase spill0014 = ref v2;
		if (v1 == null) goto Step0027;
		if (v2 == null) goto Step0027;
		if (!(diameter <= 0.0)) goto Step0029;
		Step0027:
		return v0;
		Step0029:
		v3 = v1.Density.Value;
		ref double spill0034 = ref v3;
		v4 = v2.Density.Value;
		ref double spill0040 = ref v4;
		v5 = v1.SurfaceTension.Value;
		ref double spill004d = ref v5;
		v6 = v1.Viscosity.Value;
		ref double spill005a = ref v6;
		v7 = ((((9.80665 * diameter) * diameter) * (v3 - v4)) / v5);
		ref double spill0071 = ref v7;
		v8 = (Math.Sqrt((((((9.80665 * v3) * (v3 - v4)) * diameter) * diameter) * diameter)) / v6);
		ref double spill0091 = ref v8;
		v9 = 1.0;
		ref double spill009c = ref v9;
		if (!(v8 <= 18.0)) goto Step00b8;
		v9 = 2.5;
		ref double spill00b4 = ref v9;
		goto Step0108;
		Step00b8:
		if (!(v8 > 18.0)) goto Step00f0;
		if (!(v8 < 250.0)) goto Step00f0;
		v9 = (69.0 / Math.Pow(v8, 0.35));
		ref double spill00ec = ref v9;
		goto Step0108;
		Step00f0:
		if (!(v8 >= 250.0)) goto Step0108;
		v9 = 10.0;
		ref double spill0106 = ref v9;
		Step0108:
		v10 = ((0.345 * (1.0 - Math.Exp((-0.029 * v8)))) * (1.0 - Math.Exp(((3.37 - v7) / v9))));
		ref double spill014c = ref v10;
		v0 = ((((v10 * 9.80665) * diameter) * (v3 - v4)) / v3);
		ref double spill0163 = ref v0;
		return v0;
	}
}
