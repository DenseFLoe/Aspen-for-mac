"""Clean-room reproduction from the d1b62813 self-sufficient archive.

Usage: py -3 reproduce.py <archive.zip> <new-empty-dir>

Steps:
  1. extract the archive into <new-empty-dir>
  2. verify pinned toolchain (dotnet/csc) and reference assembly SHA-256 from build-plan.json
  3. compile editable/ with the archived relative compile.rsp -> compiled/AspenDataShareCS.dll
  4. require compiled SHA-256 == receipt.candidate_sha256 (source-rebuild check)
  5. replay the archived layout recipe with tools/ -> final image
  6. require final SHA-256 == receipt.sha256 and print equal true
Exit 0 only for a byte-identical original.
"""
import hashlib, json, subprocess, sys, zipfile
from pathlib import Path

DEPS = r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps"

def sha(b):
    return hashlib.sha256(b).hexdigest()

def main(archive, out):
    out = Path(out)
    if out.exists() and any(out.iterdir()):
        raise SystemExit("target dir not empty: " + str(out))
    out.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive) as z:
        z.extractall(out)
    receipt = json.loads((out / "receipt.json").read_text(encoding="utf-8"))
    plan = json.loads((out / "build-plan.json").read_text(encoding="utf-8"))
    name = plan["assembly_name"]

    for key in ("dotnet", "csc"):
        path = Path(plan["tool_path"][key])
        if not path.is_file() or sha(path.read_bytes()) != plan[key + "_sha256"]:
            raise SystemExit("pinned %s changed: %s" % (key, path))
    for path, pin in plan["references"].items():
        p = Path(path)
        if not p.is_file() or sha(p.read_bytes()) != pin:
            raise SystemExit("pinned reference changed: " + path)

    (out / "compiled").mkdir(exist_ok=True)
    p = subprocess.run([plan["tool_path"]["dotnet"], plan["tool_path"]["csc"], "/noconfig", "@compile.rsp"],
                       cwd=str(out), capture_output=True)
    compiled = out / "compiled" / name
    if p.returncode or not compiled.is_file():
        print((p.stdout + p.stderr).decode("utf-8", "replace")[-3000:])
        return 1
    csha = sha(compiled.read_bytes())
    print(json.dumps({"compiled_sha256": csha, "expected_candidate_sha256": receipt["candidate_sha256"],
                      "candidate_equal": csha == receipt["candidate_sha256"]}, indent=1))
    if csha != receipt["candidate_sha256"]:
        print("CANDIDATE MISMATCH: source rebuild is not the archived candidate")
        return 2

    sys.path[:0] = [str(out / "tools"), DEPS]
    import token_replay
    recipe = json.loads((out / "layout-recipe.json").read_text(encoding="utf-8"))
    ob = out / "original-build"
    def asset(n):
        q = ob / n
        return q.read_bytes() if q.is_file() else b""
    data = token_replay.reproduce(compiled.read_bytes(), recipe,
                                 asset("clr-metadata.bin"), asset("debug-record.bin"),
                                 asset("certificate-table.bin"),
                                 asset("strong-name.bin") if recipe.get("strong_name") else b"")
    final = sha(data)
    expected = receipt.get("sha256") or receipt["original_sha256"]
    equal = final == expected
    print(json.dumps({"final_sha256": final, "original_sha256": expected,
                      "equal": equal}, indent=1))
    return 0 if equal else 3

if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2]))
