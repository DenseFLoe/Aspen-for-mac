"""Compile the recovered C# source using the native Windows C# 5 compiler."""

import argparse
import hashlib
import json
from pathlib import Path
import subprocess


ASSEMBLY = "Microsoft.Practices.ServiceLocation.dll"
COMPILER_SHA256 = "adeda78a951529462f9411e016c1a1b87ddfd94c55912cbd2957817f39929af1"
REFERENCES = {
    "profile136": {
        "mscorlib.dll": "6d28da2c6ed3d50c0bd8a849db3e7794239a51d8854d9a179bef0c131bb52b02",
        "System.dll": "aabceb088c1070d373531c63c0028399458fa72a7e6b1f2c3d1233a966b6f1ed",
    },
    "net40": {
        "mscorlib.dll": "f7a62c9392d6762f5b46c76149173e2f265d6ad05aae54290ff40573ab32190e",
        "System.dll": "b6dc62e2437b39f48b5c3368e0d14f86cf00fbf0c76d2685026aafca7e9b50f7",
    },
}


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_input(path, expected):
    if not path.is_file():
        raise SystemExit(f"Required build dependency missing: {path}")
    actual = sha256(path)
    if actual != expected:
        raise SystemExit(f"Unexpected build dependency SHA-256: {path}\n"
                         f"expected {expected}\nactual   {actual}")
    return path


def quote(path):
    return f'"{path}"'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--csc", required=True, type=Path, help="Native x64 csc.exe 4.8.4161.0")
    parser.add_argument("--profile", required=True, choices=REFERENCES)
    parser.add_argument("--references", required=True, type=Path,
                        help="Directory containing the selected profile's reference assemblies")
    parser.add_argument("--out", required=True, type=Path, help="Empty or absent build directory")
    args = parser.parse_args()

    package = Path(__file__).resolve().parent
    resources = package / "resources"
    compiler = checked_input(args.csc.resolve(), COMPILER_SHA256)
    references = [checked_input(args.references.resolve() / name, expected)
                  for name, expected in REFERENCES[args.profile].items()]
    source = package / (ASSEMBLY + ".cs")
    output_dir = args.out.resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    if any(output_dir.iterdir()):
        raise SystemExit(f"Build directory must be empty: {output_dir}")

    assembly = output_dir / ASSEMBLY
    resource_name = "Microsoft.Practices.ServiceLocation.Properties.Resources.resources"
    flags = [
        "/nologo", "/utf8output", "/nostdlib+", "/optimize+", "/target:library",
        "/baseaddress:0x10000000", "/filealign:512", "/subsystemversion:4.00", "/langversion:5",
        "/out:" + quote(assembly),
        "/win32res:" + quote(resources / "original.res"),
        "/delaysign+",
        "/keyfile:" + quote(resources / "assembly-public-key.snk"),
        "/resource:" + quote(resources / resource_name) + "," + resource_name + ",public",
        *("/reference:" + quote(path) for path in references),
        quote(source),
    ]
    rsp = output_dir / "compile.rsp"
    rsp.write_text("\n".join(flags) + "\n", encoding="utf-8-sig")
    command = [str(compiler), "/noconfig", "@" + str(rsp)]
    compiled = subprocess.run(command, cwd=output_dir, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, check=False)
    (output_dir / "compile.log").write_bytes(compiled.stdout)
    if compiled.returncode or not assembly.is_file():
        raise SystemExit(compiled.stdout.decode("utf-8", errors="replace") or
                         f"Compiler failed with exit code {compiled.returncode}")
    print(json.dumps({"profile": args.profile, "command": command, "path": str(assembly),
                      "size": assembly.stat().st_size, "sha256": sha256(assembly)}))


if __name__ == "__main__":
    main()
