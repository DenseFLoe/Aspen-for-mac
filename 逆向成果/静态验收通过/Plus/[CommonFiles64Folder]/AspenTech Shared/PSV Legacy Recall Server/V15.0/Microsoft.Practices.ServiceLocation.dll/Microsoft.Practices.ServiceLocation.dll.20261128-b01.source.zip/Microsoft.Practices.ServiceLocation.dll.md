# Microsoft.Practices.ServiceLocation.dll

## 原件及交付

- 产品为 Aspen Plus V15.0。文件版本和程序集版本均为 1.2.0.0，程序集目标为 `.NETPortable,Version=v4.0,Profile=Profile136`。
- 原件逻辑路径为 `[CommonFiles64Folder]/AspenTech Shared/PSV Legacy Recall Server/V15.0/Microsoft.Practices.ServiceLocation.dll`。安装原件为 18,120 字节，SHA-256 为 `78ac70411c71b7a0c68fe8746edd3f3a8cd3f72044b329a40ab53c57891be37d`。Plus 的 `AprSystem V15.0/GUI/Xeq` 副本同指纹。[固定主干验收标准](https://github.com/DenseFLoe/Aspen-for-mac/blob/adbe73b517acac25da87598cce46de033f630ccb/docs/static-acceptance.md)
- 交付含整份可编辑 C# 5、三个构建资源及两条构建命令。C# 复用夜班 v3 的可编辑成员，补录空字符串的 `AssemblyCulture` 声明以保留原件的中性程序集文化和相应构造器引用。程序集属性顺序由编译器生成。
- 制作结论为 Profile136 构建的源码、逻辑、绑定和资源均通过逐项比对，整件待独立复核。构建过程直接输出编译器生成的 DLL，采用公开强名公钥延迟签名。

| 本包输入 | 字节数 | SHA-256 |
| --- | ---: | --- |
| `Microsoft.Practices.ServiceLocation.dll.cs` | 6133 | `18a5db7e9b6a5ec2bd3a34625a1861dec860556bbd2654d57db4e559cc626fdc` |
| `resources/assembly-public-key.snk` | 160 | `6fe03f0bbe162b4b24d9f9ba0b07204d8325f15533f9b276b58a4e0db0b24cd1` |
| `resources/Microsoft.Practices.ServiceLocation.Properties.Resources.resources` | 587 | `d5a9996b36ddaf092d02a53809b09879a63a20a81c486fc94ec932d842b87ab4` |
| `resources/original.res` | 1200 | `646c117a4b125926ac326bcee801e3292c5dfbdeba5afa05cf7a447aee16d1a8` |

## 干净构建与静态比较

Windows 上把 ZIP 解到空目录后，从该目录执行。每个 `--out` 参数指向空路径或新路径。构建只读取包内源码、资源和显式指定的编译器及参考程序集。比较另需本机 Aspen PSV 安装原件和 ILDASM，两个工具都通过显式参数指定。

```powershell
$csc = "$env:windir\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$pcl = '<Profile136 引用目录>'
$net40 = '<.NET Framework 4.0 引用目录>'
$ildasm = '<Windows x64 ildasm.exe>'
$original = 'C:\Program Files\Common Files\AspenTech Shared\PSV Legacy Recall Server\V15.0\Microsoft.Practices.ServiceLocation.dll'
python -B .\build.py --csc $csc --profile profile136 --references $pcl --out .\build-profile136
python -B .\evidence\compare.py --ildasm $ildasm --original $original --candidate .\build-profile136\Microsoft.Practices.ServiceLocation.dll --out .\check-profile136
python -B .\build.py --csc $csc --profile net40 --references $net40 --out .\build-net40
python -B .\evidence\compare.py --ildasm $ildasm --original $original --candidate .\build-net40\Microsoft.Practices.ServiceLocation.dll --out .\check-net40
```

比较程序退出码 0 表示本程序的代码、元数据和资源比较范围吻合，1 表示范围内有差异。两条真实编译路线均验证全部 44 项 MethodDef。预期 Profile136 的比较为 0，`net40` 比较为 1。后者实测两条 AssemblyRef 变成 `4.0.0.0/b77a5c561934e089`，并失去 retargetable 标志。原件与 Profile136 回编均引用 retargetable 的 `2.0.5.0/7cec85d7bea7798e` 两项 `mscorlib` 和 `System`。报告和两侧 IL 清单在各自 `--out` 目录。

| 外部依赖 | 实测版本与 SHA-256 |
| --- | --- |
| Python | 3.12.10，使用标准库 |
| Windows x64 原生 C# 编译器 | 4.8.4161.0，`adeda78a951529462f9411e016c1a1b87ddfd94c55912cbd2957817f39929af1` |
| Windows x64 ILDASM | 9.0.23，`79509cec19209578a6b8a7e6aff3e5ae5e75d3a21c59107021f7e99ad4888541` |
| Profile136 `mscorlib.dll` | 2.0.5.0，`6d28da2c6ed3d50c0bd8a849db3e7794239a51d8854d9a179bef0c131bb52b02` |
| Profile136 `System.dll` | 2.0.5.0，`aabceb088c1070d373531c63c0028399458fa72a7e6b1f2c3d1233a966b6f1ed` |
| .NET Framework 4.0 `mscorlib.dll` | 4.0.0.0，NuGet 参考包 1.0.3，`f7a62c9392d6762f5b46c76149173e2f265d6ad05aae54290ff40573ab32190e` |
| .NET Framework 4.0 `System.dll` | 4.0.0.0，NuGet 参考包 1.0.3，`b6dc62e2437b39f48b5c3368e0d14f86cf00fbf0c76d2685026aafca7e9b50f7` |

本轮 Profile136 使用 Mono 上游镜像分发的 2014-04-14 Portable Reference Assemblies。压缩包 SHA-256 为 `f88305669a05657dbce32d5011d6d6d8d24f0dae925e6dac04905fecd6de0530`，从 `PortableReferenceAssemblies-2014-04-14/v4.0/Profile/Profile136/` 提取上述两 DLL。桌面 Framework 参考包 `microsoft.netframework.referenceassemblies.net40.1.0.3.nupkg` SHA-256 为 `54d6e20a1b61caf79395d6d71d091265e81f5a5705ac4ae52af45ca143c3c694`，相应目录为 `build/.NETFramework/v4.0/`。[Portable Reference Assemblies 分发](https://download.mono-project.com/repo/debian/pool/main/r/referenceassemblies-pcl/referenceassemblies-pcl_2014.04.14.orig.tar.bz2) · [.NET Framework 4.0 参考包](https://www.nuget.org/packages/Microsoft.NETFramework.ReferenceAssemblies.net40/1.0.3)

## 核验记录

- 原件与回编各有 8 项 TypeDef（含模块伪类型）、44 项 MethodDef、32 个 CIL 方法体、8 项抽象或接口声明及 4 项委托运行时声明。逐方法核对了 764 字节内的 286 条指令和 4 个异常区。方法配对使用声明类型、名称和完整符号签名，并校验 MethodDef 表令牌覆盖。报告保留两侧令牌，方法内保留操作顺序、调用/字段/类型/字符串的符号操作数、分支与异常区、局部变量、属性和覆写。
- 程序集身份、公钥、两项 AssemblyRef、所有元数据表行数、15 个程序集自定义属性及原件中的类型、属性、成员绑定一致。符号比较去掉 ILDASM 展示的重排行号并按属性构造器排序程序集级属性，保留其载荷。Resources 构造器由 `0x0600001d` 移到 `0x06000023`，6 个访问器分别由 `0x0600001e–23` 移到 `0x0600001d–22`。既有 `token_identity.pair_methods` 独立读取本次两份 PE，在内存中将候选 CIL 的令牌操作数换算到原件令牌空间，32 个方法体逐字节相等，令牌身份缺口为 0。[逐令牌比较](evidence/compare-profile136.json) · [方法体字节补证](evidence/token-bodies.json)
- 托管资源的整个 591 字节目录一致，内含一项公开命名资源及其 587 字节载荷。Win32 目录 1,224 字节逐字节一致，唯一资源为 `RT_VERSION/1/0`，大小 1,136 字节。同一 PE 平台和入口约定均通过，原件与回编的本机入口跳转均指向 `mscoree.dll!_CorDllMain`，各自 HIGHLOW 重定位落在跳转的绝对地址操作数。[代码与资源详情](evidence/compare-profile136.json)
- Profile136 制作产物为 11,264 字节，SHA-256 为 `d48ee185cd1a57233b942e9a224e21e6012264ebae7c8974903d69b653154fa6`。不同编译轮的 COFF 时间戳和 MVID 会变化，仅对这两个位置归零后的制作产物 SHA-256 为 `18f1110b23879b935639a46f8842dd32f2e17c4c9c38670f1046e16f299fbee2`，用于对照不同目录的源码回编。原件的强名标志为 `0x9` 中的签名位，回编 CLI flags 为 `0x1`，具有原程序集公钥及 128 字节延迟签名占位。原件另有 Authenticode 证书表和 CodeView 调试记录，回编无该表与记录，校验和与启动桩 RVA 随布局变化。后续 Windows 对照阶段验证签名和运行加载。
- 桌面 .NET 4.0 对照产物为 11,264 字节，制作 SHA-256 为 `cf70066492ccf26a1ed8bfedd1177a043c1abe3a44da99e38708ece1feb410d6`。此路线验证普通 .NET 4.0 可编译性和依赖身份变化，完整静态证据采用 Profile136 输出。[.NET 4.0 对照](evidence/compare-net40.json)
