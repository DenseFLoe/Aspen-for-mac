"""Compare original and rebuilt managed PE images by ILDASM and PE directories."""

import argparse
from hashlib import sha256
import json
from pathlib import Path
import re
import struct
import subprocess
from uuid import UUID


METHOD = re.compile(
    r"^[ \t]*\.method\s+/\*(?P<token>06[0-9A-F]{6})\*/[ \t]*(?P<header>.*?)"
    r"^[ \t]*\{\n(?P<body>.*?)"
    r"^[ \t]*\} // end of method (?P<owner>\S+)::(?P<name>\S+)[ \t]*$",
    re.MULTILINE | re.DOTALL,
)
METHOD_START = re.compile(r"^[ \t]*\.method\b", re.MULTILINE)
DEBUGGABLE = re.compile(
    r"^(\s*)//\s+(\.custom .+?\]System\.Diagnostics\.DebuggableAttribute.+)$", re.MULTILINE
)
ATTRIBUTE = re.compile(r"^(\.custom .+? = )\(\s*((?:[A-F0-9]{2}\s+)+)\)", re.MULTILINE)
CORFLAGS = re.compile(r"^\.corflags 0x([A-Fa-f0-9]{8})$", re.MULTILINE)
IL_TOKEN = re.compile(r"\bIL_[0-9A-Fa-f]{4,8}: .+")
TOKEN_COMMENT = re.compile(r"/\*\s*[0-9A-Fa-f]{8}(?:(?:;|:{1,2})[0-9A-Fa-f]{8})*\s*\*/")
LINE_PART = re.compile(r"""("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|/\*\s*[0-9A-Fa-f]{8}(?:(?:;|:{1,2})[0-9A-Fa-f]{8})*\s*\*/|//.*|[ \t]+)""")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return sha256(data).hexdigest()


def normalize(line):
    parts = []
    for part in LINE_PART.split(line):
        if part.startswith("//"):
            break
        if TOKEN_COMMENT.fullmatch(part):
            continue
        if not part:
            continue
        if not part.strip():
            if parts and parts[-1] != " ":
                parts.append(" ")
            continue
        parts.append(part)
    return "".join(parts).strip()


def normalize_lines(text):
    return "\n".join(line for line in map(normalize, text.splitlines()) if line)


def methods_and_metadata(text, row_count):
    methods = {}
    tokens = set()
    for entry in METHOD.finditer(text):
        original_body = entry["body"]
        body = normalize_lines(original_body)
        signature = " ".join(normalize_lines(entry["header"]).split("\n"))
        key = (entry["owner"], entry["name"], signature)
        token = int(entry["token"], 16)
        size = re.search(r"// Code size\s+(\d+)", original_body)
        instructions = [line for line in body.splitlines() if IL_TOKEN.fullmatch(line)]
        exceptions = [line for line in body.splitlines() if line.startswith(".try ")]
        require(key not in methods and token not in tokens, f"Ambiguous method: {key}")
        require(bool(size) == bool(instructions), f"Missing IL listing for {key}")
        tokens.add(token)
        methods[key] = {
            "token": f"0x{token:08x}",
            "code_size": int(size[1]) if size else 0,
            "instructions": len(instructions),
            "exceptions": len(exceptions),
            "body": body,
        }
    require(len(METHOD_START.findall(text)) == row_count == len(methods),
            "ILDASM .method count did not match the MethodDef table")
    require(tokens == set(range(0x06000001, 0x06000001 + row_count)),
            "ILDASM .method tokens did not cover every MethodDef row")

    # ILDASM prints the matching Debuggable attribute as an ILASM comment.
    rest = normalize_lines(DEBUGGABLE.sub(r"\1\2", METHOD.sub("", text)))

    # Canonicalize only the ordering of unique attributes within the main
    # assembly block. Every constructor and its binary payload is preserved.
    assembly = re.search(r"^\.assembly (?!extern )[^\n]+\n\{\n(?P<body>.*?)^\}$",
                         rest, re.MULTILINE | re.DOTALL)
    require(assembly is not None, "No assembly definition in ILDASM output")
    attributes = ATTRIBUTE.findall(assembly["body"])
    require(len(attributes) == assembly["body"].count(".custom "),
            "Unsupported assembly custom attribute representation")
    keys = [key for key, _ in attributes]
    require(len(set(keys)) == len(keys), "Duplicate assembly attribute constructor")
    canonical = sorted(key + "(" + " ".join(blob.split()) + ")"
                       for key, blob in attributes)
    flags = CORFLAGS.findall(rest)
    require(len(flags) == 1, "Expected one CLI flags directive")
    other = CORFLAGS.sub("", rest[:assembly.start("body")] +
                         ATTRIBUTE.sub("", assembly["body"]) +
                         rest[assembly.end("body"):])
    return methods, {
        "custom_attributes_in_listed_order": [key.strip() for key in keys],
        "assembly_custom_attributes": canonical,
        "il_metadata": "\n".join(line for line in other.splitlines() if line),
        "il_cli_flags": int(flags[0], 16),
    }


def pe_evidence(path):
    data = path.read_bytes()

    def read(fmt, offset):
        return struct.unpack_from("<" + fmt, data, offset)

    def span(offset, size):
        require(0 <= offset <= len(data) and 0 <= size <= len(data) - offset,
                "PE read outside file")
        return data[offset:offset + size]

    pe, = read("I", 0x3c)
    require(span(0, 2) == b"MZ" and span(pe, 4) == b"PE\0\0", "Invalid PE")
    machine, section_count, timestamp = read("HHI", pe + 4)
    optional_size, flags = read("HH", pe + 20)
    opt = pe + 24
    magic, = read("H", opt)
    require(machine == 0x14c and magic == 0x10b and optional_size >= 216,
            "Expected an x86 PE32 container")
    entry_rva, = read("I", opt + 16)
    image_base, = read("I", opt + 28)
    checksum, = read("I", opt + 64)
    directory_count, = read("I", opt + 92)
    require(directory_count >= 15, "Missing standard PE directories")
    directories = [read("II", opt + 96 + 8*i) for i in range(15)]
    sections = []
    for index in range(section_count):
        offset = opt + optional_size + 40*index
        name = span(offset, 8).rstrip(b"\0").decode("ascii")
        virtual_size, va, disk_size, offset = read("IIII", offset + 8)
        sections.append({"name": name, "va": va, "size": virtual_size,
                         "disk_size": disk_size, "offset": offset})

    def file_offset(rva, size):
        found = [s for s in sections if s["va"] <= rva and
                 rva + size <= s["va"] + min(s["size"], s["disk_size"])]
        require(len(found) == 1, f"Unmapped RVA: {rva:08x} + {size}")
        return found[0]["offset"] + rva - found[0]["va"]

    def rva_bytes(rva, size):
        return span(file_offset(rva, size), size) if size else b""

    def cstring(rva):
        offset = file_offset(rva, 1)
        end = data.find(b"\0", offset)
        require(end >= 0 and file_offset(rva, end + 1 - offset) == offset,
                "Unterminated PE import string")
        return data[offset:end].decode("ascii")

    def summary(blob):
        return {"size": len(blob), "sha256": digest(blob)}

    cli_rva, cli_size = directories[14]
    cli_at = file_offset(cli_rva, cli_size)
    cli_native = read("IHHIIIIIIIIIIIIIIII", cli_at)
    cb, major, minor, md_rva, md_size, cli_flags, cli_entry = cli_native[:7]
    require(cb == cli_size == 72 and not any(cli_native[11:]),
            "Unsupported CLR header or native CLR payload")
    sr_rva, sr_size, sn_rva, sn_size = cli_native[7:11]
    md_at = file_offset(md_rva, md_size)
    md = span(md_at, md_size)
    require(md.startswith(b"BSJB"), "Invalid CLR metadata header")

    def md_int(fmt, offset):
        return struct.unpack_from("<" + fmt, md, offset)[0]

    offset = (16 + md_int("I", 12) + 3) & ~3
    stream_count = md_int("H", offset + 2)
    offset += 4
    streams = {}
    locations = {}
    for _ in range(stream_count):
        location, length = struct.unpack_from("<II", md, offset)
        name_end = md.find(b"\0", offset + 8, offset + 40)
        require(name_end != -1, "Unterminated metadata stream name")
        name = md[offset + 8:name_end].decode("ascii")
        require(name not in streams and location + length <= len(md),
                "Duplicate or invalid metadata stream")
        streams[name] = md[location:location + length]
        locations[name] = location
        offset = (name_end + 4) & ~3
    tables = streams.get("#~", streams.get("#-"))
    require(tables is not None, "No CLR metadata tables")
    present, = struct.unpack_from("<Q", tables, 8)
    ids = [index for index in range(64) if present & (1 << index)]
    counts = dict(zip(ids, struct.unpack_from("<" + "I"*len(ids), tables, 24)))
    require(6 in counts and set(streams) == {"#~", "#Strings", "#US", "#GUID", "#Blob"},
            "Expected standard CLR metadata table and heap layout")
    require(counts.get(0) == 1, "Expected one Module row")
    heap_flags = tables[6]
    string_width = 4 if heap_flags & 1 else 2
    guid_format = "I" if heap_flags & 2 else "H"
    module_row = 24 + 4 * len(ids)
    mvid, encid, encbase = struct.unpack_from("<" + guid_format * 3, tables,
                                            module_row + 2 + string_width)
    require(0 < mvid <= len(streams["#GUID"]) // 16 and mvid not in (encid, encbase)
            and not any(index in counts for index in range(48, 56)),
            "Cannot isolate the build-generated MVID")
    mvid_offset = md_at + locations["#GUID"] + (mvid - 1) * 16
    normalized = bytearray(data)
    normalized[pe + 8:pe + 12] = b"\0" * 4
    normalized[mvid_offset:mvid_offset + 16] = b"\0" * 16
    win32_rva, win32_size = directories[2]
    win32_bytes = rva_bytes(win32_rva, win32_size)
    win32_leaves = {}
    seen = set()

    def resources(offset, resource_path):
        require(offset not in seen and offset + 16 <= len(win32_bytes),
                "Repeated or invalid Win32 resource directory")
        seen.add(offset)
        named, ids = struct.unpack_from("<HH", win32_bytes, offset + 12)
        require(offset + 16 + 8*(named + ids) <= len(win32_bytes), "Invalid resource entries")
        for j in range(named + ids):
            resource_id, child = struct.unpack_from("<II", win32_bytes, offset + 16 + 8*j)
            if resource_id >> 31:
                name_offset = resource_id & 0x7fffffff
                length, = struct.unpack_from("<H", win32_bytes, name_offset)
                name = win32_bytes[name_offset + 2:name_offset + 2 + 2*length]
                require(len(name) == 2*length, "Truncated resource name")
                resource_id = "name:" + name.decode("utf-16le")
            target = (*resource_path, str(resource_id))
            if child >> 31:
                require(len(target) < 3, "Unexpected Win32 resource depth")
                resources(child & 0x7fffffff, target)
            else:
                rva, size, page, reserved = struct.unpack_from("<IIII", win32_bytes, child)
                label = "/".join(target)
                require(len(target) == 3 and label not in win32_leaves and not reserved,
                        "Invalid Win32 resource leaf")
                win32_leaves[label] = {**summary(rva_bytes(rva, size)), "code_page": page}

    resources(0, ())
    imports = {}
    import_at = file_offset(*directories[1])
    for offset in range(import_at, import_at + directories[1][1] - 19, 20):
        original_thunk, stamped, forwarder, name_rva, iat = read("IIIII", offset)
        if not any((original_thunk, stamped, forwarder, name_rva, iat)):
            break
        name = cstring(name_rva)
        for index in range(4096):
            value, = read("I", file_offset((original_thunk or iat) + 4*index, 4))
            if not value:
                break
            require(not value >> 31, "Unexpected ordinal in CLR bootstrap import")
            imports[iat + 4*index] = f"{name}!{cstring(value + 2)}"
        else:
            raise ValueError("Unterminated import thunk table")
    jump = rva_bytes(entry_rva, 6)
    require(jump[:2] == b"\xff\x25", "Unsupported native CLR bootstrap instruction")
    bootstrap_iat = struct.unpack_from("<I", jump, 2)[0] - image_base
    require(bootstrap_iat in imports, "CLR bootstrap jump has no mapped import")
    reloc = rva_bytes(*directories[5])
    block_rva, block_size, patch, padding = struct.unpack("<IIHH", reloc)
    require(block_size == len(reloc) and patch >> 12 == 3 and not padding and
            block_rva + (patch & 0xfff) == entry_rva + 2,
            "Unexpected native bootstrap relocation")

    sn_bytes = rva_bytes(sn_rva, sn_size)
    return {
        "file": summary(data), "cli_flags": cli_flags, "cli_version": [major, minor],
        "managed_entry": cli_entry, "machine": machine, "magic": magic,
        "coff_timestamp": timestamp, "coff_characteristics": flags, "pe_checksum": checksum,
        "mvid": str(UUID(bytes_le=span(mvid_offset, 16))),
        "normalized_file_sha256": digest(normalized),
        "normalized_build_ranges": {"coff_timestamp": [pe + 8, 4], "mvid": [mvid_offset, 16]},
        "native_imports": sorted(imports.values()), "native_bootstrap": imports[bootstrap_iat],
        "native_bootstrap_rva": entry_rva, "metadata_raw": summary(md),
        "metadata_tables": counts, "metadata_streams": {k: summary(v) for k, v in streams.items()},
        "win32_directory": summary(win32_bytes), "win32_leaves": win32_leaves,
        "managed_resources": summary(rva_bytes(sr_rva, sr_size)),
        "strong_name": {**summary(sn_bytes), "empty": not any(sn_bytes)},
        "certificate_table": summary(span(*directories[4])),
        "debug_directory": summary(rva_bytes(*directories[6])),
    }


def inspect(ildasm, path, output, label):
    facts = pe_evidence(path)
    location = output / label
    location.mkdir()
    listing = location / "listing.il"
    completed = subprocess.run(
        [str(ildasm), "/UTF8", "/TOKENS", "/RAWEH", "/OUT=" + str(listing), str(path)],
        cwd=location, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, check=False,
    )
    require(not completed.returncode and listing.is_file(),
            "ILDASM failed: " + completed.stdout.decode("utf-8", errors="replace"))
    methods, metadata = methods_and_metadata(
        listing.read_text(encoding="utf-8-sig"), facts["metadata_tables"][6]
    )
    require(metadata["il_cli_flags"] == facts["cli_flags"], "ILDASM and PE CLI flags differ")
    facts.update(metadata)
    facts["listing_sha256"] = digest(listing.read_bytes())
    return facts, methods


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--ildasm", required=True, type=Path)
    parser.add_argument("--original", required=True, type=Path)
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=True)
    require(not any(output.iterdir()), f"Compare directory must be empty: {output}")
    ildasm = args.ildasm.resolve()
    left, old = inspect(ildasm, args.original.resolve(), output, "original")
    right, new = inspect(ildasm, args.candidate.resolve(), output, "candidate")
    rows = []
    for identity in sorted(old.keys() | new.keys(), key=lambda k: (old.get(k) or new[k])["token"]):
        a, b = old.get(identity), new.get(identity)
        details = [{k: v for k, v in row.items() if k != "body"} if row else None
                   for row in (a, b)]
        same = a is not None and b is not None and a["body"] == b["body"] and (
            a["code_size"] == b["code_size"]
        )
        rows.append({"owner": identity[0], "name": identity[1], "signature": identity[2],
                     "original": details[0], "candidate": details[1], "equal": same,
                     "normalized_body_sha256": digest(a["body"].encode()) if same else None,
                     "different_bodies": [a and a["body"], b and b["body"]] if not same else None})
    compared_fields = [
        "assembly_custom_attributes", "il_metadata", "cli_version", "managed_entry",
        "machine", "magic", "coff_characteristics", "metadata_tables",
        "native_imports", "native_bootstrap", "win32_directory", "win32_leaves", "managed_resources",
    ]
    differences = [field for field in compared_fields if left[field] != right[field]]
    if (left["cli_flags"] ^ right["cli_flags"]) & ~8:
        differences.append("cli_flags_without_strong_name_signed_bit")
    okay = not differences and all(row["equal"] for row in rows)
    report = {
        "scope_matches": okay, "ildasm_sha256": digest(ildasm.read_bytes()),
        "original": left, "candidate": right, "metadata_or_resource_differences": differences,
        "method_rows": rows, "equal_methods": sum(row["equal"] for row in rows),
        "coverage": {
            label: {field: sum(row[field] for row in methods.values())
                    for field in ("code_size", "instructions", "exceptions")} |
            {"method_defs": len(methods),
             "bodies": sum(row["code_size"] > 0 for row in methods.values())}
            for label, methods in (("original", old), ("candidate", new))
        },
    }
    (output / "compare.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: report[key] for key in ("scope_matches", "equal_methods",
                                                   "metadata_or_resource_differences")}))
    return 0 if okay else 1


if __name__ == "__main__":
    raise SystemExit(main())
