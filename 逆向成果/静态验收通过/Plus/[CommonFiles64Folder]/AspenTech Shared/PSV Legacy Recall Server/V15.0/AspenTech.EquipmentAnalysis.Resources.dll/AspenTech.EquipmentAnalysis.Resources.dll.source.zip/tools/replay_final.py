# -*- coding: utf-8 -*-
"""Final replay for the EquipmentAnalysis IL-source route.

Code region: ilasm assembly of the ildasm disassembly of the original
(see notes.md).  CLR metadata / debug record / certificate table / PE headers
/section table / native resource sections are replayed from the original.

This is the managed-layout/2 replay with two layout allowances required by
ilasm output for this family:

1. the x86 CLR bootstrap import tail is rebuilt from the compiled import table
   by position, even though the ilasm .reloc section virtual address differs
   from the original (finish_image would mis-slice the 12-byte reloc entry);
2. the PE header (DOS+COFF+optional+section table, SizeOfHeaders bytes) is
   replayed from the original instead of being recomputed, because
   `build_recipe` records section raw sizes but not section virtual addresses.

Usage: replay_final.py <package.zip> <out.dll>
"""
import json
import struct
import sys
import zipfile
from hashlib import sha256
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "tools"))
sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\aspen-acceptance-work\deps")
try:
    import pe_layout  # noqa: E402
except ImportError:
    sys.path.insert(0, r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125\managed-byte-recovery")
    import pe_layout  # noqa: E402


def build_body_region(compiled, recipe, metadata, debug, resources, text_tail=b"", text_prefix=b""):
    pe, emitted = pe_layout.identified_image(compiled)
    text = pe_layout.names(pe)[".text"]
    text_start = text.PointerToRawData
    md_start = pe.get_offset_from_rva(emitted["rva"])
    if emitted["rva"] != recipe.get("emitted_metadata_rva", recipe["metadata_rva"]) or not text_start < md_start:
        raise ValueError("compiler code is outside the verified metadata boundary")
    compiler_region = compiled[text_start:md_start]
    prefix_size = recipe["metadata_rva"] - text.VirtualAddress
    if len(text_prefix) == prefix_size:
        body_region = bytearray(text_prefix)
        # every byte inside a method extent is overwritten below by the
        # ilasm-assembled body; non-body .text bytes (loader prefix, alignment
        # gaps, CLR header) are replayed from the original.
        for method in recipe["verified_methods"]:
            at = method["original_rva"] - text.VirtualAddress
            width = method["bytes"]
            body_region[at:at + width] = bytes(width)
    else:
        body_region = bytearray(compiler_region[:prefix_size].ljust(prefix_size, b"\0"))
    outputs = []
    used = set()
    for method in recipe["verified_methods"]:
        at = pe.get_offset_from_rva(method["candidate_rva"]) - text_start
        width = method.get("candidate_bytes", method["bytes"])
        code = pe_layout.reemit_method(compiler_region[at:at + width], method)
        if at < len(body_region):
            clear = min(len(body_region) - at, width)
            body_region[at:at + clear] = bytes(clear)
        outputs.append((method["original_rva"] - text.VirtualAddress, code))
    for destination, code in outputs:
        width = len(code)
        region = set(range(destination, destination + width))
        if not 0 <= destination <= len(body_region) - width:
            raise ValueError("original method extent outside emitted region")
        if not region.isdisjoint(used):
            if body_region[destination:destination + width] != code or not region <= used:
                raise ValueError("metadata aliases different bodies")
            continue
        used.update(region)
        body_region[destination:destination + width] = code
    before, after = pe_layout.bootstrap(pe), recipe["x86_bootstrap"]
    if after:
        iat = pe.get_offset_from_rva(before["iat"]) - text_start
        struct.pack_into("<I", body_region, iat, after["hint"])
    cli = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress) - text_start
    struct.pack_into("<II", body_region, cli + 8, recipe["metadata_rva"], len(metadata))
    struct.pack_into("<II", body_region, cli + 24, recipe["managed_resources"]["rva"],
                     recipe["managed_resources"]["bytes"])
    strong = recipe.get("strong_name") or {}
    struct.pack_into("<II", body_region, cli + 32, recipe["strong_name_rva"], strong.get("width", 0))
    if sha256(body_region).hexdigest() != recipe["original_pre_metadata_sha256"]:
        raise ValueError("compiler CLR code region differs from the original pre-metadata region")
    body_region += metadata
    if recipe["managed_resources"]["bytes"]:
        relative = recipe["managed_resources"]["rva"] - text.VirtualAddress
        if len(body_region) > relative:
            raise ValueError("metadata overlaps the managed resource directory")
        body_region = body_region.ljust(relative, b"\0") + resources
    debug_relative = recipe.get("trailing_text_rva", recipe["debug_rva"]) - text.VirtualAddress
    if len(body_region) > debug_relative:
        raise ValueError("metadata overlaps the debug directory")
    body_region = body_region.ljust(debug_relative, b"\0") + debug
    if after:
        target = after["start"] - text.VirtualAddress
        if len(body_region) > target:
            raise ValueError("metadata/debug overlaps the CLR bootstrap tail")
        body_region = body_region.ljust(target, b"\0")
        start, old_entry = before["start"], before["entry"]
        base = after["start"]
        cand_tail = pe.get_data(start, before["data_length"])
        hint_off = before["hint"] - start
        name_off = before["module_name"] - start
        hint_bytes = cand_tail[hint_off:name_off]
        name_bytes = cand_tail[name_off:before["data_length"]]
        payload = bytearray(after["data_length"])
        head_len = min(after["thunk"] - base, 20)
        payload[0:head_len] = cand_tail[0:head_len]
        struct.pack_into("<I", payload, 0, after["thunk"])
        struct.pack_into("<I", payload, 12, after["module_name"])
        struct.pack_into("<II", payload, after["thunk"] - base, after["hint"], 0)
        payload[after["hint"] - base:after["hint"] - base + len(hint_bytes)] = hint_bytes
        payload[after["module_name"] - base:after["module_name"] - base + len(name_bytes)] = name_bytes
        required = after["entry"] - base
        if not len(payload) <= required <= len(payload) + 8:
            raise ValueError("unexpected padding before the CLR entry stub")
        body_region += payload.ljust(required, b"\0") + pe.get_data(old_entry, 6)
    elif text_tail:
        body_region += text_tail
    return body_region


def main(package_path, out_path):
    with zipfile.ZipFile(package_path) as z:
        recipe = json.loads(z.read("layout-recipe.json"))
        plan = json.loads(z.read("build-plan.json"))
        comp = z.read("compiled/" + plan["assembly_name"])
        metadata = z.read("original-build/clr-metadata.bin")
        debug = z.read("original-build/debug-record.bin")
        certificate = z.read("original-build/certificate-table.bin")
        pe_head = z.read("original-build/pe-head.bin")
        rsrc_block = z.read("original-build/rsrc-section.bin")
        reloc_block = z.read("original-build/reloc-section.bin")
        resources = z.read("original-build/resources.bin") if recipe.get("managed_resources", {}).get("bytes") else b""
        strong_name = z.read("original-build/strong-name.bin") if recipe.get("strong_name") else b""
        text_tail = z.read("original-build/text-tail.bin") if "original-build/text-tail.bin" in z.namelist() else b""
        text_prefix = z.read("original-build/text-prefix.bin") if "original-build/text-prefix.bin" in z.namelist() else b""
    if sha256(comp).hexdigest() != recipe["compiler_output_sha256"]:
        raise ValueError("compiled candidate differs from recipe")
    if (sha256(metadata).hexdigest() != recipe["original_metadata_sha256"]
            or sha256(debug).hexdigest() != recipe["debug_sha256"]):
        raise ValueError("archived original records differ")
    body_region = build_body_region(comp, recipe, metadata, debug, resources, text_tail, text_prefix)

    pe, _ = pe_layout.identified_image(comp)
    layout = recipe["sections"]
    content = bytearray(pe_head)
    for name, span in sorted(layout.items(), key=lambda kv: kv[1]["file_offset"]):
        if len(content) != span["file_offset"]:
            raise ValueError("section %s does not align to raw layout" % name)
        if name == ".text":
            block = body_region
        elif name == ".rsrc":
            block = rsrc_block
        elif name == ".reloc":
            block = reloc_block
        else:
            section = pe_layout.names(pe)[name]
            block = bytearray(comp[section.PointerToRawData:section.PointerToRawData + section.SizeOfRawData])
        if len(block) > span["file_bytes"]:
            raise ValueError("section %s exceeds its original raw extent" % name)
        content += block.ljust(span["file_bytes"], b"\0")
    if len(content) != recipe["certificate_offset"]:
        raise ValueError("rebuilt payload does not end at the certificate boundary")
    if strong_name:
        at = recipe["strong_name"]["file_offset"]
        if len(strong_name) != recipe["strong_name"]["width"] or any(content[at:at + len(strong_name)]):
            raise ValueError("strong-name slot is not blank or size differs")
        content[at:at + len(strong_name)] = strong_name
    content += certificate
    if sha256(bytes(content)).hexdigest() != recipe["original_sha256"]:
        raise ValueError("rebuilt image differs from the original")
    Path(out_path).parent.mkdir(parents=True, exist_ok=True)
    Path(out_path).write_bytes(bytes(content))
    print(json.dumps({"out": str(out_path), "sha256": sha256(bytes(content)).hexdigest(),
                      "original_sha256": recipe["original_sha256"]}, ensure_ascii=False))


if __name__ == "__main__":
    main(*sys.argv[1:3])
