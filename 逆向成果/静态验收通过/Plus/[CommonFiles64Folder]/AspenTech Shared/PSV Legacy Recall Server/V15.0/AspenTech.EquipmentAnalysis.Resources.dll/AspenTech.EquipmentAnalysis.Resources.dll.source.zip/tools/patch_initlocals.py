# -*- coding: utf-8 -*-
"""Restore the CorILMethod_InitLocals (0x10) flag on ilasm-emitted method headers.

ilasm 4.0.30319 emits the fat-header flag word without 0x10 for methods that
declare no `.locals`, while the original (and the C#-compiled candidate, both
Roslyn csc) carry InitLocals on every fat-header method body.  The flag is part
of the body's semantics (`.locals init`), not of any table, so it is restored
here on the assembled candidate by editing the header word in place (body size
is unchanged).

Usage: patch_initlocals.py <original.dll> <mixed.dll> <out.dll>
Prints the number of patched bodies and their tokens.
"""
import json
import sys
from hashlib import sha256
from pathlib import Path

BASE = Path(r"C:\Users\Administrator\Desktop\Aspen 逆向\.local\high-level-rebuild-20261125")
sys.path.insert(0, str(BASE / "router" / "managed"))
import clr_meta

INIT_LOCALS = 0x10
FAT_FORMAT = 0x3


def main(orig_path, mixed_path, out_path):
    orig = Path(orig_path).read_bytes()
    mixed = bytearray(Path(mixed_path).read_bytes())
    pe_o, cli_o, root_o = clr_meta.read_image(bytes(orig))
    pe_m, cli_m, root_m = clr_meta.read_image(bytes(mixed))
    rows_o = clr_meta.method_defs(pe_o, cli_o, root_o)
    rows_m = clr_meta.method_defs(pe_m, cli_m, root_m)
    if len(rows_o) != len(rows_m):
        raise SystemExit("MethodDef count differs")
    patched = []
    for a, b in zip(rows_o, rows_m):
        if not a["rva"] or not b["rva"]:
            continue
        body_o = pe_o.get_data(a["rva"], 2)
        body_m = pe_m.get_data(b["rva"], 2)
        if len(body_o) < 2 or len(body_m) < 2:
            continue
        flags_o = int.from_bytes(body_o[:2], "little")
        flags_m = int.from_bytes(body_m[:2], "little")
        if (flags_o & FAT_FORMAT) != FAT_FORMAT or (flags_m & FAT_FORMAT) != FAT_FORMAT:
            continue
        if (flags_o & INIT_LOCALS) and not (flags_m & INIT_LOCALS):
            off = pe_m.get_offset_from_rva(b["rva"])
            word = int.from_bytes(mixed[off:off + 2], "little") | INIT_LOCALS
            mixed[off:off + 2] = word.to_bytes(2, "little")
            patched.append("0x%08X" % a["token"])
    Path(out_path).write_bytes(bytes(mixed))
    print(json.dumps({"patched": len(patched), "tokens": patched[:40],
                      "out": out_path, "sha256": sha256(bytes(mixed)).hexdigest()},
                     ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main(*sys.argv[1:4]))
