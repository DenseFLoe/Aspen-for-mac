using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("RegisterExtension32")]
[assembly: AssemblyDescription("Aspen HYSYS® 32-bit Register Extension Utility")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("RegisterExtension32")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("666feccc-699c-4b90-b257-63babff12b95")]
[assembly: AssemblyCompany("AspenTech LTD.")]
[assembly: AssemblyCopyright("Copyright © AspenTech LTD. 2024")]
[assembly: AssemblyFileVersion("41.0.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace RegisterExtension;

public sealed class Program
{
	[STAThread]
	[EnvironmentPermission(SecurityAction.LinkDemand, Unrestricted = true)]
	public static int Main(string[] args)
	{
		bool handlerInstalled = false;
		try
		{
			return MainImplementation(args, out handlerInstalled);
		}
		catch (SecurityException exception)
		{
			if (handlerInstalled)
			{
				Output.Stream(string.Concat("A security exception has occurred.", "It appears that you do not the appropriate permissions to run this application.", "The application must now exit."));
			}
			HandleUnhandled(null, new UnhandledExceptionEventArgs(exception, isTerminating: true));
		}
		catch (Exception ex)
		{
			Output.Stream(string.Concat("An unmanaged exception was encountered on the main thread."));
			Output.Stream(ex.Message.ToString());
		}
		return -2147467259;
	}

	private static int MainImplementation(string[] args, out bool handlerInstalled)
	{
		AppDomain.CurrentDomain.UnhandledException += HandleUnhandled;
		handlerInstalled = true;
		Extension extension = new Extension();
		ParsingEngine parsingEngine = new ParsingEngine();
		if (parsingEngine.ParseCommandLine(args, extension))
		{
			extension.ExecutedFromGUI = false;
			extension.UseSurrogate = true;
			if (ValidateImage(extension, parsingEngine) < 0)
			{
				Output.Stream("FATAL ERROR:");
				Output.Stream("Validation of the HYSYS extension " + extension.FullFileName.ToString() + " failed.");
				Output.WriteStream(extension.ExecutedFromGUI);
				return -2147467259;
			}
			if (extension.RegisterImage(AddDllSurrogate: true) < 0)
			{
				Output.Stream("FATAL ERROR:");
				Output.Stream((extension.IsRegistering ? "Registration" : "Unregistration") + " of the HYSYS extension " + extension.FullFileName.ToString() + " failed.");
				Output.WriteStream(extension.ExecutedFromGUI);
				return -2147467259;
			}
			extension.RegisterEDFKeys();
			if (!extension.IsSilent)
			{
				Output.WriteStream(extension.ExecutedFromGUI);
			}
			return 0;
		}
		Output.WriteStream(extension.ExecutedFromGUI);
		return -2147467259;
	}

	private static void HandleUnhandled(object sender, UnhandledExceptionEventArgs args)
	{
		Output.Stream(args.ToString());
		Environment.Exit(-2147467259);
	}

	private static int ValidateImage(Extension extension, ParsingEngine parsingEngine)
	{
		int num = 0;
		try
		{
			string text = Path.ChangeExtension(extension.FullPathName, "edf");
			using (new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				num = parsingEngine.ParseEDFFile(extension) ? 0 : -2147467259;
				if (num < 0)
				{
					return num;
				}
				if (extension.IsVerbose)
				{
					Output.Stream("Validated .edf extension file: " + text);
				}
			}
			text = Path.ChangeExtension(extension.FullPathName, "dll");
			using (FileStream dllStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read))
			{
				if (extension.IsVerbose)
				{
					Output.Stream("Validated .dll extension file: " + text);
					Output.Stream(string.Empty);
				}
			}
		}
		catch (FileNotFoundException)
		{
			Output.Stream("E10001: Corresponding edf and dll extension files could not be found.");
			return -2147467259;
		}
		catch
		{
			Output.Stream("E10003: Unhandled exception.");
			return -2147467259;
		}
		return num;
	}
}
