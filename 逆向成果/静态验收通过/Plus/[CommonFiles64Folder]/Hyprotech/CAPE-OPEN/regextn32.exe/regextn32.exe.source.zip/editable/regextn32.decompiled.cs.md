# regextn32.decompiled.cs

Source: editable/regextn32.decompiled.cs

Source SHA-256: 1ab80fd18a4bfc471b5f3b7a62ff7f0cb8c77bfb596b30c1bb0fc42e072a9ade
