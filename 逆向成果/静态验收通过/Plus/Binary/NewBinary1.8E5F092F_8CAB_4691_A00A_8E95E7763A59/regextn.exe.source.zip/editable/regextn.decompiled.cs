using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("RegisterExtension")]
[assembly: AssemblyDescription("Aspen HYSYS® Register Extension Utility")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyProduct("RegisterExtension")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("818eeaef-373f-4823-bf72-41504b072734")]
[assembly: AssemblyCompany("AspenTech LTD.")]
[assembly: AssemblyCopyright("Copyright © AspenTech LTD. 2024")]
[assembly: AssemblyFileVersion("41.0.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.8", FrameworkDisplayName = ".NET Framework 4.8")]
[assembly: AssemblyVersion("41.0.0.0")]
namespace RegisterExtension
{
	public sealed class Program
	{
		[STAThread]
		[EnvironmentPermission(SecurityAction.LinkDemand, Unrestricted = true)]
		public static int Main(string[] args)
		{
			bool handlerInstalled = false;
			try
			{
				return MainImplementation(args, out handlerInstalled);
			}
			catch (SecurityException exception)
			{
				if (handlerInstalled)
				{
					Output.Stream(string.Concat("A security exception has occurred.", "It appears that you do not the appropriate permissions to run this application.", "The application must now exit."));
				}
				HandleUnhandled(null, new UnhandledExceptionEventArgs(exception, isTerminating: true));
			}
			catch (Exception ex)
			{
				Output.Stream(string.Concat("An unmanaged exception was encountered on the main thread."));
				Output.Stream(ex.Message.ToString());
			}
			return -2147467259;
		}

		private static int MainImplementation(string[] args, out bool handlerInstalled)
		{
			AppDomain.CurrentDomain.UnhandledException += HandleUnhandled;
			handlerInstalled = true;
			Extension extension = new Extension();
			ParsingEngine parsingEngine = new ParsingEngine();
			if (parsingEngine.ParseCommandLine(args, extension))
			{
				if (!extension.KnowsIfIsCLR)
				{
					extension.IsCLR = IsCLRImage(extension.FullPathName);
				}
				int num = ValidateImage(extension, parsingEngine);
				if (num == 1)
				{
					Output.Stream((extension.IsRegistering ? "Performing" : "Removing") + " DllSurrogate Registration of 32-bit " + (extension.IsCLR ? "CLR" : "COM") + " extension");
					IList<string> list = new List<string>();
					foreach (string text in args)
					{
						if (text.Contains(" "))
						{
							list.Add(string.Format("\"{0}\"", text));
						}
						else
						{
							list.Add(text);
						}
					}
					string text2 = string.Join(" ", list);
					text2 = text2 + " /" + (extension.IsCLR ? "n" : "c");
					Process process = new Process();
					process.StartInfo = new ProcessStartInfo("regextn32.exe", text2)
					{
						CreateNoWindow = true,
						UseShellExecute = false,
						RedirectStandardOutput = true
					};
					process.Start();
					Output.Stream(process.StandardOutput.ReadToEnd());
					process.WaitForExit();
					Output.WriteStream(extension.ExecutedFromGUI);
					if (process.ExitCode < 0)
					{
						return process.ExitCode;
					}
					return 0;
				}
				if (num < 0)
				{
					Output.Stream("FATAL ERROR:");
					Output.Stream("Validation of the HYSYS extension " + extension.FullFileName.ToString() + " failed.");
					Output.WriteStream(extension.ExecutedFromGUI);
					return -2147467259;
				}
				num = extension.RegisterImage();
				if (num < 0)
				{
					Output.Stream("FATAL ERROR:");
					Output.Stream((extension.IsRegistering ? "Registration" : "Unregistration") + " of the HYSYS extension " + extension.FullFileName.ToString() + " failed.");
					Output.WriteStream(extension.ExecutedFromGUI);
					return -2147467259;
				}
				extension.RegisterEDFKeys();
				if (!extension.IsSilent)
				{
					Output.WriteStream(extension.ExecutedFromGUI);
				}
				return 0;
			}
			Output.WriteStream(extension.ExecutedFromGUI);
			return -2147467259;
		}

		private static void HandleUnhandled(object sender, UnhandledExceptionEventArgs args)
		{
			Output.Stream(args.ToString());
			Environment.Exit(-2147467259);
		}

		private static bool IsCLRImage(string pathName)
		{
			return RegHelper.IsCLRAssembly(pathName);
		}

		private static int ValidateImage(Extension extension, ParsingEngine parsingEngine)
		{
			int num = 0;
			try
			{
				string text = Path.ChangeExtension(extension.FullPathName, "edf");
				using (new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					num = parsingEngine.ParseEDFFile(extension) ? 0 : -2147467259;
					if (num < 0)
					{
						return num;
					}
					if (extension.IsVerbose)
					{
						Output.Stream("Validated .edf extension file: " + text);
					}
				}
				text = Path.ChangeExtension(extension.FullPathName, "dll");
				using (FileStream dllStream = new FileStream(text, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					if (extension.IsVerbose)
					{
						Output.Stream("Validated .dll extension file: " + text);
						Output.Stream(string.Empty);
					}
				}
				if (!RegHelper.Is64BitAssembly(text))
				{
					if (extension.IsCLR)
					{
						Assembly.ReflectionOnlyLoadFrom(text).ManifestModule.GetPEKind(out var peKind, out var _);
						if ((peKind & PortableExecutableKinds.Required32Bit) == PortableExecutableKinds.Required32Bit)
						{
							return 1;
						}
						if (peKind == PortableExecutableKinds.NotAPortableExecutableImage)
						{
							throw new ArgumentException("File not a recognized Portable Executable Image", text);
						}
					}
					else
					{
						return 1;
					}
				}
			}
			catch (FileNotFoundException)
			{
				Output.Stream("E10001: Corresponding edf and dll extension files could not be found.");
				return -2147467259;
			}
			catch
			{
				Output.Stream("E10003: Unhandled exception.");
				return -2147467259;
			}
			return num;
		}
	}
}
namespace RegisterExtension.Properties
{
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "15.0.0.0")]
	[DebuggerNonUserCode]
	[CompilerGenerated]
	internal class Resources
	{
		private static ResourceManager resourceMan;

		private static CultureInfo resourceCulture;

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				if (resourceMan == null)
				{
					resourceMan = new ResourceManager("RegisterExtension.Properties.Resources", typeof(Resources).Assembly);
				}
				return resourceMan;
			}
		}

		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return resourceCulture;
			}
			set
			{
				resourceCulture = value;
			}
		}

		internal Resources()
		{
		}
	}
}
