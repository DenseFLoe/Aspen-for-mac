using System;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using Interop.SECSERVEROBJECTLib;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: AssemblyTitle("SLMServerCLS")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Aspen Technology")]
[assembly: AssemblyProduct("SLMServerCLS")]
[assembly: AssemblyCopyright("Copyright © Aspen Technology 2008")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(true)]
[assembly: Guid("03d89d84-e769-4073-b25c-7345fe7c8ad0")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.7", FrameworkDisplayName = ".NET Framework 4.7")]
[assembly: AssemblyVersion("2.0.0.0")]
namespace SLMServerCLS
{
	[ClassInterface(ClassInterfaceType.AutoDual)]
	public class clsServer : IclsServer
	{
		private SecServer mySecurityServer;

		private ISecCallback myCallBack;

		public clsServer()
		{
			if (mySecurityServer == null)
			{
				mySecurityServer = (SecServer)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("1460FDB4-752B-11D4-B067-0090271CF383")));
			}
		}

		public bool SLMCheckoutLicense(string licenseName, string version, out int cookie, LicenseImportance_enum importance, out string result)
		{
			myCallBack = null;
			result = mySecurityServer.CheckoutLicense(licenseName, version, out cookie, myCallBack, importance);
			if (result != string.Empty)
			{
				return false;
			}
			return true;
		}

		public LicenseStatus_enum SLMValidateLicense(int cookie, bool bWait)
		{
			int waitforit = 1;
			if (!bWait)
			{
				waitforit = 0;
			}
			return mySecurityServer.ValidateLicense(cookie, waitforit);
		}

		public void SLMReleaseLicense(int cookie)
		{
			mySecurityServer.ReleaseLicense(cookie);
		}
	}
	[ComVisible(true)]
	[ClassInterface(ClassInterfaceType.AutoDual)]
	[Guid("10E380F6-9134-4AEE-8B5F-BC67891B4917")]
	public class clsServer2 : IclsServer
	{
		private SecServer mySecurityServer;

		private ISecCallback myCallBack;

		public clsServer2()
		{
			if (mySecurityServer == null)
			{
				mySecurityServer = (SecServer)Activator.CreateInstance(Marshal.GetTypeFromCLSID(new Guid("1460FDB4-752B-11D4-B067-0090271CF383")));
			}
		}

		public bool SLMCheckoutLicense(string licenseName, string version, out int cookie, LicenseImportance_enum importance, out string result)
		{
			myCallBack = null;
			result = mySecurityServer.CheckoutLicense(licenseName, version, out cookie, myCallBack, importance);
			if (result != string.Empty)
			{
				return false;
			}
			return true;
		}

		public LicenseStatus_enum SLMValidateLicense(int cookie, bool bWait)
		{
			int waitforit = 1;
			if (!bWait)
			{
				waitforit = 0;
			}
			return mySecurityServer.ValidateLicense(cookie, waitforit);
		}

		public void SLMReleaseLicense(int cookie)
		{
			mySecurityServer.ReleaseLicense(cookie);
		}
	}
	internal interface IclsServer
	{
		bool SLMCheckoutLicense(string licenseName, string version, out int cookie, LicenseImportance_enum importance, out string result);

		LicenseStatus_enum SLMValidateLicense(int cookie, bool bWait);

		void SLMReleaseLicense(int cookie);
	}
}
namespace Interop.SECSERVEROBJECTLib
{
	[ComImport]
	[CompilerGenerated]
	[Guid("1460FDB6-752B-11D4-B067-0090271CF383")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecCallback
	{
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("A61D34E7-943C-4B91-A7CB-EFEC599ED919")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecServer : ISecServer4
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: MarshalAs(UnmanagedType.BStr)]
		string CheckoutLicense([In][MarshalAs(UnmanagedType.BStr)] string license, [In][MarshalAs(UnmanagedType.BStr)] string licversion, out int cookie, [Optional][In][MarshalAs(UnmanagedType.Interface)] ISecCallback lostLicenseCallback, [Optional][In] LicenseImportance_enum importance);

		[MethodImpl(MethodCodeType = MethodCodeType.Runtime)]
		void _VtblGap1_1();

		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		LicenseStatus_enum ValidateLicense([In] int cookie, [In] int waitforit);

		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		void ReleaseLicense([In] int cookie);
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("69C4BC11-E968-4190-A674-F1E0928C63F0")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface ISecServer2 : _ISecServer
	{
	}
	[ComImport]
	[CompilerGenerated]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("A09377DA-340B-4BBC-8DF5-F8A100055DD9")]
	[TypeIdentifier]
	public interface ISecServer3 : ISecServer2
	{
	}
	[ComImport]
	[CompilerGenerated]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[Guid("AE942D5A-12E1-42F9-AA95-B77631A4F6DE")]
	[TypeIdentifier]
	public interface ISecServer4 : ISecServer3
	{
	}
	[CompilerGenerated]
	[TypeIdentifier("1460FDB3-752B-11D4-B067-0090271CF383", "Interop.SECSERVEROBJECTLib.LicenseImportance_enum")]
	public enum LicenseImportance_enum
	{
		liNotCritical,
		liCritical
	}
	[CompilerGenerated]
	[TypeIdentifier("1460FDB3-752B-11D4-B067-0090271CF383", "Interop.SECSERVEROBJECTLib.LicenseStatus_enum")]
	public enum LicenseStatus_enum
	{
		ls_NOLIC,
		ls_Pending,
		ls_OK
	}
	[ComImport]
	[CompilerGenerated]
	[CoClass(typeof(object))]
	[Guid("A61D34E7-943C-4B91-A7CB-EFEC599ED919")]
	[TypeIdentifier]
	public interface SecServer : ISecServer
	{
	}
	[ComImport]
	[CompilerGenerated]
	[Guid("1460FDB5-752B-11D4-B067-0090271CF383")]
	[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
	[TypeIdentifier]
	public interface _ISecServer
	{
	}
}
