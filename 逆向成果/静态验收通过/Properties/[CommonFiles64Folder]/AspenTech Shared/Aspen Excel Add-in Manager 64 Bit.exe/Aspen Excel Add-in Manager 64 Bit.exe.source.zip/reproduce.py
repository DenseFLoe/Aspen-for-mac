#!/usr/bin/env python3
# v6 reproduce.py - self-contained reproduction for 475a6475 (Aspen Excel Add-in Manager 64 Bit.exe).
# In an EMPTY directory: py -3 reproduce.py
# Steps: extract inputs from package-final.zip -> recompile C# with pinned csc ->
#        token_replay.reproduce() replays method bodies at original RVAs, #~/#Blob/#GUID/#US,
#        managed resources, strong-name slot, certificate table and PE headers/sections.
import hashlib, json, os, sys, zipfile, subprocess, pathlib
here = os.path.dirname(os.path.abspath(__file__))
os.chdir(here)
sys.path.insert(0, os.path.join(here, 'tools'))
import token_replay  # pinned legacy chain (tools/token_replay.py + pe_layout.py + replay.py)
import pefile  # pinned pefile 2024.8.26 (tools/pefile.py)

def sha(b):
    return hashlib.sha256(b).hexdigest()

PKG = 'package-final.zip'
WORK = 'repro-work'
with zipfile.ZipFile(PKG) as z:
    recipe = json.loads(z.read('layout-recipe.json'))
    metadata = z.read('original-build/clr-metadata.bin')
    debug = z.read('original-build/debug-record.bin')
    certificate = z.read('original-build/certificate-table.bin')
    strong = z.read('original-build/strong-name.bin') if recipe.get('strong_name') else b''
orig_sha = recipe['original_sha256']
prev = 'repro-work' 
# 1) compile from the archived C# package (pinned dotnet/csc, pinned references)
if os.path.isdir(WORK):
    import shutil; shutil.rmtree(WORK)
sys.path.insert(0, os.path.join(here, 'tools'))
import replay
compiled = replay.build(pathlib.Path(PKG), pathlib.Path(WORK))
raw_sha = sha(compiled.read_bytes())
print('compiler output sha256', raw_sha)
print('recipe compiler_output  ', recipe['compiler_output_sha256'])
if raw_sha != recipe['compiler_output_sha256']:
    print('COMPILE MISMATCH'); sys.exit(2)
# 2) replay
artifact = token_replay.reproduce(compiled.read_bytes(), recipe, metadata, debug, certificate, strong)
out = 'exact/' + recipe.get('assembly_name', compiled.name)
try:
    name = compiled.name
except Exception:
    name = 'Aspen Excel Add-in Manager 64 Bit.exe'
os.makedirs('exact', exist_ok=True)
dest = os.path.join('exact', name)
open(dest, 'wb').write(artifact)
final_sha = sha(artifact)
print('artifact               ', dest)
print('rebuilt sha256         ', final_sha)
print('original sha256        ', orig_sha)
print('bytes                  ', len(artifact))
print('MATCH' if final_sha == orig_sha else 'MISMATCH')
sys.exit(0 if final_sha == orig_sha else 4)