Attribute VB_Name = "Sheet10"
Attribute VB_Base = "0{00020820-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True
Attribute VB_Control = "cmd_OpenSimulaiton, 1, 0, MSForms, CommandButton"
Attribute VB_Control = "cmd_DefineDrug, 2, 1, MSForms, CommandButton"
Attribute VB_Control = "cmd_Run, 3, 2, MSForms, CommandButton"
Attribute VB_Control = "CboSol1, 4, 3, MSForms, ComboBox"
Attribute VB_Control = "CboSol2, 5, 4, MSForms, ComboBox"
Attribute VB_Control = "CboSol3, 6, 5, MSForms, ComboBox"
Attribute VB_Control = "CboSol4, 7, 6, MSForms, ComboBox"
Attribute VB_Control = "CboSol5, 8, 7, MSForms, ComboBox"
Attribute VB_Control = "CboSol6, 9, 8, MSForms, ComboBox"
Attribute VB_Control = "CboSol7, 10, 9, MSForms, ComboBox"
Attribute VB_Control = "CboSol8, 11, 10, MSForms, ComboBox"
Attribute VB_Control = "CboSol9, 12, 11, MSForms, ComboBox"
Attribute VB_Control = "CboSol10, 13, 12, MSForms, ComboBox"
Attribute VB_Control = "chk_IsVisible, 14, 13, MSForms, CheckBox"
Attribute VB_Control = "CboParamx, 15, 14, MSForms, ComboBox"
Attribute VB_Control = "CboParamY1, 16, 15, MSForms, ComboBox"
Attribute VB_Control = "CboParamY2, 17, 16, MSForms, ComboBox"
Attribute VB_Control = "CboParamZ, 18, 17, MSForms, ComboBox"
Attribute VB_Control = "CboKspA, 19, 18, MSForms, ComboBox"
Attribute VB_Control = "CboKspB, 21, 19, MSForms, ComboBox"
Attribute VB_Control = "CboSol11, 22, 20, MSForms, ComboBox"
Attribute VB_Control = "CboSol15, 23, 21, MSForms, ComboBox"
Attribute VB_Control = "CboSol14, 24, 22, MSForms, ComboBox"
Attribute VB_Control = "CboSol13, 25, 23, MSForms, ComboBox"
Attribute VB_Control = "CboSol12, 26, 24, MSForms, ComboBox"
Attribute VB_Control = "CboSol16, 27, 25, MSForms, ComboBox"
Attribute VB_Control = "CboSol17, 28, 26, MSForms, ComboBox"
Attribute VB_Control = "CboSol18, 29, 27, MSForms, ComboBox"
Attribute VB_Control = "CboSol19, 30, 28, MSForms, ComboBox"
Attribute VB_Control = "CboSol20, 31, 29, MSForms, ComboBox"
Attribute VB_Control = "Cmd_SetParam, 32, 30, MSForms, CommandButton"
Attribute VB_Control = "cmd_calksp, 33, 31, MSForms, CommandButton"
Attribute VB_Control = "CboKspC, 34, 32, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch1, 39, 33, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch2, 40, 34, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch3, 41, 35, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch4, 42, 36, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch5, 43, 37, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch6, 44, 38, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch7, 45, 39, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch8, 46, 40, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch9, 47, 41, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch10, 48, 42, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch11, 49, 43, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch12, 50, 44, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch13, 51, 45, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch14, 52, 46, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch15, 53, 47, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch16, 54, 48, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch17, 55, 49, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch18, 56, 50, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch19, 57, 51, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch20, 58, 52, MSForms, ComboBox"
Attribute VB_Control = "CboSol21, 59, 53, MSForms, ComboBox"
Attribute VB_Control = "CboSol25, 60, 54, MSForms, ComboBox"
Attribute VB_Control = "CboSol24, 61, 55, MSForms, ComboBox"
Attribute VB_Control = "CboSol23, 62, 56, MSForms, ComboBox"
Attribute VB_Control = "CboSol22, 63, 57, MSForms, ComboBox"
Attribute VB_Control = "CboSol26, 64, 58, MSForms, ComboBox"
Attribute VB_Control = "CboSol27, 65, 59, MSForms, ComboBox"
Attribute VB_Control = "CboSol28, 66, 60, MSForms, ComboBox"
Attribute VB_Control = "CboSol29, 67, 61, MSForms, ComboBox"
Attribute VB_Control = "CboSol30, 68, 62, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch21, 69, 63, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch22, 70, 64, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch23, 71, 65, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch24, 72, 66, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch25, 73, 67, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch26, 74, 68, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch27, 75, 69, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch28, 76, 70, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch29, 77, 71, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch30, 78, 72, MSForms, ComboBox"
Attribute VB_Control = "CommandButton1, 85, 73, MSForms, CommandButton"
Option Explicit

Const HAP_RESULTS_SUCCESS = 1
Const HAP_NORESULTS = 2
Const HAP_RESULTS_ERRORS = 3
Const HAP_RESULTS_WARNINGS = 4

Private Const SolventKind = 173
Private Const NumberofDataPoint = 30
Private Const NumberofParameter = 7

Private SolventID(SolventKind - 1) As String
Private SolventName(SolventKind - 1) As String

Dim NodeReg As IHNode
Dim NodeProp As IHNode
Dim node As IHNode
Dim NodeComp As IHNode
Dim Nodechem As IHNode
Dim NodeData As IHNode

Private Combosolvent(1 To NumberofDataPoint) As MSForms.ComboBox
Private ComboSwitch(1 To NumberofDataPoint) As MSForms.ComboBox


Dim RegFlag(NumberofParameter) As Integer
Dim RegCount As Integer
Dim Param(NumberofParameter) As Variant   ' To fit for German OS
Dim StdDev(NumberofParameter) As Double
Dim RegIndex(NumberofParameter) As Integer
Private Sub chk_IsVisible_Click()

    ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
    
        ' -- set the simulation Visible/Not Visible based on check box value --
        go_Simulation.Visible = chk_IsVisible.Value
    End If 'IsSimLoaded = True
End Sub

Private Sub cmd_calksp_Click()
Dim R As Double
R = 8314.4
Range("KspA").Value = Range("DrugS0").Value / R
Range("KspB").Value = -Range("KspA").Value * Range("DrugTm").Value
End Sub

Private Sub cmd_OpenSimulaiton_Click()
Dim lv_FilePathName As Variant

On Error GoTo ErrorHandler
    ' -- use the xlGetFilePathName subroutine to get name
    '    and path of Aspen Plus file --
    lv_FilePathName = xlGetFilePathName
    
    ' -- call xlStartSettings --
    Call xlStartSettings("Opening Simulation")
    
    ' -- check if the Cancel button was used in the
    '    File/Open dialogue box --
    If lv_FilePathName <> False Then
        
        ' -- check to see if simulation is loaded --
        If IsSimLoaded = True Then
            
            ' -- set the simulation to Not Visible so it can be closed --
            go_Simulation.Visible = False
            
            ' -- close simulation --
            go_Simulation.Close
            Set go_Simulation = Nothing
        End If 'IsSimLoaded = True
        
        ' -- open the selected Aspen Plus File --
        Set go_Simulation = GetObject(lv_FilePathName)
        
        ' -- write the FilePathName to the workbook --
        ActiveSheet.Range("FilePath").Value = lv_FilePathName
        
        ' -- make the Aspen Plus GUI Visible/Not Visible based on check box value --
        go_Simulation.Visible = chk_IsVisible.Value
    End If 'lv_FilePathName <> False
    
    ' -- call xlEndSettings --
    Call xlEndSettings
    
    Call LoadCompList
Exit Sub
ErrorHandler:
MsgBox "Error in opening file" & Err & ":" & Error(Err)
End Sub

Private Sub cmd_DefineDrug_Click()
    
    Dim R As Double
    Dim ParamA As Double
    Dim ParamB As Double
    Dim ParamC As Double
    R = 8314.4 'J/Kmole-K
    
    'Prompt to run step 1 first if the simulation hasn't been loaded.
    If go_Simulation Is Nothing Then
    MsgBox "Please run Step 1 to load the simulation first!", 1, "Please Load Simulation First"
    Exit Sub
    End If
    
    On Error GoTo ErrorHandler
  
    '-- Set MW for DRUG -
    Set node = go_Simulation.Tree.Data
    
    If (Range("DrugName").Value = "" Or Range("DrugName").Value = " ") Then
    Else
        node.FindNode("\Components\Specifications\Comments\#0").Value = Range("DrugName").Value
    End If
    
    If (Range("DrugMW").Value = "" Or Range("DrugMW").Value = " ") Then
    Else
        node.FindNode("Properties\Parameters\Pure Components\MW\Input\VALUE\(MW,DRUG)").Value = Range("DrugMW").Value
        node.FindNode("Properties\Parameters\Pure Components\MW\Input\VALUE\(MW,SOLID)").Value = Range("DrugMW").Value
      
    End If
    
    If (Range("DrugTm").Value = "" Or Range("DrugTm").Value = " ") Then
    Else
        If (Range("DrugS0").Value = "" Or Range("DrugS0").Value = " ") Then
           If (Range("DrugH0").Value = "" Or Range("DrugH0").Value = " ") Then
           MsgBox (" Please input the entropy or the enthalpy of fusion")
           Else
           Range("DrugS0").Value = Range("DrugH0").Value * 1000 / Range("DrugTm").Value
           End If
        Else
           Range("DrugH0").Value = Range("DrugS0").Value * Range("DrugTm").Value / 1000
        End If
        
        Range("KspC").Value = 0
         ' set default value for Ksp C
         
        ParamA = Range("DrugS0").Value / R
        ParamB = -ParamA * Range("DrugTm").Value
        ParamC = Range("KspC").Value
        
        node.FindNode("Chemistry\SOLID\Input\K_A\SOLID").Value = ParamA
        node.FindNode("Chemistry\SOLID\Input\K_B\SOLID").Value = ParamB
        node.FindNode("Chemistry\SOLID\Input\K_C\SOLID").Value = ParamC
        
    End If
    'MsgBox ("Drug name, MW, and Ksp are defined")
    
   
Exit Sub
ErrorHandler:
MsgBox "Error in defining drug" & Err & ":" & Error(Err)
End Sub

Private Sub Cmd_SetParam_Click()
   Dim FilePath As String
   Dim FileName As String
   Dim flag As Long
   Dim iap As IAPPDF
  
   'Prompt to run step 1 first if the simulation hasn't been loaded.
    If go_Simulation Is Nothing Then
    MsgBox "Please Run Step 1 To Load The Simulation First!", 1, "Please Load Simulation First"
    Exit Sub
    End If
   
   On Error GoTo ErrorHandler
   FilePath = Range("FilePath").Value
   FileName = Left(FilePath, InStr(FilePath, ".aprbkp"))
   Set node = go_Simulation.Tree.Data
  ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
    
        ' -- put the model parameters --
        Call PutModelParam
        
        Call go_Simulation.SaveAs(FileName + "aprbkp")
          
        ' -- call xlEndSettings --
        Call xlEndSettings
        'MsgBox ("Estimated parameters are entered")
    
     End If 'IsSimLoaded = True
Exit Sub
ErrorHandler:
MsgBox "Error in updating parameters" & Err & ":" & Error(Err)
End Sub
Private Sub cmd_Run_Click()
    Dim flag
    Dim FilePath As String
    Dim FileName As String
    Dim flag1 As Long
    Dim iap As IAPPDF
    Dim i As Integer
    Dim sInput As String
    
    'Prompt to run step 1 first if the simulation hasn't been loaded.
    If go_Simulation Is Nothing Then
    MsgBox "Please Run Step 1 To Load The Simulation First!", 1, "Please Load Simulation First"
    Exit Sub
    End If
    
  ' check the rangenames
    Range("$a$8").Name = "DrugName"
    Range("$B$8").Name = "DrugMW"
    Range("$C$8").Name = "DrugTm"
    Range("$D$8").Name = "DrugH0"
    Range("$E$8").Name = "DrugS0"
    Range("$A$13").Name = "ParamX"
    Range("$B$13").Name = "ParamY1"
    Range("$C$13").Name = "ParamY2"
    Range("$D$13").Name = "ParamZ"
    Range("$E$13").Name = "KspA"
    Range("$F$13").Name = "KspB"
    Range("$G$13").Name = "KspC"
    
    For i = 1 To NumberofDataPoint
      Range("$B$" & 23 + i).Name = "Temp" & i
      Range("$C$" & 23 + i).Name = "Solubility" & i
      Range("$D$" & 23 + i).Name = "Std_dev" & i
      Range("$I$" & 23 + i).Name = "TempEst" & i
      Range("$J$" & 23 + i).Name = "SoluEst" & i
    Next i
   
    Range("$M$23").Name = "ParamXEst"
    Range("$M$24").Name = "ParamY1Est"
    Range("$M$25").Name = "ParamY2Est"
    Range("$M$26").Name = "ParamZEst"
    Range("$M$27").Name = "KspAEst"
    Range("$M$28").Name = "KspBEst"
    Range("$M$29").Name = "KspCEst"
    Range("$N$23").Name = "StdDevX"
    Range("$N$24").Name = "StdDevY1"
    Range("$N$25").Name = "StdDevY2"
    Range("$N$26").Name = "StdDevZ"
    Range("$N$27").Name = "StdDevKspA"
    Range("$N$28").Name = "StdDevKspB"
    Range("$N$29").Name = "StdDevKspC"
    Range("$M$31").Name = "SumWeight"
    
    
'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!incase user changes the regress/exclude manually.
    
    Set NodeProp = go_Simulation.Tree.Data.Properties

    'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Input\USAGE\#0")
    Set node = NodeProp.FindNode("Regression\PURE\Input\USAGE\#0")
    node.Value = CboParamx.Text
    'NodeProp.Regression.Elements("PURE").Input.Elements("USAGE").Elements(0).Value = CboParamx.Text
    
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#1").Value = CboParamY1.Text
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#2").Value = CboParamY2.Text
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#3").Value = CboParamZ.Text
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#4").Value = CboKspA.Text
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#5").Value = CboKspB.Text
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#6").Value = CboKspC.Text
'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
    On Error GoTo ErrorHandler
    FilePath = Range("FilePath").Value
    FileName = Left(FilePath, InStr(FilePath, ".aprbkp"))
    Set node = go_Simulation.Tree.Data
    ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
        flag = MsgBox("DRS run will override the current parameters. Please select the ""PURE"" case when being prompted.", 1, "Run DRS")
      If (flag = 2) Then
        Exit Sub 'Msgbox Cancel
      Else
        ' -- call xlStartSettings --
        Call xlStartSettings("Running Simulation")
        
        ' -- turn off messages resulting from a long Aspen Plus run --
        Application.DisplayAlerts = False
        
        'Set the run class to DRS
        node.FindNode("Setup\Main\Input\RUN_CLASS").Value = "DRS"
        
        ' -- put the Input Values --
        Call PutInputValues
        
        go_Simulation.Activate
        
        ' -- turn Interactively Load Results off --
        go_Simulation.Engine.OptionSettings(IAP_RUN_INTERTACTIVE) = False
        
        ' -- suppress the dialog box for DRS runs --
        go_Simulation.SuppressDialogs = False
        
        ' -- run the simulation --
        go_Simulation.Engine.Run
        '
        ' Call COM
        '
        sInput = "xlmain" + " " + Application.Caption
        Call COMAddinHelper.Invoke("APXL_SetForegroundWindow", sInput)
        
        
       'Application.Cursor = xlWait
      
        
        ' -- get the Output Values --
        Call GetOutputValues
        
        
        go_Simulation.SuppressDialogs = True
        Call go_Simulation.SaveAs(FileName + "aprbkp")

        If chk_IsVisible.Value = False Then go_Simulation.Visible = False
         
        ' -- call xlEndSettings --
        Call xlEndSettings
        
        go_Simulation.Engine.Stop
        go_Simulation.SuppressDialogs = False
        
       End If 'msgbox OK

    End If 'IsSimLoaded = True
Exit Sub

ErrorHandler:
Application.Cursor = xlDefault
go_Simulation.SuppressDialogs = True
go_Simulation.Visible = False
'MsgBox "Error in running DRS" & Err & ":" & Error(Err)
MsgBox "Error in running DRS for Pure Solvents. This normally happens when you run the second DRS. You can re-run DRS for Pure Solvents by re-opening the regression file"
go_Simulation.Engine.Stop
go_Simulation.SuppressDialogs = False

End Sub
Private Sub LoadCompList()

    Dim NOlig As Integer
    Dim NCC As Integer
    Dim i As Integer
    Dim j As Integer
    Dim Conventional As String
    Dim count As Integer
    
    On Error GoTo ErrorHandler
    
    For i = 1 To NumberofDataPoint
        Set Combosolvent(i) = Sheet10.OLEObjects("CboSol" & i).Object
        Set ComboSwitch(i) = Sheet10.OLEObjects("CboSwitch" & i).Object
    Next i
    
    count = CboSol1.ListCount
    If (count = 0) Then
        For i = 0 To SolventKind - 1
            SolventName(i) = Sheets("Solvent List").Range("SolventName").Item(i + 1).Value
            SolventID(i) = Sheets("Solvent List").Range("SolventID").Item(i + 1).Value
            
            For j = 1 To NumberofDataPoint
                Combosolvent(j).AddItem (SolventName(i))
            Next j
           
        Next i
        
        'Add empty string for "clear"
    
        For j = 1 To NumberofDataPoint
            Combosolvent(j).AddItem ("")
        Next j
        
        
        'Load option list for Parameter regression
        CboParamx.Font.Bold = False
        CboParamY1.Font.Bold = False
        CboParamY2.Font.Bold = False
        CboParamZ.Font.Bold = False
        CboKspA.Font.Bold = False
        CboKspB.Font.Bold = False
        CboKspC.Font.Bold = False
        
        CboParamx.AddItem ("REGRESS")
        CboParamY1.AddItem ("REGRESS")
        CboParamY2.AddItem ("REGRESS")
        CboParamZ.AddItem ("REGRESS")
        CboKspA.AddItem ("REGRESS")
        CboKspB.AddItem ("REGRESS")
        CboKspC.AddItem ("REGRESS")
        CboParamx.AddItem ("EXCLUDE")
        CboParamY1.AddItem ("EXCLUDE")
        CboParamY2.AddItem ("EXCLUDE")
        CboParamZ.AddItem ("EXCLUDE")
        CboKspA.AddItem ("EXCLUDE")
        CboKspB.AddItem ("EXCLUDE")
        CboKspC.AddItem ("EXCLUDE")
        
        For j = 1 To NumberofDataPoint
            ComboSwitch(j).AddItem ("Yes")
            ComboSwitch(j).AddItem ("No")
        Next j
            
        'initialize Parameter regression for Excel and bkp
    '    CboParamx.Text = "REGRESS"
    '    CboParamY1.Text = "REGRESS"
    '    CboParamY2.Text = "REGRESS"
    '    CboParamZ.Text = "REGRESS"
    '    CboKspA.Text = "REGRESS"
    '    CboKspB.Text = "EXCLUDE"
    '    CboKspC.Text = "EXCLUDE"
    '
    '    CboSwitch1.Text = "Yes"
    '    CboSwitch2.Text = "Yes"
    '    CboSwitch3.Text = "Yes"
    '    CboSwitch4.Text = "Yes"
    '    CboSwitch5.Text = "Yes"
    '    CboSwitch6.Text = "Yes"
    '    CboSwitch7.Text = "Yes"
    '    CboSwitch8.Text = "Yes"
    '    CboSwitch9.Text = "Yes"
    '    CboSwitch10.Text = "Yes"
    '    CboSwitch11.Text = "Yes"
    '    CboSwitch12.Text = "Yes"
    '    CboSwitch13.Text = "Yes"
    '    CboSwitch14.Text = "Yes"
    '    CboSwitch15.Text = "Yes"
    '    CboSwitch16.Text = "Yes"
    '    CboSwitch17.Text = "Yes"
    '    CboSwitch18.Text = "Yes"
    '    CboSwitch19.Text = "Yes"
    '    CboSwitch20.Text = "Yes"
    '    CboSwitch21.Text = "Yes"
    '    CboSwitch22.Text = "Yes"
    '    CboSwitch23.Text = "Yes"
    '    CboSwitch24.Text = "Yes"
    '    CboSwitch25.Text = "Yes"
    '    CboSwitch26.Text = "Yes"
    '    CboSwitch27.Text = "Yes"
    '    CboSwitch28.Text = "Yes"
    '    CboSwitch29.Text = "Yes"
    '    CboSwitch30.Text = "Yes"
    '
    '    Dim NodeProp As IHNode
    '    Set NodeProp = go_Simulation.Tree.Data.Properties
    '    For j = 0 To 4
    '    NodeProp.Regression.Elements("PURE").Input.Elements("USAGE").Elements(j).Value = "REGRESS"
    '    Next j
    '    NodeProp.Regression.Elements("PURE").Input.Elements("USAGE").Elements(5).Value = "EXCLUDE"
    '    NodeProp.Regression.Elements("PURE").Input.Elements("USAGE").Elements(6).Value = "EXCLUDE"
        
    End If
  
    If SolventName(1) = "" Then
        For i = 0 To SolventKind - 1
            SolventName(i) = Sheets("Solvent List").Range("SolventName").Item(i + 1).Value
            SolventID(i) = Sheets("Solvent List").Range("SolventID").Item(i + 1).Value
        Next i
    End If
    
Exit Sub
ErrorHandler:
MsgBox "Error in loading component list" & Err & ":" & Error(Err)
End Sub
Public Sub PutModelParam()
    
    Dim R As Double
    R = 8314.4   'J/(kmol*k)
    
    On Error GoTo ErrorHandler
    
    Set NodeProp = go_Simulation.Tree.Data.Properties
    Set Nodechem = go_Simulation.Tree.Data.Chemistry
    
    '-- Set x, y-, y+, z parameters for PURE ---
    If (Range("ParamX").Value = "" Or Range("ParamX").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL1\XYZE\DRUG").Value = Range("ParamX").Value
    End If
    
    If (Range("ParamY1").Value = "" Or Range("ParamY1").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL2\XYZE\DRUG").Value = Range("ParamY1").Value
    End If
    
    If (Range("ParamY2").Value = "" Or Range("ParamY2").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL3\XYZE\DRUG").Value = Range("ParamY2").Value
    End If
    
    If (Range("ParamZ").Value = "" Or Range("ParamZ").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL4\XYZE\DRUG").Value = Range("ParamZ").Value
    End If
     
    '-- Set KspA parameters for Chemistry ---
     'Application.Tree.Data.Chemistry.C-NRTL.Input.K_A.SOLID
     'If (Range("KspA").Value = "" Or Range("KspA").Value = " ") Then
   '  Range("KspA").Value = Range("DrugS0").Value / R
   '  Range("KspB").Value = -Range("DrugH") / R

    'Else
         Nodechem.FindNode("SOLID\Input\K_A\SOLID").Value = Range("KspA").Value
         Nodechem.FindNode("SOLID\Input\K_B\SOLID").Value = Range("KspB").Value
         Nodechem.FindNode("SOLID\Input\K_C\SOLID").Value = Range("KspC").Value
    'End If
Exit Sub
ErrorHandler:
MsgBox "Error in setting parameters" & Err & ":" & Error(Err)
End Sub

Private Sub CloseSimulation()
    'Dim lv_FilePathName As Variant

    'lv_FilePathName = xlGetFilePathName
    
    ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
    
        ' --Export the aprbkp file
        'Call go_Simulation.Export(HAPEXP_BACKUP, lv_FilePathName)
        Call go_Simulation.Save
        
        ' -- call xlStartSettings --
        Call xlStartSettings("Closing Simulation")
        
        ' -- set the simulation to Not Visible so it can be closed --
        go_Simulation.Visible = False
        
        ' -- close simulation --
        go_Simulation.Close
        Set go_Simulation = Nothing
        
        ' Update aprpdf used by the xla
        'Call xlStartSettings("Updating aprpdf file")
        'Worksheets("Define solute").Range("F1").Formula = "=RefreshBkpPackage()"
        'Worksheets("Define solute").Range("F1").Formula = ""

        ' -- delete displayed name of simulation --
        'Worksheets("Define solute").Range("A5").Value = ""
        
        ' -- call xlEndSettings --
        'Call xlEndSettings
    End If 'IsSimLoaded = True
End Sub
Public Sub PutInputValues()

   
    Dim X As Double
    Dim i As Integer
    Dim Solu(NumberofDataPoint) As Double
    
    On Error GoTo ErrorHandler
    
    Set NodeProp = go_Simulation.Tree.Data.Properties
    Set NodeReg = go_Simulation.Tree.Data.Properties.Regression
    Set Nodechem = go_Simulation.Tree.Data.Chemistry
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    
    Call CleanUpResults
    
    For i = 1 To NumberofDataPoint
    
        Solu(i) = Range("Solubility" & i).Value / (1 + Range("Solubility" & i).Value)
        
        'Init weight factor for DRS
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Input\WEIGHT\SOL41")
        Set node = NodeReg.FindNode("PURE\Input\WEIGHT\SOL" & 40 + i)
        node.Value = 0.0000000001
        'NodeReg.Elements("PURE").Input.Elements("WEIGHT").Elements("SOL" & 40 + i).Value = 0.0000000001
        
        ' -- Set Temperature (Exp) for solvents --
        If (Range("Temp" & i).Value = "" Or Range("Temp" & i).Value = " ") Then
        Else
            NodeProp.FindNode("Data\SOL" & 40 + i & "\Input\VALUE\(#1,TEMPERATURE,C)").Value = Range("Temp" & i).Value
        End If
        
    Next i
  
    ' -- Set Solubility (Exp) for solvents --
    For i = 1 To NumberofDataPoint
        If (Range("Solubility" & i).Value = "" Or Range("Solubility" & i).Value = " ") Then
        Else
          'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\VALUE\#1 X DRUG")
          Set node = NodeProp.FindNode("Data\SOL" & 40 + i & "\Input\VALUE\(#1,X,DRUG)")
          node.Value = Solu(i)
          'NodeProp.Data.Elements("SOL" & 40 + i).Input.Elements("VALUE").Elements(1, X, "DRUG").Value = Solu(i)
    
          Set node = NodeProp.FindNode("Data\SOL" & 40 + i & "\Input\VALUE\(#0,X,DRUG)")
          node.Value = Range("Std_Dev" & i) & "%"
          'NodeProp.Data.Elements("SOL" & 40 + i).Input.Elements("VALUE").Elements(0, x, "DRUG").Value = Range("Std_Dev" & i) & "%"
          
          'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Input\WEIGHT\SOL41")
          If (ComboSwitch(i).Text <> "No") Then
              Set node = NodeReg.FindNode("PURE\Input\WEIGHT\SOL" & 40 + i)
              node.Value = 1
              'NodeReg.Elements("PURE").Input.Elements("WEIGHT").Elements("SOL" & 40 + i).Value = 1
          End If
          
        End If
    Next i
    
    '
    'On Error Resume Next
     
    For i = 1 To NumberofDataPoint
        If (Combosolvent(i).Text = "" Or Combosolvent(i).Text = " ") Then
        Combosolvent(i).Text = ""
        Else
            If FindSolventID(Combosolvent(i).Text) <> "" Then
               'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\CIDS\#1")
                Set node = NodeData.FindNode("SOL" & 40 + i & "\Input\CIDS\#1")
                node.Value = FindSolventID(Combosolvent(i).Text)
                'NodeData.Elements("SOL" & 40 + i).Input.Elements("CIDS").Elements(1).Value = FindSolventID(Combosolvent(i).Text)
            Else
                If ComboSwitch(i).Value <> "No" Then ComboSwitch(i).Value = "No"
            End If
        End If
    Next i
    
    Call SetRegressionWeight
    
    'Set Regression flag, counter, and indexed parameters
    
    For i = 1 To 4
    RegFlag(i) = 0
    Param(i) = 0
    RegIndex(i) = 0
    StdDev(i) = 0
    Next i
    
    RegFlag(5) = 0
    RegIndex(5) = 0
    StdDev(5) = 0
   ' RegCount = 0
    
    RegFlag(6) = 0
    RegIndex(6) = 0
    StdDev(6) = 0
   ' RegCount = 0
    
    RegFlag(7) = 0
    RegIndex(7) = 0
    StdDev(7) = 0
    RegCount = 0
    
    
    If (CboParamx.Text = "REGRESS") Then
      RegFlag(1) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 1
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,X-R)").Value = 0#
    End If
    
    If (CboParamY1.Text = "REGRESS") Then
      RegFlag(2) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 2
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,Y-R)").Value = 0#
    End If
    
    If (CboParamY2.Text = "REGRESS") Then
      RegFlag(3) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 3
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,Y+R)").Value = 0#
    End If
    
    If (CboParamZ.Text = "REGRESS") Then
      RegFlag(4) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 4
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,Z-R)").Value = 0#
    End If
    
    If (CboKspA.Text = "REGRESS") Then
      RegFlag(5) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 5
    End If
    
    If (CboKspB.Text = "REGRESS") Then
      RegFlag(6) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 6
    End If
    
    If (CboKspC.Text = "REGRESS") Then
      RegFlag(7) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 7
    End If
    
Exit Sub
ErrorHandler:
MsgBox "Error in setting input data" & Err & ":" & Error(Err)
    
End Sub


Private Sub CboSol1_Change()
'    Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL41").Input.Elements("CIDS")
    If (CboSol1.Text = "" Or CboSol1.Text = " ") Then
        CboSol1.Text = ""
    Else
        If FindSolventID(CboSol1.Text) <> "" Then
            CboSwitch1.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL41\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL41\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol1.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol1.Text)
        Else
            CboSwitch1.Value = "No"
        End If
    End If
    
End Sub
Private Sub CboSol2_Change()
'    Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL42").Input.Elements("CIDS")
    If (CboSol2.Text = "" Or CboSol2.Text = " ") Then
        CboSol2.Text = ""
    Else
        If FindSolventID(CboSol2.Text) <> "" Then
            CboSwitch2.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL42\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL42\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol2.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol2.Text)
        Else
            CboSwitch2.Value = "No"
        End If
    End If

End Sub
Private Sub CboSol3_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL43").Input.Elements("CIDS")
    If (CboSol3.Text = "" Or CboSol3.Text = " ") Then
        CboSol3.Text = ""
    Else
        If FindSolventID(CboSol3.Text) <> "" Then
            CboSwitch3.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL43\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL43\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol3.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol3.Text)
        Else
            CboSwitch3.Value = "No"
        End If
    End If

End Sub
Private Sub CboSol4_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL44").Input.Elements("CIDS")
    If (CboSol4.Text = "" Or CboSol4.Text = " ") Then
        CboSol4.Text = ""
    Else
        If FindSolventID(CboSol4.Text) <> "" Then
            CboSwitch4.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL44\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL44\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol4.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol4.Text)
        Else
            CboSwitch4.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol5_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL45").Input.Elements("CIDS")
    
    If (CboSol5.Text = "" Or CboSol5.Text = " ") Then
        CboSol5.Text = ""
    Else
        If FindSolventID(CboSol5.Text) <> "" Then
            CboSwitch5.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL45\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL45\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol5.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol5.Text)
        Else
            CboSwitch5.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol6_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL46").Input.Elements("CIDS")
    If (CboSol6.Text = "" Or CboSol6.Text = " ") Then
        CboSol6.Text = ""
        'go_Simulation.Tree.Data.Properties.Data.Elements("SOL1").Input.Elements("CIDS").Elements(1).Value = ""
    Else
        If FindSolventID(CboSol6.Text) <> "" Then
            CboSwitch6.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL46\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL46\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol6.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol6.Text)
        Else
            CboSwitch6.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol7_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL47").Input.Elements("CIDS")
    If (CboSol7.Text = "" Or CboSol7.Text = " ") Then
        CboSol7.Text = ""
    Else
        If FindSolventID(CboSol7.Text) <> "" Then
            CboSwitch7.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL47\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL47\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol7.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol7.Text)
        Else
            CboSwitch7.Value = "No"
        End If
    End If
    
End Sub
Private Sub CboSol8_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL48").Input.Elements("CIDS")
    If (CboSol8.Text = "" Or CboSol8.Text = " ") Then
        CboSol8.Text = ""
    Else
        If FindSolventID(CboSol8.Text) <> "" Then
            CboSwitch8.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL48\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL48\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol8.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol8.Text)
        Else
            CboSwitch8.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol9_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL49").Input.Elements("CIDS")
    If (CboSol9.Text = "" Or CboSol9.Text = " ") Then
        CboSol9.Text = ""
    Else
        If FindSolventID(CboSol9.Text) <> "" Then
            CboSwitch9.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL49\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL49\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol9.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol9.Text)
        Else
            CboSwitch9.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol10_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL50").Input.Elements("CIDS")
    
    If (CboSol10.Text = "" Or CboSol10.Text = " ") Then
        CboSol10.Text = ""
    Else
        If FindSolventID(CboSol10.Text) <> "" Then
            CboSwitch10.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL50\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL50\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol10.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol10.Text)
        Else
            CboSwitch10.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol11_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL51").Input.Elements("CIDS")
    
    If (CboSol11.Text = "" Or CboSol11.Text = " ") Then
        CboSol11.Text = ""
    Else
        If FindSolventID(CboSol11.Text) <> "" Then
            CboSwitch11.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL51\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL51\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol11.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol11.Text)
        Else
            CboSwitch11.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol12_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL52").Input.Elements("CIDS")
    
    If (CboSol12.Text = "" Or CboSol12.Text = " ") Then
        CboSol12.Text = ""
    Else
        If FindSolventID(CboSol12.Text) <> "" Then
            CboSwitch12.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL52\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL52\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol12.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol12.Text)
        Else
            CboSwitch12.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol13_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL53").Input.Elements("CIDS")
    
    If (CboSol13.Text = "" Or CboSol13.Text = " ") Then
        CboSol13.Text = ""
    Else
        If FindSolventID(CboSol13.Text) <> "" Then
            CboSwitch13.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL53\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL53\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol13.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol13.Text)
        Else
            CboSwitch13.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol14_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL54").Input.Elements("CIDS")
    
    If (CboSol14.Text = "" Or CboSol14.Text = " ") Then
        CboSol14.Text = ""
    Else
        If FindSolventID(CboSol14.Text) <> "" Then
            CboSwitch14.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL54\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL54\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol14.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol14.Text)
        Else
            CboSwitch14.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol15_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL55").Input.Elements("CIDS")
    
    If (CboSol15.Text = "" Or CboSol15.Text = " ") Then
        CboSol15.Text = ""
    Else
        If FindSolventID(CboSol15.Text) <> "" Then
            CboSwitch15.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL55\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL55\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol15.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol15.Text)
        Else
            CboSwitch15.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol16_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL56").Input.Elements("CIDS")
    
    If (CboSol16.Text = "" Or CboSol16.Text = " ") Then
        CboSol16.Text = ""
    Else
        If FindSolventID(CboSol16.Text) <> "" Then
            CboSwitch16.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL56\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL56\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol16.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol16.Text)
        Else
            CboSwitch16.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol17_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL57").Input.Elements("CIDS")
    
    If (CboSol17.Text = "" Or CboSol17.Text = " ") Then
        CboSol17.Text = ""
    Else
        If FindSolventID(CboSol17.Text) <> "" Then
            CboSwitch17.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL57\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL57\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol17.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol17.Text)
        Else
            CboSwitch17.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol18_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL58").Input.Elements("CIDS")
    
    If (CboSol18.Text = "" Or CboSol18.Text = " ") Then
        CboSol18.Text = ""
    Else
        If FindSolventID(CboSol18.Text) <> "" Then
            CboSwitch18.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL58\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL58\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol18.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol18.Text)
        Else
            CboSwitch18.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol19_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL59").Input.Elements("CIDS")
    
    If (CboSol19.Text = "" Or CboSol19.Text = " ") Then
        CboSol19.Text = ""
    Else
        If FindSolventID(CboSol19.Text) <> "" Then
            CboSwitch19.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL59\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL59\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol19.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol19.Text)
        Else
            CboSwitch19.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol20_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL60").Input.Elements("CIDS")
    
    If (CboSol20.Text = "" Or CboSol20.Text = " ") Then
        CboSol20.Text = ""
    Else
        If FindSolventID(CboSol20.Text) <> "" Then
            CboSwitch20.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL60\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL60\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol20.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol20.Text)
        Else
            CboSwitch20.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol21_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL61").Input.Elements("CIDS")
    
    If (CboSol21.Text = "" Or CboSol21.Text = " ") Then
        CboSol21.Text = ""
    Else
        If FindSolventID(CboSol21.Text) <> "" Then
            CboSwitch21.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL61\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL61\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol21.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol21.Text)
        Else
            CboSwitch21.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol22_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL62").Input.Elements("CIDS")
    
    If (CboSol22.Text = "" Or CboSol22.Text = " ") Then
        CboSol22.Text = ""
    Else
        If FindSolventID(CboSol22.Text) <> "" Then
            CboSwitch22.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL62\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL62\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol22.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol22.Text)
        Else
            CboSwitch22.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol23_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL63").Input.Elements("CIDS")
    
    If (CboSol23.Text = "" Or CboSol23.Text = " ") Then
        CboSol23.Text = ""
    Else
        If FindSolventID(CboSol23.Text) <> "" Then
            CboSwitch23.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL63\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL63\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol23.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol23.Text)
        Else
            CboSwitch23.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol24_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL64").Input.Elements("CIDS")
    
    If (CboSol24.Text = "" Or CboSol24.Text = " ") Then
        CboSol24.Text = ""
    Else
        If FindSolventID(CboSol24.Text) <> "" Then
            CboSwitch24.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL64\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL64\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol24.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol24.Text)
        Else
            CboSwitch24.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol25_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL65").Input.Elements("CIDS")
    
    If (CboSol25.Text = "" Or CboSol25.Text = " ") Then
        CboSol25.Text = ""
    Else
        If FindSolventID(CboSol25.Text) <> "" Then
            CboSwitch25.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL65\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL65\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol25.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol25.Text)
        Else
            CboSwitch25.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol26_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL66").Input.Elements("CIDS")
    
    If (CboSol26.Text = "" Or CboSol26.Text = " ") Then
        CboSol26.Text = ""
    Else
        If FindSolventID(CboSol26.Text) <> "" Then
            CboSwitch26.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL66\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL66\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol26.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol26.Text)
        Else
            CboSwitch26.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol27_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL67").Input.Elements("CIDS")
    
    If (CboSol27.Text = "" Or CboSol27.Text = " ") Then
        CboSol27.Text = ""
    Else
        If FindSolventID(CboSol27.Text) <> "" Then
            CboSwitch27.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL67\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL67\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol27.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol27.Text)
        Else
            CboSwitch27.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol28_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL68").Input.Elements("CIDS")
    
    If (CboSol28.Text = "" Or CboSol28.Text = " ") Then
        CboSol28.Text = ""
    Else
        If FindSolventID(CboSol28.Text) <> "" Then
            CboSwitch28.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL68\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL68\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol28.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol28.Text)
        Else
            CboSwitch28.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol29_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL69").Input.Elements("CIDS")
    
    If (CboSol29.Text = "" Or CboSol29.Text = " ") Then
        CboSol29.Text = ""
    Else
        If FindSolventID(CboSol29.Text) <> "" Then
            CboSwitch29.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL69\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL69\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol29.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol29.Text)
        Else
            CboSwitch29.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol30_Change()
    'Dim NodeData As IHNode

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL70").Input.Elements("CIDS")
    
    If (CboSol30.Text = "" Or CboSol30.Text = " ") Then
        CboSol30.Text = ""
    Else
        If FindSolventID(CboSol30.Text) <> "" Then
            CboSwitch30.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL70\Input\CIDS\#1")
            Set node = NodeData.FindNode("SOL70\Input\CIDS\#1")
            node.Value = FindSolventID(CboSol30.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol30.Text)
        Else
            CboSwitch30.Value = "No"
        End If
    End If
End Sub


Private Sub CboParamX_Change()
 
    On Error Resume Next
    Set NodeProp = go_Simulation.Tree.Data.Properties

    NodeProp.FindNode("Regression\PURE\Input\USAGE\#0").Value = CboParamx.Text
    'NodeProp.Regression.Elements("PURE").Input.Elements("USAGE").Elements(0).Value = CboParamx.Text
    
End Sub
Private Sub CboParamY1_Change()

    
    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#1").Value = CboParamY1.Text
    
End Sub
Private Sub CboParamY2_Change()
    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#2").Value = CboParamY2.Text
    
End Sub
Private Sub CboParamZ_Change()
    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#3").Value = CboParamZ.Text
    
End Sub
Private Sub CboKspA_Change()
    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#4").Value = CboKspA.Text
End Sub

Private Sub CboKspB_Change()
    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#5").Value = CboKspB.Text
End Sub

Private Sub CboKspC_Change()
    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\PURE\Input\USAGE\#6").Value = CboKspC.Text
End Sub


Public Sub GetOutputValues()

    Dim i As Integer
    Dim Rstatus As String
    Dim SoluResult(NumberofDataPoint) As Double
    
    
    Set NodeReg = go_Simulation.Tree.Data.Properties.Regression
    Set NodeProp = go_Simulation.Tree.Data.Properties
    Set Nodechem = go_Simulation.Tree.Data.Chemistry
    ' -- Get x, y-, y+, z parameters for "PURE" --
    Rstatus = status(NodeReg.AttributeValue(HAP_COMPSTATUS))
    If (Rstatus = "DRS Success" Or Rstatus = "DRS Warning") Then
    
        For i = 1 To 4
            Param(i) = NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL" & i & "\XYZE\DRUG").Value
        Next i
          
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Output\ESTVALUE2\1")
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Output\STAND_DEV2\1")
        For i = 0 To RegCount - 1
            Set node = NodeReg.FindNode("PURE\Output\ESTVALUE2\" & i + 1)
            Param(RegIndex(i + 1)) = node.Value
            'Param(RegIndex(i + 1)) = NodeReg.Elements("PURE").Output.Elements("ESTVALUE2").Elements(i).Value
            
            Set node = NodeReg.FindNode("PURE\Output\STAND_DEV2\" & i + 1)
            StdDev(RegIndex(i + 1)) = node.Value
            'StdDev(RegIndex(i + 1)) = NodeReg.Elements("PURE").Output.Elements("STAND_DEV2").Elements(i).Value
        Next i
        
        Range("paramxEst").Value = Param(1)
        Range("paramy1Est").Value = Param(2)
        Range("paramy2Est").Value = Param(3)
        Range("paramzEst").Value = Param(4)
    
    
        Range("StdDevX").Value = StdDev(1)
        Range("StdDevY1").Value = StdDev(2)
        Range("StdDevY2").Value = StdDev(3)
        Range("StdDevZ").Value = StdDev(4)
    
        'Don't override the initial guess
        'Range("paramx").Value = Param(1)
        'Range("paramy1").Value = Param(2)
        'Range("paramy2").Value = Param(3)
        'Range("paramz").Value = Param(4)

   
        If (RegFlag(5) = 1) Then
            Range("KspAEst").Value = Param(5)
            Range("StdDevKspA").Value = StdDev(5)
            Nodechem.FindNode("SOLID\Input\K_A\SOLID").Value = Param(5)
            'Range("KspA").Value = Param(5)
        Else
            Range("KspAEst").Value = Nodechem.FindNode("SOLID\Input\K_A\SOLID").Value
            Range("StdDevKspA").Value = 0
            'Range("KspA").Value = ""
        End If
        
        If (RegFlag(6) = 1) Then
            Range("KspBEst").Value = Param(6)
            Range("StdDevKspB").Value = StdDev(6)
            Nodechem.FindNode("SOLID\Input\K_B\SOLID").Value = Param(6)
            'Range("KspA").Value = Param(6)
        Else
            Range("KspBEst").Value = Nodechem.FindNode("SOLID\Input\K_B\SOLID").Value
            Range("StdDevKspB").Value = 0
            'Range("KspA").Value = ""
        End If
            
        If (RegFlag(7) = 1) Then
            Range("KspCEst").Value = Param(7)
            Range("StdDevKspC").Value = StdDev(7)
            Nodechem.FindNode("SOLID\Input\K_C\SOLID").Value = Param(7)
            'Range("KspA").Value = Param(6)
        Else
            Range("KspCEst").Value = Nodechem.FindNode("SOLID\Input\K_C\SOLID").Value
            Range("StdDevKspC").Value = 0
            'Range("KspA").Value = ""
        End If
        
        ' -- Get Solubility (Est) and Temperature (Est) for solvents
        
        For i = 1 To NumberofDataPoint
            If (Range("Solubility" & i).Value = "" Or Range("Solubility" & i).Value = " ") Then
'            Range("SoluEst1").Formula = "=na()"
            Else
            SoluResult(i) = NodeReg.FindNode("PURE\Output\Prop Data\PROFILE\SOL" & 40 + i & "\(Est Val MASSFRAC X DRUG,1)").Value
            Range("SoluEst" & i).Value = SoluResult(i) / (1 - SoluResult(i))
            Range("TempEst" & i).Value = _
            NodeReg.FindNode("PURE\Output\Prop Data\PROFILE\SOL" & 40 + i & "\(Est Val TEMP,1)").Value
            End If
        Next i
        
         'Sum of square
    
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Output\SIGMAMX")
        Set node = NodeReg.FindNode("PURE\Output\SIGMAMX")
        Range("SumWeight").Value = node.Value
        'Range("SumWeight").Value = NodeReg.Elements("PURE").Output.Elements("SIGMAMX").Value
            
             '======================================================================================================================
    
        Dim sse_Log, sst_Log, R_Squared_Log As Double
        Dim TotalExperimental_Log, AverageExperimental_Log As Double
        Dim sse, sst, R_Squared As Double
        Dim TotalExperimental, AverageExperimental As Double
        Dim NofData As Integer
        
        NofData = 0
        sse_Log = 0
        sst_Log = 0
        R_Squared_Log = 0
        TotalExperimental_Log = 0
        sse = 0
        sst = 0
        R_Squared = 0
        TotalExperimental = 0
             
        For i = 1 To NumberofDataPoint
        
            If (Range("c24:c53").Item(i) <> 0 And Range("j24:j53").Item(i) <> "") Then
                Range("k24:k53").Item(i) = Range("j24:j53").Item(i) / Range("c24:c53").Item(i)
            Else
                Range("k24:k53").Item(i) = ""
            End If
            
            If (go_Simulation.Tree.FindNode("\Data\Properties\Regression\PURE\Input\WEIGHT\SOL" & 40 + i).Value = 1) Then
                
                If (Range("c24:c53").Item(i).Value <> "") Then
                    TotalExperimental_Log = TotalExperimental_Log + Log(Range("c24:c53").Item(i).Value) / Log(10)
                    NofData = NofData + 1
                End If
             
                TotalExperimental = TotalExperimental + Range("c24:c53").Item(i).Value
            End If
        Next
            
        If (NofData <> 0) Then
            AverageExperimental_Log = TotalExperimental_Log / NofData
            AverageExperimental = TotalExperimental / NofData
        End If
              
        For i = 1 To NumberofDataPoint
        
            If (Range("c24:c53").Item(i).Value <> "" And Range("j24:j53").Item(i).Value <> "" And go_Simulation.Tree.FindNode("\Data\Properties\Regression\PURE\Input\WEIGHT\SOL" & 40 + i).Value = 1) Then
            
                 sse_Log = sse_Log + (Log(Range("J24:J53").Item(i).Value) / Log(10) - Log(Range("c24:c53").Item(i).Value) / Log(10)) ^ 2
                 sst_Log = sst_Log + (Log(Range("c24:c53").Item(i).Value) / Log(10) - AverageExperimental_Log) ^ 2
                 
                 sse = sse + (Range("J24:J53").Item(i).Value - Range("c24:c53").Item(i).Value) ^ 2
                 sst = sst + (Range("c24:c53").Item(i).Value - AverageExperimental) ^ 2
                 
            End If
               
        Next i
            
        If (sst_Log <> 0) Then
            R_Squared_Log = 1 - sse_Log / sst_Log
            Range("M33").Value = R_Squared_Log
        End If
        
        If (sst <> 0) Then
            R_Squared = 1 - sse / sst
            Range("M32").Value = R_Squared
        End If
    
    '
    ''=====================RMSE(LOG)calculation====================================================
        Dim RMSE, RMSE_Log As Double
    
            RMSE = 0
            RMSE_Log = 0
            
            For i = 1 To NumberofDataPoint
                If (Range("c24:c53").Item(i).Value <> "" And Range("j24:j53").Item(i).Value <> "" And go_Simulation.Tree.FindNode("\Data\Properties\Regression\PURE\Input\WEIGHT\SOL" & 40 + i).Value = 1) Then
                  RMSE = RMSE + (Range("j24:j53").Item(i).Value - Range("c24:c53").Item(i).Value) ^ 2
                  RMSE_Log = RMSE_Log + (Log(Range("j24:j53").Item(i).Value) / Log(10) - Log(Range("c24:c53").Item(i).Value) / Log(10)) ^ 2
                End If
            Next i
                 
            RMSE = Sqr(RMSE / NofData)
            RMSE_Log = Sqr(RMSE_Log / NofData)
                   
        Range("M34").Value = RMSE
        Range("M35").Value = RMSE_Log
      
        'Application.Tree.Data.Properties.Regression.PURE.Input.USAGE.#0
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Input\USAGE\#0")
        'Application.Tree.Data.Properties.Regression.PURE.Input.WEIGHT.SOL41
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Input\WEIGHT\SOL41")
        
        ''===============================================================================================
        
        'If (Rstatus = "DRS Warning") Then MsgBox ("Calculated with warning. Please check the .aprbkp file.")
        
        'Update the plot
         Call DrawSquarePlot
    Else
        MsgBox Rstatus & "! Please check data or use differnt parameters"
    End If
      
   End Sub
   
   Function status(CompStat As Long) As String

    If ((CompStat And HAP_RESULTS_SUCCESS) = HAP_RESULTS_SUCCESS) Then
      status = "DRS Success"
    ElseIf ((CompStat And HAP_RESULTS_ERRORS) = HAP_RESULTS_ERRORS) Then
      status = "DRS Error"
    ElseIf ((CompStat And HAP_NORESULTS) = HAP_NORESULTS) Then
      status = "DRS No results"
    ElseIf ((CompStat And HAP_RESULTS_WARNINGS) = HAP_RESULTS_WARNINGS) Then
      status = "DRS Warning"
    End If
   
   End Function
   
Private Sub CommandButton1_Click()
    ActiveSheet.Visible = xlSheetVeryHidden
    Sheet1.Visible = xlSheetVisible
    Sheet12.Visible = xlSheetVeryHidden
End Sub

'Private Sub Worksheet_selectionchange(ByVal target As Range)
'
'    Dim Nm As Name
'    For Each Nm In ActiveWorkbook.Names
'        Nm.Visible = False
'    Next
'
'    Range("$b$24:$d$53").Font.Color = vbBlue
'
'
'End Sub

Private Sub Worksheet_Activate()

    Dim Nm As Name
    For Each Nm In ActiveSheet.Names
        Nm.Visible = False
    Next
    
End Sub

Private Sub Worksheet_Change(ByVal Target As Range)
If Target.Column >= 2 And Target.Column <= 4 And Target.Row >= 24 And Target.Row <= 53 Then
    Target.Font.Color = vbBlue
    Target.HorizontalAlignment = xlRight
End If
If Target.Column >= 1 And Target.Column <= 5 And Target.Row = 8 Then
    Target.Font.Color = vbBlue
    Target.HorizontalAlignment = xlCenter
End If
If Target.Column >= 1 And Target.Column <= 7 And Target.Row = 13 Then
    Target.Font.Color = vbBlue
    Target.HorizontalAlignment = xlCenter
End If

End Sub

Private Sub DrawSquarePlot()

Dim MaximumScale, MinimumScale As Double
Dim MyChart As Chart
Dim i, NofPositivePoint As Integer
Dim XValue(NumberofDataPoint), YValue(NumberofDataPoint) As Double
Dim sXString, sYString As String

On Error GoTo ErrorHandler:

Set MyChart = ActiveSheet.ChartObjects("Chart 83").Chart

    MaximumScale = 10 ^ (TrimtoTens(Application.WorksheetFunction.Max(Range("$c$24:$c$53, $j$24:$J$53"))) + 1)
    MinimumScale = 10 ^ TrimtoTens(Application.WorksheetFunction.Min(Range("$c$24:$c$53, $j$24:$J$53")))

    'Get all the non zero solubilities
    
    NofPositivePoint = 0

    For i = 1 To NumberofDataPoint
        If Range("Solubility" & i).Value > 0 And Range("SoluEst" & i).Value > 0 Then
            NofPositivePoint = NofPositivePoint + 1
            If TrimtoTens(Range("Solubility" & i).Value) <= 0 Then
                XValue(NofPositivePoint) = FormatNumber(Range("Solubility" & i).Value, Abs(TrimtoTens(Range("Solubility" & i).Value)) + 1)
                YValue(NofPositivePoint) = FormatNumber(Range("SoluEst" & i).Value, Abs(TrimtoTens(Range("SoluEst" & i).Value)) + 1)
            Else
                XValue(NofPositivePoint) = FormatNumber(Range("Solubility" & i).Value, 1)
                YValue(NofPositivePoint) = FormatNumber(Range("SoluEst" & i).Value, 1)
            End If
        End If
    Next i
    
    For i = 1 To NofPositivePoint - 1
        sXString = sXString & Replace(XValue(i), ",", ".") & ","  ' To fit for German OS, Replace function is used here.
        sYString = sYString & Replace(YValue(i), ",", ".") & ","
    Next i

    sXString = sXString & Replace(XValue(NofPositivePoint), ",", ".")
    sYString = sYString & Replace(YValue(NofPositivePoint), ",", ".")
    
    Sheet10.Unprotect "aspen123"
    
    If MyChart.SeriesCollection.count = 1 Then
        MyChart.SeriesCollection.NewSeries
    ElseIf MyChart.SeriesCollection.count = 2 Then
        MyChart.SeriesCollection(2).Delete
        MyChart.SeriesCollection.NewSeries
    ElseIf MyChart.SeriesCollection.count > 2 Then
        For i = 3 To MyChart.SeriesCollection.count
            MyChart.SeriesCollection(i).Delete
        Next i
    End If
    
    With MyChart.SeriesCollection(1)
        .XValues = "={" & Replace(MinimumScale, ",", ".") & "," & Replace(MaximumScale, ",", ".") & "}"         '"={" & MinimumScale & "," & MaximumScale & "}"
        .Values = "={" & Replace(MinimumScale, ",", ".") & "," & Replace(MaximumScale, ",", ".") & "}"
        .Border.ColorIndex = 7
        .MarkerStyle = xlNone
    End With
    
    With MyChart.SeriesCollection(2)
        .XValues = "={" & sXString & "}"
        .Values = "={" & sYString & "}"
        .Border.LineStyle = xlNone
        .MarkerBackgroundColorIndex = 11
        .MarkerForegroundColorIndex = 11
    End With

   
'    Debug.Print "{" & sXString & "}"
'    Debug.Print "{" & sYString & "}"
'    Debug.Print MyChart.SeriesCollection(2).Points.count

    With MyChart.Axes(xlCategory)
        .ScaleType = xlLogarithmic
        .MinimumScaleIsAuto = False
        .MaximumScaleIsAuto = False
        .MinimumScale = MinimumScale
        .MaximumScale = MaximumScale
        .MinorUnitIsAuto = True
        .MajorUnitIsAuto = True
        .Crosses = xlAutomatic
        .ReversePlotOrder = False
        .DisplayUnit = xlNone
        .CrossesAt = MinimumScale
    End With
        'Application.Run "getUnits"
    
    With MyChart.Axes(xlValue)
        
        .ScaleType = xlLogarithmic
        .MinimumScaleIsAuto = False
        .MaximumScaleIsAuto = False
        .MinimumScaleIsAuto = False
        .MinimumScale = MinimumScale
        .MaximumScale = MaximumScale
        .MinorUnitIsAuto = True
        .MajorUnitIsAuto = True
        .Crosses = xlAutomatic
        .ReversePlotOrder = False
        .DisplayUnit = xlNone
        .CrossesAt = MinimumScale
    End With
        
    Sheet10.Protect "aspen123", DrawingObjects:=False, Contents:=True, Scenarios:= _
        True, AllowFormattingCells:=True
    
Exit Sub

ErrorHandler: MsgBox "Error in drawing the plot! The Series2 input string may be too large."

End Sub

Public Function TrimtoTens(X As Double)
Dim i As Integer
For i = -7 To 5
    If X / 10 ^ i > 0 And X / 10 ^ i < 1 Then
        TrimtoTens = i - 1
        Exit For
    End If
Next

End Function

Public Function FindSolventID(SolvName As String)
Dim i As Integer
Dim fFound As Boolean

If SolvName = "" Then
  Exit Function
End If

'If SolventName(1) = "" Then
'   For i = 0 To SolventKind - 1
'      SolventName(i) = Sheets("Solvent List").Range("SolventName").Item(i + 1).Value
'      SolventID(i) = Sheets("Solvent List").Range("SolventID").Item(i + 1).Value
'   Next i
'End If

fFound = False

For i = 0 To SolventKind - 1
    If SolventName(i) = SolvName Then
        FindSolventID = SolventID(i)
        fFound = True
        Exit For
    End If
Next

If fFound = False Then
    MsgBox "The solvent name" & " """ & SolvName & """ is not in the databank." & _
    Chr(10) & Chr(10) & "The corresponding data point will be EXCLUDED in the regression." & _
    Chr(10) & Chr(10) & "Please always select a solvent from the dropdown list.", vbOKOnly, "Solvent not found"
End If

End Function

Public Sub SetRegressionWeight()
Dim i As Integer

    For i = 1 To NumberofDataPoint
        If (ComboSwitch(i).Text = "No") Then
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Input\WEIGHT\SOL41")
          Set node = NodeReg.FindNode("PURE\Input\WEIGHT\SOL" & 40 + i)
          node.Value = 0.0000000001
          'NodeReg.Elements("PURE").Input.Elements("WEIGHT").Elements("SOL" & 40 + i).Value = 0.0000000001
        End If
    Next i
    
End Sub

Public Sub CleanUpResults()
Dim i As Integer
Dim MyChart As Chart
 'clean up the regression results for the previous run
    Range("paramxEst").Value = ""
    Range("paramy1Est").Value = ""
    Range("paramy2Est").Value = ""
    Range("paramzEst").Value = ""
    Range("KspAEst").Value = ""
    Range("KspBEst").Value = ""
    Range("KspCEst").Value = ""
    
    Range("StdDevX").Value = ""
    Range("StdDevY1").Value = ""
    Range("StdDevY2").Value = ""
    Range("StdDevZ").Value = ""
    Range("StdDevKspA").Value = ""
    Range("StdDevKspB").Value = ""
    Range("StdDevKspC").Value = ""
    
    Range("SumWeight").Value = ""
    Range("m32:m35").Value = ""

    For i = 1 To NumberofDataPoint
        Range("SoluEst" & i).Value = ""
        Range("TempEst" & i).Value = ""
    Next
   
    Range("K24:K53").Value = ""
    
    Set MyChart = ActiveSheet.ChartObjects("Chart 83").Chart
    
    Sheet10.Unprotect "aspen123"
    
    If MyChart.SeriesCollection.count >= 2 Then
        For i = 2 To MyChart.SeriesCollection.count
            MyChart.SeriesCollection(i).Delete
        Next i
    End If
    
    Sheet10.Protect "aspen123", DrawingObjects:=False, Contents:=True, Scenarios:= _
        True, AllowFormattingCells:=True

End Sub

