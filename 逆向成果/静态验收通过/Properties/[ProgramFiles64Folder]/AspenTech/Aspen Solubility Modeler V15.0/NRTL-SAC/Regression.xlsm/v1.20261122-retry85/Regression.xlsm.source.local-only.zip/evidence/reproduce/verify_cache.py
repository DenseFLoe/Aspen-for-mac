import contextlib
import io
import json
import re
import struct
from collections import Counter, defaultdict
from pathlib import Path
from types import SimpleNamespace

import pcodedmp.pcodedmp as pc

root=Path(__file__).resolve().parent
manifest=json.loads((root/"structure.json").read_text(encoding="utf-8"))
assert manifest["vba_cache_version"] == "0xb5" and manifest["syskind"] == 3

id_original = pc.getID
def get_id(word, ids, version, is64):
    idx = (word >> 1) - 0x107
    if version == 7 and is64 and 0xBE < idx < len(ids):
        return ids[idx]
    return id_original(word,ids,version,is64)
pc.getID = get_id
dump, stderr = io.StringIO(),io.StringIO()
with contextlib.redirect_stderr(stderr):
    pc.processFile(str(root.parent/"input/Regression.xlsm"),SimpleNamespace(disasmOnly=True,verbose=False),output_file=dump)
assert not stderr.getvalue()

modules={}
for row in dump.getvalue().splitlines():
    if m := re.fullmatch(r"VBA/(.+) - \d+ bytes",row):
        assert m[1] not in modules
        current = modules[m[1]] = []
    elif m := re.fullmatch(r"Line #(\d+):",row):
        assert int(m[1]) == len(current)
        current.append([])
    elif row.startswith("\t"):
        assert not row.strip().startswith(("Unrecognized","Illegal","Error"))
        current[-1].append(row.strip())
assert set(modules) == {m["name"] for m in manifest["modules"]}

quoted = re.compile(r'''"(?:[^"]|"")*"|'.*$''')
decl = re.compile(r"(?i)^\s*(?:(?:Public|Private|Friend|Static)\s+)?(Sub|Function|Property (?:Get|Let|Set))\s+(\w+)")
call = re.compile(r"^(?:ArgsCall|ArgsMemCall|ArgsMemCallWith|ArgsLd|ArgsMemLd|ArgsMemLdWith)\b.* ([^\s]+) 0x[0-9A-F]+$")
number = re.compile(r"(?i)(?<![\w.])(?:&H[0-9a-f]+|(?:\d+(?:\.\d*)?|\.\d+)(?:E[+-]?\d+)?)(?:[!#%&^@])?(?!\w)")
num_code = {"LitDI2":"h","LitDI4":"i","LitDI8":"q","LitR4":"f","LitR8":"d"}
control = {
    "for each":{"ForEach","ForEachAs"}, "for":{"For","ForStep"}, "next":{"Next","NextVar"}, "do":{"Do"},
    "do while":{"DoWhile"}, "do until":{"DoUnitil"}, "loop":{"Loop","LoopWhile","LoopUntil"},
    "elseif":{"ElseIfBlock"}, "else":{"Else","ElseBlock"}, "end if":{"EndIfBlock","EndIf"},
    "if":{"If","IfBlock"}, "select case":{"SelectCase"}, "case else":{"CaseElse"}, "case":{"Case"},
    "end select":{"EndSelect"}, "on error":{"OnError"}, "exit sub":{"ExitSub"},
    "end sub":{"EndSub"}, "end function":{"EndFunc"}, "exit function":{"ExitFunc"}, "stop":{"Stop"},
    "goto":{"GoTo"}, "resume":{"Resume"}, "while":{"While"}, "wend":{"Wend"}, "with":{"With"},"end with":{"EndWith"}
}
control_re = re.compile(r"(?i)^(?:" + "|".join(sorted(control,key=len,reverse=True)) + r")\b")
def source_rows(lines):
    start = None
    pending = []
    for i,line in enumerate(lines,1):
        if line.startswith("Attribute "):
            continue
        if start is None:
            start = i
        line = line.rstrip()
        if line.endswith(" _"):
            pending.append(line[:-2])
            continue
        yield start,i," ".join((*pending,line))
        pending.clear()
        start = None
    assert not pending
def numeric(literal):
    value = literal.rstrip("!#%&^@")
    if value.casefold().startswith("&h"):
        n = int(value[2:],16)
        if literal.endswith("&"):
            return n - 2**32 if n >= 2**31 else n
        if n < 2**16:
            return n - 2**16 if n >= 2**15 else n
        return n - 2**32 if n >= 2**31 else n
    if literal.endswith("!"):
        return struct.unpack("<f",struct.pack("<f",float(value)))[0]
    return float(value) if re.search(r"[.Ee]",value) else int(value)
dest = root/"cache"
dest.mkdir(exist_ok=True)
for m in manifest["modules"]:
    rows=list(source_rows((root/"stage/vba"/m["filename"]).read_bytes().decode(manifest["codec"]).splitlines()))
    compiled=modules[m["name"]]
    stats=Counter()
    diffs=defaultdict(list)
    procs=[]
    evidence=[]
    if len(rows) != len(compiled):
        diffs["row_count"].append(dict(source=len(rows),compiled=len(compiled)))
    for index,((start,end,line),ops) in enumerate(zip(rows,compiled)):
        tokens=list(quoted.finditer(line))
        comment=tokens.pop() if tokens and tokens[-1][0].startswith("'") else None
        code=line[:comment.start()].strip() if comment else line.strip()
        values=[t[0][1:-1].replace('""','"') for t in tokens]
        sanitized=quoted.sub('""',code)
        op_names=[o.split()[0] for o in ops]
        stats["logical_lines"]+=1
        stats["opcode_total"]+=len(ops)
        location=dict(source_line=start,source_line_end=end,cache_line=index)
        if bool(code)!=bool(set(op_names)-{"QuoteRem"}):
            diffs["code_presence"].append(location)
        pstrings=[s[1] for op in ops if (s := re.fullmatch(r'LitStr 0x[0-9A-F]+ "(.*)"',op))]
        stats["strings"]+=len(values)
        if Counter(pstrings) != Counter(values):
            diffs["strings"].append(location)
        nums=[]
        for op in ops:
            o,*args=op.split()
            if o in num_code:
                raw=b"".join(int(v,16).to_bytes(2,"little") for v in args)
                nums.append(struct.unpack("<"+num_code[o],raw)[0])
        expected=[numeric(t[0]) for t in number.finditer(sanitized)]
        stats["numeric_literals"]+=len(nums)
        if Counter(expected)!=Counter(nums):
            diffs["numeric_literals"].append(location)
        calls=[c[1] for op in ops if (c := call.match(op))]
        stats["call_operands"]+=len(calls)
        missing=[c for c in calls if not re.search(r"(?i)(?<!\w)"+re.escape(c)+r"(?!\w)",sanitized)]
        if missing:
            diffs["call_operands"].append({**location,"names":missing})
        if b := control_re.match(sanitized):
            stats["control_statements"]+=1
            if not control[b[0].lower()] & set(op_names):
                diffs["control_statements"].append({**location,"construct":b[0],"opcodes":op_names})
        signature=decl.match(sanitized)
        defns=[op for op in ops if op.startswith("FuncDefn")]
        if signature:
            row={**location,"name":signature[2],"kind":signature[1]}
            procs.append(row)
            if len(defns)!=1 or not re.search(r"(?i)\b"+re.escape(signature[2])+r"\s*\(",defns[0]):
                diffs["procedure_name"].append(row)
        elif defns:
            diffs["procedure_source"].append(location)
        if re.match(r"(?i)^end (sub|function|property)\b",sanitized) and procs:
            procs[-1].update(source_end=end,cache_end=index)
        if signature or set(op_names) & {"OnError","GoTo","Resume","Open","Close","SelectCase"}:
            evidence.append({**location,"opcodes":op_names})
    data=dict(module=m["name"],source_sha256=m["sha256"],counts=stats,procedures=procs,checks=evidence,differences=diffs)
    (dest/(m["name"]+".json")).write_text(json.dumps(data,indent=2)+"\n",encoding="utf-8")
    print(m["name"], len(rows),len(compiled),len(procs),{k:len(v) for k,v in diffs.items()})

