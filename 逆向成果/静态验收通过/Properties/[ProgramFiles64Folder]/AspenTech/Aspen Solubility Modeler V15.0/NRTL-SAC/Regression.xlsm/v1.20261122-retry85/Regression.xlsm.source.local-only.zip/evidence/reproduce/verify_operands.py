"""Compare names, branch targets and arithmetic tokens without writing source literals or P-code."""
from collections import Counter, defaultdict
from pathlib import Path
import contextlib
import io
import json
import re
import sys
import types

work = Path(__file__).resolve().parent
dep = work / "deps"
if not (dep / "pcodedmp").is_dir():
    raise RuntimeError("Install pinned dependencies in work/deps")
sys.path.insert(0, str(dep))
import pcodedmp.pcodedmp as pc

prior = pc.getID
def resolve(w, ids, version, bit64):
    n = (w >> 1) - 0x107
    if version == 7 and bit64 and 0xbe < n < len(ids):
        return ids[n]
    return prior(w, ids, version, bit64)
pc.getID = resolve
prior_import = pc.disasmImp
import_evidence = []
def resolve_import(table, ids, arg, word, mnemonic, endian, version, bit64):
    if mnemonic == 'New' and arg == 'imp_' and version == 7 and bit64:
        assert word == 24 and len(table) == 320
        slot = word // 8
        address = slot * 10 + 6
        raw_id = pc.getWord(table, address, endian)
        name = pc.getID(raw_id, ids, version, bit64)
        assert raw_id == 0x023c and name == 'clsServer2'
        import_evidence.append(dict(raw_operand=word, slot=slot, record_bytes=10,
                            identifier_offset=address, raw_identifier=hex(raw_id), target=name))
        return name
    return prior_import(table, ids, arg, word, mnemonic, endian, version, bit64)
pc.disasmImp = resolve_import
buf, err = io.StringIO(), io.StringIO()
with contextlib.redirect_stderr(err):
    pc.processFile(str(work.parent / 'input/Regression.xlsm'),
        types.SimpleNamespace(disasmOnly=True, verbose=False), output_file=buf)
assert not err.getvalue()
mods = {}
for line in buf.getvalue().splitlines():
    if m := re.fullmatch(r'VBA/(.+) - \d+ bytes', line):
        mod = mods[m[1]] = []
    elif line.startswith("Line #"):
        mod.append([])
    elif line.startswith("\t"):
        mod[-1].append(line.strip().split(maxsplit=1))

def lines(raw):
    pending = ''
    for index, line in enumerate(raw.splitlines(), 1):
        if line.startswith('Attribute '):
            continue
        if not pending:
            first = index
        if line.rstrip().endswith(' _'):
            pending += line.rstrip()[:-2] + ' '
            continue
        yield first, pending + line
        pending = ''
    assert not pending

identifier = re.compile(r'[A-Za-z_][A-Za-z_0-9]*')
symbols = re.compile(r'<>|<=|>=|:=|[=<>+*/^&-]|\b(?:and|or|not|is)\b',re.I)
quoted = re.compile(r'"(?:[^"]|"")*"|\'.*$')
opmap = {'eq':'=', 'ge':'>=', 'le':'<=', 'ne':'<>', 'lt':'<', 'gt':'>',
         'add':'+', 'sub':'-', 'umi':'-', 'concat':'&','pwr':'^', 'div':'/',
         'mul':'*','is':'is','and':'and','or':'or','not':'not','paramnamed':':='}
nameops = set('Ld MemLd MemLdWith ArgsLd ArgsMemLd ArgsMemLdWith St MemSt MemStWith ArgsSt ArgsMemSt Set ArgsSet ArgsCall ArgsMemCall ParamNamed Label New'.split())
storeops = set('St MemSt MemStWith ArgsSt ArgsMemSt Set ArgsSet'.split())
opts = {'stats':Counter(),'discrepancies':defaultdict(list), 'import_evidence':import_evidence}
manifest = json.loads((work/'structure.json').read_text('utf8'))
for item in manifest['modules']:
    modname = item['name']
    raw = (work/'stage/vba'/item['filename']).read_bytes().decode(manifest['codec'])
    rows = list(lines(raw))
    assert len(rows) == len(mods[modname])
    for (i,src), ops in zip(rows,mods[modname]):
        # Whitespace prevents joining adjacent identifiers across removed strings.
        src = quoted.sub(' ',src).strip().lower()
        ids = Counter(identifier.findall(src))
        names, symbols2 = Counter(), Counter()
        opname = [x[0] for x in ops]
        for op,*args in ops:
            if op in nameops:
                operand = re.sub(r'^\(Call\)\s*','',args[0]).split()[0].casefold()
                if operand == 'id_ffff' and op == 'Ld':
                    assert modname == 'ThisWorkbook' and i == 120 and re.search(r'\bme\.name\b',src)
                    assert ['MemLd','Name'] in ops
                    operand = 'me'
                    opts['stats']['implicit_instance_operand'] += 1
                names[operand] += 1
            if op == 'OnError':
                if args:
                    dest = args[0].strip().lower().strip('()')
                    opts['stats']['error_branches'] += 1
                    normalized = ' '.join(src.split())
                    if not re.search(r'\bon error (?:goto )?'+re.escape(dest)+r'\b',normalized):
                        opts['discrepancies']['onerror'].append([modname,i])
            if val := opmap.get(op.lower()) if op != 'FuncDefn' else None:
                symbols2[val] += 1
            if op in storeops or op in {'For','ForStep'}:
                symbols2['='] += 1
        for key,n in (names-ids).items():
            opts['discrepancies']['names'].append([modname,i,
                    [o for o,*a in ops if a and a[0].lower().split()[0]==key and o in nameops],n])
        if names:
            opts['stats']['named_operands'] += sum(names.values())
        # Declaration syntax and numeric literal suffixes can use the same tokens as operators.
        if any(x in opname for x in ('FuncDefn','VarDefn','Type','EndEnum')):
            continue
        src = re.sub(r'&h[0-9a-f]+&?|\b\d+&\b','0',src)
        symbols1 = Counter(s.lower() for s in symbols.findall(src))
        if symbols1 != symbols2:
            opts['discrepancies']['operators'].append([modname,i,dict(symbols1-symbols2),
                                                       dict(symbols2-symbols1),opname])
        opts['stats']['operator_tokens'] += sum(symbols2.values())
out = Path(__file__).with_name('operands.json')
out.write_text(json.dumps(opts,indent=2),encoding='utf8')
print(dict(opts['stats']), {k:len(v) for k,v in opts['discrepancies'].items()})

