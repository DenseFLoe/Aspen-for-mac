import io
import json
import re
import sys
import zipfile
from collections import Counter
from hashlib import sha256
from pathlib import Path
from types import SimpleNamespace

import olefile
from oletools.olevba import VBA_Project, decompress_stream
from pcodedmp.pcodedmp import processFile

work = Path(__file__).resolve().parent
original = work.parent / "input" / "Regression.xlsm"
assert sha256(original.read_bytes()).hexdigest() == "1b7d06872c829af52c73c0a650af2ed6bb4a3b4eb50d5cf6d01e96f50b7c3f4b"
def write(relative, data):
    target = (work / relative).resolve()
    assert target.is_relative_to(work)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

def digest(raw):
    return sha256(raw).hexdigest()

with zipfile.ZipFile(original) as z:
    assert z.testzip() is None and len(set(z.namelist())) == len(z.namelist())
    parts = {n: dict(size=len(raw), sha256=digest(raw)) for n in z.namelist() if (raw := z.read(n)) is not None}
    compound = z.read("xl/vbaProject.bin")
    for name in parts.keys() - {"xl/vbaProject.bin"}:
        write("stage/ooxml/" + name, z.read(name))

with olefile.OleFileIO(io.BytesIO(compound), raise_defects=olefile.DEFECT_INCORRECT) as ole:
    project = VBA_Project(ole, "", "PROJECT", "VBA/dir", relaxed=False)
    project.parse_project_stream()
    list(project.parse_modules())
    metadata = ole.openstream("PROJECT").read()
    write("PROJECT.private.bin", metadata)
    records = metadata.decode(project.codec).splitlines()
    kinds = {}
    for line in records:
        key, _, value = line.partition("=")
        if key in {"Document", "Module", "Class", "BaseClass"}:
            name = value.split("/")[0]
            assert name not in kinds
            kinds[name] = key
    streams = {}
    storage = ["/".join(p) for p in ole.listdir(streams=False, storages=True)]
    for p in ole.listdir():
        raw = ole.openstream(p).read()
        streams["/".join(p)] = dict(size=len(raw), sha256=digest(raw))
        if kinds.get(p[0]) == "BaseClass":
            write("stage/forms/" + "/".join(p[:-1] + [p[-1].replace("\x03", "_03_")]), raw)
    modules = []
    for m in project.modules:
        assert m.code_raw is not None
        stream = ole.openstream(m.code_path).read()
        assert m.code_raw == decompress_stream(stream[m.textoffset:])
        assert re.fullmatch(r"\w+", m.name)
        kind = kinds.pop(m.name)
        file = m.name + {"Document":".cls", "Class":".cls", "Module":".bas", "BaseClass":".frm.code"}[kind]
        assert re.search(rb'(?m)^Attribute VB_Name = "' + re.escape(m.name.encode(project.codec)) + rb'"', m.code_raw)
        write("stage/vba/" + file, m.code_raw)
        modules.append(dict(name=m.name, stream=m.code_path, filename=file, kind=kind,
                            source_offset=m.textoffset, bytes=len(m.code_raw), sha256=digest(m.code_raw), lines=len(m.code_raw.splitlines())))
    assert not kinds
    structure = dict(parts=parts, project=project.projectname, codepage=project.codepage, codec=project.codec,
                     syskind=project.syskind, vba_cache_version=hex(int.from_bytes(ole.openstream("VBA/_VBA_PROJECT").read()[2:4], "little")),
                     modules=modules, streams=streams, storages=storage,
                     project_fields=sorted({line.split("=",1)[0] for line in records if "=" in line and not line.startswith('"')}))
    write("structure.json", json.dumps(structure, indent=2, ensure_ascii=False).encode("utf-8"))
print("parts", len(parts), "modules", len(modules), "streams", len(streams), "VBA", project.codec, project.syskind, structure["vba_cache_version"])
for m in modules:
    print(m["name"], m["kind"], m["source_offset"], m["lines"])
print("storages", storage)
print("parts groups", Counter("/".join(n.split("/")[:2]) if n.startswith("xl/") else n.split("/")[0] for n in parts))
with (work / "pcode.private.txt").open("w", encoding="utf-8") as out:
    processFile(str(original), SimpleNamespace(disasmOnly=True, verbose=False), output_file=out)

