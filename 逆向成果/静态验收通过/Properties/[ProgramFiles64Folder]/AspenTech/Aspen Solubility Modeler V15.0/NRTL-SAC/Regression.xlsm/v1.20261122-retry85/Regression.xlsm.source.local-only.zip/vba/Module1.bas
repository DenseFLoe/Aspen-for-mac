Attribute VB_Name = "Module1"
Option Explicit

Public hWndP1 As LongLong
Public hWndP2 As LongLong
Public Const SWP_NOMOVE = 2
Public Const SWP_NOSIZE = 1
Public Const FLAGS = SWP_NOMOVE Or SWP_NOSIZE
Public Const HWND_TOPMOST = -1
Public Const HWND_NOTOPMOST = -2


    'Find the hWnd of the main Excel window
    

' global variable to hold simulation
Public go_Simulation As IHapp
Public Const aspenPropertiesAddInStr As String = "Aspen Properties"
Public gbAddinInstalled As Boolean
Function GetFileNameFromFull(FullPath As String)
Dim StrFind As String
Dim iCount As Integer
    iCount = 0
    Do Until Left(StrFind, 1) = "\"
        iCount = iCount + 1
        StrFind = Right(FullPath, iCount)
        If iCount = Len(FullPath) Then Exit Do
    Loop
    GetFileNameFromFull = StrFind
    If Left(StrFind, 1) = "\" Then GetFileNameFromFull = Right(StrFind, Len(StrFind) - 1)
End Function
 
Public Function xlGetFilePathName() As Variant
Dim ls_Header As String
Dim lv_FilePathName As Variant
Dim lf_FileDlg As FileDialog
Dim sFileName As String
Dim sDir As String
 
    sDir = ActiveWorkbook.Path
    lv_FilePathName = False
    
    On Error GoTo ErrorHandler

    sFileName = ActiveSheet.Range("FilePath")
    sFileName = GetFileNameFromFull(sFileName)
    sFileName = sDir & "\" & sFileName
    If Dir(sFileName) = "" Then sFileName = ActiveSheet.Range("FilePath") 'In case the file cannot be found in local path

    
   
    
    ' -- assign values to string for File/Open dialogue box --
    
    ls_Header = "Open Aspen Properties Template File"
        
    Set lf_FileDlg = Application.FileDialog(msoFileDialogOpen)
    With lf_FileDlg
        .InitialFileName = sFileName
        .ButtonName = "Select"
        .AllowMultiSelect = False
        .Filters.Add "Aspen Properties Backup File", "*.aprbkp", 1
        .Title = ls_Header
        .InitialView = msoFileDialogViewDetails
        If .Show Then
           lv_FilePathName = .SelectedItems(1)
        End If
    End With
    
    ' -- assign filepathname to the name of the function --
    xlGetFilePathName = lv_FilePathName
    
    Exit Function
    
ErrorHandler:
    MsgBox Err.Description, vbCritical, "Error in opening the file"
 
End Function

Public Function IsSimLoaded() As Boolean

' -- function to check if a simulation has been loaded --

Dim lb_IsLoaded As Boolean

    If go_Simulation Is Nothing Then
        lb_IsLoaded = False
    Else
        lb_IsLoaded = True
    End If ' go_Simulation Is Nothing
    
    IsSimLoaded = lb_IsLoaded
End Function

Public Sub xlStartSettings(Optional as_StatusString As String = "Working")

' -- subroutine to change settings to put Excel "on hold" until a long
'    process is completed --

    ' -- change the cursor to a hourglass --
    Application.Cursor = xlWait
    
    ' -- place message in status bar --
    Application.StatusBar = as_StatusString
End Sub

Public Sub xlEndSettings()

' -- subroutine to change settings to default after a long process
'    is completed --

    ' -- return status bar to Excel's control --
    Application.StatusBar = False
    
    ' -- change cursor to default --
    Application.Cursor = xlDefault
    
    ' -- set focus to Sheet1, Cell G1 --
    ' Worksheets("Regression").Activate
    Range("E1").Select
End Sub

Public Function CheckAddInInstalled() As Boolean
    Dim retval As String
    Dim isLoaded As Boolean
    Dim mcolIdx As Integer
    Dim addin As COMAddin
    
        On Error Resume Next
        isLoaded = False
        For Each addin In Application.COMAddIns
            If InStr(1, addin.progID, "APXLAddinLoader.Connect") = 1 And addin.Connect = True Then
                isLoaded = True
                Exit For
            End If
        Next
        
        ' Check whether Addin has been installed for Aspen Properties
        If isLoaded = False Then
            'retVal = "The Aspen Properties add-in is not enabled.  Please enable it using 'Aspen Excel Add-in Manager'."
            retval = "The Aspen Properties add-in is not enabled"
            mcolIdx = 3
        Else
            retval = "Aspen Properties Add-In enabled"
            mcolIdx = 1
        End If
        
        Application.Range("AddinInfo").Value = retval
        Application.Range("AddinInfo").Font.ColorIndex = mcolIdx
        Application.Range("AddinInfo").Font.Bold = True
        
        If isLoaded = True Then
            Application.StatusBar = False
        Else
            Application.StatusBar = "Aspen Properties Add-In is not enabled."
        End If
             
        CheckAddInInstalled = isLoaded
        
End Function

'Public Function xlGetFilePathName() As Variant
'Dim ls_Filter As String
'Dim ls_Header As String
'Dim lv_FilePathName As Variant
'
'    ChDir ActiveWorkbook.Path
'
'    ' -- assign values to string for File/Open dialogue box --
'
'    ls_Filter = "Aspen Properties Backup File (*.aprbkp), *.aprbkp"
'    ls_Header = "Open Aspen Properties template File"
'
'    ' -- use Excel GetOpenFilename function to get the path and name
'    '    of the Aspen Plus file --
'    lv_FilePathName = Application.GetOpenFilename(ls_Filter, 2, ls_Header)
'
'    ' -- assign filepathname to the name of the function --
'    xlGetFilePathName = lv_FilePathName
'End Function


