Attribute VB_Name = "Sheet1"
Attribute VB_Base = "0{00020820-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True
Attribute VB_Control = "Image1, 59, 17, MSForms, Image"
Attribute VB_Control = "OBBinary1, 4, 18, MSForms, OptionButton"
Attribute VB_Control = "OBPure1, 3, 19, MSForms, OptionButton"
Attribute VB_Control = "cmdOK, 49, 20, MSForms, CommandButton"
Private Const myWelcomePage = "AspenSolubilityModeler"
Private Const mSolventList = "Solvent List"
Private Const mPureSolventNonelectrolyte = "Pure Solvent"
Private Const mBinarySolventNonelectrolyte = "Binary Solvent"


Private Sub cmdOK_Click()

    Sheets(mSolventList).Visible = xlSheetVisible
    
    If OBPure1.Value = True Then
        Sheets(mPureSolventNonelectrolyte).Visible = xlSheetVisible
    Else
        Sheets(mBinarySolventNonelectrolyte).Visible = xlSheetVisible
    End If
    
    Sheets(myWelcomePage).Visible = xlSheetVeryHidden

End Sub
Private Sub Worksheet_Activate()
    'gbAddinInstalled = CheckAddInInstalled
End Sub

Private Sub Worksheet_Calculate()
   'gbAddinInstalled = CheckAddInInstalled
End Sub

Private Sub Worksheet_SelectionChange(ByVal Target As Range)

    ' try to track the menu modification here
    'gbAddinInstalled = CheckAddInInstalled

End Sub

