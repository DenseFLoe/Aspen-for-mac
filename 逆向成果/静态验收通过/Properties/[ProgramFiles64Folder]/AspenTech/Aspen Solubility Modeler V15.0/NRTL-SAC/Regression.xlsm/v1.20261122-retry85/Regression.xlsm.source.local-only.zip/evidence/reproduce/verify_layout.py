import io
import json
import logging
import posixpath
import re
import uuid
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from xml.etree import ElementTree as ET

import olefile
from oletools import olevba

work = Path(__file__).resolve().parent
root = work / "stage/ooxml"
evidence = work / "layout"
evidence.mkdir(exist_ok=True)
struct = json.loads((work / "structure.json").read_text(encoding="utf-8"))
parts = set(struct["parts"])
rel_ns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
ax_ns = "{http://schemas.microsoft.com/office/2006/activeX}"
def local(tag):
    return tag.rsplit("}", 1)[-1]
def nodes(el, key):
    return [n for n in el.iter() if local(n.tag) == key]
def one(iterable):
    result, = iterable
    return result
def export(name, data):
    (evidence / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

xml = {n:ET.parse(root/n).getroot() for n in sorted(parts) if n.endswith((".xml",".rels",".vml"))}
rels = {}
for n, doc in xml.items():
    if not n.endswith(".rels"):
        continue
    parent, stem = posixpath.split(n)
    owner = posixpath.join(posixpath.dirname(parent), stem[:-5])
    assert not owner or owner in parts
    group = rels[owner] = {}
    for e in doc:
        rid, target = e.get("Id"), e.get("Target")
        mode = e.get("TargetMode","Internal")
        assert rid not in group
        if mode == "Internal":
            target = posixpath.normpath(posixpath.join(posixpath.dirname(owner),target)).lstrip("/")
            assert target in parts, (n,rid,target)
        group[rid] = dict(target=target,mode=mode,type=e.get("Type").rsplit("/",1)[-1])
for n, doc in xml.items():
    for el in doc.iter():
        for key, val in el.attrib.items():
            if key.startswith(rel_ns) or local(key) == "relid":
                assert val in rels[n],(n,key,val)

overrides = {n.get("PartName").lstrip("/"):n.get("ContentType") for n in nodes(xml["[Content_Types].xml"],"Override")}
defaults = {n.get("Extension") for n in nodes(xml["[Content_Types].xml"],"Default")}
assert set(overrides) <= parts
assert all(n in overrides or n.rsplit(".",1)[-1] in defaults for n in parts-{"[Content_Types].xml"})
assert not any("macrosheet" in t.casefold() for t in overrides.values())
assert not any(n.startswith(("xl/embeddings/","xl/externalLinks/")) for n in parts)

decl = re.compile(r"(?i)^\s*(?:(?:Private|Public|Friend|Static)\s+)?(?:Sub|Function|Property (?:Get|Let|Set))\s+(\w+)")
event_names = set("click dblclick change mousedown mouseup mousemove keydown keyup keypress beforeupdate afterupdate gotfocus lostfocus enter exit error beforedragover beforedroporpaste".split())
modules = {}
secret_locs = []
for m in struct["modules"]:
    source = (work/"stage/vba"/m["filename"]).read_bytes().decode(struct["codec"]).splitlines()
    modules[m["name"]] = [(i,s[1]) for i,line in enumerate(source,1) if (s := decl.match(line))]
    for i,line in enumerate(source,1):
        if re.search(r"(?i)\b(?:unprotect|protect|password|pwd|connectionstring|api[_ -]?key|client[_ -]?secret|access[_ -]?token)\b",line):
            secret_locs.append(dict(module=m["name"],line=i,literal=bool(re.search(r'(?i)\b(?:unprotect|protect|password|pwd)\b[^''\n]*"',line))))
book = xml["xl/workbook.xml"]
book_code = one(nodes(book,"workbookPr")).get("codeName")
sheets = []
seen_xml, seen_bin = set(),set()
codes = {book_code}
clsids = Counter()
for entry in nodes(book,"sheet"):
    sheet_rel = rels["xl/workbook.xml"][entry.get(rel_ns+"id")]
    assert sheet_rel["type"] == "worksheet"
    sheet = sheet_rel["target"]
    doc = xml[sheet]
    code = one(nodes(doc,"sheetPr")).get("codeName")
    assert code in modules and code not in codes
    codes.add(code)
    vml = one(r["target"] for r in rels[sheet].values() if r["type"]=="vmlDrawing")
    shapes = {n.get("id"):n for n in nodes(xml[vml],"shape")}
    drawings = [r["target"] for r in rels[sheet].values() if r["type"]=="drawing"]
    modern = {}
    for d in drawings:
        for anchor in nodes(xml[d],"twoCellAnchor"):
            p = one(nodes(anchor,"cNvPr"))
            modern[p.get("id")] = (anchor,p)
    control_records = defaultdict(list)
    for n in nodes(doc,"control"):
        control_records[(n.get("shapeId"),n.get(rel_ns+"id"),n.get("name"))].append(n)
    controls = []
    matched_events = set()
    for (sid,rid,name), pair in control_records.items():
        choice = one(n for n in pair if nodes(n,"controlPr"))
        fallback = one(n for n in pair if not nodes(n,"controlPr"))
        assert choice.attrib == fallback.attrib
        cp = one(nodes(choice,"controlPr"))
        d_anchor,d_prop = modern[sid]
        vshape = shapes[name]
        assert d_prop.get("name") == name
        assert one(nodes(d_prop,"compatExt")).get("spid") == f"_x0000_s{sid}"
        assert one(v for k,v in vshape.attrib.items() if local(k)=="spid") == f"_x0000_s{sid}"
        ax = rels[sheet][rid]["target"]
        ax_elem = xml[ax]
        clsid = ax_elem.get(ax_ns+"classid")
        persist = ax_elem.get(ax_ns+"persistence")
        binary_rel = rels[ax][ax_elem.get(rel_ns+"id")]
        binary = binary_rel["target"]
        raw = (root/binary).read_bytes()
        assert ax not in seen_xml and binary not in seen_bin
        assert rels[sheet][rid]["type"] == "control" and binary_rel["type"] == "activeXControlBinary"
        assert persist == "persistStreamInit" and len(raw) >= 20
        assert str(uuid.UUID(bytes_le=raw[:16])) == clsid.strip("{}").lower(),(binary,clsid)
        body_len = int.from_bytes(raw[18:20],"little")
        assert 20 + body_len <= len(raw),binary
        seen_xml.add(ax)
        seen_bin.add(binary)
        clsids[clsid] += 1
        layout = {key:{local(e.tag):{local(a.tag):int(a.text) for a in e}
                       for e in anchor if local(e.tag) in {"from","to"}}
                  for key,anchor in (("worksheet",one(nodes(cp,"anchor"))),("drawing",d_anchor))}
        layout["vml"] = one(nodes(vshape,"Anchor")).text
        images = [rels[vml][one(v for k,v in im.attrib.items() if local(k)=="relid")]["target"] for im in nodes(vshape,"imagedata")]
        if rid_image := cp.get(rel_ns+"id"):
            assert rels[sheet][rid_image]["target"] in images,(sheet,name)
        events = []
        for line, proc in modules[code]:
            prefix,_,suffix = proc.rpartition("_")
            if prefix.casefold()==name.casefold() and suffix.casefold() in event_names:
                matched_events.add(proc)
                events.append(dict(line=line,name=proc,event=suffix))
        controls.append(dict(name=name,shape_id=int(sid),worksheet_rid=rid,activeX=ax,binary_rid=ax_elem.get(rel_ns+"id"),
            binary=binary,binary_sha256=struct["parts"][binary]["sha256"],clsid=clsid,persistence=persist,
            state_version=list(raw[16:18]),property_record_bytes=body_len,layout=layout,images=images,
            control_properties={local(k):v for k,v in cp.attrib.items()},events=events))
    unmatched = [dict(line=i,name=p) for i,p in modules[code] if not p.casefold().startswith("worksheet_") and p.rpartition("_")[2].casefold() in event_names and p not in matched_events]
    assert not unmatched, (code, unmatched)
    sheets.append(dict(name=entry.get("name"),state=entry.get("state","visible"),code_name=code,part=sheet,vml=vml,
        drawings=drawings,controls=len(controls),with_events=sum(bool(c["events"]) for c in controls),events=len(matched_events),
        unmatched_event_like=unmatched,sheet_events=[dict(line=i,name=p) for i,p in modules[code] if p.lower().startswith("worksheet_")],
        formula_cells=[n.get("r") for n in nodes(doc,"c") if nodes(n,"f")],
        protection_fields=sorted({local(k) for n in nodes(doc,"sheetProtection") for k in n.attrib})))
    for i in range(0,len(controls),25):
        export(f"{code}-controls-{1+i//25:02}.json",dict(sheet=sheet,code_name=code,controls=controls[i:i+25]))

assert codes == {m["name"] for m in struct["modules"] if m["kind"]=="Document"}
assert seen_xml == {n for n in parts if re.fullmatch(r"xl/activeX/activeX\d+\.xml",n)}
assert seen_bin == {n for n in parts if re.fullmatch(r"xl/activeX/activeX\d+\.bin",n)}
assert len(seen_xml) == len(seen_bin) == 212
refs = []
class RefHandler(logging.Handler):
    def emit(self, rec):
        msg = rec.getMessage()
        if msg.startswith("REFERENCE "):
            refs.append(msg)
olevba.log.logger.propagate = False
olevba.log.logger.addHandler(RefHandler())
olevba.log.logger.setLevel(logging.DEBUG)
with zipfile.ZipFile(work.parent/"input/Regression.xlsm") as z:
    with olefile.OleFileIO(io.BytesIO(z.read("xl/vbaProject.bin"))) as ole:
        olevba.VBA_Project(ole,"","PROJECT","VBA/dir",relaxed=False)
export("workbook.json",dict(code_name=book_code,book_events=[dict(line=i,name=p) for i,p in modules[book_code] if p.lower().startswith("workbook_")],
    sheets=sheets,defined_names=len(nodes(book,"definedName")),parts=len(parts),xml_parts=len(xml),
    relationships=sum(len(g) for g in rels.values()),external_relationships=sum(r["mode"]!="Internal" for g in rels.values() for r in g.values()),
    macro_signature_parts=sorted(n for n in parts if "/vbaProjectSignature" in n and n.endswith(".bin")),
    workbook_protection_fields=sorted({local(k) for n in nodes(book,"workbookProtection") for k in n.attrib}),
    control_clsids=clsids,references=refs))
export("package-relationships.json",rels)
export("protection-locations.json",secret_locs)
for s in sheets:
    print(s["code_name"],s["controls"],s["events"],s["with_events"],s["unmatched_event_like"],
          "formulas",len(s["formula_cells"]),"protection keys",s["protection_fields"])
print("XML",len(xml),"rels",sum(len(g) for g in rels.values()),"names",len(nodes(book,"definedName")))
print("protection",len(secret_locs),Counter(x["module"] for x in secret_locs if x["literal"]))


