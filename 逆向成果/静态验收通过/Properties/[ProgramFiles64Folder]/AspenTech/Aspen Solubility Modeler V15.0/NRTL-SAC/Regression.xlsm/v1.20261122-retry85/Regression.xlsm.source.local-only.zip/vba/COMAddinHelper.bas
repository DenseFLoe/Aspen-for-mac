Attribute VB_Name = "COMAddinHelper"
' The prog id for the current version of the addin
Private Const APAddinProgid = "APXLAddinLoader.Connect.V15.0"
Private app As AspenPropertiesExcelCalculator.PropertiesApp

Public Function Invoke(action As String, Optional args As Variant = "")
On Error GoTo giveup
    If (app Is Nothing) Then
        Call GetCOMApplication(app)
    End If
    If Not app Is Nothing Then
        Invoke = app.Invoke(action, args)
    End If
giveup:
End Function

Private Sub GetCOMApplication(ByRef retval As AspenPropertiesExcelCalculator.PropertiesApp)
    Set retval = Nothing
    
    Dim addin As COMAddin
    For Each addin In Application.COMAddIns
        If addin.progID = APAddinProgid Then
            
            Dim apAddin As IAPComAddin
            Set apAddin = addin.Object
            If Not apAddin Is Nothing Then
                Set retval = apAddin.PropertiesXLApp
            End If
            
            Exit For
        End If
    Next

End Sub
