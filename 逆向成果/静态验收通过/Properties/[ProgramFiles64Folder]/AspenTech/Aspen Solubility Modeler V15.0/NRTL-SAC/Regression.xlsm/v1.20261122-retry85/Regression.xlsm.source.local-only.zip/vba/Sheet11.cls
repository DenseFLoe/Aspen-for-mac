Attribute VB_Name = "Sheet11"
Attribute VB_Base = "0{00020820-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True
Attribute VB_Control = "cmd_OpenSimulaiton, 1, 0, MSForms, CommandButton"
Attribute VB_Control = "cmd_DefineDrug, 2, 1, MSForms, CommandButton"
Attribute VB_Control = "cmd_Run, 3, 2, MSForms, CommandButton"
Attribute VB_Control = "CboSol1, 4, 3, MSForms, ComboBox"
Attribute VB_Control = "CboSol2, 5, 4, MSForms, ComboBox"
Attribute VB_Control = "CboSol3, 6, 5, MSForms, ComboBox"
Attribute VB_Control = "CboSol4, 7, 6, MSForms, ComboBox"
Attribute VB_Control = "CboSol5, 8, 7, MSForms, ComboBox"
Attribute VB_Control = "CboSol6, 9, 8, MSForms, ComboBox"
Attribute VB_Control = "CboSol7, 10, 9, MSForms, ComboBox"
Attribute VB_Control = "CboSol8, 11, 10, MSForms, ComboBox"
Attribute VB_Control = "CboSol9, 12, 11, MSForms, ComboBox"
Attribute VB_Control = "CboSol10, 13, 12, MSForms, ComboBox"
Attribute VB_Control = "chk_IsVisible, 14, 13, MSForms, CheckBox"
Attribute VB_Control = "CboParamx, 15, 14, MSForms, ComboBox"
Attribute VB_Control = "CboParamY1, 16, 15, MSForms, ComboBox"
Attribute VB_Control = "CboParamY2, 17, 16, MSForms, ComboBox"
Attribute VB_Control = "CboParamZ, 18, 17, MSForms, ComboBox"
Attribute VB_Control = "CboKspA, 19, 18, MSForms, ComboBox"
Attribute VB_Control = "CboKspB, 20, 19, MSForms, ComboBox"
Attribute VB_Control = "CboSol11, 21, 20, MSForms, ComboBox"
Attribute VB_Control = "CboSol15, 22, 21, MSForms, ComboBox"
Attribute VB_Control = "CboSol14, 23, 22, MSForms, ComboBox"
Attribute VB_Control = "CboSol13, 24, 23, MSForms, ComboBox"
Attribute VB_Control = "CboSol12, 25, 24, MSForms, ComboBox"
Attribute VB_Control = "CboSol16, 26, 25, MSForms, ComboBox"
Attribute VB_Control = "CboSol17, 27, 26, MSForms, ComboBox"
Attribute VB_Control = "CboSol18, 28, 27, MSForms, ComboBox"
Attribute VB_Control = "CboSol19, 29, 28, MSForms, ComboBox"
Attribute VB_Control = "CboSol20, 30, 29, MSForms, ComboBox"
Attribute VB_Control = "Cmd_SetParam, 31, 30, MSForms, CommandButton"
Attribute VB_Control = "cmd_calksp, 32, 31, MSForms, CommandButton"
Attribute VB_Control = "CboKspC, 33, 32, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_1, 35, 33, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_2, 36, 34, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_3, 37, 35, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_4, 38, 36, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_5, 39, 37, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_6, 40, 38, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_7, 41, 39, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_8, 42, 40, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_9, 43, 41, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_10, 44, 42, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_11, 45, 43, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_15, 46, 44, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_14, 47, 45, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_13, 48, 46, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_12, 49, 47, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_16, 50, 48, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_17, 51, 49, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_18, 52, 50, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_19, 53, 51, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_20, 54, 52, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch1, 58, 53, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch2, 59, 54, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch3, 60, 55, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch4, 61, 56, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch5, 62, 57, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch6, 63, 58, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch7, 64, 59, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch8, 65, 60, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch9, 66, 61, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch10, 67, 62, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch11, 68, 63, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch12, 69, 64, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch13, 70, 65, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch14, 71, 66, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch15, 72, 67, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch16, 73, 68, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch17, 74, 69, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch18, 75, 70, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch19, 76, 71, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch20, 77, 72, MSForms, ComboBox"
Attribute VB_Control = "CboSol21, 78, 73, MSForms, ComboBox"
Attribute VB_Control = "CboSol22, 79, 74, MSForms, ComboBox"
Attribute VB_Control = "CboSol23, 80, 75, MSForms, ComboBox"
Attribute VB_Control = "CboSol24, 81, 76, MSForms, ComboBox"
Attribute VB_Control = "CboSol26, 82, 77, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_21, 83, 78, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_22, 84, 79, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_23, 85, 80, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_24, 86, 81, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_26, 87, 82, MSForms, ComboBox"
Attribute VB_Control = "CboSol27, 88, 83, MSForms, ComboBox"
Attribute VB_Control = "CboSol28, 89, 84, MSForms, ComboBox"
Attribute VB_Control = "CboSol29, 90, 85, MSForms, ComboBox"
Attribute VB_Control = "CboSol30, 91, 86, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_27, 92, 87, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_28, 93, 88, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_29, 94, 89, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_30, 95, 90, MSForms, ComboBox"
Attribute VB_Control = "CboSol25, 96, 91, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_25, 97, 92, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch22, 98, 93, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch23, 99, 94, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch24, 100, 95, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch25, 101, 96, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch26, 102, 97, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch27, 103, 98, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch28, 104, 99, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch29, 105, 100, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch30, 106, 101, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch21, 107, 102, MSForms, ComboBox"
Attribute VB_Control = "CboSol31, 109, 103, MSForms, ComboBox"
Attribute VB_Control = "CboSol32, 110, 104, MSForms, ComboBox"
Attribute VB_Control = "CboSol33, 111, 105, MSForms, ComboBox"
Attribute VB_Control = "CboSol34, 112, 106, MSForms, ComboBox"
Attribute VB_Control = "CboSol35, 113, 107, MSForms, ComboBox"
Attribute VB_Control = "CboSol36, 114, 108, MSForms, ComboBox"
Attribute VB_Control = "CboSol37, 115, 109, MSForms, ComboBox"
Attribute VB_Control = "CboSol38, 116, 110, MSForms, ComboBox"
Attribute VB_Control = "CboSol39, 117, 111, MSForms, ComboBox"
Attribute VB_Control = "CboSol40, 118, 112, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_31, 119, 113, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_32, 120, 114, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_33, 121, 115, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_34, 122, 116, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_35, 123, 117, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_36, 124, 118, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_37, 125, 119, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_38, 126, 120, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_39, 127, 121, MSForms, ComboBox"
Attribute VB_Control = "CboSol2_40, 128, 122, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch31, 129, 123, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch33, 130, 124, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch35, 131, 125, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch32, 132, 126, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch34, 133, 127, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch37, 134, 128, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch36, 135, 129, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch39, 136, 130, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch38, 137, 131, MSForms, ComboBox"
Attribute VB_Control = "CboSwitch40, 138, 132, MSForms, ComboBox"
Attribute VB_Control = "CommandButton1, 144, 133, MSForms, CommandButton"
Option Explicit

Const HAP_RESULTS_SUCCESS = 1
Const HAP_NORESULTS = 2
Const HAP_RESULTS_ERRORS = 3
Const HAP_RESULTS_WARNINGS = 4

Private Const SolventKind = 173
Private Const NumberofDataPoint = 40
Private Const NumberofParameter = 7

Private SolventID(SolventKind - 1) As String
Private SolventName(SolventKind - 1) As String

Dim node As IHNode
Dim NodeProp As IHNode
Dim NodeComp As IHNode
Dim Nodechem As IHNode
Dim NodeReg As IHNode
Dim NodeData As IHNode

Private Combosolvent1(1 To NumberofDataPoint) As MSForms.ComboBox
Private Combosolvent2(1 To NumberofDataPoint) As MSForms.ComboBox
Private ComboSwitch(1 To NumberofDataPoint) As MSForms.ComboBox

Dim RegFlag(NumberofParameter) As Integer
Dim RegCount As Integer
Dim Param(NumberofParameter) As Variant
Dim StdDev(NumberofParameter) As Double
Dim RegIndex(NumberofParameter) As Integer

Private Sub chk_IsVisible_Click()

    ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
    
        ' -- set the simulation Visible/Not Visible based on check box value --
        go_Simulation.Visible = chk_IsVisible.Value
    End If 'IsSimLoaded = True
End Sub

Private Sub cmd_calksp_Click()
Dim R As Double
R = 8314.4
Range("KspA").Value = Range("DrugS").Value / R
Range("KspB").Value = -Range("KspA").Value * Range("DrugTm").Value
End Sub

Private Sub cmd_OpenSimulaiton_Click()
Dim lv_FilePathName As Variant

On Error GoTo ErrorHandler
    ' -- use the xlGetFilePathName subroutine to get name
    '    and path of Aspen Plus file --
    lv_FilePathName = xlGetFilePathName
    
    ' -- call xlStartSettings --
    Call xlStartSettings("Opening Simulation")
    
    ' -- check if the Cancel button was used in the
    '    File/Open dialogue box --
    If lv_FilePathName <> False Then
        
        ' -- check to see if simulation is loaded --
        If IsSimLoaded = True Then
            
            ' -- set the simulation to Not Visible so it can be closed --
            go_Simulation.Visible = False
            
            ' -- close simulation --
            go_Simulation.Close
            Set go_Simulation = Nothing
        End If 'IsSimLoaded = True
        
        ' -- open the selected Aspen Plus File --
        Set go_Simulation = GetObject(lv_FilePathName)
        
        ' -- write the FilePathName to the workbook --
        ActiveSheet.Range("FilePath").Value = lv_FilePathName
        
        ' -- make the Aspen Plus GUI Visible/Not Visible based on check box value --
        go_Simulation.Visible = chk_IsVisible.Value
    End If 'lv_FilePathName <> False
    
    ' -- call xlEndSettings --
    Call xlEndSettings
    
    Call LoadCompList
Exit Sub
ErrorHandler:
Application.Cursor = xlDefault
MsgBox "Error in opening file" & Err & ":" & Error(Err)
End Sub

Private Sub cmd_DefineDrug_Click()
   
    Dim R As Double
    Dim ParamA As Double
    Dim ParamB As Double
    Dim ParamC As Double
    R = 8314.4 'J/Kmole-K
    
    'Prompt to run step 1 first if the simulation hasn't been loaded.
    If go_Simulation Is Nothing Then
    MsgBox "Please run Step 1 to load the simulation first!", 1, "Please Load Simulation First"
    Exit Sub
    End If
    
    On Error GoTo ErrorHandler
  
    '-- Set MW for DRUG -
    Set node = go_Simulation.Tree.Data
    
    If (Range("DrugName").Value = "" Or Range("DrugName").Value = " ") Then
    Else
        node.FindNode("\Components\Specifications\Comments\#0").Value = Range("DrugName").Value
    End If

    
    If (Range("DrugMW").Value = "" Or Range("DrugMW").Value = " ") Then
    Else
        node.FindNode("Properties\Parameters\Pure Components\MW\Input\VALUE\(MW,DRUG)").Value = Range("DrugMW").Value
        node.FindNode("Properties\Parameters\Pure Components\MW\Input\VALUE\(MW,SOLID)").Value = Range("DrugMW").Value
       
    End If
    
    If (Range("DrugTm").Value = "" Or Range("DrugTm").Value = " ") Then
    Else
        If (Range("DrugS").Value = "" Or Range("DrugS").Value = " ") Then
           If (Range("DrugH").Value = "" Or Range("DrugH").Value = " ") Then
           MsgBox (" Please input the entropy or the enthalpy of fusion")
           Else
           Range("DrugS").Value = Range("DrugH").Value * 1000 / Range("DrugTm").Value
           End If
        Else
           Range("DrugH").Value = Range("DrugS") * Range("DrugTm").Value / 1000
        End If
        
        Range("KspC").Value = 0
         ' set default value for Ksp C
         
        ParamA = Range("DrugS").Value / R
        ParamB = -ParamA * Range("DrugTm").Value
        ParamC = Range("KspC").Value
        
        node.FindNode("Chemistry\SOLID\Input\K_A\SOLID").Value = ParamA
        node.FindNode("Chemistry\SOLID\Input\K_B\SOLID").Value = ParamB
        node.FindNode("Chemistry\SOLID\Input\K_C\SOLID").Value = ParamC
        
    End If
    'MsgBox ("Drug name, MW, and Ksp are defined")
     
Exit Sub
ErrorHandler:
Application.Cursor = xlDefault
MsgBox "Error in defining drug" & Err & ":" & Error(Err)
End Sub

Private Sub Cmd_SetParam_Click()
   Dim FilePath As String
   Dim FileName As String
   Dim flag As Long
   Dim iap As IAPPDF
    
   'Prompt to run step 1 first if the simulation hasn't been loaded.
    If go_Simulation Is Nothing Then
    MsgBox "Please run Step 1 to load the simulation first!", 1, "Please Load Simulation First"
    Exit Sub
    End If
 
   On Error GoTo ErrorHandler
   FilePath = Range("FilePath").Value
   FileName = Left(FilePath, InStr(FilePath, ".aprbkp"))
   Set node = go_Simulation.Tree.Data
  ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
    
        ' -- put the model parameters --
        Call PutModelParam
               
        Call go_Simulation.SaveAs(FileName + "aprbkp")
            
        ' -- call xlEndSettings --
        Call xlEndSettings
        'MsgBox ("Estimated parameters are entered")
    
     End If 'IsSimLoaded = True
Exit Sub
ErrorHandler:
Application.Cursor = xlDefault
MsgBox "Error in updating parameters" & Err & ":" & Error(Err)
End Sub
Private Sub cmd_Run_Click()
    Dim flag
    Dim FilePath As String
    Dim FileName As String
    Dim flag1 As Long
    Dim iap As IAPPDF
    Dim i As Integer
    Dim sInput As String
   
    'Prompt to run step 1 first if the simulation hasn't been loaded.
    If go_Simulation Is Nothing Then
    MsgBox "Please run Step 1 to load the simulation first!", 1, "Please Load Simulation First"
    Exit Sub
    End If
    
    Range("$A$8").Name = "DrugName"
    Range("$B$8").Name = "DrugMW"
    Range("$C$8").Name = "DrugTm"
    Range("$D$8").Name = "DrugH"
    Range("$E$8").Name = "DrugS"
    Range("$A$13").Name = "ParamX"
    Range("$B$13").Name = "ParamY1"
    Range("$C$13").Name = "ParamY2"
    Range("$D$13").Name = "ParamZ"
    Range("$E$13").Name = "KspA"
    Range("$F$13").Name = "KspB"
    Range("$G$13").Name = "KspC"
    For i = 1 To NumberofDataPoint
        Range("$B$" & 23 + i).Name = "Solv1_" & i
        Range("$D$" & 23 + i).Name = "Solv2_" & i
        Range("$E$" & 23 + i).Name = "Temp" & i
        Range("$F$" & 23 + i).Name = "Solubility" & i
        Range("$G$" & 23 + i).Name = "Std_dev" & i
        Range("$J$" & 23 + i).Name = "TempEst" & i
        Range("$K$" & 23 + i).Name = "SoluEst" & i
    Next i
    Range("$N$23").Name = "ParamXEst"
    Range("$N$24").Name = "ParamY1Est"
    Range("$N$25").Name = "ParamY2Est"
    Range("$N$26").Name = "ParamZEst"
    Range("$N$27").Name = "KspAEst"
    Range("$N$28").Name = "KspBEst"
    Range("$N$29").Name = "KspCEst"
    Range("$O$23").Name = "StdDevX"
    Range("$O$24").Name = "StdDevY1"
    Range("$O$25").Name = "StdDevY2"
    Range("$O$26").Name = "StdDevZ"
    Range("$O$27").Name = "StdDevKspA"
    Range("$O$28").Name = "StdDevKspB"
    Range("$O$29").Name = "StdDevKspC"
    Range("$N$31").Name = "SumWeight"
    
'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!incase user changes the regress/exclude manually.
   
    
    Set NodeProp = go_Simulation.Tree.Data.Properties
    
    'Application.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\USAGE\#0")
    Set node = NodeProp.FindNode("Regression\BINARY\Input\USAGE\#0")
    node.Value = CboParamx.Text
    'NodeProp.Regression.Elements("BINARY").Input.Elements("USAGE").Elements(0).Value = CboParamx.Text
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#1").Value = CboParamY1.Text
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#2").Value = CboParamY2.Text
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#3").Value = CboParamZ.Text
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#4").Value = CboKspA.Text
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#5").Value = CboKspB.Text
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#6").Value = CboKspC.Text
'!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    
    On Error GoTo ErrorHandler
    FilePath = Range("FilePath").Value
    FileName = Left(FilePath, InStr(FilePath, ".aprbkp"))
    Set node = go_Simulation.Tree.Data
    ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
        flag = MsgBox("DRS run will override the current parameters. Please select the ""BINARY"" case when being prompted.", 1, "Run DRS")
      If (flag = 2) Then
        Exit Sub 'Msgbox Cancel
      Else
        ' -- call xlStartSettings --
        Call xlStartSettings("Running Simulation")
        
        ' -- turn off messages resulting from a long Aspen Plus run --
        Application.DisplayAlerts = False
        
        'Set the run class to DRS
        node.FindNode("Setup\Main\Input\RUN_CLASS").Value = "DRS"
        
        ' -- put the Input Values --
        Call PutInputValues
        
        go_Simulation.Activate
        
        ' -- turn Interactively Load Results off --
        go_Simulation.Engine.OptionSettings(IAP_RUN_INTERTACTIVE) = False
        
        ' -- suppress the dialog box for DRS runs --
        go_Simulation.SuppressDialogs = False
        
        ' -- run the simulation --
        go_Simulation.Engine.Run
        
         'go_Simulation.Visible = False
        ' go_Simulation.Close
        '
        ' Call COM
        '
        sInput = "xlmain" + " " + Application.Caption
        Call COMAddinHelper.Invoke("APXL_SetForegroundWindow", sInput)
        
        ' -- get the Output Values --
        Call GetOutputValues
             
        '--- Set KspA
        'Call PutModelParam
        
        ' -- call xlEndSettings --
        'Call xlEndSettings
        
        'Call CloseSimulation
        
        go_Simulation.SuppressDialogs = True
        Call go_Simulation.SaveAs(FileName + "aprbkp")
        
        If chk_IsVisible.Value = False Then go_Simulation.Visible = False
        
        'Set iap = go_Simulation
        'Call iap.GetAPPDF(FileName + "aprpdf", flag1)
        
        ' Update aprpdf used by the xla
        'Call xlStartSettings("Updating aprpdf file")
        'Worksheets("Regression").Range("F1").Formula = "=RefreshBkpPackage2(FilePath)"
        'Worksheets("Regression").Range("F1").Formula = ""
        
        ' -- call xlEndSettings --
        Call xlEndSettings
        
        go_Simulation.Engine.Stop
        go_Simulation.SuppressDialogs = False
        
       End If 'msgbox OK

    End If 'IsSimLoaded = True
Exit Sub

ErrorHandler:
Application.Cursor = xlDefault
go_Simulation.SuppressDialogs = True
go_Simulation.Visible = False
'MsgBox "Error in running DRS" & Err & ":" & Error(Err)
MsgBox "Error in running DRS for Binary Solvents. This normally happens when you run the second DRS. You can re-run DRS for Binary Solvents by re-opening the regression file"
go_Simulation.Engine.Stop
go_Simulation.SuppressDialogs = False

End Sub
Private Sub LoadCompList()
    
    Dim NOlig As Integer
    Dim NCC As Integer
    Dim i As Integer
    Dim j As Integer
    Dim Conventional As String
    Dim count As Integer
    
    On Error GoTo ErrorHandler
    
    For i = 1 To NumberofDataPoint
        Set Combosolvent1(i) = Sheet11.OLEObjects("CboSol" & i).Object
        Set Combosolvent2(i) = Sheet11.OLEObjects("CboSol2_" & i).Object
        Set ComboSwitch(i) = Sheet11.OLEObjects("CboSwitch" & i).Object
    Next i
     
    count = CboSol1.ListCount
    If (count = 0) Then
    
     For i = 0 To SolventKind - 1
        SolventName(i) = Sheets("Solvent List").Range("SolventName").Item(i + 1).Value
        SolventID(i) = Sheets("Solvent List").Range("SolventID").Item(i + 1).Value
        For j = 1 To NumberofDataPoint
            Combosolvent1(j).AddItem (SolventName(i))
            Combosolvent2(j).AddItem (SolventName(i))
        Next j
    Next i
 
    'Add empty string for "clear"
    For j = 1 To NumberofDataPoint
        Combosolvent1(j).AddItem ("")
        Combosolvent2(j).AddItem ("")
    Next j
     
    'Load option list for Parameter regression
    CboParamx.Font.Bold = False
    CboParamY1.Font.Bold = False
    CboParamY2.Font.Bold = False
    CboParamZ.Font.Bold = False
    CboKspA.Font.Bold = False
    CboKspB.Font.Bold = False
    CboKspC.Font.Bold = False
    
    CboParamx.AddItem ("REGRESS")
    CboParamY1.AddItem ("REGRESS")
    CboParamY2.AddItem ("REGRESS")
    CboParamZ.AddItem ("REGRESS")
    CboKspA.AddItem ("REGRESS")
    CboKspB.AddItem ("REGRESS")
    CboKspC.AddItem ("REGRESS")
    CboParamx.AddItem ("EXCLUDE")
    CboParamY1.AddItem ("EXCLUDE")
    CboParamY2.AddItem ("EXCLUDE")
    CboParamZ.AddItem ("EXCLUDE")
    CboKspA.AddItem ("EXCLUDE")
    CboKspB.AddItem ("EXCLUDE")
    CboKspC.AddItem ("EXCLUDE")
    
    For j = 1 To NumberofDataPoint
        ComboSwitch(j).AddItem ("Yes")
        ComboSwitch(j).AddItem ("No")
    Next j
    
    'initialize Parameter regression for Excel and bkp
'    CboParamx.Text = "REGRESS"
'    CboParamY1.Text = "REGRESS"
'    CboParamY2.Text = "REGRESS"
'    CboParamZ.Text = "REGRESS"
'    CboKspA.Text = "REGRESS"
'    CboKspB.Text = "EXCLUDE"
'    CboKspC.Text = "EXCLUDE"
    
'    CboSwitch1.Text = "Yes"
'    CboSwitch2.Text = "Yes"
'    CboSwitch3.Text = "Yes"
'    CboSwitch4.Text = "Yes"
'    CboSwitch5.Text = "Yes"
'    CboSwitch6.Text = "Yes"
'    CboSwitch7.Text = "Yes"
'    CboSwitch8.Text = "Yes"
'    CboSwitch9.Text = "Yes"
'    CboSwitch10.Text = "Yes"
'    CboSwitch11.Text = "Yes"
'    CboSwitch12.Text = "Yes"
'    CboSwitch13.Text = "Yes"
'    CboSwitch14.Text = "Yes"
'    CboSwitch15.Text = "Yes"
'    CboSwitch16.Text = "Yes"
'    CboSwitch17.Text = "Yes"
'    CboSwitch18.Text = "Yes"
'    CboSwitch19.Text = "Yes"
'    CboSwitch20.Text = "Yes"
'    CboSwitch21.Text = "Yes"
'    CboSwitch22.Text = "Yes"
'    CboSwitch23.Text = "Yes"
'    CboSwitch24.Text = "Yes"
'    CboSwitch25.Text = "Yes"
'    CboSwitch26.Text = "Yes"
'    CboSwitch27.Text = "Yes"
'    CboSwitch28.Text = "Yes"
'    CboSwitch29.Text = "Yes"
'    CboSwitch30.Text = "Yes"
'    CboSwitch31.Text = "Yes"
'    CboSwitch32.Text = "Yes"
'    CboSwitch33.Text = "Yes"
'    CboSwitch34.Text = "Yes"
'    CboSwitch35.Text = "Yes"
'    CboSwitch36.Text = "Yes"
'    CboSwitch37.Text = "Yes"
'    CboSwitch38.Text = "Yes"
'    CboSwitch39.Text = "Yes"
'    CboSwitch40.Text = "Yes"
        
'    Dim NodeProp As IHNode
'    Set NodeProp = go_Simulation.Tree.Data.Properties
'    For j = 0 To 4
'    NodeProp.Regression.Elements("BINARY").Input.Elements("USAGE").Elements(j).Value = "REGRESS"
'    Next j
'    NodeProp.Regression.Elements("BINARY").Input.Elements("USAGE").Elements(5).Value = "EXCLUDE"
'    NodeProp.Regression.Elements("BINARY").Input.Elements("USAGE").Elements(6).Value = "EXCLUDE"
    
    End If

    If SolventName(1) = "" Then
        For i = 0 To SolventKind - 1
            SolventName(i) = Sheets("Solvent List").Range("SolventName").Item(i + 1).Value
            SolventID(i) = Sheets("Solvent List").Range("SolventID").Item(i + 1).Value
        Next i
    End If
Exit Sub
ErrorHandler:
Application.Cursor = xlDefault
MsgBox "Error in loading component list" & Err & ":" & Error(Err)
End Sub
Public Sub PutModelParam()

    Dim R As Double
    R = 8314.4   'J/(kmol*k)
    
    On Error GoTo ErrorHandler
    
    Set NodeProp = go_Simulation.Tree.Data.Properties
    Set Nodechem = go_Simulation.Tree.Data.Chemistry
    
    '-- Set x, y-, y+, z parameters for BINARY ---
    If (Range("ParamX").Value = "" Or Range("ParamX").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL1\XYZE\DRUG").Value = Range("ParamX").Value
    End If
    
    If (Range("ParamY1").Value = "" Or Range("ParamY1").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL2\XYZE\DRUG").Value = Range("ParamY1").Value
    End If
    
    If (Range("ParamY2").Value = "" Or Range("ParamY2").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL3\XYZE\DRUG").Value = Range("ParamY2").Value
    End If
    
    If (Range("ParamZ").Value = "" Or Range("ParamZ").Value = " ") Then
    Else
         NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL4\XYZE\DRUG").Value = Range("ParamZ").Value
    End If
     
    '-- Set KspA parameters for Chemistry ---
     'Application.Tree.Data.Chemistry.SOLID.Input.K_A.SOLID
     'If (Range("KspA").Value = "" Or Range("KspA").Value = " ") Then
   '  Range("KspA").Value = Range("DrugS").Value / R
   '  Range("KspB").Value = -Range("DrugH") / R

    'Else
         Nodechem.FindNode("SOLID\Input\K_A\SOLID").Value = Range("KspA").Value
         Nodechem.FindNode("SOLID\Input\K_B\SOLID").Value = Range("KspB").Value
         Nodechem.FindNode("SOLID\Input\K_C\SOLID").Value = Range("KspC").Value
    'End If
Exit Sub
ErrorHandler:
Application.Cursor = xlDefault
MsgBox "Error in setting parameters" & Err & ":" & Error(Err)
End Sub

Private Sub CloseSimulation()
    'Dim lv_FilePathName As Variant

    'lv_FilePathName = xlGetFilePathName
    
    ' -- check to see if simulation is loaded --
    If IsSimLoaded = True Then
    
        ' --Export the aprbkp file
        'Call go_Simulation.Export(HAPEXP_BACKUP, lv_FilePathName)
        Call go_Simulation.Save
        
        ' -- call xlStartSettings --
        Call xlStartSettings("Closing Simulation")
        
        ' -- set the simulation to Not Visible so it can be closed --
        go_Simulation.Visible = False
        
        ' -- close simulation --
        go_Simulation.Close
        Set go_Simulation = Nothing
        
        ' Update aprpdf used by the xla
        'Call xlStartSettings("Updating aprpdf file")
        'Worksheets("Define solute").Range("F1").Formula = "=RefreshBkpPackage()"
        'Worksheets("Define solute").Range("F1").Formula = ""

        ' -- delete displayed name of simulation --
        'Worksheets("Define solute").Range("A5").Value = ""
        
        ' -- call xlEndSettings --
        'Call xlEndSettings
    End If 'IsSimLoaded = True
End Sub
Public Sub PutInputValues()

Dim X As Double
Dim i As Integer
Dim FracSol1(NumberofDataPoint) As Double
Dim SOL As String
    
    For i = 1 To NumberofDataPoint
        FracSol1(i) = Range("Solv1_" & i).Value / (1 + Range("Solubility" & i).Value)
    Next i
    
    On Error GoTo ErrorHandler
    
    Set NodeProp = go_Simulation.Tree.Data.Properties
    Set NodeReg = go_Simulation.Tree.Data.Properties.Regression
    Set Nodechem = go_Simulation.Tree.Data.Chemistry
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    
    'clean up the regression results for the previous run
    Call CleanResults
    
    'Init weight factor for DRS
    For i = 1 To NumberofDataPoint
        'Application.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\WEIGHT\SOL1")
        NodeReg.FindNode("BINARY\Input\WEIGHT\SOL" & i).Value = 0.0000000001
        'NodeReg.Elements("BINARY").Input.Elements("WEIGHT").Elements("SOL" & i).Value = 0.0000000001
    Next i
       
    ' -- Set Solubility (Exp) for solvents --
    Call SetDrugSolubility
    
     'On Error Resume Next
    For i = 1 To NumberofDataPoint
        If (Combosolvent1(i).Text = "" Or Combosolvent1(i).Text = " ") Then
          Combosolvent1(i).Text = ""
        Else
            SOL = FindSolventID(Combosolvent1(i).Text)
            If FindSolventID(Combosolvent1(i).Text) <> "" Then
                'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\CIDS\#0")
                Set node = NodeData.FindNode("SOL" & i & "\Input\CIDS\#2")
                If node.Value <> FindSolventID(Combosolvent1(i).Text) Then
                    NodeData.FindNode("SOL" & i & "\Input\CIDS\#1").Value = FindSolventID(Combosolvent1(i).Text)
                Else
                    node.Value = "SOLID"
                    NodeData.FindNode("SOL" & i & "\Input\CIDS\#1").Value = FindSolventID(Combosolvent1(i).Text)
                End If
                
                'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\VALUE\#1 X 12-NH2C2")
                Set node = NodeProp.FindNode("Data\SOL" & i & "\Input\VALUE\(#1,X,FindSolventID(Combosolvent1(i).Text))")
                If node Is Nothing Then
                Else
                  node.Value = FracSol1(i)
                End If
            Else
               If ComboSwitch(i).Text <> "No" Then ComboSwitch(i).Text = "No"
            End If
            
'            If FindSolventID(Combosolvent1(i).Text) <> "" Then
'                If NodeData.Elements("SOL" & i).Input.Elements("CIDS").Elements(2).Value <> FindSolventID(Combosolvent1(i).Text) Then
'                    NodeData.Elements("SOL" & i).Input.Elements("CIDS").Elements(1).Value = FindSolventID(Combosolvent1(i).Text)
'                Else
'                    NodeData.Elements("SOL" & i).Input.Elements("CIDS").Elements(2).Value = "SOLID"
'                    NodeData.Elements("SOL" & i).Input.Elements("CIDS").Elements(1).Value = FindSolventID(Combosolvent1(i).Text)
'                End If
'                NodeProp.Data.Elements("SOL" & i).Input.Elements("VALUE").Elements(1, x, FindSolventID(Combosolvent1(i).Text)).Value = FracSol1(i)
'            Else
'               If ComboSwitch(i).Text <> "No" Then ComboSwitch(i).Text = "No"
'            End If
        End If
    Next i
    
    '
    'Below stands for the second solvent in the solution
 
    For i = 1 To NumberofDataPoint
        If (Combosolvent2(i).Text = "" Or Combosolvent2(i).Text = " ") Then
        Combosolvent2(i).Text = ""
        Else
            SOL = FindSolventID(Combosolvent2(i).Text)
            If FindSolventID(Combosolvent2(i).Text) <> "" Then
                'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\CIDS\#2")
                NodeData.FindNode("SOL" & i & "\Input\CIDS\#2").Value = FindSolventID(Combosolvent2(i).Text)
                'NodeData.Elements("SOL" & i).Input.Elements("CIDS").Elements(2).Value = FindSolventID(Combosolvent2(i).Text)
            Else
               If ComboSwitch(i).Text <> "No" Then ComboSwitch(i).Text = "No"
            End If
        End If
    Next i
    
    ' -- Set Temperature (Exp) for solvents --
    For i = 1 To NumberofDataPoint
        If (Range("Temp" & i).Value = "" Or Range("Temp" & i).Value = " ") Then
        Else
        NodeProp.FindNode("Data\SOL" & i & "\Input\VALUE\(#1,TEMPERATURE,C)").Value = Range("Temp" & i).Value
        End If
    Next i
    
    Call SetRegressionWeight
    
    'Set Regression flag, counter, and indexed parameters
    
    For i = 1 To 4
        RegFlag(i) = 0
        Param(i) = 0
        RegIndex(i) = 0
        StdDev(i) = 0
    Next i
    
    RegFlag(5) = 0
    RegIndex(5) = 0
    StdDev(5) = 0
   ' RegCount = 0
    
    RegFlag(6) = 0
    RegIndex(6) = 0
    StdDev(6) = 0
   ' RegCount = 0
    
    RegFlag(7) = 0
    RegIndex(7) = 0
    StdDev(7) = 0
    RegCount = 0
    
    
    If (CboParamx.Text = "REGRESS") Then
      RegFlag(1) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 1
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,X-R)").Value = 0#
    End If
    
    If (CboParamY1.Text = "REGRESS") Then
      RegFlag(2) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 2
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,Y-R)").Value = 0#
    End If
    
    If (CboParamY2.Text = "REGRESS") Then
      RegFlag(3) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 3
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,Y+R)").Value = 0#
    End If
    
    If (CboParamZ.Text = "REGRESS") Then
      RegFlag(4) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 4
    Else
      'NodeProp.FindNode("Parameters\Binary Interaction\NRTLXY-1\Input\VALUE\NRTLXY\(DRUG,Z-R)").Value = 0#
    End If
    
    If (CboKspA.Text = "REGRESS") Then
      RegFlag(5) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 5
    End If
    
    If (CboKspB.Text = "REGRESS") Then
      RegFlag(6) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 6
    End If
    
    If (CboKspC.Text = "REGRESS") Then
      RegFlag(7) = 1
      RegCount = RegCount + 1
      RegIndex(RegCount) = 7
    End If
    
Exit Sub
ErrorHandler:
Application.Cursor = xlDefault
MsgBox "Error in setting input data" & Err & ":" & Error(Err)
    
End Sub


Private Sub CboSol1_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL1").Input.Elements("CIDS")
    If (CboSol1.Text = "" Or CboSol1.Text = " " Or CboSol1.Text = CboSol2_1.Text) Then
        CboSol1.Text = ""
    Else
        If FindSolventID(CboSol1.Text) <> "" Then
            If FindSolventID(CboSol2_1.Text) <> "" Then CboSwitch1.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\CIDS\#1")
            NodeData.FindNode("SOL1\Input\CIDS\#1").Value = FindSolventID(CboSol1.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol1.Text)
        Else
            CboSwitch1.Value = "No"
        End If
    End If
     
End Sub
Private Sub CboSol2_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL2").Input.Elements("CIDS")
    If (CboSol2.Text = "" Or CboSol2.Text = " " Or CboSol2.Text = CboSol2_2.Text) Then
        CboSol2.Text = ""
    Else
        If FindSolventID(CboSol2.Text) <> "" Then
            If FindSolventID(CboSol2_2.Text) <> "" Then CboSwitch2.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL2\Input\CIDS\#1")
            NodeData.FindNode("SOL2\Input\CIDS\#1").Value = FindSolventID(CboSol2.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol2.Text)
        Else
            CboSwitch2.Value = "No"
        End If
    End If
    
End Sub
Private Sub CboSol3_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL3").Input.Elements("CIDS")
    If (CboSol3.Text = "" Or CboSol3.Text = " " Or CboSol3.Text = CboSol2_3.Text) Then
        CboSol3.Text = ""
    Else
        If FindSolventID(CboSol3.Text) <> "" Then
            If FindSolventID(CboSol2_3.Text) <> "" Then CboSwitch3.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\CIDS\#1")
            NodeData.FindNode("SOL3\Input\CIDS\#1").Value = FindSolventID(CboSol3.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol3.Text)
        Else
            CboSwitch3.Value = "No"
        End If
    End If

End Sub
Private Sub CboSol4_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL4").Input.Elements("CIDS")
    If (CboSol4.Text = "" Or CboSol4.Text = " " Or CboSol4.Text = CboSol2_4.Text) Then
        CboSol4.Text = ""
    Else
        If FindSolventID(CboSol4.Text) <> "" Then
            If FindSolventID(CboSol2_4.Text) <> "" Then CboSwitch4.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL4\Input\CIDS\#1")
            NodeData.FindNode("SOL4\Input\CIDS\#1").Value = FindSolventID(CboSol4.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol4.Text)
        Else
            CboSwitch4.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol5_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL5").Input.Elements("CIDS")
    
    If (CboSol5.Text = "" Or CboSol5.Text = " " Or CboSol5.Text = CboSol2_5.Text) Then
        CboSol5.Text = ""
    Else
        If FindSolventID(CboSol5.Text) <> "" Then
            If FindSolventID(CboSol2_5.Text) <> "" Then CboSwitch5.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL5\Input\CIDS\#1")
            NodeData.FindNode("SOL5\Input\CIDS\#1").Value = FindSolventID(CboSol5.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol5.Text)
        Else
            CboSwitch5.Value = "No"
        End If
    End If

End Sub

Private Sub CboSol6_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL6").Input.Elements("CIDS")
    If (CboSol6.Text = "" Or CboSol6.Text = " " Or CboSol6.Text = CboSol2_6.Text) Then
        CboSol6.Text = ""
        'go_Simulation.Tree.Data.Properties.Data.Elements("SOL1").Input.Elements("CIDS").Elements(1).Value = ""
    Else
        If FindSolventID(CboSol6.Text) <> "" Then
            If FindSolventID(CboSol2_6.Text) <> "" Then CboSwitch6.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL6\Input\CIDS\#1")
            NodeData.FindNode("SOL6\Input\CIDS\#1").Value = FindSolventID(CboSol6.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol6.Text)
        Else
            CboSwitch6.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol7_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL7").Input.Elements("CIDS")
    If (CboSol7.Text = "" Or CboSol7.Text = " " Or CboSol7.Text = CboSol2_7.Text) Then
        CboSol7.Text = ""
    Else
        If FindSolventID(CboSol7.Text) <> "" Then
            If FindSolventID(CboSol2_7.Text) <> "" Then CboSwitch7.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL7\Input\CIDS\#1")
            NodeData.FindNode("SOL7\Input\CIDS\#1").Value = FindSolventID(CboSol7.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol7.Text)
        Else
            CboSwitch7.Value = "No"
        End If
    End If
    
End Sub
Private Sub CboSol8_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL8").Input.Elements("CIDS")
    If (CboSol8.Text = "" Or CboSol8.Text = " " Or CboSol8.Text = CboSol2_8.Text) Then
        CboSol8.Text = ""
    Else
        If FindSolventID(CboSol8.Text) <> "" Then
            If FindSolventID(CboSol2_8.Text) <> "" Then CboSwitch8.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL8\Input\CIDS\#1")
            NodeData.FindNode("SOL8\Input\CIDS\#1").Value = FindSolventID(CboSol8.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol8.Text)
        Else
            CboSwitch8.Value = "No"
        End If
    End If

End Sub
Private Sub CboSol9_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL9").Input.Elements("CIDS")
    If (CboSol9.Text = "" Or CboSol9.Text = " " Or CboSol9.Text = CboSol2_9.Text) Then
        CboSol9.Text = ""
    Else
        If FindSolventID(CboSol9.Text) <> "" Then
            If FindSolventID(CboSol2_9.Text) <> "" Then CboSwitch9.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL9\Input\CIDS\#1")
            NodeData.FindNode("SOL9\Input\CIDS\#1").Value = FindSolventID(CboSol9.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol9.Text)
        Else
            CboSwitch9.Value = "No"
        End If
    End If
    
End Sub
Private Sub CboSol10_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL10").Input.Elements("CIDS")
    
    If (CboSol10.Text = "" Or CboSol10.Text = " " Or CboSol10.Text = CboSol2_10.Text) Then
        CboSol10.Text = ""
    Else
        If FindSolventID(CboSol10.Text) <> "" Then
            If FindSolventID(CboSol2_10.Text) <> "" Then CboSwitch10.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL10\Input\CIDS\#1")
            NodeData.FindNode("SOL10\Input\CIDS\#1").Value = FindSolventID(CboSol10.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol10.Text)
        Else
            CboSwitch10.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol11_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL11").Input.Elements("CIDS")
    
    If (CboSol11.Text = "" Or CboSol11.Text = " " Or CboSol11.Text = CboSol2_11.Text) Then
        CboSol11.Text = ""
    Else
        If FindSolventID(CboSol11.Text) <> "" Then
            If FindSolventID(CboSol2_11.Text) <> "" Then CboSwitch11.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL11\Input\CIDS\#1")
            NodeData.FindNode("SOL11\Input\CIDS\#1").Value = FindSolventID(CboSol11.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol11.Text)
        Else
            CboSwitch11.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol12_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL12").Input.Elements("CIDS")
    
    If (CboSol12.Text = "" Or CboSol12.Text = " " Or CboSol12.Text = CboSol2_12.Text) Then
        CboSol12.Text = ""
    Else
        If FindSolventID(CboSol12.Text) <> "" Then
            If FindSolventID(CboSol2_12.Text) <> "" Then CboSwitch12.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL12\Input\CIDS\#1")
            NodeData.FindNode("SOL12\Input\CIDS\#1").Value = FindSolventID(CboSol12.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol12.Text)
        Else
            CboSwitch12.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol13_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL13").Input.Elements("CIDS")
    
    If (CboSol13.Text = "" Or CboSol13.Text = " " Or CboSol13.Text = CboSol2_13.Text) Then
        CboSol13.Text = ""
    Else
        If FindSolventID(CboSol13.Text) <> "" Then
            If FindSolventID(CboSol2_13.Text) <> "" Then CboSwitch13.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL13\Input\CIDS\#1")
            NodeData.FindNode("SOL13\Input\CIDS\#1").Value = FindSolventID(CboSol13.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol13.Text)
        Else
            CboSwitch13.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol14_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL14").Input.Elements("CIDS")
    
    If (CboSol14.Text = "" Or CboSol14.Text = " " Or CboSol14.Text = CboSol2_14.Text) Then
        CboSol14.Text = ""
    Else
        If FindSolventID(CboSol14.Text) <> "" Then
            If FindSolventID(CboSol2_14.Text) <> "" Then CboSwitch14.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL14\Input\CIDS\#1")
            NodeData.FindNode("SOL14\Input\CIDS\#1").Value = FindSolventID(CboSol14.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol14.Text)
        Else
            CboSwitch14.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol15_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL15").Input.Elements("CIDS")
    
    If (CboSol15.Text = "" Or CboSol15.Text = " " Or CboSol15.Text = CboSol2_15.Text) Then
        CboSol15.Text = ""
    Else
        If FindSolventID(CboSol15.Text) <> "" Then
            If FindSolventID(CboSol2_15.Text) <> "" Then CboSwitch15.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL15\Input\CIDS\#1")
            NodeData.FindNode("SOL15\Input\CIDS\#1").Value = FindSolventID(CboSol15.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol15.Text)
        Else
            CboSwitch15.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol16_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL16").Input.Elements("CIDS")
    
    If (CboSol16.Text = "" Or CboSol16.Text = " " Or CboSol16.Text = CboSol2_16.Text) Then
        CboSol16.Text = ""
    Else
        If FindSolventID(CboSol16.Text) <> "" Then
            If FindSolventID(CboSol2_16.Text) <> "" Then CboSwitch16.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL16\Input\CIDS\#1")
            NodeData.FindNode("SOL16\Input\CIDS\#1").Value = FindSolventID(CboSol16.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol16.Text)
        Else
            CboSwitch16.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol17_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL17").Input.Elements("CIDS")
    
    If (CboSol17.Text = "" Or CboSol17.Text = " " Or CboSol17.Text = CboSol2_17.Text) Then
        CboSol17.Text = ""
    Else
        If FindSolventID(CboSol17.Text) <> "" Then
            If FindSolventID(CboSol2_17.Text) <> "" Then CboSwitch17.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL17\Input\CIDS\#1")
            NodeData.FindNode("SOL17\Input\CIDS\#1").Value = FindSolventID(CboSol17.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol17.Text)
        Else
            CboSwitch17.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol18_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL18").Input.Elements("CIDS")
    
    If (CboSol18.Text = "" Or CboSol18.Text = " " Or CboSol18.Text = CboSol2_18.Text) Then
        CboSol18.Text = ""
    Else
        If FindSolventID(CboSol18.Text) <> "" Then
            If FindSolventID(CboSol2_18.Text) <> "" Then CboSwitch18.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL18\Input\CIDS\#1")
            NodeData.FindNode("SOL18\Input\CIDS\#1").Value = FindSolventID(CboSol18.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol18.Text)
        Else
            CboSwitch18.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol19_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL19").Input.Elements("CIDS")
    
    If (CboSol19.Text = "" Or CboSol19.Text = " " Or CboSol19.Text = CboSol2_19.Text) Then
        CboSol19.Text = ""
    Else
        If FindSolventID(CboSol19.Text) <> "" Then
            If FindSolventID(CboSol2_19.Text) <> "" Then CboSwitch19.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL19\Input\CIDS\#1")
            NodeData.FindNode("SOL19\Input\CIDS\#1").Value = FindSolventID(CboSol19.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol19.Text)
        Else
            CboSwitch19.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol20_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL20").Input.Elements("CIDS")
    
    If (CboSol20.Text = "" Or CboSol20.Text = " " Or CboSol20.Text = CboSol2_20.Text) Then
        CboSol20.Text = ""
    Else
        If FindSolventID(CboSol20.Text) <> "" Then
            If FindSolventID(CboSol2_20.Text) <> "" Then CboSwitch20.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL20\Input\CIDS\#1")
            NodeData.FindNode("SOL20\Input\CIDS\#1").Value = FindSolventID(CboSol20.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol20.Text)
        Else
            CboSwitch20.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol21_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL21").Input.Elements("CIDS")
    
    If (CboSol21.Text = "" Or CboSol21.Text = " " Or CboSol21.Text = CboSol2_21.Text) Then
        CboSol21.Text = ""
    Else
        If FindSolventID(CboSol21.Text) <> "" Then
            If FindSolventID(CboSol2_21.Text) <> "" Then CboSwitch21.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL21\Input\CIDS\#1")
            NodeData.FindNode("SOL21\Input\CIDS\#1").Value = FindSolventID(CboSol21.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol21.Text)
        Else
            CboSwitch21.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol22_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL22").Input.Elements("CIDS")
    
    If (CboSol22.Text = "" Or CboSol22.Text = " " Or CboSol22.Text = CboSol2_22.Text) Then
        CboSol22.Text = ""
    Else
        If FindSolventID(CboSol22.Text) <> "" Then
            If FindSolventID(CboSol2_22.Text) <> "" Then CboSwitch22.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL22\Input\CIDS\#1")
            NodeData.FindNode("SOL22\Input\CIDS\#1").Value = FindSolventID(CboSol22.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol22.Text)
        Else
            CboSwitch22.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol23_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL23").Input.Elements("CIDS")
    
    If (CboSol23.Text = "" Or CboSol23.Text = " " Or CboSol23.Text = CboSol2_23.Text) Then
        CboSol23.Text = ""
    Else
        If FindSolventID(CboSol23.Text) <> "" Then
            If FindSolventID(CboSol2_23.Text) <> "" Then CboSwitch23.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL23\Input\CIDS\#1")
            NodeData.FindNode("SOL23\Input\CIDS\#1").Value = FindSolventID(CboSol23.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol23.Text)
        Else
            CboSwitch23.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol24_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL24").Input.Elements("CIDS")
    
    If (CboSol24.Text = "" Or CboSol24.Text = " " Or CboSol24.Text = CboSol2_24.Text) Then
        CboSol24.Text = ""
    Else
        If FindSolventID(CboSol24.Text) <> "" Then
            If FindSolventID(CboSol2_24.Text) <> "" Then CboSwitch24.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL24\Input\CIDS\#1")
            NodeData.FindNode("SOL24\Input\CIDS\#1").Value = FindSolventID(CboSol24.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol24.Text)
        Else
            CboSwitch24.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol25_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL25").Input.Elements("CIDS")
    
    If (CboSol25.Text = "" Or CboSol25.Text = " " Or CboSol25.Text = CboSol2_25.Text) Then
        CboSol25.Text = ""
    Else
        If FindSolventID(CboSol25.Text) <> "" Then
            If FindSolventID(CboSol2_25.Text) <> "" Then CboSwitch25.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL25\Input\CIDS\#1")
            NodeData.FindNode("SOL25\Input\CIDS\#1").Value = FindSolventID(CboSol25.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol25.Text)
        Else
            CboSwitch25.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol26_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL26").Input.Elements("CIDS")
    
    If (CboSol26.Text = "" Or CboSol26.Text = " " Or CboSol26.Text = CboSol2_26.Text) Then
        CboSol26.Text = ""
    Else
        If FindSolventID(CboSol26.Text) <> "" Then
            If FindSolventID(CboSol2_26.Text) <> "" Then CboSwitch26.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL26\Input\CIDS\#1")
            NodeData.FindNode("SOL26\Input\CIDS\#1").Value = FindSolventID(CboSol26.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol26.Text)
        Else
            CboSwitch26.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol27_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL27").Input.Elements("CIDS")
    
    If (CboSol27.Text = "" Or CboSol27.Text = " " Or CboSol27.Text = CboSol2_27.Text) Then
        CboSol27.Text = ""
    Else
        If FindSolventID(CboSol27.Text) <> "" Then
            If FindSolventID(CboSol2_27.Text) <> "" Then CboSwitch27.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL27\Input\CIDS\#1")
            NodeData.FindNode("SOL27\Input\CIDS\#1").Value = FindSolventID(CboSol27.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol27.Text)
        Else
            CboSwitch27.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol28_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL28").Input.Elements("CIDS")
    
    If (CboSol28.Text = "" Or CboSol28.Text = " " Or CboSol28.Text = CboSol2_28.Text) Then
        CboSol28.Text = ""
    Else
        If FindSolventID(CboSol28.Text) <> "" Then
            If FindSolventID(CboSol2_28.Text) <> "" Then CboSwitch28.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL28\Input\CIDS\#1")
            NodeData.FindNode("SOL28\Input\CIDS\#1").Value = FindSolventID(CboSol28.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol28.Text)
        Else
            CboSwitch28.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol29_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL29").Input.Elements("CIDS")
    
    If (CboSol29.Text = "" Or CboSol29.Text = " " Or CboSol29.Text = CboSol2_29.Text) Then
        CboSol29.Text = ""
    Else
        If FindSolventID(CboSol29.Text) <> "" Then
            If FindSolventID(CboSol2_29.Text) <> "" Then CboSwitch29.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL29\Input\CIDS\#1")
            NodeData.FindNode("SOL29\Input\CIDS\#1").Value = FindSolventID(CboSol29.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol29.Text)
        Else
            CboSwitch29.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol30_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL30").Input.Elements("CIDS")
    
    If (CboSol30.Text = "" Or CboSol30.Text = " " Or CboSol30.Text = CboSol2_30.Text) Then
        CboSol30.Text = ""
    Else
        If FindSolventID(CboSol30.Text) <> "" Then
            If FindSolventID(CboSol2_30.Text) <> "" Then CboSwitch30.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL30\Input\CIDS\#1")
            NodeData.FindNode("SOL30\Input\CIDS\#1").Value = FindSolventID(CboSol30.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol30.Text)
        Else
            CboSwitch30.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol31_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL31").Input.Elements("CIDS")
    
    If (CboSol31.Text = "" Or CboSol31.Text = " " Or CboSol31.Text = CboSol2_31.Text) Then
        CboSol31.Text = ""
    Else
        If FindSolventID(CboSol31.Text) <> "" Then
            If FindSolventID(CboSol2_31.Text) <> "" Then CboSwitch31.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL31\Input\CIDS\#1")
            NodeData.FindNode("SOL31\Input\CIDS\#1").Value = FindSolventID(CboSol31.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol31.Text)
        Else
            CboSwitch31.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol32_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL32").Input.Elements("CIDS")
    
    If (CboSol32.Text = "" Or CboSol32.Text = " " Or CboSol32.Text = CboSol2_32.Text) Then
        CboSol32.Text = ""
    Else
        If FindSolventID(CboSol32.Text) <> "" Then
            If FindSolventID(CboSol2_32.Text) <> "" Then CboSwitch32.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL32\Input\CIDS\#1")
            NodeData.FindNode("SOL32\Input\CIDS\#1").Value = FindSolventID(CboSol32.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol32.Text)
        Else
            CboSwitch32.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol33_Change()
     
    On Error Resume Next
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data
    Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL33").Input.Elements("CIDS")
    
    If (CboSol33.Text = "" Or CboSol33.Text = " " Or CboSol33.Text = CboSol2_33.Text) Then
        CboSol33.Text = ""
    Else
        If FindSolventID(CboSol33.Text) <> "" Then
            If FindSolventID(CboSol2_33.Text) <> "" Then CboSwitch33.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL33\Input\CIDS\#1")
            NodeData.FindNode("SOL33\Input\CIDS\#1").Value = FindSolventID(CboSol33.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol33.Text)
        Else
            CboSwitch33.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol34_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL34").Input.Elements("CIDS")
    
    If (CboSol34.Text = "" Or CboSol34.Text = " " Or CboSol34.Text = CboSol2_34.Text) Then
        CboSol34.Text = ""
    Else
        If FindSolventID(CboSol34.Text) <> "" Then
            If FindSolventID(CboSol2_34.Text) <> "" Then CboSwitch34.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL34\Input\CIDS\#1")
            NodeData.FindNode("SOL34\Input\CIDS\#1").Value = FindSolventID(CboSol34.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol34.Text)
        Else
            CboSwitch34.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol35_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL35").Input.Elements("CIDS")
    
    If (CboSol35.Text = "" Or CboSol35.Text = " " Or CboSol35.Text = CboSol2_35.Text) Then
        CboSol35.Text = ""
    Else
        If FindSolventID(CboSol35.Text) <> "" Then
            If FindSolventID(CboSol2_35.Text) <> "" Then CboSwitch35.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL35\Input\CIDS\#1")
            NodeData.FindNode("SOL35\Input\CIDS\#1").Value = FindSolventID(CboSol35.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol35.Text)
        Else
            CboSwitch35.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol36_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL36").Input.Elements("CIDS")
    
    If (CboSol36.Text = "" Or CboSol36.Text = " " Or CboSol36.Text = CboSol2_36.Text) Then
        CboSol36.Text = ""
    Else
        If FindSolventID(CboSol36.Text) <> "" Then
            If FindSolventID(CboSol2_36.Text) <> "" Then CboSwitch36.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL36\Input\CIDS\#1")
            NodeData.FindNode("SOL36\Input\CIDS\#1").Value = FindSolventID(CboSol36.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol36.Text)
        Else
            CboSwitch36.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol37_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL37").Input.Elements("CIDS")
    
    If (CboSol37.Text = "" Or CboSol37.Text = " " Or CboSol37.Text = CboSol2_37.Text) Then
        CboSol37.Text = ""
    Else
        If FindSolventID(CboSol37.Text) <> "" Then
            If FindSolventID(CboSol2_37.Text) <> "" Then CboSwitch37.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL37\Input\CIDS\#1")
            NodeData.FindNode("SOL37\Input\CIDS\#1").Value = FindSolventID(CboSol37.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol37.Text)
        Else
            CboSwitch37.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol38_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL38").Input.Elements("CIDS")
    
    If (CboSol38.Text = "" Or CboSol38.Text = " " Or CboSol38.Text = CboSol2_38.Text) Then
        CboSol38.Text = ""
    Else
        If FindSolventID(CboSol38.Text) <> "" Then
            If FindSolventID(CboSol2_38.Text) <> "" Then CboSwitch38.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL38\Input\CIDS\#1")
            NodeData.FindNode("SOL38\Input\CIDS\#1").Value = FindSolventID(CboSol38.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol38.Text)
        Else
            CboSwitch38.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol39_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL39").Input.Elements("CIDS")
    
    If (CboSol39.Text = "" Or CboSol39.Text = " " Or CboSol39.Text = CboSol2_39.Text) Then
        CboSol39.Text = ""
    Else
        If FindSolventID(CboSol39.Text) <> "" Then
            If FindSolventID(CboSol2_39.Text) <> "" Then CboSwitch39.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL39\Input\CIDS\#1")
            NodeData.FindNode("SOL39\Input\CIDS\#1").Value = FindSolventID(CboSol39.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol39.Text)
        Else
            CboSwitch39.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol40_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL40").Input.Elements("CIDS")
    
    If (CboSol40.Text = "" Or CboSol40.Text = " " Or CboSol40.Text = CboSol2_40.Text) Then
        CboSol40.Text = ""
    Else
        If FindSolventID(CboSol40.Text) <> "" Then
            If FindSolventID(CboSol2_40.Text) <> "" Then CboSwitch40.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL40\Input\CIDS\#1")
            NodeData.FindNode("SOL40\Input\CIDS\#1").Value = FindSolventID(CboSol40.Text)
            'NodeData.Elements(1).Value = FindSolventID(CboSol40.Text)
        Else
            CboSwitch40.Value = "No"
        End If
    End If
End Sub

'           For the second solvent
'
'
Private Sub CboSol2_1_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL1").Input.Elements("CIDS")
    
    If (CboSol2_1.Text = "" Or CboSol2_1.Text = " " Or CboSol2_1.Text = CboSol1.Text) Then
        CboSol2_1.Text = ""
    Else
        If FindSolventID(CboSol2_1.Text) <> "" Then
                If FindSolventID(CboSol1.Text) <> "" Then CboSwitch1.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\CIDS\#2")
            NodeData.FindNode("SOL1\Input\CIDS\#2").Value = FindSolventID(CboSol2_1.Text)
            'NodeData.Elements(2).Value = FindSolventID(CboSol2_1.Text)
        Else
            CboSwitch1.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_2_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL2").Input.Elements("CIDS")
    
    If (CboSol2_2.Text = "" Or CboSol2_2.Text = " " Or CboSol2_2.Text = CboSol2.Text) Then
        CboSol2_2.Text = ""
    Else
        If FindSolventID(CboSol2_2.Text) <> "" Then
                If FindSolventID(CboSol2.Text) <> "" Then CboSwitch2.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL2\Input\CIDS\#2")
            NodeData.FindNode("SOL2\Input\CIDS\#2").Value = FindSolventID(CboSol2_2.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_2.Text)
        Else
            CboSwitch2.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_3_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL3").Input.Elements("CIDS")
    
    If (CboSol2_3.Text = "" Or CboSol2_3.Text = " " Or CboSol2_3.Text = CboSol3.Text) Then
        CboSol2_3.Text = ""
    Else
        If FindSolventID(CboSol2_3.Text) <> "" Then
                If FindSolventID(CboSol3.Text) <> "" Then CboSwitch3.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL3\Input\CIDS\#2")
            NodeData.FindNode("SOL3\Input\CIDS\#2").Value = FindSolventID(CboSol2_3.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_3.Text)
        Else
            CboSwitch3.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_4_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL4").Input.Elements("CIDS")
    
    If (CboSol2_4.Text = "" Or CboSol2_4.Text = " " Or CboSol2_4.Text = CboSol4.Text) Then
        CboSol2_4.Text = ""
    Else
        If FindSolventID(CboSol2_4.Text) <> "" Then
                If FindSolventID(CboSol4.Text) <> "" Then CboSwitch4.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL4\Input\CIDS\#2")
            NodeData.FindNode("SOL4\Input\CIDS\#2").Value = FindSolventID(CboSol2_4.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_4.Text)
        Else
            CboSwitch4.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_5_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL5").Input.Elements("CIDS")
    
    If (CboSol2_5.Text = "" Or CboSol2_5.Text = " " Or CboSol2_5.Text = CboSol5.Text) Then
        CboSol2_5.Text = ""
    Else
        If FindSolventID(CboSol2_5.Text) <> "" Then
                If FindSolventID(CboSol5.Text) <> "" Then CboSwitch5.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL5\Input\CIDS\#2")
            NodeData.FindNode("SOL5\Input\CIDS\#2").Value = FindSolventID(CboSol2_5.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_5.Text)
        Else
            CboSwitch5.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_6_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL6").Input.Elements("CIDS")
    
    If (CboSol2_6.Text = "" Or CboSol2_6.Text = " " Or CboSol2_6.Text = CboSol6.Text) Then
        CboSol2_6.Text = ""
    Else
        If FindSolventID(CboSol2_6.Text) <> "" Then
                If FindSolventID(CboSol6.Text) <> "" Then CboSwitch6.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL6\Input\CIDS\#2")
            NodeData.FindNode("SOL6\Input\CIDS\#2").Value = FindSolventID(CboSol2_6.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_6.Text)
        Else
            CboSwitch6.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_7_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL7").Input.Elements("CIDS")
    
    If (CboSol2_7.Text = "" Or CboSol2_7.Text = " " Or CboSol2_7.Text = CboSol7.Text) Then
        CboSol2_7.Text = ""
    Else
        If FindSolventID(CboSol2_7.Text) <> "" Then
                If FindSolventID(CboSol7.Text) <> "" Then CboSwitch7.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL7\Input\CIDS\#2")
            NodeData.FindNode("SOL7\Input\CIDS\#2").Value = FindSolventID(CboSol2_7.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_7.Text)
        Else
            CboSwitch7.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_8_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL8").Input.Elements("CIDS")
    
    If (CboSol2_8.Text = "" Or CboSol2_8.Text = " " Or CboSol2_8.Text = CboSol8.Text) Then
        CboSol2_8.Text = ""
    Else
        If FindSolventID(CboSol2_8.Text) <> "" Then
                If FindSolventID(CboSol8.Text) <> "" Then CboSwitch8.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL8\Input\CIDS\#2")
            NodeData.FindNode("SOL8\Input\CIDS\#2").Value = FindSolventID(CboSol2_8.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_8.Text)
        Else
            CboSwitch8.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_9_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL9").Input.Elements("CIDS")
    
    If (CboSol2_9.Text = "" Or CboSol2_9.Text = " " Or CboSol2_9.Text = CboSol9.Text) Then
        CboSol2_9.Text = ""
    Else
        If FindSolventID(CboSol2_9.Text) <> "" Then
                If FindSolventID(CboSol9.Text) <> "" Then CboSwitch9.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL9\Input\CIDS\#2")
            NodeData.FindNode("SOL9\Input\CIDS\#2").Value = FindSolventID(CboSol2_9.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_9.Text)
        Else
            CboSwitch9.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_10_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL10").Input.Elements("CIDS")
    
    If (CboSol2_10.Text = "" Or CboSol2_10.Text = " " Or CboSol2_10.Text = CboSol10.Text) Then
        CboSol2_10.Text = ""
    Else
        If FindSolventID(CboSol2_10.Text) <> "" Then
                If FindSolventID(CboSol10.Text) <> "" Then CboSwitch10.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL10\Input\CIDS\#2")
            NodeData.FindNode("SOL10\Input\CIDS\#2").Value = FindSolventID(CboSol2_10.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_10.Text)
        Else
            CboSwitch10.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_11_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL11").Input.Elements("CIDS")
    
    If (CboSol2_11.Text = "" Or CboSol2_11.Text = " " Or CboSol2_11.Text = CboSol11.Text) Then
        CboSol2_11.Text = ""
    Else
        If FindSolventID(CboSol2_11.Text) <> "" Then
                If FindSolventID(CboSol11.Text) <> "" Then CboSwitch11.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL11\Input\CIDS\#2")
            NodeData.FindNode("SOL11\Input\CIDS\#2").Value = FindSolventID(CboSol2_11.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_11.Text)
        Else
            CboSwitch11.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_12_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL12").Input.Elements("CIDS")
    
    If (CboSol2_12.Text = "" Or CboSol2_12.Text = " " Or CboSol2_12.Text = CboSol12.Text) Then
        CboSol2_12.Text = ""
    Else
        If FindSolventID(CboSol2_12.Text) <> "" Then
                If FindSolventID(CboSol12.Text) <> "" Then CboSwitch12.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL12\Input\CIDS\#2")
            NodeData.FindNode("SOL12\Input\CIDS\#2").Value = FindSolventID(CboSol2_12.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_12.Text)
        Else
            CboSwitch12.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_13_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL13").Input.Elements("CIDS")
    
    If (CboSol2_13.Text = "" Or CboSol2_13.Text = " " Or CboSol2_13.Text = CboSol13.Text) Then
        CboSol2_13.Text = ""
    Else
        If FindSolventID(CboSol2_13.Text) <> "" Then
                If FindSolventID(CboSol13.Text) <> "" Then CboSwitch13.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL13\Input\CIDS\#2")
            NodeData.FindNode("SOL13\Input\CIDS\#2").Value = FindSolventID(CboSol2_13.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_13.Text)
        Else
            CboSwitch13.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_14_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL14").Input.Elements("CIDS")
    
    If (CboSol2_14.Text = "" Or CboSol2_14.Text = " " Or CboSol2_14.Text = CboSol14.Text) Then
        CboSol2_14.Text = ""
    Else
        If FindSolventID(CboSol2_14.Text) <> "" Then
                If FindSolventID(CboSol14.Text) <> "" Then CboSwitch14.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL14\Input\CIDS\#2")
            NodeData.FindNode("SOL14\Input\CIDS\#2").Value = FindSolventID(CboSol2_14.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_14.Text)
        Else
            CboSwitch14.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_15_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL15").Input.Elements("CIDS")
    
    If (CboSol2_15.Text = "" Or CboSol2_15.Text = " " Or CboSol2_15.Text = CboSol15.Text) Then
        CboSol2_15.Text = ""
    Else
        If FindSolventID(CboSol2_15.Text) <> "" Then
                If FindSolventID(CboSol15.Text) <> "" Then CboSwitch15.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL15\Input\CIDS\#2")
            NodeData.FindNode("SOL15\Input\CIDS\#2").Value = FindSolventID(CboSol2_15.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_15.Text)
        Else
            CboSwitch15.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_16_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL16").Input.Elements("CIDS")
    
    If (CboSol2_16.Text = "" Or CboSol2_16.Text = " " Or CboSol2_16.Text = CboSol16.Text) Then
        CboSol2_16.Text = ""
    Else
        If FindSolventID(CboSol2_16.Text) <> "" Then
                If FindSolventID(CboSol16.Text) <> "" Then CboSwitch16.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL16\Input\CIDS\#2")
            NodeData.FindNode("SOL16\Input\CIDS\#2").Value = FindSolventID(CboSol2_16.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_16.Text)
        Else
            CboSwitch16.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_17_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL17").Input.Elements("CIDS")
    
    If (CboSol2_17.Text = "" Or CboSol2_17.Text = " " Or CboSol2_17.Text = CboSol17.Text) Then
        CboSol2_17.Text = ""
    Else
        If FindSolventID(CboSol2_17.Text) <> "" Then
                If FindSolventID(CboSol17.Text) <> "" Then CboSwitch17.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL17\Input\CIDS\#2")
            NodeData.FindNode("SOL17\Input\CIDS\#2").Value = FindSolventID(CboSol2_17.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_17.Text)
        Else
            CboSwitch17.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_18_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL18").Input.Elements("CIDS")
    
    If (CboSol2_18.Text = "" Or CboSol2_18.Text = " " Or CboSol2_18.Text = CboSol18.Text) Then
        CboSol2_18.Text = ""
    Else
        If FindSolventID(CboSol2_18.Text) <> "" Then
                If FindSolventID(CboSol18.Text) <> "" Then CboSwitch18.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL18\Input\CIDS\#2")
            NodeData.FindNode("SOL18\Input\CIDS\#2").Value = FindSolventID(CboSol2_18.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_18.Text)
        Else
            CboSwitch18.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_19_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL19").Input.Elements("CIDS")
    
    If (CboSol2_19.Text = "" Or CboSol2_19.Text = " " Or CboSol2_19.Text = CboSol19.Text) Then
        CboSol2_19.Text = ""
    Else
        If FindSolventID(CboSol2_19.Text) <> "" Then
                If FindSolventID(CboSol19.Text) <> "" Then CboSwitch19.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL19\Input\CIDS\#2")
            NodeData.FindNode("SOL19\Input\CIDS\#2").Value = FindSolventID(CboSol2_19.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_19.Text)
        Else
            CboSwitch19.Value = "No"
        End If
    End If
End Sub

Private Sub CboSol2_20_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL20").Input.Elements("CIDS")
    
    If (CboSol2_20.Text = "" Or CboSol2_20.Text = " " Or CboSol2_20.Text = CboSol20.Text) Then
        CboSol2_20.Text = ""
    Else
        If FindSolventID(CboSol2_20.Text) <> "" Then
                If FindSolventID(CboSol20.Text) <> "" Then CboSwitch20.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL20\Input\CIDS\#2")
            NodeData.FindNode("SOL20\Input\CIDS\#2").Value = FindSolventID(CboSol2_20.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_20.Text)
        Else
            CboSwitch20.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_21_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL21").Input.Elements("CIDS")
    
    If (CboSol2_21.Text = "" Or CboSol2_21.Text = " " Or CboSol2_21.Text = CboSol21.Text) Then
        CboSol2_21.Text = ""
    Else
        If FindSolventID(CboSol2_21.Text) <> "" Then
                If FindSolventID(CboSol21.Text) <> "" Then CboSwitch21.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL21\Input\CIDS\#2")
            NodeData.FindNode("SOL21\Input\CIDS\#2").Value = FindSolventID(CboSol2_21.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_21.Text)
        Else
            CboSwitch21.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_22_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL22").Input.Elements("CIDS")
    
    If (CboSol2_22.Text = "" Or CboSol2_22.Text = " " Or CboSol2_22.Text = CboSol22.Text) Then
        CboSol2_22.Text = ""
    Else
        If FindSolventID(CboSol2_22.Text) <> "" Then
                If FindSolventID(CboSol22.Text) <> "" Then CboSwitch22.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL22\Input\CIDS\#2")
            NodeData.FindNode("SOL22\Input\CIDS\#2").Value = FindSolventID(CboSol2_22.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_22.Text)
        Else
            CboSwitch22.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_23_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL23").Input.Elements("CIDS")
    
    If (CboSol2_23.Text = "" Or CboSol2_23.Text = " " Or CboSol2_23.Text = CboSol23.Text) Then
        CboSol2_23.Text = ""
    Else
        If FindSolventID(CboSol2_23.Text) <> "" Then
                If FindSolventID(CboSol23.Text) <> "" Then CboSwitch23.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL23\Input\CIDS\#2")
            NodeData.FindNode("SOL23\Input\CIDS\#2").Value = FindSolventID(CboSol2_23.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_23.Text)
        Else
            CboSwitch23.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_24_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL24").Input.Elements("CIDS")
    
    If (CboSol2_24.Text = "" Or CboSol2_24.Text = " " Or CboSol2_24.Text = CboSol24.Text) Then
        CboSol2_24.Text = ""
    Else
        If FindSolventID(CboSol2_24.Text) <> "" Then
                If FindSolventID(CboSol24.Text) <> "" Then CboSwitch24.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL24\Input\CIDS\#2")
            NodeData.FindNode("SOL24\Input\CIDS\#2").Value = FindSolventID(CboSol2_24.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_24.Text)
        Else
            CboSwitch24.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_25_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL25").Input.Elements("CIDS")
    
    If (CboSol2_25.Text = "" Or CboSol2_25.Text = " " Or CboSol2_25.Text = CboSol25.Text) Then
        CboSol2_25.Text = ""
    Else
        If FindSolventID(CboSol2_25.Text) <> "" Then
                If FindSolventID(CboSol25.Text) <> "" Then CboSwitch25.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL25\Input\CIDS\#2")
            NodeData.FindNode("SOL25\Input\CIDS\#2").Value = FindSolventID(CboSol2_25.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_25.Text)
        Else
            CboSwitch25.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_26_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL26").Input.Elements("CIDS")
    
    If (CboSol2_26.Text = "" Or CboSol2_26.Text = " " Or CboSol2_26.Text = CboSol26.Text) Then
        CboSol2_26.Text = ""
    Else
        If FindSolventID(CboSol2_26.Text) <> "" Then
                If FindSolventID(CboSol26.Text) <> "" Then CboSwitch26.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL26\Input\CIDS\#2")
            NodeData.FindNode("SOL26\Input\CIDS\#2").Value = FindSolventID(CboSol2_26.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_26.Text)
        Else
            CboSwitch26.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_27_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL27").Input.Elements("CIDS")
    
    If (CboSol2_27.Text = "" Or CboSol2_27.Text = " " Or CboSol2_27.Text = CboSol27.Text) Then
        CboSol2_27.Text = ""
    Else
        If FindSolventID(CboSol2_27.Text) <> "" Then
                If FindSolventID(CboSol27.Text) <> "" Then CboSwitch27.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL27\Input\CIDS\#2")
            NodeData.FindNode("SOL27\Input\CIDS\#2").Value = FindSolventID(CboSol2_27.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_27.Text)
        Else
            CboSwitch27.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_28_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL28").Input.Elements("CIDS")
    
    If (CboSol2_28.Text = "" Or CboSol2_28.Text = " " Or CboSol2_28.Text = CboSol28.Text) Then
        CboSol2_28.Text = ""
    Else
        If FindSolventID(CboSol2_28.Text) <> "" Then
                If FindSolventID(CboSol28.Text) <> "" Then CboSwitch28.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL28\Input\CIDS\#2")
            NodeData.FindNode("SOL28\Input\CIDS\#2").Value = FindSolventID(CboSol2_28.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_28.Text)
        Else
            CboSwitch28.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_29_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL29").Input.Elements("CIDS")
    
    If (CboSol2_29.Text = "" Or CboSol2_29.Text = " " Or CboSol2_29.Text = CboSol29.Text) Then
        CboSol2_29.Text = ""
    Else
        If FindSolventID(CboSol2_29.Text) <> "" Then
                If FindSolventID(CboSol29.Text) <> "" Then CboSwitch29.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL29\Input\CIDS\#2")
            NodeData.FindNode("SOL29\Input\CIDS\#2").Value = FindSolventID(CboSol2_29.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_29.Text)
        Else
            CboSwitch29.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_30_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL30").Input.Elements("CIDS")
    
    If (CboSol2_30.Text = "" Or CboSol2_30.Text = " " Or CboSol2_30.Text = CboSol30.Text) Then
        CboSol2_30.Text = ""
    Else
        If FindSolventID(CboSol2_30.Text) <> "" Then
                If FindSolventID(CboSol30.Text) <> "" Then CboSwitch30.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL30\Input\CIDS\#2")
            NodeData.FindNode("SOL30\Input\CIDS\#2").Value = FindSolventID(CboSol2_30.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_30.Text)
        Else
            CboSwitch30.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_31_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL31").Input.Elements("CIDS")
    
    If (CboSol2_31.Text = "" Or CboSol2_31.Text = " " Or CboSol2_31.Text = CboSol31.Text) Then
        CboSol2_31.Text = ""
    Else
        If FindSolventID(CboSol2_31.Text) <> "" Then
                If FindSolventID(CboSol31.Text) <> "" Then CboSwitch31.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL31\Input\CIDS\#2")
            NodeData.FindNode("SOL31\Input\CIDS\#2").Value = FindSolventID(CboSol2_31.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_31.Text)
        Else
            CboSwitch31.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_32_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL32").Input.Elements("CIDS")
    
    If (CboSol2_32.Text = "" Or CboSol2_32.Text = " " Or CboSol2_32.Text = CboSol32.Text) Then
        CboSol2_32.Text = ""
    Else
        If FindSolventID(CboSol2_32.Text) <> "" Then
                If FindSolventID(CboSol32.Text) <> "" Then CboSwitch32.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL32\Input\CIDS\#2")
            NodeData.FindNode("SOL32\Input\CIDS\#2").Value = FindSolventID(CboSol2_32.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_32.Text)
        Else
            CboSwitch32.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_33_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL33").Input.Elements("CIDS")
    
    If (CboSol2_33.Text = "" Or CboSol2_33.Text = " " Or CboSol2_33.Text = CboSol33.Text) Then
        CboSol2_33.Text = ""
    Else
        If FindSolventID(CboSol2_33.Text) <> "" Then
                If FindSolventID(CboSol33.Text) <> "" Then CboSwitch33.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL33\Input\CIDS\#2")
            NodeData.FindNode("SOL33\Input\CIDS\#2").Value = FindSolventID(CboSol2_33.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_33.Text)
        Else
            CboSwitch33.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_34_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL34").Input.Elements("CIDS")
    
    If (CboSol2_34.Text = "" Or CboSol2_34.Text = " " Or CboSol2_34.Text = CboSol34.Text) Then
        CboSol2_34.Text = ""
    Else
        If FindSolventID(CboSol2_34.Text) <> "" Then
                If FindSolventID(CboSol34.Text) <> "" Then CboSwitch34.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL34\Input\CIDS\#2")
            NodeData.FindNode("SOL34\Input\CIDS\#2").Value = FindSolventID(CboSol2_34.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_34.Text)
        Else
            CboSwitch34.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_35_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL35").Input.Elements("CIDS")
    
    If (CboSol2_35.Text = "" Or CboSol2_35.Text = " " Or CboSol2_35.Text = CboSol35.Text) Then
        CboSol2_35.Text = ""
    Else
        If FindSolventID(CboSol2_35.Text) <> "" Then
                If FindSolventID(CboSol35.Text) <> "" Then CboSwitch35.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL35\Input\CIDS\#2")
            NodeData.FindNode("SOL35\Input\CIDS\#2").Value = FindSolventID(CboSol2_35.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_35.Text)
        Else
            CboSwitch35.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_36_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL36").Input.Elements("CIDS")
    
    If (CboSol2_36.Text = "" Or CboSol2_36.Text = " " Or CboSol2_36.Text = CboSol36.Text) Then
        CboSol2_36.Text = ""
    Else
        If FindSolventID(CboSol2_36.Text) <> "" Then
                If FindSolventID(CboSol36.Text) <> "" Then CboSwitch36.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL36\Input\CIDS\#2")
            NodeData.FindNode("SOL36\Input\CIDS\#2").Value = FindSolventID(CboSol2_36.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_36.Text)
        Else
            CboSwitch36.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_37_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL37").Input.Elements("CIDS")
    
    If (CboSol2_37.Text = "" Or CboSol2_37.Text = " " Or CboSol2_37.Text = CboSol37.Text) Then
        CboSol2_37.Text = ""
    Else
        If FindSolventID(CboSol2_37.Text) <> "" Then
                If FindSolventID(CboSol37.Text) <> "" Then CboSwitch37.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL37\Input\CIDS\#2")
            NodeData.FindNode("SOL37\Input\CIDS\#2").Value = FindSolventID(CboSol2_37.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_37.Text)
        Else
            CboSwitch37.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_38_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL38").Input.Elements("CIDS")
    
    If (CboSol2_38.Text = "" Or CboSol2_38.Text = " " Or CboSol2_38.Text = CboSol38.Text) Then
        CboSol2_38.Text = ""
    Else
        If FindSolventID(CboSol2_38.Text) <> "" Then
                If FindSolventID(CboSol38.Text) <> "" Then CboSwitch38.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL38\Input\CIDS\#2")
            NodeData.FindNode("SOL38\Input\CIDS\#2").Value = FindSolventID(CboSol2_38.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_38.Text)
        Else
            CboSwitch38.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_39_Change()
     
    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL39").Input.Elements("CIDS")
    
    If (CboSol2_39.Text = "" Or CboSol2_39.Text = " " Or CboSol2_39.Text = CboSol39.Text) Then
        CboSol2_39.Text = ""
    Else
        If FindSolventID(CboSol2_39.Text) <> "" Then
                If FindSolventID(CboSol39.Text) <> "" Then CboSwitch39.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL39\Input\CIDS\#2")
            NodeData.FindNode("SOL39\Input\CIDS\#2").Value = FindSolventID(CboSol2_39.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_39.Text)
        Else
            CboSwitch39.Value = "No"
        End If
    End If
End Sub
Private Sub CboSol2_40_Change()

    On Error Resume Next
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    'Set NodeData = go_Simulation.Tree.Data.Properties.Data.Elements("SOL40").Input.Elements("CIDS")
    
    If (CboSol2_40.Text = "" Or CboSol2_40.Text = " " Or CboSol2_40.Text = CboSol40.Text) Then
        CboSol2_40.Text = ""
    Else
        If FindSolventID(CboSol2_40.Text) <> "" Then
                If FindSolventID(CboSol40.Text) <> "" Then CboSwitch40.Value = "Yes"
            'Application.Tree.FindNode("\Data\Properties\Data\SOL40\Input\CIDS\#2")
            NodeData.FindNode("SOL40\Input\CIDS\#2").Value = FindSolventID(CboSol2_40.Text)
                'NodeData.Elements(2).Value = FindSolventID(CboSol2_40.Text)
        Else
            CboSwitch40.Value = "No"
        End If
    End If
End Sub


Private Sub CboParamX_Change()
     
    On Error Resume Next
    Set NodeProp = go_Simulation.Tree.Data.Properties
    
    'Application.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\USAGE\#0")
    Set node = NodeProp.FindNode("Regression\BINARY\Input\USAGE\#0")
    node.Value = CboParamx.Text

    'NodeProp.Regression.Elements("BINARY").Input.Elements("USAGE").Elements(0).Value = CboParamx.Text
    
End Sub
Private Sub CboParamY1_Change()

    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#1").Value = CboParamY1.Text
    
End Sub
Private Sub CboParamY2_Change()

    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#2").Value = CboParamY2.Text
    
End Sub
Private Sub CboParamZ_Change()

    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#3").Value = CboParamZ.Text
    
End Sub
Private Sub CboKspA_Change()

    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#4").Value = CboKspA.Text
End Sub

Private Sub CboKspB_Change()

    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#5").Value = CboKspB.Text
End Sub

Private Sub CboKspC_Change()

    Set NodeProp = go_Simulation.Tree.Data.Properties
    NodeProp.FindNode("Regression\BINARY\Input\USAGE\#6").Value = CboKspC.Text
End Sub

Public Sub GetOutputValues()

    Dim i As Integer
    Dim Rstatus As String
    Dim SolResult(NumberofDataPoint) As Double

    Set NodeReg = go_Simulation.Tree.Data.Properties.Regression
    Set NodeProp = go_Simulation.Tree.Data.Properties
    Set Nodechem = go_Simulation.Tree.Data.Chemistry
    ' -- Get x, y-, y+, z parameters for "BINARY" --
    Rstatus = status(NodeReg.AttributeValue(HAP_COMPSTATUS))
    If (Rstatus = "DRS Success" Or Rstatus = "DRS Warning") Then
    
        For i = 1 To 4
            Param(i) = NodeProp.FindNode("Parameters\Pure Components\XYZE-1\Input\VAL" & i & "\XYZE\DRUG").Value
        Next i
    
        'Application.Tree.FindNode("\Data\Properties\Regression\BINARY\Output\ESTVALUE2\1")
        'Application.Tree.FindNode("\Data\Properties\Regression\BINARY\Output\STAND_DEV2\1")
        For i = 0 To RegCount - 1
            'Set node = NodeReg.FindNode("BINARY\Output\ESTVALUE2\" & i + 1)
            Param(RegIndex(i + 1)) = NodeReg.FindNode("BINARY\Output\ESTVALUE2\" & i + 1).Value
            'Param(RegIndex(i + 1)) = NodeReg.Elements("BINARY").Output.Elements("ESTVALUE2").Elements(i).Value
            
            'Set node = NodeReg.FindNode("BINARY\Output\STAND_DEV2\" & i + 1)
            StdDev(RegIndex(i + 1)) = NodeReg.FindNode("BINARY\Output\STAND_DEV2\" & i + 1).Value
            'StdDev(RegIndex(i + 1)) = NodeReg.Elements("BINARY").Output.Elements("STAND_DEV2").Elements(i).Value
        Next i
    
        Range("paramxEst").Value = Param(1)
        Range("paramy1Est").Value = Param(2)
        Range("paramy2Est").Value = Param(3)
        Range("paramzEst").Value = Param(4)
    
        Range("StdDevX").Value = StdDev(1)
        Range("StdDevY1").Value = StdDev(2)
        Range("StdDevY2").Value = StdDev(3)
        Range("StdDevZ").Value = StdDev(4)
    
        'Don't override the initial guess
        'Range("paramx").Value = Param(1)
        'Range("paramy1").Value = Param(2)
        'Range("paramy2").Value = Param(3)
        'Range("paramz").Value = Param(4)
 
    
        If (RegFlag(5) = 1) Then
            Range("KspAEst").Value = Param(5)
            Range("StdDevKspA").Value = StdDev(5)
            Nodechem.FindNode("SOLID\Input\K_A\SOLID").Value = Param(5)
            'Range("KspA").Value = Param(5)
        Else
            Range("KspAEst").Value = Nodechem.FindNode("SOLID\Input\K_A\SOLID").Value
            Range("StdDevKspA").Value = 0
            'Range("KspA").Value = ""
        End If
        
        If (RegFlag(6) = 1) Then
            Range("KspBEst").Value = Param(6)
            Range("StdDevKspB").Value = StdDev(6)
            Nodechem.FindNode("SOLID\Input\K_B\SOLID").Value = Param(6)
            'Range("KspA").Value = Param(6)
        Else
            Range("KspBEst").Value = Nodechem.FindNode("SOLID\Input\K_B\SOLID").Value
            Range("StdDevKspB").Value = 0
            'Range("KspA").Value = ""
        End If
        
        If (RegFlag(7) = 1) Then
            Range("KspCEst").Value = Param(7)
            Range("StdDevKspC").Value = StdDev(7)
            Nodechem.FindNode("SOLID\Input\K_C\SOLID").Value = Param(7)
            'Range("KspA").Value = Param(6)
        Else
            Range("KspCEst").Value = Nodechem.FindNode("SOLID\Input\K_C\SOLID").Value
            Range("StdDevKspC").Value = 0
            'Range("KspA").Value = ""
        End If
    
        ' -- Get Solubility (Est) and Temperature (Est) for solvents
        
        For i = 1 To NumberofDataPoint
            If (Range("Solubility" & i).Value = "" Or Range("Solubility" & i).Value = " ") Then
            Else
                SolResult(i) = NodeReg.FindNode("BINARY\Output\Prop Data\PROFILE\SOL" & i & "\(Est Val MASSFRAC X DRUG,1)").Value
                Range("SoluEst" & i).Value = SolResult(i) / (1 - SolResult(i))
                Range("TempEst" & i).Value = _
                NodeReg.FindNode("BINARY\Output\Prop Data\PROFILE\SOL" & i & "\(Est Val TEMP,1)").Value
            End If
        Next i
        
        'Sum of square
        'Application.Tree.FindNode("\Data\Properties\Regression\PURE\Output\SIGMAMX")
        Set node = NodeReg.FindNode("BINARY\Output\SIGMAMX")
        Range("SumWeight").Value = node.Value
        'Range("SumWeight").Value = NodeReg.Elements("BINARY").Output.Elements("SIGMAMX").Value
    
        '======================================================================================================================

        Dim sse_Log, sst_Log, R_Squared_Log As Double
        Dim TotalExperimental_Log, AverageExperimental_Log As Double
        Dim sse, sst, R_Squared As Double
        Dim TotalExperimental, AverageExperimental As Double
        Dim NofData As Integer
        
        NofData = 0
        sse_Log = 0
        sst_Log = 0
        R_Squared_Log = 0
        TotalExperimental_Log = 0
        sse = 0
        sst = 0
        R_Squared = 0
        TotalExperimental = 0
        
        For i = 1 To NumberofDataPoint
        
            If (Range("f24:f63").Item(i) <> 0 And Range("k24:k63").Item(i) <> "") Then
                Range("l24:l63").Item(i) = Range("k24:k63").Item(i) / Range("f24:f63").Item(i)
            Else
                Range("l24:l63").Item(i) = ""
            End If
            
            If (go_Simulation.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\WEIGHT\SOL" & i).Value = 1) Then
                
                If (Range("f24:f63").Item(i).Value <> "") Then
                    TotalExperimental_Log = TotalExperimental_Log + Log(Range("f24:f63").Item(i).Value) / Log(10)
                    NofData = NofData + 1
                End If
             
                TotalExperimental = TotalExperimental + Range("f24:f63").Item(i).Value
            End If
        Next
        
        If (NofData <> 0) Then
            AverageExperimental_Log = TotalExperimental_Log / NofData
            AverageExperimental = TotalExperimental / NofData
        End If
        
        For i = 1 To NumberofDataPoint
        
            If (Range("f24:f63").Item(i).Value <> "" And Range("k24:k63").Item(i).Value <> "" And go_Simulation.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\WEIGHT\SOL" & i).Value = 1) Then
            
                 sse_Log = sse_Log + (Log(Range("k24:k63").Item(i).Value) / Log(10) - Log(Range("f24:f63").Item(i).Value) / Log(10)) ^ 2
                 sst_Log = sst_Log + (Log(Range("f24:f63").Item(i).Value) / Log(10) - AverageExperimental_Log) ^ 2
                 
                 sse = sse + (Range("k24:k63").Item(i).Value - Range("f24:f63").Item(i).Value) ^ 2
                 sst = sst + (Range("f24:f63").Item(i).Value - AverageExperimental) ^ 2
                 
            End If
                     
        Next i
        
        If (sst_Log <> 0) Then
            R_Squared_Log = 1 - sse_Log / sst_Log
            Range("n33").Value = R_Squared_Log
        End If
        
        If (sst <> 0) Then
            R_Squared = 1 - sse / sst
            Range("n32").Value = R_Squared
        End If
            
    '        Range("M34").Value = go_Simulation.Tree.FindNode("\Data\Properties\Regression\PURE\Output\SIGMA").Value
    '
    ''=====================RMSE(LOG) calculation====================================================
        Dim RMSE, RMSE_Log As Double

        RMSE = 0
        RMSE_Log = 0
        
        For i = 1 To NumberofDataPoint
            If (Range("f24:f63").Item(i).Value <> "" And Range("k24:k63").Item(i).Value <> "" And go_Simulation.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\WEIGHT\SOL" & i).Value = 1) Then
              RMSE = RMSE + (Range("k24:k63").Item(i).Value - Range("f24:f63").Item(i).Value) ^ 2
              RMSE_Log = RMSE_Log + (Log(Range("k24:k63").Item(i).Value) / Log(10) - Log(Range("f24:f63").Item(i).Value) / Log(10)) ^ 2
            End If
        Next i
             
        RMSE = Sqr(RMSE / NofData)
        RMSE_Log = Sqr(RMSE_Log / NofData)
        
        Range("n34").Value = RMSE
        Range("n35").Value = RMSE_Log

''=======================================================================================================================
         
        'If (Rstatus = "DRS Warning") Then MsgBox ("Calculated with warning. Please check the .aprbkp file.")
        
          '--Update the plot
        Call DrawSquarePlot
    Else
        MsgBox Rstatus & "! Please check data or use differnt parameters"
    End If
   End Sub
   
   Function status(CompStat As Long) As String

    If ((CompStat And HAP_RESULTS_SUCCESS) = HAP_RESULTS_SUCCESS) Then
      status = "DRS Success"
    ElseIf ((CompStat And HAP_RESULTS_ERRORS) = HAP_RESULTS_ERRORS) Then
      status = "DRS Error"
    ElseIf ((CompStat And HAP_NORESULTS) = HAP_NORESULTS) Then
      status = "DRS No Results"
    ElseIf ((CompStat And HAP_RESULTS_WARNINGS) = HAP_RESULTS_WARNINGS) Then
      status = "DRS Warning"
    End If
   
   End Function

Private Sub CommandButton1_Click()
    ActiveSheet.Visible = xlSheetVeryHidden
    Sheet1.Visible = xlSheetVisible
    Sheet12.Visible = xlSheetVeryHidden
End Sub

 Private Sub Worksheet_Change(ByVal Target As Range)
 Dim i, j As Integer
If Target.Column >= 4 And Target.Column <= 7 And Target.Row >= 24 And Target.Row <= 63 Then
    Target.Font.Color = vbBlue
    Target.HorizontalAlignment = xlRight
    If Target.Column = 4 Then
        For j = 1 To Target.count Step 1
          If Range("d" & Target.Row + j - 1) <> "" Then
            If (Range("b" & Target.Row + j - 1).Value <> 1 - Range("d" & Target.Row + j - 1).Value Or Range("b" & Target.Row + j - 1) = "") Then
                Range("b" & Target.Row + j - 1).Value = 1 - Range("d" & Target.Row + j - 1).Value
            End If
          Else
            If Not Range("b" & Target.Row + j - 1) = "" Then Range("b" & Target.Row + j - 1) = ""
          End If
        Next j
    End If
End If
If Target.Column = 2 And Target.Row >= 24 And Target.Row <= 63 Then
    Target.Font.Color = vbBlue
    Target.HorizontalAlignment = xlRight
    For i = 1 To Target.count Step 1
      If Range("b" & Target.Row + i - 1) <> "" Then
        If (Range("D" & Target.Row + i - 1).Value <> 1 - Range("b" & Target.Row + i - 1).Value Or Range("D" & Target.Row + i - 1) = "") Then
            Range("D" & Target.Row + i - 1).Value = 1 - Range("b" & Target.Row + i - 1).Value
        End If
      Else
        If Range("d" & Target.Row + i - 1) <> "" Then Range("d" & Target.Row + i - 1) = ""
      End If
    Next i
End If
If Target.Column >= 1 And Target.Column <= 5 And Target.Row = 8 Then
    Target.Font.Color = vbBlue
    Target.HorizontalAlignment = xlCenter
End If
If Target.Column >= 1 And Target.Column <= 7 And Target.Row = 13 Then
    Target.Font.Color = vbBlue
    Target.HorizontalAlignment = xlCenter
End If

End Sub
Private Sub Worksheet_Activate()
  
    Dim Nm As Name

    For Each Nm In ActiveSheet.Names
    Nm.Visible = False
    Next

End Sub


Private Sub SetSinglePoint(pos As Integer, val As Double, count As Integer)
  
    On Error GoTo ErrorHandler
  
    NodeProp.FindNode("Data\SOL" & pos & "\Input\VALUE\(#1,X,DRUG)").Value = val
  
    Exit Sub

ErrorHandler:

    count = count + 1
    If (count < 10) Then
      val = val / 10
      Call SetSinglePoint(pos, val, count)
    End If

    'NodeProp.FindNode("Data\SOL" & pos & "\Input\VALUE\(#1,X,DRUG)").Value = val / 10

End Sub


Private Sub SetDrugSolubility()
 
    Dim X As Double
    Dim i As Integer
    Dim Solu(NumberofDataPoint) As Double
    Dim Solv As String
    Dim count As Integer
 
    Set NodeProp = go_Simulation.Tree.Data.Properties
    Set NodeReg = go_Simulation.Tree.Data.Properties.Regression
    Set NodeData = go_Simulation.Tree.Data.Properties.Data
    
    For i = 1 To NumberofDataPoint
        Solu(i) = Range("Solubility" & i).Value / (1 + Range("Solubility" & i).Value)
        If (Range("Solubility" & i).Value = "" Or Range("Solubility" & i).Value = " ") Then
        Else
          ' Old code
          'NodeProp.Data.Elements("SOL" & i).Input.Elements("VALUE").Elements(1, X, NodeData.Elements("SOL" & i).Input.Elements("CIDS").Elements(1).Value).Value = 0 '''''''''' Lines added.
          'It is equivalent to
          '
          'Solv = NodeData.Elements("SOL" & i).Input.Elements("CIDS").Elements(1).Value ' = 12-NH2C2
          'NodeProp.Data.Elements("SOL" & i).Input.Elements("VALUE").Elements(1, X, Solv).Value = 1
          '
          'New code
          'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\CIDS\#1")
          Set node = NodeData.FindNode("SOL" & i & "\Input\CIDS\#1")
          Solv = node.Value '12-NH2C2
          
          'Application.Tree.FindNode("\Data\Properties\Data\SOL1\Input\VALUE\#1 X DRUG")
          Set node = NodeProp.FindNode("Data\SOL" & i & "\Input\VALUE\(#1,X,Solv)")
          If node Is Nothing Then
          Else
            node.Value = 0
          End If
          
         'Clear solvent1 fraction.
         'Old code
         'NodeProp.Data.Elements("SOL" & i).Input.Elements("VALUE").Elements(1, X, "DRUG").Value = Solu(i)
         'NodeProp.Data.Elements("SOL" & i).Input.Elements("VALUE").Elements(0, X, "DRUG").Value = Range("Std_Dev" & i) & "%"
         '
         'New code
         ' Set a single value
          count = 0
          Call SetSinglePoint(i, Solu(i), count)
          'NodeProp.FindNode("Data\SOL" & i & "\Input\VALUE\(#1,X,DRUG)").Value = Solu(i)
          NodeProp.FindNode("Data\SOL" & i & "\Input\VALUE\(#0,X,DRUG)").Value = Range("Std_Dev" & i) & "%"
          
          'Old code
          'If (ComboSwitch(i).Text <> "No") Then NodeReg.Elements("BINARY").Input.Elements("WEIGHT").Elements("SOL" & i).Value = 1
          '
          'New code
          If (ComboSwitch(i).Text <> "No") Then
            'Application.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\WEIGHT\SOL1")
            NodeReg.FindNode("BINARY\Input\WEIGHT\SOL" & i).Value = 1
          End If
        End If
    Next i
      
End Sub


Private Sub DrawSquarePlot()

Dim MaximumScale, MinimumScale As Double
Dim MyChart As Chart
Dim i, NofPositivePoint As Integer
Dim XValue(NumberofDataPoint), YValue(NumberofDataPoint) As Double
Dim sXString, sYString As String

On Error GoTo ErrorHandler

Set MyChart = ActiveSheet.ChartObjects("Chart 143").Chart

    MaximumScale = 10 ^ (TrimtoTens(Application.WorksheetFunction.Max(Range("$f$24:$f$63, $k$24:$k$63"))) + 1)
    MinimumScale = 10 ^ TrimtoTens(Application.WorksheetFunction.Min(Range("$f$24:$f$63, $k$24:$k$63")))
        
    'Get all the non zero solubilities
    
    NofPositivePoint = 0

    For i = 1 To NumberofDataPoint
        If Range("Solubility" & i).Value > 0 And Range("SoluEst" & i).Value > 0 Then
            NofPositivePoint = NofPositivePoint + 1
            If TrimtoTens(Range("Solubility" & i).Value) <= 0 Then
                XValue(NofPositivePoint) = FormatNumber(Range("Solubility" & i).Value, Abs(TrimtoTens(Range("Solubility" & i).Value)) + 1)
                YValue(NofPositivePoint) = FormatNumber(Range("SoluEst" & i).Value, Abs(TrimtoTens(Range("SoluEst" & i).Value)) + 1)
            Else
                XValue(NofPositivePoint) = FormatNumber(Range("Solubility" & i).Value, 1)
                YValue(NofPositivePoint) = FormatNumber(Range("SoluEst" & i).Value, 1)
            End If
        End If
    Next i
    
    For i = 1 To NofPositivePoint - 1
        sXString = sXString & Replace(XValue(i), ",", ".") & ","
        sYString = sYString & Replace(YValue(i), ",", ".") & ","
    Next i

    sXString = sXString & Replace(XValue(NofPositivePoint), ",", ".")
    sYString = sYString & Replace(YValue(NofPositivePoint), ",", ".")
    
    Sheet11.Unprotect "aspen123"
    
    If MyChart.SeriesCollection.count = 1 Then
        MyChart.SeriesCollection.NewSeries
    ElseIf MyChart.SeriesCollection.count = 2 Then
        MyChart.SeriesCollection(2).Delete
        MyChart.SeriesCollection.NewSeries
    ElseIf MyChart.SeriesCollection.count > 2 Then
        For i = 3 To MyChart.SeriesCollection.count
            MyChart.SeriesCollection(i).Delete
        Next i
    End If
    
    With MyChart.SeriesCollection(1)
        .XValues = "={" & Replace(MinimumScale, ",", ".") & "," & Replace(MaximumScale, ",", ".") & "}"
        .Values = "={" & Replace(MinimumScale, ",", ".") & "," & Replace(MaximumScale, ",", ".") & "}"
        .Border.ColorIndex = 7
        .MarkerStyle = xlNone
    End With
    
    With MyChart.SeriesCollection(2)
        .XValues = "={" & sXString & "}"
        .Values = "={" & sYString & "}"
        .Border.LineStyle = xlNone
        .MarkerBackgroundColorIndex = 11
        .MarkerForegroundColorIndex = 11
    End With
    
'    Debug.Print "{" & sXString & "}"
'    Debug.Print "{" & sYString & "}"
       
    With MyChart.Axes(xlCategory)
        .ScaleType = xlLogarithmic
        .MinimumScaleIsAuto = False
        .MaximumScaleIsAuto = False
        .MinimumScale = MinimumScale
        .MaximumScale = MaximumScale
        .MinorUnitIsAuto = True
        .MajorUnitIsAuto = True
        .Crosses = xlAutomatic
        .ReversePlotOrder = False
        .DisplayUnit = xlNone
        .CrossesAt = MinimumScale
    End With
        'Application.Run "getUnits"
        
    
    With MyChart.Axes(xlValue)
        
        .ScaleType = xlLogarithmic
        .MinimumScaleIsAuto = False
        .MaximumScaleIsAuto = False
        .MinimumScaleIsAuto = False
        .MinimumScale = MinimumScale
        .MaximumScale = MaximumScale
        .MinorUnitIsAuto = True
        .MajorUnitIsAuto = True
        .Crosses = xlAutomatic
        .ReversePlotOrder = False
        .DisplayUnit = xlNone
        .CrossesAt = MinimumScale
    End With
       
    Sheet11.Protect "aspen123", DrawingObjects:=False, Contents:=True, Scenarios:= _
        True, AllowFormattingCells:=True
      
Exit Sub

ErrorHandler: MsgBox "Error in drawing the plot! The Series2 input string may be too large."
Application.Cursor = xlDefault

End Sub

Public Function TrimtoTens(X As Double)
Dim i As Integer
For i = -7 To 5
    If X / 10 ^ i > 0 And X / 10 ^ i < 1 Then
        TrimtoTens = i - 1
        Exit For
    End If
Next

End Function

Private Sub CleanResults()
Dim i As Integer
Dim MyChart As Chart
    Range("paramxEst").Value = ""
    Range("paramy1Est").Value = ""
    Range("paramy2Est").Value = ""
    Range("paramzEst").Value = ""
    Range("KspAEst").Value = ""
    Range("KspBEst").Value = ""
    Range("KspCEst").Value = ""
    
    Range("StdDevX").Value = ""
    Range("StdDevY1").Value = ""
    Range("StdDevY2").Value = ""
    Range("StdDevZ").Value = ""
    Range("StdDevKspA").Value = ""
    Range("StdDevKspB").Value = ""
    Range("StdDevKspC").Value = ""
    
    Range("SumWeight").Value = ""
    Range("N32:N35").Value = ""
    
    For i = 1 To NumberofDataPoint
        Range("SoluEst" & i).Value = ""
        Range("TempEst" & i).Value = ""
    Next i
    
    Range("L24:L63").Value = ""
    
    Set MyChart = ActiveSheet.ChartObjects("Chart 143").Chart
    
    Sheet11.Unprotect "aspen123"
        
    If MyChart.SeriesCollection.count >= 2 Then
        For i = 2 To MyChart.SeriesCollection.count
            MyChart.SeriesCollection(i).Delete
        Next i
    End If
    
    Sheet11.Protect "aspen123", DrawingObjects:=False, Contents:=True, Scenarios:= _
        True, AllowFormattingCells:=True
    
End Sub

Public Function FindSolventID1(node As IHNode)
  FindSolventID1 = node.Value
End Function

Public Function FindSolventID(SolvName As String)
Dim i As Integer
Dim fFound As Boolean

If SolvName = "" Then
  Exit Function
End If

'If SolventName(1) = "" Then
'   For i = 0 To SolventKind - 1
'      SolventName(i) = Sheets("Solvent List").Range("SolventName").Item(i + 1).Value
'      SolventID(i) = Sheets("Solvent List").Range("SolventID").Item(i + 1).Value
'   Next i
'End If

fFound = False

For i = 0 To SolventKind - 1
    If SolventName(i) = SolvName Then
        FindSolventID = SolventID(i)
        fFound = True
        Exit For
    End If
Next

If fFound = False Then
    MsgBox "The solvent name" & " """ & SolvName & """ is not in the databank." & _
    Chr(10) & Chr(10) & "The corresponding data point will be EXCLUDED in the regression." & _
    Chr(10) & Chr(10) & "Please always select a solvent from the dropdown list.", vbOKOnly, "Solvent not found"
End If

End Function


Public Sub SetRegressionWeight()
Dim i As Integer
    Set NodeReg = go_Simulation.Tree.Data.Properties.Regression
    For i = 1 To NumberofDataPoint
        If (ComboSwitch(i).Text = "No") Then
          'Application.Tree.FindNode("\Data\Properties\Regression\BINARY\Input\WEIGHT\SOL41")
          Set node = NodeReg.FindNode("BINARY\Input\WEIGHT\SOL" & i)
          node.Value = 0.0000000001
          'NodeReg.Elements("BINARY").Input.Elements("WEIGHT").Elements("SOL" & i).Value = 0.0000000001
        End If
    Next i
End Sub
