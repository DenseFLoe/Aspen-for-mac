import contextlib
import io
import json
import re
from pathlib import Path
from types import SimpleNamespace
from collections import Counter

import pcodedmp.pcodedmp as pc
work=Path(__file__).resolve().parent
spec=json.loads((work/"structure.json").read_text(encoding="utf-8"))
assert spec["vba_cache_version"]=="0xb5" and spec["syskind"]==3
base_id,base_func=pc.getID,pc.disasmFunc
record_list=[]
def get_id(word,ids,v,is64):
    idx=(word>>1)-0x107
    return ids[idx] if v==7 and is64 and 0xBE<idx<len(ids) else base_id(word,ids,v,is64)
def function(indirect,declarations,ids,offset,op_type,endian,v,is64):
    assert is64 and v==7
    args=[]
    cursor=pc.getDWord(indirect,offset+56,endian)
    seen=set()
    return_slot=None
    while cursor not in (0,0xFFFFFFFF):
        assert 0<cursor<=len(indirect)-32 and cursor not in seen
        seen.add(cursor)
        ident=pc.getWord(indirect,cursor+2,endian)
        desc=pc.getDWord(indirect,cursor+16,endian)
        bits=pc.getWord(indirect,cursor+28,endian)
        previous,cursor=cursor,pc.getDWord(indirect,cursor+24,endian)
        builtin=pc.getTypeName(desc&0xFF) if desc>>16==0xFFFF else None
        if ident==0xFFFE:
            assert cursor==0xFFFFFFFF
            return_slot=builtin
        else:
            custom=indirect[desc:desc+8].hex() if builtin is None else None
            args.append(dict(name=get_id(ident,ids,v,is64),by_value=bool(bits&4),optional=bool(bits&0x200),builtin=builtin,
                             custom_type_descriptor=custom,offset=hex(previous)))
    name=pc.getName(indirect,ids,offset+2,endian,v,is64)
    rendered=base_func(indirect,declarations,ids,offset,op_type,endian,v,is64)
    record_list.append(dict(name=name, visibility="Public" if op_type&4 else "Private", args=args,offset=hex(offset),
                            return_slot=return_slot, rendered=rendered))
    return rendered
pc.getID,pc.disasmFunc=get_id,function
errors=io.StringIO()
with contextlib.redirect_stderr(errors):
    pc.processFile(str(work.parent/"input/Regression.xlsm"),SimpleNamespace(disasmOnly=True,verbose=False),output_file=io.StringIO())
assert not errors.getvalue()
assert len(record_list)==181
procedures=iter(record_list)
signature=re.compile(r"(?i)^\s*(?:(Public|Private)\s+)?(Sub|Function)\s+(\w+)\s*\(([^)]*)\)\s*(?:As\s+(\w+))?")
param=re.compile(r"(?i)^\s*(Optional\s+)?(?:(ByVal|ByRef)\s+)?(\w+)\s+As\s+([\w.]+)(?:\s*=\s*.+)?$")
rows=[]
counts=Counter()
for module in spec["modules"]:
    code=(work/"stage/vba"/module["filename"]).read_bytes().decode(spec["codec"])
    for n, line in enumerate(code.splitlines(),1):
        m=signature.match(line)
        if not m:
            continue
        scope,kind,name,arguments,returns=m.groups()
        r=next(procedures)
        label=(module["name"],n,name)
        assert name.casefold()==r["name"].casefold(),label
        assert not scope or scope==r["visibility"],label
        assert re.search(rf"(?i)\b{kind}\s+{re.escape(name)}\(",r["rendered"]),label
        if returns:
            assert r["rendered"].endswith(f" As {returns})") and r["return_slot"] in (None,returns),label
        a_source=arguments.split(",") if arguments else []
        assert len(a_source)==len(r["args"]),label
        for a, a_cache in zip(a_source,r["args"],strict=True):
            opt,mode,a_name,a_type=param.fullmatch(a).groups()
            assert a_name.casefold()==a_cache["name"].casefold(),label
            assert bool(opt)==a_cache["optional"] and (mode=="ByVal")==a_cache["by_value"],label
            if a_cache["builtin"] is not None:
                assert a_type.casefold()==a_cache["builtin"].casefold(),label
                counts["builtin_types"]+=1
            else:
                assert a_cache["custom_type_descriptor"],label
                counts["custom_type_descriptors"]+=1
            a_cache["source_type"]=a_type
        counts["procedures"]+=1
        counts["parameters"]+=len(a_source)
        if a_source or returns:
            rows.append(dict(module=module["name"],source_line=n,name=name,kind=kind,offset=r["offset"],
                             parameters=r["args"],source_return=returns,cache_return=r["return_slot"]))
assert next(procedures,None) is None
(work/"signatures.json").write_text(json.dumps(dict(counts=counts,signatures=rows),indent=2)+"\n",encoding="utf-8")
print(counts)

