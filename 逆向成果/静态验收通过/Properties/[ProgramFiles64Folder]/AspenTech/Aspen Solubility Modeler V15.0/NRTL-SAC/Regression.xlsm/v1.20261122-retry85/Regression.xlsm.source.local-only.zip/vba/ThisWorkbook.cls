Attribute VB_Name = "ThisWorkbook"
Attribute VB_Base = "0{00020819-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True
Option Explicit
Private Const myWelcomePage = "AspenSolubilityModeler"
Private Const sMajorVersionNumber = "41"
Private Const sMinorVersionNumber = "0"
Private Const sThirdVersionNumber = "0"
Private Const sBulidNumber = "1000" ' Dec 05 2008 Jiangchu Liu,  need incremented by 1 everytime this module has been modified
Private mySecServer As clsServer2
Private myLicName As String
Private myLicProp As String
Private myCookie As Long
Private myCheck As Boolean
Private myClose As Long

Enum slmLicStatus
    lsNoLic = 0
    lsPending = 1
    lsOK = 2
End Enum

Enum slmLicImportance
   lsNotCritical = 0
   lsCritical = 1
End Enum

Private Sub Workbook_Open()
   Sheets(myWelcomePage).Visible = xlSheetVisible

'Unhide all sheets except "AspenSolubilityModeler"
  
    Dim Sheet As Object
    For Each Sheet In Sheets
      If Not Sheet.Name = myWelcomePage Then
        Sheet.Visible = xlSheetVeryHidden
      End If
    Next
  'Sheets("ASWXL.Storage").Visible = xlSheetVeryHidden
    'gbAddinInstalled = CheckAddInInstalled
    Application.DisplayAlerts = False
    Sheet1.Range("F20").Formula = "=1"
    Range("VersionNumber").Value = sMajorVersionNumber & "." & sMinorVersionNumber & "." & sThirdVersionNumber & "." & sBulidNumber
    
'Check Aspen Solubility Modeler tracking license.
  Dim sLicVer As String
  Dim sErrString As String
   
'Initial
  myClose = 0
  Set mySecServer = New clsServer2
  myCookie = 0
  myLicName = "SLM_TR_PML_PLS_SOL" '"SLM_Solubility_Modeler"
  myLicProp = "AEA_AspenProperties" 'Aspen Properties
  sLicVer = ""
  myCheck = False
  
  'Aspen Properties license must be available
  Application.Cursor = xlWait
  If mySecServer.SLMCheckoutLicense(myLicProp, sLicVer, myCookie, lsCritical, sErrString) = False Then
    Application.Cursor = xlDefault
    MsgBox "Aspen Properties encounters a fatal license error." & _
                        " This workbook needs to close.", _
                        vbOKOnly, "Aspen Solubility Modeler Denial"
                        
    If myCookie <> 0 Then
      mySecServer.SLMReleaseLicense (myCookie)
      myCookie = 0
      'MsgBox "License is released"
    End If
    
    myCheck = False
    Application.DisplayAlerts = False
    Application.ActiveWorkbook.Saved = True
    Application.Quit

    Exit Sub
  Else
   'Release Aspen Properties license first.
    If myCookie <> 0 Then
      mySecServer.SLMReleaseLicense (myCookie)
      myCookie = 0
      'MsgBox "Aspen Properties License is released"
    End If
   'Check the tracking license of ASM
    If mySecServer.SLMCheckoutLicense(myLicName, sLicVer, myCookie, lsCritical, sErrString) Then
      myCheck = True
      'MsgBox "Checkout ok"
    End If
  End If
  
  Application.Cursor = xlDefault

End Sub

Private Sub Workbook_BeforeClose(Cancel As Boolean)
'This event is called only if Macros are enabled.

'Hide all sheets except "AspenSolubilityModeler"
 
    Dim Sheet As Object
    With Sheets(myWelcomePage)
        .Visible = xlSheetVisible
        For Each Sheet In Sheets
          If Not Sheet.Name = myWelcomePage Then
            Sheet.Visible = xlSheetVeryHidden
          End If
        Next
    End With

    Dim Msg As String
    Dim Ans As String
    If (ThisWorkbook.Saved = False And myClose = 0) Then
        Msg = "Do you want to save the changes you made to "
        Msg = Msg & Me.Name & "?"
        Ans = MsgBox(Msg, vbQuestion + vbYesNoCancel)
        Select Case Ans
            Case vbYes
                myClose = myClose + 1
                ThisWorkbook.Save
                ThisWorkbook.Application.DisplayAlerts = False
            Case vbNo
                myClose = myClose + 1
                ThisWorkbook.Saved = True
                ThisWorkbook.Application.DisplayAlerts = False
            Case vbCancel
                myClose = 0
                Cancel = True
                'Exit Sub
        End Select
    End If

    If (myClose <> 0 And myCookie <> 0) Then
'To keep the status of the workbook to show whether it's changed or not before the next step.
      Dim blFlagSaved As Boolean
      blFlagSaved = ActiveWorkbook.Saved

      Application.StatusBar = False
  
   ' -- check if simulation is loaded --
      If IsSimLoaded = True Then
    
        ' -- set the simulation to Not Visible so it can be closed --
        go_Simulation.Visible = False
        
        ' -- Delete Aspen Properties from Memory
        go_Simulation.Close
        ' -- close simulation --
        Set go_Simulation = Nothing
      End If 'IsSimLoaded = True
    
      'If blFlagSaved = True Then
      'ActiveWorkbook.Saved = True
      'End If
    
'Release Aspen Solubility Modeler tracking license.
      If myCookie <> 0 Then
        mySecServer.SLMReleaseLicense (myCookie)
        myCookie = 0
       'MsgBox "License is released"
      End If
    End If
     
End Sub

