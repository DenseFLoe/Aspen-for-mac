Attribute VB_Name = "Sheet8"
Attribute VB_Base = "0{00020820-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True
Attribute VB_Control = "cmdGoBackToWelcomePage, 260, 0, MSForms, CommandButton"
'Private CalculationTime  ' for progress  bar

Private Sub Worksheet_Activate()
Dim StartTime, EndTime
    ActiveSheet.EnableCalculation = True
'    StartTime = Timer
    ActiveSheet.Calculate
    ActiveSheet.EnableCalculation = False
'    EndTime = Timer
'    CalculationTime = EndTime - StartTime  'for progress bar
    
End Sub
Private Sub worksheet_change(ByVal Target As Range)
'  Dim row As Integer
Dim MessageBox

If ActiveSheet.CodeName = "Sheet8" Then

  If Target.Address = "$L$1331" Then Exit Sub
  
  
   If ((Target.Column = 1 And ((Target.Row >= 8 And Target.Row <= 17) Or Target.Row = 4)) _
   Or (Target.Column = 2 And (Target.Row = 1 Or Target.Row = 2))) Then
        MessageBox = MsgBox("The calculation will take time. Would you like to continue?", vbYesNo, "Continue the calculation?")
        If MessageBox = vbNo Then Exit Sub
        ActiveSheet.EnableCalculation = True
        ActiveSheet.Calculate
'  Code below is for progress bar
'===================================================================================
'        With frmHTE
'            .Show 0
'            For i = 1 To Round(CalculationTime)
'                Dim Time0
'                Time0 = Timer
'                .Label3.Width = Int(i / Round(CalculationTime) * 285)
'                .Label4.Caption = CStr(Int(i / Round(CalculationTime) * 100)) + "%"
'                DoEvents
'                Do While Timer < Time0 + 1
'                Loop
'            Next i
'            .Hide
'        End With
'=====================================================================================
        ActiveSheet.EnableCalculation = False
   End If
End If
End Sub

Private Sub Worksheet_Calculate()
Dim j As Integer
' Macro recorded 12/30/2006 by Jiangchu Liu
' Resets the Y Axis Minimum to the value in named cell VLE_Y_Min
'
On Error GoTo errorhandler

If ActiveSheet.CodeName = "Sheet8" Then


For j = 1 To 9
    If Range("j1151,j1155,j1159,j1163,j1167,j1171,j1175,j1179,j1183").Areas.Item(j).Value = "Yes" Then
        Range("e8:m8").Item(j).Font.ColorIndex = 43
        Range("e8:m8").Item(j).Font.Strikethrough = False
    Else
        Range("e8:m8").Item(j).Font.Color = vbRed
        Range("e8:m8").Item(j).Font.Strikethrough = True
    End If
Next j

'For j = 1 To 45
'    If Range("j1152,j1156,j1160,j1164,j1168,j1172,j1176,j1180,j1184,j1188,j1192,j1196,j1200,j1204,j1208,j1212,j1216,j1220,j1224,j1228,j1232,j1236,j1240,j1244,j1248,j1252,j1256,j1260,j1264,j1268,j1272,j1276,j1280,j1284,j1288,j1292,j1296,j1300,j1304,j1308,j1312,j1316,j1320,j1324,j1328").Areas.Item(j).Value = "Yes" Then
'        Range("e8:m8, f9:m9, g10:m10, h11:m11, i12:m12, j13:m13, k14:m14, l15:m15, m16").Areas.Item(j).Font.Color = vbGreen
'    Else
'        Range("e8:m8, f9:m9, g10:m10, h11:m11, i12:m12, j13:m13, k14:m14, l15:m15, m16").Areas.Item(j).Font.Color = vbRed
'    End If
'Next j
For j = 1 To 8
    If Range("j1187,j1191,j1195,j1199,j1203,j1207,j1211,j1215").Areas.Item(j).Value = "Yes" Then
        Range("f9:m9").Item(j).Font.ColorIndex = 43
        Range("f9:m9").Item(j).Font.Strikethrough = False
    Else
        Range("f9:m9").Item(j).Font.Color = vbRed
        Range("f9:m9").Item(j).Font.Strikethrough = True
    End If
Next j

For j = 1 To 7
    If Range("j1219,j1223,j1227,j1231,j1235,j1239,j1243").Areas.Item(j).Value = "Yes" Then
        Range("g10:m10").Item(j).Font.ColorIndex = 43
        Range("g10:m10").Item(j).Font.Strikethrough = False
    Else
        Range("g10:m10").Item(j).Font.Color = vbRed
        Range("g10:m10").Item(j).Font.Strikethrough = True
    End If
Next j

For j = 1 To 6
    If Range("j1247,j1251,j1255,j1259,j1263,j1267").Areas.Item(j).Value = "Yes" Then
        Range("h11:m11").Item(j).Font.ColorIndex = 43
        Range("h11:m11").Item(j).Font.Strikethrough = False
    Else
        Range("h11:m11").Item(j).Font.Color = vbRed
        Range("h11:m11").Item(j).Font.Strikethrough = True
    End If
Next j

For j = 1 To 5
    If Range("j1271,j1275,j1279,j1283,j1287").Areas.Item(j).Value = "Yes" Then
        Range("i12:m12").Item(j).Font.ColorIndex = 43
        Range("i12:m12").Item(j).Font.Strikethrough = False
    Else
        Range("i12:m12").Item(j).Font.Color = vbRed
        Range("i12:m12").Item(j).Font.Strikethrough = True
    End If
Next j

For j = 1 To 4
    If Range("j1291,j1295,j1299,j1303").Areas.Item(j).Value = "Yes" Then
        Range("j13:m13").Item(j).Font.ColorIndex = 43
        Range("j13:m13").Item(j).Font.Strikethrough = False
    Else
        Range("j13:m13").Item(j).Font.Color = vbRed
        Range("j13:m13").Item(j).Font.Strikethrough = True
    End If
Next j

For j = 1 To 3
    If Range("j1307,j1311,j1315").Areas.Item(j).Value = "Yes" Then
        Range("k14:m14").Item(j).Font.ColorIndex = 43
        Range("k14:m14").Item(j).Font.Strikethrough = False
    Else
        Range("k14:m14").Item(j).Font.Color = vbRed
        Range("k14:m14").Item(j).Font.Strikethrough = True
    End If
Next j

For j = 1 To 2
    If Range("j1319,j1323").Areas.Item(j).Value = "Yes" Then
        Range("l15:m15").Item(j).Font.ColorIndex = 43
        Range("l15:m15").Item(j).Font.Strikethrough = False
    Else
        Range("l15:m15").Item(j).Font.Color = vbRed
        Range("l15:m15").Item(j).Font.Strikethrough = True
    End If
Next j

    If Range("j1327").Value = "Yes" Then
        Range("m16").Font.ColorIndex = 43
        Range("m16").Font.Strikethrough = False
    Else
        Range("m16").Font.Color = vbRed
        Range("m16").Font.Strikethrough = True
    End If
        
    

'   If Range("e8:m8,f9:m9,g10:m10,h11:m11,i12:m12,j13:m13,k14:m14,l15:m15,m16").Item(j).Value = "Yes" Then
'        Range("e8:m8,f9:m9,g10:m10,h11:m11,i12:m12,j13:m13,k14:m14,l15:m15,m16").Item(j).Font.Color = vbGreen
'    Else
'        Range("e8:m8,f9:m9,g10:m10,h11:m11,i12:m12,j13:m13,k14:m14,l15:m15,m16").Item(j).Font.Color = vbRed
'    End If
'========================================================================
'   NOT CORRECT FOR INCONTINUOUS AREAS!!!!!!!!!!!!!!!!!!!!!!!! Need to Use Range.Areas.Item(j)
'========================================================================


End If

Exit Sub

errorhandler:
MsgBox "Worksheet Calculation Error!"

End Sub





Private Sub Worksheet_SelectionChange(ByVal Target As Range)
   'Debug.Print Target.Address
    Dim i, j As Integer
    Dim RowNumber As Integer
    
    For i = 1 To 9
        For j = 1 To 10 - i
           If (Target.Column = 3 + i + j And Target.Row = 7 + i) Then
                RowNumber = (46 + 25 * (((20 - i) * (i - 1) / 2 + j) - 1))
                Range("L1331").Value = Range("p" & RowNumber).Value
                Range("L1331").Font.ColorIndex = Target.Font.ColorIndex
                Range("L1331").Font.Strikethrough = Target.Font.Strikethrough
                UpdateDiagram (RowNumber)
                Exit Sub
            End If
           'Debug.Print Range("p" & 46 + 25 * (j - 1)).Address
        Next j
    Next i

End Sub
Private Sub cmdGoBackToWelcomePage_Click()
    ActiveSheet.Visible = xlSheetVeryHidden
    Sheet14.Visible = xlSheetVisible
    Sheet2.Visible = xlSheetVeryHidden
End Sub

Private Sub UpdateDiagram(ByVal rown As Integer)
Dim myChart As Chart

Set myChart = ActiveSheet.ChartObjects("Chart 274").Chart

'Sheet8.Unprotect "aspen123"

With myChart
'myChart.Activate
.ChartTitle.Caption = Range("s" & rown - 24).Value
.Axes(xlCategory).AxisTitle.Caption = Range("s" & rown - 23).Value
.SeriesCollection(1).XValues = _
        "='High Throughput Prediction'!R" & rown - 22 & "C1:R" & rown - 2 & "C1"
.SeriesCollection(1).Values = _
        "='High Throughput Prediction'!R" & rown - 22 & "C16:R" & rown - 2 & "C16"
End With

'Sheet8.Protect "aspen123", DrawingObjects:=False, Contents:=True, Scenarios:= _
        True, AllowFormattingCells:=True

End Sub

