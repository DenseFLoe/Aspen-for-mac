from collections import Counter, defaultdict
from contextlib import redirect_stderr
from hashlib import sha256
from importlib.metadata import version
from io import BytesIO, StringIO
import json
from pathlib import Path, PurePosixPath
import posixpath
import re
import subprocess
import sys
from types import SimpleNamespace
from urllib.parse import unquote
from xml.etree import ElementTree as ET
from zipfile import ZIP_DEFLATED, ZipFile

from oletools import oleform
from oletools.olevba import VBA_Parser, VBA_Project, decompress_stream
from pcodedmp import pcodedmp


EXPECTED = "52674742bc3dd7acb67367c4c72e1c8fe0cfde23b023f9050c1eef84baecf0b0"
BIND = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
OFFICE = "{urn:schemas-microsoft-com:office:office}"
SOURCE_PROC = re.compile(
    r"(?im)^[ \t]*(?:(?:Private|Public|Friend|Static)\s+)*"
    r"(Sub|Function|Property\s+(?:Get|Let|Set))\s+([a-z_]\w*)"
)
PCODE_PROC = re.compile(
    r"(?im)^[ \t]*FuncDefn\s+\((?:(?:Private|Public|Friend|Static)\s+)*"
    r"(Sub|Function|Property\s+(?:Get|Let|Set))\s+([a-z_]\w*)"
)


def digest(data):
    return sha256(data).hexdigest()


def json_bytes(data):
    return (json.dumps(data, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def part_relations(parts, xml):
    relations = {}
    missing = []
    external = []
    for filename, root in xml.items():
        if not filename.endswith(".rels"):
            continue
        parent, base = filename.rsplit("/_rels/", 1) if filename != "_rels/.rels" else ("", ".rels")
        origin = posixpath.join(parent, base[:-5])
        relations[origin] = {}
        for item in root:
            rid = item.attrib["Id"]
            kind = item.attrib["Type"].rsplit("/", 1)[-1]
            assert rid not in relations[origin], (filename, rid)
            raw = item.attrib["Target"]
            if item.get("TargetMode") == "External":
                target = unquote(raw.replace("\\", "/")).rstrip("/").rsplit("/", 1)[-1]
                external.append([filename, rid, kind, target])
            else:
                target = posixpath.normpath(posixpath.join(parent, unquote(raw).split("#")[0]))
                target = target.lstrip("/")
                if target not in parts:
                    missing.append([filename, rid])
            relations[origin][rid] = (target, kind)
    return relations, missing, external


def build_structure(parts, modules):
    xml = {
        name: ET.fromstring(data)
        for name, data in parts.items()
        if name.endswith((".xml", ".rels", ".vml"))
    }
    relations, missing, external = part_relations(parts, xml)
    dangling_ids = []
    for name, node in xml.items():
        for entry in node.iter():
            for key, value in entry.attrib.items():
                if key.startswith(BIND) and key.rsplit("}", 1)[-1] in {"id", "embed", "link"}:
                    if value and value not in relations.get(name, {}):
                        dangling_ids.append([name, key.rsplit("}", 1)[-1], value])

    book = xml["xl/workbook.xml"]
    defined_names = book.findall(".//{*}definedName")
    sheets = []
    all_controls = set()
    workbook_codename = book.find("{*}workbookPr").attrib["codeName"]
    assert workbook_codename in modules
    unbound_event_candidates = []
    for sheet in book.findall(".//{*}sheet"):
        path, kind = relations["xl/workbook.xml"][sheet.attrib[BIND + "id"]]
        assert kind == "worksheet"
        node = xml[path]
        code_name = node.find("{*}sheetPr").attrib["codeName"]
        assert code_name in modules
        formula_types = Counter()
        external_cells = Counter()
        formula_fingerprints = []
        for cell in node.findall(".//{*}c"):
            formula = cell.find("{*}f")
            if formula is None:
                continue
            formula_types[formula.get("t", "normal")] += 1
            text = formula.text or ""
            for index in set(re.findall(r"\[(\d+)\]", text)):
                external_cells[index] += 1
            formula_fingerprints.append([cell.attrib["r"], sorted(formula.attrib.items()), text])
        vml_shapes = set()
        drawing_shapes = set()
        for target, tag in relations.get(path, {}).values():
            if tag == "vmlDrawing":
                for shape in xml[target].findall(".//{*}shape"):
                    for key in ["id", OFFICE + "spid"]:
                        val = shape.get(key, "")
                        if val.startswith("_x0000_s"):
                            vml_shapes.add(val.removeprefix("_x0000_s"))
            if tag == "drawing":
                drawing_shapes.update(x.attrib["id"] for x in xml[target].findall(".//{*}cNvPr"))

        procedures = [item["name"] for item in modules[code_name]["procedures"]]
        controls = []
        seen = set()
        bound = set()
        for control in node.findall(".//{*}control"):
            rid = control.attrib[BIND + "id"]
            name = control.attrib["name"]
            shape = control.attrib["shapeId"]
            if (rid, name, shape) in seen:
                continue
            seen.add((rid, name, shape))
            activex, tag = relations[path][rid]
            assert tag == "control"
            all_controls.add(activex)
            ocx = xml[activex]
            ocx_rid = ocx.get(BIND + "id")
            binary = relations[activex][ocx_rid][0] if ocx_rid else None
            events = [n for n in procedures if n.casefold().startswith(name.casefold() + "_")]
            bound.update(events)
            controls.append({
                "name": name,
                "shape_id": shape,
                "worksheet_relationship": rid,
                "vml_shape": shape in vml_shapes,
                "drawing_shape": shape in drawing_shapes,
                "descriptor": activex,
                "class_id": next(value for key, value in ocx.attrib.items() if key.endswith("}classid")),
                "persisted_properties": binary,
                "handlers": events,
            })
        remaining = [
            n for n in procedures
            if n.casefold().endswith(("_click", "_change")) and not n.casefold().startswith("worksheet_") and n not in bound
        ]
        unbound_event_candidates.extend([code_name, n] for n in remaining)
        sheets.append({
            "name": sheet.attrib["name"],
            "state": sheet.get("state", "visible"),
            "part": path,
            "vba_codename": code_name,
            "formula_counts": dict(formula_types),
            "formula_cells_sha256": digest(json_bytes(formula_fingerprints)),
            "formula_entries_with_explicit_external_book_index": dict(external_cells),
            "controls": controls,
        })
    active_parts = {name for name in xml if re.fullmatch(r"xl/activeX/activeX\d+\.xml", name)}
    return {
        "parts_sha256": {name: digest(data) for name, data in sorted(parts.items())},
        "parts_by_suffix": dict(Counter(PurePosixPath(name).suffix for name in parts)),
        "xml_parts": len(xml),
        "relationship_ids_unresolved": dangling_ids,
        "relationship_targets_missing": missing,
        "external_relationships": external,
        "workbook_vba_codename": workbook_codename,
        "defined_names_count": len(defined_names),
        "charts_count": sum(bool(re.fullmatch(r"xl/charts/chart\d+\.xml", name)) for name in xml),
        "external_names": [
            e.attrib["name"] for e in xml["xl/externalLinks/externalLink1.xml"].findall(".//{*}definedName")
        ],
        "sheets": sheets,
        "unreferenced_activex_parts": sorted(active_parts - all_controls),
        "activex_without_drawing_or_vml": [
            [sheet["part"], control["name"]]
            for sheet in sheets for control in sheet["controls"]
            if not (control["drawing_shape"] or control["vml_shape"])
        ],
        "event_candidates_without_activex": unbound_event_candidates,
    }


def vba_sources(data, work):
    parser = VBA_Parser("vbaProject.bin", data=data, relaxed=False)
    (root, project_stream, dir_stream), = parser.find_vba_projects()
    ole = parser.ole_file
    project = VBA_Project(ole, root, project_stream, dir_stream, False)
    project.parse_project_stream()
    list(project.parse_modules())
    assert len(project.modules) == project.modules_count

    artifact = {}
    modules = {}
    for module in project.modules:
        raw_stream = ole.openstream(module.code_path).read()
        code = decompress_stream(bytearray(raw_stream[module.textoffset:]))
        assert code == module.code_raw
        source = code.decode(project.codec, errors="strict")
        assert source == module.code_str
        assert re.search(r'(?m)^Attribute VB_Name = "' + re.escape(module.name) + r'"\r?$', source)
        name = "vba/" + (module.filename_str if module.name != "frmHTE" else "frmHTE.frm.vba")
        artifact[name] = code
        modules[module.name] = {
            "stream": module.code_path,
            "source_offset": module.textoffset,
            "source_path": name,
            "source_sha256": digest(code),
            "source_bytes": len(code),
            "procedures": [
                {"kind": match[1].lower(), "name": match[2], "source_line": source.count("\n", 0, match.start()) + 1}
                for match in SOURCE_PROC.finditer(source)
            ],
        }

    ole_members = {
        "/".join(stream): digest(ole.openstream(stream).read()) for stream in ole.listdir()
    }
    expected_code_streams = {
        key for key in ole_members if key.startswith("VBA/")
        and key.split("/")[1] not in {"dir", "_VBA_PROJECT"} and not key.split("/")[1].startswith("__SRP_")
    }
    assert {m["stream"] for m in modules.values()} == expected_code_streams
    roles = {}
    for line in ole.openstream("PROJECT").read().decode(project.codec).splitlines():
        kind, _, name = line.partition("=")
        if kind in {"Document", "Module", "Class", "BaseClass"}:
            roles[name.split("/")[0]] = kind
    assert roles.keys() == modules.keys()
    for name, info in modules.items():
        info["role"] = roles[name]

    fields = oleform.extract_OleFormVariables(ole, ["frmHTE"])
    assert len(fields) == 4
    artifact["form/frmHTE/controls.json"] = json_bytes([
        {k: x.decode(project.codec) if isinstance(x, bytes) else x for k, x in field.items()}
        for field in fields
    ])
    for raw_name, target in [
        ("\x01CompObj", "CompObj.bin"), ("\x03VBFrame", "VBFrame.txt"), ("f", "f.bin"), ("o", "o.bin")
    ]:
        artifact["form/frmHTE/" + target] = ole.openstream(["frmHTE", raw_name]).read()

    cache = ole.openstream("VBA/_VBA_PROJECT").read()
    cache_version = int.from_bytes(cache[2:4], "little")
    assert cache_version == 0xB5 and project.syskind == 3
    names_by_definition = []
    original_disasm_func = pcodedmp.disasmFunc

    def record_raw_identifier(indirect, declarations, identifiers, offset, op_type, endian, vba_ver, is64bit):
        assert is64bit and vba_ver == 7
        word = pcodedmp.getWord(indirect, offset + 2, endian)
        index = (word >> 1) - 0x107
        assert 0 <= index < len(identifiers)
        names_by_definition.append((word, index, identifiers[index]))
        return original_disasm_func(indirect, declarations, identifiers, offset, op_type, endian, vba_ver, is64bit)

    output = StringIO()
    errors = StringIO()
    pcodedmp.disasmFunc = record_raw_identifier
    try:
        with redirect_stderr(errors):
            pcodedmp.processFile(str(work / "vbaProject.bin"), SimpleNamespace(verbose=False, disasmOnly=True), output)
    finally:
        pcodedmp.disasmFunc = original_disasm_func
    assert not errors.getvalue(), "P-code tool reported an error"
    body = output.getvalue()
    blocks = {
        match[1]: (match[2], body.count("\n", 0, match.start(2)) + 1)
        for match in re.finditer(r"(?ms)^(VBA/[^\n]+?) - \d+ bytes\n(.*?)(?=^VBA/|\Z)", body)
    }
    assert blocks.keys() == expected_code_streams
    identifiers_in_order = iter(names_by_definition)
    modules_by_stream = {info["stream"]: info for info in modules.values()}
    for stream, (block, first_line) in blocks.items():
        info = modules_by_stream[stream]
        pcode = [
            {"kind": match[1].lower(), "rendered_name": match[2], "dump_line": first_line + block.count("\n", 0, match.start())}
            for match in PCODE_PROC.finditer(block)
        ]
        assert len(info["procedures"]) == len(pcode)
        for source, compiled in zip(info["procedures"], pcode):
            assert source["kind"] == compiled["kind"]
            raw_id, identifier_index, recovered_name = next(identifiers_in_order)
            assert source["name"].casefold() == recovered_name.casefold(), info["stream"]
            source["pcodedmp_line"] = compiled["dump_line"]
            source["pcodedmp_rendered_name"] = compiled["rendered_name"]
            source["rendered_name_matches"] = source["name"].casefold() == compiled["rendered_name"].casefold()
            source["compiled_identifier_code"] = f"0x{raw_id:04X}"
            source["compiled_identifier_index"] = identifier_index
            source["compiled_identifier_name"] = recovered_name
    assert next(identifiers_in_order, None) is None

    parser.close()
    return artifact, {
        "codepage": project.codepage,
        "module_count": project.modules_count,
        "compiled_cache_version": f"0x{cache_version:04X}",
        "compiled_syskind": project.syskind_name,
        "compiled_identifier_index_rule": "(raw_id >> 1) - 0x107 for external procedure identifiers in this workbook",
        "form_control_count": len(fields),
        "ole_streams_sha256": ole_members,
        "modules": modules,
    }


def main():
    item = Path(sys.argv[1]).resolve()
    source = item / "input/Calculation.xlsm"
    work = item / "work"
    assert digest(source.read_bytes()) == EXPECTED
    with ZipFile(source) as src:
        assert src.testzip() is None
        assert len(set(src.namelist())) == len(src.namelist())
        parts = {name: src.read(name) for name in src.namelist()}
    assert (work / "vbaProject.bin").read_bytes() == parts["xl/vbaProject.bin"]
    output, project = vba_sources(parts["xl/vbaProject.bin"], work)
    structure = build_structure(parts, project["modules"])
    output.update({f"opc/{name}": data for name, data in parts.items()})
    output["repack_ooxml.py"] = (work / "repack_ooxml.py").read_bytes()
    output["evidence/recover_workbook.py"] = Path(__file__).read_bytes()
    for name, data in output.items():
        target = work / "payload" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    repacked = work / "repacked.xlsm"
    if repacked.exists():
        # This file is the disposable round-trip product for this item.
        repacked.unlink()
    subprocess.run([
        sys.executable, "-B", str(work / "payload/repack_ooxml.py"),
        str(work / "payload/opc"), str(repacked)
    ], check=True)
    with ZipFile(repacked) as check:
        assert check.testzip() is None
        assert len(check.namelist()) == len(parts)
        assert parts == {name: check.read(name) for name in check.namelist()}

    evidence = {
        "original_sha256": EXPECTED,
        "original_size": source.stat().st_size,
        "tools": {
            "python": sys.version.split()[0],
            **{name: version(name) for name in ["olefile", "oletools", "pcodedmp"]},
        },
        "round_trip_payloads_identical": len(parts),
        "round_trip_xlsm_sha256": digest(repacked.read_bytes()),
        "opc": structure,
        "vba": project,
        "payload_sha256": {name: digest(data) for name, data in sorted(output.items()) if not name.startswith("opc/")},
        "local_only_archive": True,
    }
    (work / "coverage.json").write_bytes(json_bytes(evidence))
    output["evidence/coverage.json"] = json_bytes(evidence)
    with ZipFile(work / "Calculation.xlsm.source.zip", "w", ZIP_DEFLATED) as result:
        for name, data in sorted(output.items()):
            result.writestr(name, data)
    with ZipFile(work / "Calculation.xlsm.source.zip") as result:
        assert result.testzip() is None
        assert output == {name: result.read(name) for name in result.namelist()}
    print(json.dumps({
        "parts": len(parts),
        "sheets": len(structure["sheets"]),
        "formulas": sum(sum(x["formula_counts"].values()) for x in structure["sheets"]),
        "definitions": structure["defined_names_count"],
        "charts": structure["charts_count"],
        "controls": sum(len(x["controls"]) for x in structure["sheets"]),
        "unbound": structure["event_candidates_without_activex"],
        "controls_without_shape": structure["activex_without_drawing_or_vml"],
        "orphan_activeX": structure["unreferenced_activex_parts"],
        "dangling": structure["relationship_ids_unresolved"],
        "missing_targets": structure["relationship_targets_missing"],
        "vba_procedures": sum(len(x["procedures"]) for x in project["modules"].values()),
        "pcode_label_mismatches": sum(
            not p["rendered_name_matches"] for x in project["modules"].values() for p in x["procedures"]
        ),
    }))


if __name__ == "__main__":
    main()
