import contextlib
import io
import json
from pathlib import Path
import re
import sys
from types import SimpleNamespace

from pcodedmp import pcodedmp
from recover_workbook import PCODE_PROC, SOURCE_PROC, json_bytes

TOKEN = re.compile(r'"(?:[^"\r\n]|"")*"|\'[^\r\n]*|\bRem[ \t][^\r\n]*', re.I)
CHECKS = [
    ("on_error", r"(?im)^[ \t]*On Error\b", r"(?m)^[ \t]*OnError\b"),
    ("for_next", r"(?im)^[ \t]*For(?:\s+Each)?\b", r"(?m)^[ \t]*For(?:Each)?\b"),
    ("if_block", r"(?im)\bEnd If\b", r"(?m)^[ \t]*EndIfBlock\b"),
    ("select_case", r"(?im)^[ \t]*Select Case\b", r"(?m)^[ \t]*SelectCase\b"),
    ("exit", r"(?im)\bExit (?:Sub|Function)\b", r"(?m)^[ \t]*Exit(?:Sub|Func)\b"),
]
# For these four assignments the cache evaluates the right-hand side
# before resolving the range on the left-hand side.
ASSIGNMENTS = {
    "ThisWorkbook": {
        81: (70, ["LitStr", "LitStr", "Ld", "ArgsMemLd", "MemSt"]),
        83: (72, [
            "Ld", "LitStr", "Concat", "Ld", "Concat", "LitStr", "Concat",
            "Ld", "Concat", "LitStr", "Concat", "Ld", "Concat", "LitStr", "ArgsLd", "MemSt"
        ]),
    },
    "Sheet8": {
        197: (186, ["LitStr", "Ld", "Concat", "ArgsLd", "MemLd", "LitStr", "ArgsLd", "MemSt"]),
    },
    "Sheet12": {
        103: (88, [
            "LitDI2", "LitStr", "ArgsLd", "MemLd", "Sub", "LitStr", "ArgsLd", "MemLd", "Sub",
            "LitStr", "ArgsLd", "MemSt"
        ]),
    },
}


def mask_tokens(source):
    return TOKEN.sub(lambda match: " " * len(match[0]), source)


def literals(text):
    return [match[0][1:-1].replace('""', '"') for match in TOKEN.finditer(text) if match[0].startswith('"')]


def compiled_literals(text):
    return re.findall(r'(?m)^[ \t]*LitStr\s+0x[0-9A-F]+ "(.*)"[ \t]*$', text)


def main():
    work = Path(sys.argv[1]) / "work"
    evidence = json.loads((work / "coverage.json").read_bytes())
    dump, errors = io.StringIO(), io.StringIO()
    with contextlib.redirect_stderr(errors):
        pcodedmp.processFile(str(work / "vbaProject.bin"), SimpleNamespace(verbose=False, disasmOnly=True), dump)
    assert not errors.getvalue()
    modules = dict(re.findall(r"(?ms)^(VBA/[^\n]+?) - \d+ bytes\n(.*?)(?=^VBA/|\Z)", dump.getvalue()))
    out = {}
    assignment_evidence = []
    for name, module in evidence["vba"]["modules"].items():
        code = (work / "payload" / module["source_path"]).read_bytes().decode("cp1252")
        block = modules[module["stream"]]
        source_lines = code.splitlines(keepends=True)
        for source_line, (compiled_line, expected_mnemonics) in ASSIGNMENTS.get(name, {}).items():
            statement = source_lines[source_line - 1]
            assert re.match(r"(?i)^\s*(?:Application\.)?Range\(", statement)
            assert re.search(r"(?i)\)\.(?:Formula|Value)\s*=", statement)
            pcode = re.search(rf"(?ms)^Line\s+#{compiled_line}:\n(.*?)(?=^Line|\Z)", block)[1]
            mnemonics = [line.split()[0] for line in pcode.splitlines() if line.strip()]
            assert mnemonics == expected_mnemonics, (name, compiled_line)
            sl = literals(statement)
            assert sl[1:] + sl[:1] == compiled_literals(pcode), (name, source_line)
            assignment_evidence.append({
                "module": name,
                "source_line": source_line,
                "compiled_line": compiled_line,
                "opcodes": mnemonics,
                "literal_order": "right-hand side followed by destination",
            })

        source_offsets = [m.start() for m in SOURCE_PROC.finditer(code)] + [len(code)]
        pcode_offsets = [m.start() for m in PCODE_PROC.finditer(block)] + [len(block)]
        out[name] = []
        for n, procedure in enumerate(module["procedures"]):
            source = code[source_offsets[n]:source_offsets[n + 1]]
            compiled = block[pcode_offsets[n]:pcode_offsets[n + 1]]
            clean = mask_tokens(source)
            first_line = code.count("\n", 0, source_offsets[n]) + 1
            sl = []
            for i, line in enumerate(source.splitlines(), first_line):
                items = literals(line)
                if i in ASSIGNMENTS.get(name, {}):
                    items = items[1:] + items[:1]
                sl.extend(items)
            pl = compiled_literals(compiled)
            flow = {
                key: [len(re.findall(a, clean)), len(re.findall(b, compiled))]
                for key, a, b in CHECKS
            }
            out[name].append({
                "procedure": procedure["name"],
                "literal_strings": [len(sl), len(pl)],
                "literal_sequence_equal": sl == pl,
                "flow_counts": flow,
            })
    result = {
        "procedures": out,
        "operand_evaluation_order_checks": assignment_evidence,
        "string_sequence_differences": [
            [name, method["procedure"], method["literal_strings"]]
            for name, methods in out.items() for method in methods if not method["literal_sequence_equal"]
        ],
        "flow_count_differences": [
            [name, method["procedure"], {k: v for k, v in method["flow_counts"].items() if v[0] != v[1]}]
            for name, methods in out.items() for method in methods
            if any(v[0] != v[1] for v in method["flow_counts"].values())
        ]
    }
    print(json.dumps({key: result[key] for key in ["string_sequence_differences", "flow_count_differences"]}))
    (work / "procedure_checks.json").write_bytes(json_bytes(result))
    assert not result["string_sequence_differences"] and not result["flow_count_differences"]


if __name__ == "__main__":
    main()
