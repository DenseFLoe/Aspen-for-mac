import argparse
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile


def main():
    parser = argparse.ArgumentParser(description="Repack the editable OOXML parts into an XLSM.")
    parser.add_argument("parts_dir", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    base = args.parts_dir.resolve(strict=True)
    if not (base / "[Content_Types].xml").is_file() or not (base / "_rels/.rels").is_file():
        parser.error("parts_dir must point to the extracted opc directory")
    output = args.output.resolve()
    if output.is_relative_to(base) or output.suffix.lower() != ".xlsm":
        parser.error("output must be an .xlsm outside parts_dir")
    files = sorted(path for path in base.rglob("*") if path.is_file())
    with ZipFile(output, "x", ZIP_DEFLATED) as archive:
        for path in files:
            if not path.resolve().is_relative_to(base):
                raise ValueError("Part resolves outside parts_dir")
            archive.write(path, path.relative_to(base).as_posix())


if __name__ == "__main__":
    main()
