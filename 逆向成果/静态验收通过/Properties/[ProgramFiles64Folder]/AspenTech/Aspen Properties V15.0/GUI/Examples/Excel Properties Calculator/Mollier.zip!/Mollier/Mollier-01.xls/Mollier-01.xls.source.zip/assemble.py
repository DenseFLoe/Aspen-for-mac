"""Assemble the Mollier BIFF8 and VBA sources into their recorded CFB layout."""

import argparse
import json
import struct
from pathlib import Path

from ovba_vbe6 import encode_source


TOKEN_TYPES = {
    0x01: ("Exp", "<HH"), 0x03: ("Add", "<"), 0x04: ("Sub", "<"),
    0x05: ("Mul", "<"), 0x06: ("Div", "<"), 0x15: ("Paren", "<"),
    0x17: ("Str", None), 0x1E: ("Int", "<H"), 0x1F: ("Num", None),
    0x23: ("Name", "<I"), 0x24: ("Ref", "<HH"), 0x25: ("Area", "<HHHH"),
    0x39: ("NameX", "<HI"), 0x3A: ("Ref3d", "<HHH"),
    0x3B: ("Area3d", "<HHHHH"), 0x42: ("FuncVar", "<BH"),
    0x44: ("RefValue", "<HH"), 0x4C: ("RefNValue", "<HH"),
}
TOKEN_CODES = {name: (code, layout) for code, (name, layout) in TOKEN_TYPES.items()}


def decode_tokens(raw):
    tokens = []
    position = 0
    while position < len(raw):
        opcode = raw[position]
        name, layout = TOKEN_TYPES[opcode]
        position += 1
        if name == "Str":
            count, flags = struct.unpack_from("<BB", raw, position)
            encoding = "utf-16-le" if flags & 1 else "latin-1"
            end = position + 2 + count * (2 if flags & 1 else 1)
            arguments = [flags, raw[position + 2:end].decode(encoding)]
            position = end
        elif name == "Num":
            arguments = [struct.unpack_from("<d", raw, position)[0].hex()]
            position += 8
        else:
            arguments = list(struct.unpack_from(layout, raw, position))
            position += struct.calcsize(layout)
        tokens.append([name, *arguments])
    if position != len(raw) or encode_tokens(tokens) != raw:
        raise ValueError("BIFF formula tokens did not round-trip")
    return tokens


def encode_tokens(tokens):
    encoded = bytearray()
    for name, *arguments in tokens:
        opcode, layout = TOKEN_CODES[name]
        encoded.append(opcode)
        if name == "Str":
            flags, value = arguments
            encoding = "utf-16-le" if flags & 1 else "latin-1"
            text = value.encode(encoding)
            encoded.extend(struct.pack("<BB", len(text) // (2 if flags & 1 else 1), flags))
            encoded.extend(text)
        elif name == "Num":
            encoded.extend(struct.pack("<d", float.fromhex(arguments[0])))
        else:
            encoded.extend(struct.pack(layout, *arguments))
    return bytes(encoded)


def assemble_workbook(directory):
    workbook = bytearray()
    for path in sorted(directory.glob("*.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            record = json.loads(line)
            if record["offset"] != len(workbook):
                raise ValueError(f"Record layout changed at {path.name}:{record['offset']:#x}")
            payload = bytearray.fromhex(record["data"])
            if "ptg" in record:
                tokens = encode_tokens(record["ptg"])
                if "length_field" in record:
                    struct.pack_into("<H", payload, record["length_field"], len(tokens))
                payload += tokens
            workbook.extend(struct.pack("<HH", int(record["type"], 16), len(payload)))
            workbook.extend(payload)
    if not workbook:
        raise ValueError("No BIFF records found")
    return bytes(workbook)


def write_chain(buffer, data, chain, sector_size, first_offset):
    if len(data) > len(chain) * sector_size:
        raise ValueError("Content exceeds its CFB sector chain")
    for index, sector in enumerate(chain):
        start = index * sector_size
        piece = data[start:start + sector_size]
        offset = first_offset + sector * sector_size
        if offset + sector_size > len(buffer):
            raise ValueError("CFB sector outside its container")
        buffer[offset:offset + sector_size] = piece.ljust(sector_size, b"\0")


def assemble(source):
    layout = json.loads((source / "cfb-layout.json").read_text(encoding="utf-8"))
    workbook = assemble_workbook(source / "biff")
    header = bytes.fromhex(layout["header"])
    sector_size = 1 << struct.unpack_from("<H", header, 30)[0]
    mini_size = 1 << struct.unpack_from("<H", header, 32)[0]
    output = bytearray(layout["file_size"])
    output[:sector_size] = header
    mini_stream = bytearray(layout["mini_stream_size"])
    tables = {
        "fat": struct.pack(f"<{len(layout['fat'])}I", *layout["fat"]),
        "minifat": struct.pack(f"<{len(layout['minifat'])}I", *layout["minifat"]),
        "directory": b"".join(map(bytes.fromhex, layout["directory_entries"])),
    }
    for name, data in tables.items():
        write_chain(output, data, layout[f"{name}_chain"], sector_size, sector_size)
    for entry in layout["streams"]:
        if entry["cfb_path"] == ["Workbook"]:
            data = workbook
        else:
            data = (source / entry["resource"]).read_bytes()
            if "vba_source" in entry:
                data += encode_source((source / entry["vba_source"]).read_bytes())
        if len(data) != entry["length"]:
            raise ValueError(f"Recorded stream size changed for {entry['cfb_path']}")
        if entry["mini"]:
            write_chain(mini_stream, data, entry["chain"], mini_size, 0)
        else:
            write_chain(output, data, entry["chain"], sector_size, sector_size)
    write_chain(output, mini_stream, layout["mini_stream_chain"], sector_size, sector_size)
    return bytes(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    parser.add_argument("--source", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    raw = assemble(args.source)
    with args.output.open("xb") as file:
        file.write(raw)


if __name__ == "__main__":
    main()
