Attribute VB_Name = "Module1"
Option Explicit

Function Interp(xval As Double, xrange As Range, _
   yrange As Range) As Double
'
'  Function estimates a y for a given x given a range
'  of x's and y's.
'  Simple linear interpolation is used
'
  Dim ic As Integer
  Dim il As Integer
  Dim iu As Integer
  Dim xi As Double
  Dim xl As Double
  Dim xu As Double
  Dim yl As Double
  Dim yu As Double
'
  ic = 0
  Do While ic < 100
  ic = ic + 1
  xi = xrange.Cells(ic).Value
  If xi > xval Then Exit Do
  Loop
'
  il = ic - 1
  If il < 1 Then il = 1
  xl = xrange.Cells(il).Value
  xu = xrange.Cells(il + 1).Value
  yl = yrange.Cells(il).Value
  yu = yrange.Cells(il + 1).Value
'
  Interp = yl + (xval - xl) / (xu - xl) * (yu - yl)
'

End Function

