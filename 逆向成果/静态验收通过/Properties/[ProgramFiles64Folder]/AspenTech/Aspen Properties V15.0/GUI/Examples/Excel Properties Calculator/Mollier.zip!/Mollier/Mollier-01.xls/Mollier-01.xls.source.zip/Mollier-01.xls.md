# Mollier-01.xls 源码和静态复验

原件是 Aspen Properties V15.0 安装目录 `GUI/Examples/Excel Properties Calculator/Mollier.zip` 中的 `Mollier/Mollier-01.xls`，格式为 BIFF8/CFB。沿用此前解包副本。安装成员大小为 114,688 字节，CRC-32 为 `36e28637`，原件 SHA-256 为 `69f437799ed15090185a8c1b178840ba4d305295fe119052ce6faec6faf8659d`。

## 源码和资源

- [BIFF8 工作簿源码](biff/)按子流保存 3,498 条记录。公式使用可编辑的带类型指令序列 `ptg`，保留相对和绝对引用、常量、求值顺序及共享和数组公式锚点。其余记录的 `data` 字段是原 BIFF8 载荷，包含布局、样式、图表、单元格值和缓存、保护字段、名称及外部链接。
- [可读公式](formulas.tsv)覆盖 1,000 个单元格，含 214 个直接公式、754 个共享公式成员和 32 个数组公式成员。[图表引用](chart-links.tsv)列出 175 条 BRAI，其中 66 条指向工作表数据。[名称](defined-names.tsv)包含 `interp` 和 `pkgname`。
- [VBA 源码](vba/)保留原代码页和行结束符。工作簿及五个表的宿主模块均可与 BIFF `CodeName` 对应。`Module1.bas` 实现 `Interp`。资源目录保存 7 个模块的原编译前缀、工程流、保护字段、缓存和 OLE 属性。
- [CFB 布局](cfb-layout.json)记录流、目录与扇区分配。3 张工作表为 `Calculation`、`Sheet2`、`Sheet3`，2 张图表工作表为 `PH-Diagram`、`MollierDiagram`。

## 重建

解包后在源码目录运行以下命令。组装只依赖 Python 3 标准库和随包资源。

```text
python -B assemble.py Mollier-01.rebuilt.xls
```

公式、图表及单元格 TSV 是便于阅读的核对视图。重建读取 `biff/*.jsonl`、`vba/`、`resources/` 和 `cfb-layout.json`。组装按原记录长度和扇区布局写入。修改导致记录或 VBA 流长度变化时，须同步更新 BIFF 偏移和 CFB 分配。VBA 编译缓存取自原件，修改 VBA 后须用对应 Excel/VBE 环境重新编译及验证缓存。

## 静态证据

仅复制交付目录至干净路径，禁用用户与系统 Python 第三方包后重建。产物与安装原件逐字节一致。olefile 核对了 27 个流，xlrd 独立核对公式表达式、两张图表的 66 个数据引用及两个定义名称。原件和重建件使用 pcodedmp 回读，7 个模块的指令一致。`Interp` 的循环上限、提前退出分支、下标下限、四次 `Cells(...).Value` 读取及线性插值运算次序均可对照 VBA 与 P-code。

工作簿和 VBA 工程均未发现本地窗体或嵌入控件。VBA `dir` 声明的注册类型库为 `stdole` 和 `Office`。外部工作簿的链接保留原始虚拟路径。`Aspen Properties.xla` 是独立安装依赖，已在本机安装文件的 `Functions.bas` 确认三项接口声明 `MixtureProperty`、`PureComponentConstant`、`TPFlash`。项目窗体名称出现在该外部链接的数据中。

VBA 重新编译、Excel 重算及加载项行为留待 Windows 重建对照阶段。

[逐条覆盖](static-evidence.json) · [独立工具复核](cross-check.json) · [VBA 模块指纹](vba-evidence.json) · [P-code](Mollier-01.xls.pcode.txt)
