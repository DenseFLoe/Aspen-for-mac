#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ovba_vbe6.py -- MS-OVBA compressor rewritten from VBE6.DLL pseudocode.

Source of truth (Ghidra, router/work/r-vbe6-ghidra/decomp/):
  65059cd4.c  per-chunk tokenizer (tier table, flag bytes, raw fallback)
  65059f6d.c  match lookup: 12-bit hash, 2-slot bucket, insert-and-shift
  65059c5f.c  chunk container loop
  Data tables read from VBE6.DLL (image base 0x65000000):
    0x65227938 (u32[9]) = 16,32,64,128,256,512,1024,2048,4096   distance tiers
    0x6522c7d0 (u32[9]) = 4098,2050,1026,514,258,130,66,34,18   length caps

Differences from office-l2/model_b.py (model B):
  * bucket = 12-bit hash (((b0<<4)^b1)<<4^b2)*0xFFFF9E5F >>4 & 0xFFF, 4096 buckets;
    every visit overwrites slot1/slot2 regardless of whether the 3-byte key matches
    (colliding keys evict each other) -- this is the rule model B approximated as
    "exact 3-byte key, depth 2".
  * insertion always happens for the visited position (token start), even when a
    copy token was chosen and even when the stored candidate is stale.
  * raw-chunk fallback follows the C buffer checks (literal: data offset >= 4096;
    copy: 4 + 2*(tokens+flags) >= 4096), not the empirical 4088 threshold.

Read-only w.r.t. every existing file; writes nothing unless a CLI subcommand says so.
"""
import struct


DIST_TIERS = (16, 32, 64, 128, 256, 512, 1024, 2048, 4096)
LEN_CAPS = (0x1002, 0x802, 0x402, 0x202, 0x102, 0x82, 0x42, 0x22, 0x12)
OUT_LIMIT = 4096           # param_5 = output buffer size
HASH_MUL = 0xFFFF9E5F      # (int)-0x61a1 as uint32


def hash3(b0, b1, b2):
    x = ((((b0 << 4) ^ b1) << 4) ^ b2) & 0xFFFFFFFF
    return (((x * HASH_MUL) & 0xFFFFFFFF) >> 4) & 0xFFF


class Vbe6:
    """Tokenize one source chunk exactly as FUN_65059cd4 / FUN_65059f6d."""

    def __init__(self, trace=False):
        self.trace = trace

    def match(self, ch, pos, n, cap, s1, s2):
        """FUN_65059f6d: return (length, matchpos); always inserts pos."""
        b0, b1, b2 = ch[pos], ch[pos + 1], ch[pos + 2]
        h = hash3(b0, b1, b2)
        c1, c2 = s1[h], s2[h]
        best_len, best_pos = 0, -1
        cap = min(cap, n - pos)   # C also stops at window end (puVar7[1])
        # slot1 (most recent) is tried first; ties keep slot1
        if c1 >= 0 and c1 < pos and ch[c1] == b0 and ch[c1 + 1] == b1 and ch[c1 + 2] == b2:
            m = 3
            while m < cap and ch[c1 + m] == ch[pos + m]:
                m += 1
            best_len, best_pos = m, c1
        if c2 >= 0 and c2 < pos and ch[c2] == b0 and ch[c2 + 1] == b1 and ch[c2 + 2] == b2:
            m = 3
            while m < cap and ch[c2 + m] == ch[pos + m]:
                m += 1
            if best_len < m:
                best_len, best_pos = m, c2
        # insert: slot2 <- old slot1, slot1 <- pos (unconditional)
        s2[h] = c1
        s1[h] = pos
        return best_len, best_pos

    def encode_chunk(self, ch):
        """Return (block_bytes, raw_flag). Mirrors FUN_65059cd4 byte layout."""
        n = len(ch)
        s1 = [-1] * 4096
        s2 = [-1] * 4096
        blk = bytearray(b"\x00\x00")   # chunk header placeholder
        flag_index = 2
        blk.append(0)                  # first flag byte
        data_pos = 3                   # puVar11 offset (bytes)
        ntokens = 0
        nflags = 0
        pos = 0
        group = 0
        while pos < n:
            # tier from current output position (iStack_c, monotone)
            tier = 0
            while tier < 8 and pos > DIST_TIERS[tier]:
                tier += 1
            cap = LEN_CAPS[tier]
            length, mpos = 0, -1
            if pos + 3 <= n:
                length, mpos = self.match(ch, pos, n, cap, s1, s2)
            if length == 0:
                if OUT_LIMIT <= data_pos:
                    return self._raw(ch)
                blk[flag_index] &= ~(1 << group) & 0xFF
                blk.append(ch[pos])
                data_pos += 1
                pos += 1
            else:
                if OUT_LIMIT <= 4 + 2 * (ntokens + nflags):
                    return self._raw(ch)
                blk[flag_index] |= (1 << group)
                bits = 4 + tier
                off = (pos - mpos - 1) & 0xFFFF          # distance-1
                val = ((off << (16 - bits)) | ((length - 3) & ((0xFFFF >> bits)))) & 0xFFFF
                blk += struct.pack("<H", val)
                data_pos += 2
                pos += length
            ntokens += 1
            group = (group + 1) & 7
            if group == 0:
                nflags += 1
                flag_index = data_pos
                blk.append(0)
                data_pos += 1
        # finalisation (C: if puStack_1c < out_end write pad flag, else puVar11 -= 1)
        if flag_index < OUT_LIMIT:
            length_block = data_pos
        else:
            length_block = data_pos - 1
        hdr = (((length_block - 3) & 0xFFF) | 0xB000) & 0xFFFF
        blk[0] = hdr & 0xFF
        blk[1] = hdr >> 8
        return bytes(blk[:length_block]), False

    @staticmethod
    def _raw(ch):
        hdr = 0x3FFF
        return struct.pack("<H", hdr) + bytes(ch[:4096]), True


def encode_source(src):
    out = bytearray(b"\x01")
    for s in range(0, len(src), 4096):
        blk, _ = Vbe6().encode_chunk(src[s:s + 4096])
        out += blk
    return bytes(out)
