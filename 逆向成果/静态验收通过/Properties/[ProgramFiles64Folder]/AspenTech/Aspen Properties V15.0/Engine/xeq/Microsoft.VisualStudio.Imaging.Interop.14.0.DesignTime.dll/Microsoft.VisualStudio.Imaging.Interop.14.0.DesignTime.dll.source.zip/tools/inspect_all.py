import subprocess, json, os, sys
from pathlib import Path
W=Path(r"C:/Users/Administrator/Desktop/Aspen 逆向/.local/high-level-rebuild-20261125/router/work/managed-near-1")
DN=r"C:/Users/Administrator/Desktop/Aspen 逆向/.local/patrol-0857/review340/net9/dotnet.exe"
APP=W/"_helper/ResolvedMetadataDetails.dll"
env=dict(os.environ, DOTNET_ROLL_FORWARD="LatestMajor")
def run(args):
    p=subprocess.run([DN,str(APP)]+args,capture_output=True,env=env)
    if p.returncode: raise SystemExit(p.stdout+p.stderr)
    return p.stdout.decode("utf-8-sig")
if not (W/"_helper/opcodes.json").exists():
    (W/"_helper/opcodes.json").write_text(run(["--opcode-kinds"]),encoding="utf-8")
for sha in ["21e93889","69334416","521985e1","1e3f6ded"]:
    op=Path((W/sha/"original/name.txt").read_text().strip())
    cand=next((W/sha/"candidate").glob("*.dll"))
    for label,path in (("original",op),("candidate",cand)):
        out=W/sha/(label+"-meta.json")
        out.write_text(run([str(path)]),encoding="utf-8")
        d=json.loads(out.read_text(encoding="utf-8"))
        print(sha,label,"methods",len(d["methods"]),"types",len(d["types"]),"refs",len(d["assemblyReferences"]))
