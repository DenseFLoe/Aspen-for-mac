import sys, json, struct
from pathlib import Path
sys.path.insert(0, r"C:/Users/Administrator/Desktop/Aspen 逆向/.local/aspen-acceptance-work/deps")
import pefile
from hashlib import sha256

def digest(b): return sha256(b).hexdigest()

def probe(path):
    data=Path(path).read_bytes()
    pe=pefile.PE(data=data, fast_load=False)
    clr=pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]
    out={"path":path,"sha256":digest(data),"size":len(data),
         "machine":hex(pe.FILE_HEADER.Machine),"characteristics":hex(pe.FILE_HEADER.Characteristics),
         "timestamp":pe.FILE_HEADER.TimeDateStamp,
         "linker":(pe.OPTIONAL_HEADER.MajorLinkerVersion,pe.OPTIONAL_HEADER.MinorLinkerVersion),
         "dllchars":hex(pe.OPTIONAL_HEADER.DllCharacteristics),
         "entry":pe.OPTIONAL_HEADER.AddressOfEntryPoint,"imagebase":pe.OPTIONAL_HEADER.ImageBase,
         "filealign":pe.OPTIONAL_HEADER.FileAlignment,"subsysver":(pe.OPTIONAL_HEADER.MajorSubsystemVersion,pe.OPTIONAL_HEADER.MinorSubsystemVersion),
         "sections":[{"name":s.Name.rstrip(b"\0").decode(),"va":s.VirtualAddress,"vs":s.Misc_VirtualSize,"raw":s.SizeOfRawData,"ptr":s.PointerToRawData,"ch":hex(s.Characteristics)} for s in pe.sections],
         "cert":{"va":pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].VirtualAddress,"size":pe.OPTIONAL_HEADER.DATA_DIRECTORY[4].Size},
         "debug":{"va":pe.OPTIONAL_HEADER.DATA_DIRECTORY[6].VirtualAddress,"size":pe.OPTIONAL_HEADER.DATA_DIRECTORY[6].Size},
         "import":{"va":pe.OPTIONAL_HEADER.DATA_DIRECTORY[1].VirtualAddress,"size":pe.OPTIONAL_HEADER.DATA_DIRECTORY[1].Size},
         "clr":{"va":clr.VirtualAddress,"size":clr.Size},
         "checksum":pe.OPTIONAL_HEADER.CheckSum,
         "stack":(pe.OPTIONAL_HEADER.SizeOfStackReserve,pe.OPTIONAL_HEADER.SizeOfStackCommit),
         }
    raw=pe.get_data(clr.VirtualAddress, clr.Size)
    if len(raw)>=72:
        out["clr_header"]={"cb":struct.unpack_from("<I",raw,0)[0],"major":struct.unpack_from("<H",raw,4)[0],"minor":struct.unpack_from("<H",raw,6)[0],
            "md_rva":struct.unpack_from("<I",raw,8)[0],"md_size":struct.unpack_from("<I",raw,12)[0],
            "flags":hex(struct.unpack_from("<I",raw,16)[0]),"entry":struct.unpack_from("<I",raw,20)[0],
            "res_rva":struct.unpack_from("<I",raw,24)[0],"res_size":struct.unpack_from("<I",raw,28)[0],
            "strong_rva":struct.unpack_from("<I",raw,32)[0],"strong_size":struct.unpack_from("<I",raw,36)[0],
            "tail":raw[40:].hex()}
    md=out["clr_header"]["md_rva"]
    ver_len=struct.unpack_from("<I",pe.get_data(md,16)[12:16] if False else pe.get_data(md+12,4))[0]
    root=pe.get_data(md,out["clr_header"]["md_size"])
    out["md_version"]=root[16:16+ver_len].decode("ascii","replace").rstrip("\0")
    at=16+ver_len; count=struct.unpack_from("<H",root,at+2)[0]; at+=4
    streams={}
    for _ in range(count):
        off,ln=struct.unpack_from("<II",root,at)
        end=root.index(b"\0",at+8); nm=root[at+8:end].decode()
        streams[nm]=(off,ln,digest(root[off:off+ln]))
        at=(end+4)&~3
    out["streams"]=streams
    return out,pe,root

if __name__=="__main__":
    print(json.dumps(probe(sys.argv[1])[0],ensure_ascii=False,indent=1))
