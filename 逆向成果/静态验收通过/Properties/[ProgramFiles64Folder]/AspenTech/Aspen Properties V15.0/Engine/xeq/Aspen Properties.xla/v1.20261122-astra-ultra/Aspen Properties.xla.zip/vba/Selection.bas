Attribute VB_Name = "Selection"
Option Private Module

Public mobjClass1 As Class1
' ListView is replaced by ListBox
'Public cItem As ColumnHeader
Public strComponentName As String
Dim IHNodeCol
Dim app As Object
Dim IHNode

' Function   : GetWorkingFolder(sRegistryName As Variant, sApplicationPath As String) As String
'              Finds the path for Aspen Properties Working folder from registry
' Created    : 03/13/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas

'Function GetWorkingFolder(sRegistryName As Variant, sApplicationPath As String) As String
Function GetWorkingFolder() As String
 Dim lReserved As Long
'
'[HKEY_CURRENT_USER\SOFTWARE\Aspentech\Aspen Properties\41.0\mmgini]
'"startupdir"="C:\\Users\\songy\\Documents\\AspenTech\\Aspen Properties V15.0"
'
  ' Call COM
  GetWorkingFolder = Invoke("APXL_GetWorkingFolder")
  '
End Function

' Function   : GetUserOptionFromRegistry
'              Finds the value of a User-option from the registry
' Created    : Jan 25, 2003
' Version    : Aspen Properties 12.1
' Author     : Abhijit Dutta (adapted from GetWorkingFolder)

Function GetUserOptionFromRegistry(lHkey As Variant, szRegKeyPath As String, optionName As String) As Long
  Dim lValue As Long
  Dim lDataType As Long
  'Dim hRegApropExcelKey As Long
'
' No longer used.
'
  GetUserOptionFromRegistry = lValue
End Function

' Write working folder to the Registry
Sub WriteWorkingFolderToRegistry(strFolder As String)
    'Dim hNewKey As Long
'
' Create registry and set the working folder.
'[HKEY_CURRENT_USER\SOFTWARE\Aspentech\Aspen Properties\41.0\mmgini]
'"startupdir"="C:\\Users\\songy\\Documents\\AspenTech\\Aspen Properties V15.0"
'
' Call COM
  Call Invoke("APXL_WriteWorkingFolderToRegistry", strFolder)
'
End Sub

' Accessing 64 bit registry key (Aspen Properties) from either 32 bit or 64 bit Excel using "KEY_READ Or KEY_WOW64_64KEY" and
' get the location of Excel-Add In from the Registry: \\Program Files\AspenTech\Aspen Properties VX.X\Engine\xeq\Aspen Properties.xla
Function GetStringValueFromRegistry(hKey_Which_Tree As Variant, regPath As String, regValueVariable As String) As String
  Dim sData As String * 512
  Dim lDataSize As Long
  Dim lDataType As Long
  Dim lRetVal As Long
  'Dim hKey As Long
  Dim sInput As String
'
' No longer used.
'
  GetStringValueFromRegistry = Left(sData, lDataSize - 1)
End Function

' Subroutine : InitClass1()
'              Initiate an object of class1 type
' Created    : 03/06/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub InitClass1()
 Set mobjClass1 = New Class1
End Sub
Sub DeleteClass1()
If mobjClass1 Is Nothing Then
   Exit Sub
End If
If mobjClass1.bCloseApp = True Then
    Dim saveCursor As XlMousePointer
    saveCursor = Application.Cursor
    Application.Cursor = xlWait
    mobjClass1.bCloseApp = False
    Call mobjClass1.CloseTempApp
    Call mobjClass1.CloseApp
    Set mobjClass1 = Nothing
    ' This seems necessary when the application is closing
    ' otherwise it seems to have problems with OLE references
    'MsgBox "Information: Removed OLE references to previously opened Aspen Properties", vbOKOnly, "Aspen Properties Excel Add-In"
    Application.Cursor = saveCursor
End If
End Sub

Public Function GetCAPEPropertyPackages() As String
    Dim props As Variant
    Dim counter As Integer
    
    Call DeleteClass1
    
    If g_CapeOpenVersion = "" Then
       Call InitializeGlobalVariables
    End If
    
    If g_PropSys Is Nothing Then
        Set g_PropSys = CreateObject("ATCOProperties.COPropertySystem." + g_CapeOpenVersion)
        Dim AspenPropSys As IAspenCapeThermoSystem
        Set AspenPropSys = g_PropSys
        Call AspenPropSys.SetPropertiesExclusiveLicense
        Call AspenPropSys.SetPropertiesExcelAddin
        Set AspenPropSys = Nothing
    End If
        props = g_PropSys.GetPropertyPackages
        For counter = LBound(props) To UBound(props)
           GetCAPEPropertyPackages = GetCAPEPropertyPackages & (props(counter)) & ";"
        Next
        props = Empty

End Function

Sub SelectPropertyMethodSet()
  Call DeleteClass1
  If IsPropertyPackageAvailable() = False Then Exit Sub
  Unload frmPropMethSet
  Load frmPropMethSet
  frmPropMethSet.Show
End Sub

' Subroutine : LaunchNewApplication()
'              Launch new Aspen Properties via OLE Autimation
' Created    : 03/06/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub LaunchNewApplication()
     If g_MMVersion = "" Then
       Call InitializeGlobalVariables
     End If
     Call GetWorkingFolder '(HKEY_CURRENT_USER, "Software\AspenTech\Aspen Properties\" + g_MMVersion + "\mmgini")
     Call DeleteClass1
     If Application.Workbooks.count = 0 Then
        MsgBox "At least one workbook must be open to use Aspen Properties functionality"
        Exit Sub
     End If
'
' 4/10/2009 by Yuhua Song. CQ00252621: Open Aspen Properties
'
     Call InitClass1
     mobjClass1.OpenCase
     mobjClass1.bNewAppFlag = True
End Sub

Sub EditExistingPackage(fileName As String)
    If g_MMVersion = "" Then
       Call InitializeGlobalVariables
    End If
     Call GetWorkingFolder '(HKEY_CURRENT_USER, "Software\AspenTech\Aspen Properties\" + g_MMVersion + "\mmgini")
     Call DeleteClass1
     If Application.Workbooks.count = 0 Then
        MsgBox "At least one workbook must be open to use Aspen Properties functionality"
        Exit Sub
     End If
     'Release existing package
     ReleasePackage
     
     Call InitClass1
     mobjClass1.OpenCase (fileName)
End Sub

Public Function SetGetLabel(sPropName As String) As String
    Dim sGlobal As String
    sGlobal = aUnitSet(0)
    If sPropName = "TEMPERATURE" Or sPropName = "PRESSURE" Or sPropName = "MOLE-VOLUME" Or sPropName = "MOLE-ENTHALPY" Or sPropName = "MOLE-HEAT-CAPACITY" Then
        Select Case sPropName
        Case "TEMPERATURE"
            If IsEmpty(aUnitSet(1)) Then
                SetGetLabel = GetConvertUnit(sGlobal, sPropName)
            Else
                SetGetLabel = aUnitSet(1)
            End If
        Case "PRESSURE"
            If IsEmpty(aUnitSet(2)) Then
                SetGetLabel = GetConvertUnit(sGlobal, sPropName)
            Else
                SetGetLabel = aUnitSet(2)
            End If
        Case "MOLE-VOLUME"
            If IsEmpty(aUnitSet(3)) Then
                SetGetLabel = GetConvertUnit(sGlobal, sPropName)
            Else
                SetGetLabel = aUnitSet(3)
            End If
        Case "MOLE-ENTHALPY"
            If IsEmpty(aUnitSet(4)) Then
                SetGetLabel = GetConvertUnit(sGlobal, sPropName)
            Else
                SetGetLabel = aUnitSet(4)
            End If
        Case "MOLE-HEAT-CAPACITY"
        If IsEmpty(aUnitSet(5)) Then
            SetGetLabel = GetConvertUnit(sGlobal, sPropName)
        Else
            SetGetLabel = aUnitSet(5)
        End If
    End Select
Else
    SetGetLabel = GetConvertUnit(sGlobal, sPropName)
End If
End Function
' Function   : GetConvertUnit(sGlobalSet As String, sPropName As String)
' Returns    : String
'            : Takes input as property name and global unit set defined by the user
'              and returns corresponding unit for that property, makes use of units.dat file
' Created    : 04/05/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Public Function GetConvertUnit(sGlobalSet As String, sPropName As String) As String
    Dim i As Integer
    Dim j As Integer
    Dim unitIndex As Integer
    For i = LBound(arrProp, 1) To UBound(arrProp, 1)
       If Trim(arrProp(i, 2)) = sPropName Then
          unitIndex = Val(arrProp(i, 5)) - Val(arrProp(i, 1))
          For j = LBound(arrUnit, 2) To UBound(arrUnit, 2)
            If j = unitIndex Then
                 Select Case sGlobalSet
                    Case "SI"
                        GetConvertUnit = (arrUnit(1, unitIndex))
                    Case "English"
                        GetConvertUnit = (arrUnit(1, unitIndex + 1))
                    Case "Metric", "Metrics"
                        GetConvertUnit = (arrUnit(1, unitIndex + 2))
                    Case Else
                        Select Case Module8.aUnitSet(6)
                            Case "SI"
                                GetConvertUnit = (arrUnit(1, unitIndex))
                            Case "English"
                                GetConvertUnit = (arrUnit(1, unitIndex + 1))
                            Case "Metric", "Metrics"
                                GetConvertUnit = (arrUnit(1, unitIndex + 2))
                            Case Else
                                GetConvertUnit = (arrUnit(1, unitIndex))
                        End Select
                 End Select
                Exit For
            End If
             Next j
        End If
            Next i

End Function

' kill a file after checking if it exists
Sub KillExists(fileName As String)
    On Error GoTo exitsub
    If DirCatch(fileName) <> "" Then
        Kill (fileName)
    End If
exitsub:
End Sub

Public Function DirCatch(pathname As String, Optional vbFileAttribute As vbFileAttribute = vbNormal) As String
DirCatch = ""
On Error GoTo exitfun
    DirCatch = Dir(pathname, vbFileAttribute)
exitfun:
End Function

