Attribute VB_Name = "VBACaller"
Option Explicit
Option Base 1

Public Function GetConnection() As VBConnection

    Set GetConnection = New VBConnection
    
End Function
