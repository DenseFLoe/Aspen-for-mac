import sys, json, os, subprocess, zipfile
from hashlib import sha256
from pathlib import Path
W=Path(r"C:/Users/Administrator/Desktop/Aspen 逆向/.local/high-level-rebuild-20261125/router/work/managed-near-1")
ROOT=Path(r"C:/Users/Administrator/Desktop/Aspen 逆向")
sys.path.insert(0,str(ROOT/".local/aspen-acceptance-work/deps"))
sys.path.insert(0,str(ROOT/".local/high-level-rebuild-20261125/managed-byte-recovery"))
sys.path.insert(0,str(W.parent/"managed-override-1"))
sys.path.insert(0,str(W))
import pefile
from pe_layout import identified_image

def digest(b): return sha256(b).hexdigest()

def pe_facts(path):
    data=Path(path).read_bytes()
    pe=pefile.PE(data=data, fast_load=True)
    h=pe.OPTIONAL_HEADER
    return {"image_base":h.ImageBase,"file_alignment":h.FileAlignment,
            "subsystem_version":f"{h.MajorSubsystemVersion}.{h.MinorSubsystemVersion:02d}",
            "dll":bool(pe.FILE_HEADER.Characteristics & 0x2000),
            "machine":pe.FILE_HEADER.Machine,
            "dllchars":h.DllCharacteristics,"entry":h.AddressOfEntryPoint,
            "clr_flags":None}

def public_key_from_meta(path):
    # Assembly row PublicKey via pefile+metadata reader
    import build_recipe2 as br
    data=Path(path).read_bytes()
    pe=br.pefile.PE(data=data, fast_load=True)
    cli=br.cli_header(pe); root=br.metadata_root(pe,cli)
    p=br.public_key_blob(pe,cli,root)
    return p["bytes"]

def main(sha8, langversion="10", optimize=True, extra_flags=()):
    d=W/sha8
    op=Path((d/"original/name.txt").read_text().strip())
    name=op.name
    cand=next((d/"candidate").glob("*.dll"))
    bi=json.loads((d/"candidate/build-inputs.json").read_text(encoding="utf-8"))
    facts=pe_facts(op)
    pkg=d/"pkg"
    if pkg.exists(): raise SystemExit("pkg exists")
    (pkg/"editable").mkdir(parents=True)
    (pkg/"resources").mkdir(parents=True)
    (pkg/"build").mkdir(parents=True)
    src=next((d/"candidate").glob("*.cs"))
    (pkg/"editable"/(src.name)).write_bytes(src.read_bytes())
    (pkg/"resources/original.res").write_bytes((d/"candidate/resources/original.res").read_bytes())
    inputs={"editable/"+src.name: ("editable/"+src.name),
            "resources/original.res":"resources/original.res"}
    managed=[]
    for r in bi.get("managed_resources") or []:
        member=None
        for cand_member in ("resources/"+r.get("file",""), "resources/managed/"+r.get("file","")):
            p=d/"candidate"/cand_member
            if p.is_file(): member=cand_member; break
        if not member: raise SystemExit("missing managed resource "+str(r))
        (pkg/member).parent.mkdir(parents=True,exist_ok=True)
        (pkg/member).write_bytes((d/"candidate"/member).read_bytes())
        inputs[member]=member
        managed.append({"member":member,"manifest_name":r["name"],
                        "visibility":"public" if r.get("publicResource") else "private"})
    pk=public_key_from_meta(op)
    if pk:
        (pkg/"build/assembly-public-key.snk").write_bytes(pk)
        inputs["build/assembly-public-key.snk"]="build/assembly-public-key.snk"
    flags=["/nologo","/utf8output","/nostdlib+","/deterministic+","/langversion:"+langversion,
           "/optimize"+("+" if optimize else "-"),"/target:library",
           "/baseaddress:0x%x"%facts["image_base"],"/filealign:%d"%facts["file_alignment"],
           "/subsystemversion:"+facts["subsystem_version"]]
    flags+=list(extra_flags)
    DN=ROOT/".local/patrol-0857/review340/net9/dotnet.exe"
    CSC=ROOT/".local/patrol-0857/review340/net9/sdk/9.0.321/Roslyn/bincore/csc.dll"
    plan={"assembly_name":name,"original_sha256":digest(op.read_bytes()),
          "tool_path":{"dotnet":str(DN),"csc":str(CSC)},
          "dotnet_sha256":digest(DN.read_bytes()),"csc_sha256":digest(CSC.read_bytes()),
          "references":bi["references"],"fixed_flags":flags,"managed_resources":managed,
          "build_input_sha256":{k:digest((pkg/v).read_bytes()) for k,v in inputs.items()}}
    (pkg/"build-plan.json").write_text(json.dumps(plan,ensure_ascii=False,indent=1)+"\n",encoding="utf-8")
    # original-build assets (certificate/debug/strong) from the read-only original
    import struct as _struct
    ob=pkg/"original-build"; ob.mkdir(exist_ok=True)
    data=op.read_bytes(); pe=pefile.PE(data=data,fast_load=True)
    cert=pe.OPTIONAL_HEADER.DATA_DIRECTORY[4]
    cli=pe.OPTIONAL_HEADER.DATA_DIRECTORY[14]; coff=pe.get_offset_from_rva(cli.VirtualAddress)
    s_rva,s_sz=_struct.unpack_from("<II",data,coff+32)
    dbg=pe.OPTIONAL_HEADER.DATA_DIRECTORY[6]
    (ob/"certificate-table.bin").write_bytes(data[cert.VirtualAddress:cert.VirtualAddress+cert.Size] if cert.Size else b"")
    (ob/"debug-record.bin").write_bytes(data[pe.get_offset_from_rva(dbg.VirtualAddress):pe.get_offset_from_rva(dbg.VirtualAddress)+dbg.Size] if dbg.Size and dbg.VirtualAddress else b"")
    if s_sz:
        so=pe.get_offset_from_rva(s_rva); (ob/"strong-name.bin").write_bytes(data[so:so+s_sz])
    # compile
    import replay
    work=d/"compile"
    built=replay.build(pkg/"build-plan.json",work) if False else None
    # replay.build needs a zip package
    seed=d/"pkg-seed.zip"
    with zipfile.ZipFile(seed,"w",zipfile.ZIP_DEFLATED) as z:
        for k,v in plan["build_input_sha256"].items():
            z.writestr(k,(pkg/k).read_bytes())
        z.writestr("build-plan.json",(pkg/"build-plan.json").read_bytes())
        z.write(ROOT/".local/high-level-rebuild-20261125/managed-byte-recovery/replay.py","replay.py")
        z.write(ROOT/".local/high-level-rebuild-20261125/managed-byte-recovery/pe_layout.py","pe_layout.py")
    target=replay.build(seed,work)
    print(json.dumps({"sha8":sha8,"compiled":str(target),"compiled_sha256":digest(target.read_bytes()),
        "artifact_candidate_sha256":digest(cand.read_bytes()),
        "match":digest(target.read_bytes())==digest(cand.read_bytes()),
        "flags":flags},ensure_ascii=False,indent=1))

if __name__=="__main__":
    opts=json.loads(sys.argv[2]) if len(sys.argv)>2 else {}
    main(sys.argv[1], **opts)
