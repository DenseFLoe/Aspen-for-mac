// IL code: Microsoft.VisualStudio.Imaging.Interop.14.0.DesignTime
.class private auto ansi '<Module>'
{
} // end of class <Module>

.class public auto ansi sealed Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags
	extends [mscorlib]System.Enum
{
	.custom instance void [mscorlib]System.FlagsAttribute::.ctor() = (
		01 00 00 00
	)
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_Size = int32(1)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_Type = int32(2)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_Format = int32(4)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_Dpi = int32(8)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_Background = int32(-2147483648)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_Grayscale = int32(1073741824)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_GrayscaleBiasColor = int32(536870912)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_HighContrast = int32(268435456)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_RequiredFlags = int32(15)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags IAF_OptionalFlags = int32(-268435456)

} // end of class Microsoft.VisualStudio.Imaging.Interop._ImageAttributesFlags

.class public auto ansi sealed Microsoft.VisualStudio.Imaging.Interop._UIDataFormat
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIDataFormat DF_Win32 = int32(1)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIDataFormat DF_WinForms = int32(2)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIDataFormat DF_WPF = int32(3)

} // end of class Microsoft.VisualStudio.Imaging.Interop._UIDataFormat

.class public auto ansi sealed Microsoft.VisualStudio.Imaging.Interop._UIImageType
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageType IT_Bitmap = int32(1)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageType IT_Icon = int32(2)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageType IT_ImageList = int32(3)

} // end of class Microsoft.VisualStudio.Imaging.Interop._UIImageType

.class public auto ansi sealed Microsoft.VisualStudio.Imaging.Interop._ImageMonikerType
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageMonikerType IMT_Unknown = int32(0)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageMonikerType IMT_LoadedFromManifest = int32(1)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageMonikerType IMT_Custom = int32(2)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._ImageMonikerType IMT_System = int32(3)

} // end of class Microsoft.VisualStudio.Imaging.Interop._ImageMonikerType

.class public auto ansi sealed Microsoft.VisualStudio.Imaging.Interop._UIImageHorizontalAlignment
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageHorizontalAlignment IHA_Left = int32(1)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageHorizontalAlignment IHA_Center = int32(2)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageHorizontalAlignment IHA_Right = int32(3)

} // end of class Microsoft.VisualStudio.Imaging.Interop._UIImageHorizontalAlignment

.class public auto ansi sealed Microsoft.VisualStudio.Imaging.Interop._UIImageVerticalAlignment
	extends [mscorlib]System.Enum
{
	// Fields
	.field public specialname rtspecialname int32 value__
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageVerticalAlignment IVA_Top = int32(1)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageVerticalAlignment IVA_Center = int32(2)
	.field public static literal valuetype Microsoft.VisualStudio.Imaging.Interop._UIImageVerticalAlignment IVA_Bottom = int32(3)

} // end of class Microsoft.VisualStudio.Imaging.Interop._UIImageVerticalAlignment

.class public sequential ansi sealed beforefieldinit Microsoft.VisualStudio.Imaging.Interop.ImageAttributes
	extends [mscorlib]System.ValueType
{
	.pack 8
	.size 0

	// Fields
	.field public int32 StructSize
	.field public uint32 Flags
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 3b 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 49 6d 61 67 65 41
		74 74 72 69 62 75 74 65 73 46 6c 61 67 73 00 00
	)
	.field public int32 LogicalWidth
	.field public int32 LogicalHeight
	.field public int32 Dpi
	.field public uint32 Format
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 33 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 55 49 44 61 74 61
		46 6f 72 6d 61 74 00 00
	)
	.field public uint32 ImageType
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 32 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 55 49 49 6d 61 67
		65 54 79 70 65 00 00
	)
	.field public uint32 Background
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 2b 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 52 47 42 41 00 00
	)
	.field public uint32 GrayscaleBiasColor
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 2b 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 52 47 42 41 00 00
	)
	.field public int32 HighContrast
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 2b 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 42 4f 4f 4c 00 00
	)

} // end of class Microsoft.VisualStudio.Imaging.Interop.ImageAttributes

.class public sequential ansi sealed beforefieldinit Microsoft.VisualStudio.Imaging.Interop.ImageMoniker
	extends [mscorlib]System.ValueType
{
	.pack 8
	.size 0

	// Fields
	.field public valuetype [mscorlib]System.Guid Guid
	.field public int32 Id

} // end of class Microsoft.VisualStudio.Imaging.Interop.ImageMoniker

.class public sequential ansi sealed beforefieldinit Microsoft.VisualStudio.Imaging.Interop.ImageCompositionLayer
	extends [mscorlib]System.ValueType
{
	.pack 8
	.size 0

	// Fields
	.field public valuetype Microsoft.VisualStudio.Imaging.Interop.ImageMoniker ImageMoniker
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 33 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 49 6d 61 67 65 4d
		6f 6e 69 6b 65 72 00 00
	)
	.field public int32 VirtualWidth
	.field public int32 VirtualHeight
	.field public int32 VirtualXOffset
	.field public int32 VirtualYOffset
	.field public uint32 HorizontalAlignment
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 41 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 55 49 49 6d 61 67
		65 48 6f 72 69 7a 6f 6e 74 61 6c 41 6c 69 67 6e
		6d 65 6e 74 00 00
	)
	.field public uint32 VerticalAlignment
	.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
		01 00 3f 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
		75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
		67 2e 49 6e 74 65 72 6f 70 2e 55 49 49 6d 61 67
		65 56 65 72 74 69 63 61 6c 41 6c 69 67 6e 6d 65
		6e 74 00 00
	)

} // end of class Microsoft.VisualStudio.Imaging.Interop.ImageCompositionLayer

.class interface public auto ansi abstract import Microsoft.VisualStudio.Imaging.Interop.IImageHandle
{
	.custom instance void [mscorlib]System.Runtime.InteropServices.GuidAttribute::.ctor(string) = (
		01 00 24 42 34 44 34 34 45 38 35 2d 46 43 46 36
		2d 34 38 31 45 2d 42 46 42 46 2d 43 44 46 33 41
		35 37 33 45 32 39 38 00 00
	)
	.custom instance void [mscorlib]System.Runtime.InteropServices.InterfaceTypeAttribute::.ctor(valuetype [mscorlib]System.Runtime.InteropServices.ComInterfaceType) = (
		01 00 01 00 00 00 00 00
	)
	// Methods
	.method public hidebysig specialname newslot abstract virtual 
		instance valuetype Microsoft.VisualStudio.Imaging.Interop.ImageMoniker get_Moniker () runtime managed internalcall 
	{
		.param [0]
			.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
				01 00 33 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
				75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
				67 2e 49 6e 74 65 72 6f 70 2e 49 6d 61 67 65 4d
				6f 6e 69 6b 65 72 00 00
			)
	} // end of method IImageHandle::get_Moniker

	// Properties
	.property valuetype Microsoft.VisualStudio.Imaging.Interop.ImageMoniker Moniker()
	{
		.custom instance void [mscorlib]System.Runtime.InteropServices.DispIdAttribute::.ctor(int32) = (
			01 00 00 00 01 60 00 00
		)
		.custom instance void [mscorlib]System.Runtime.InteropServices.ComAliasNameAttribute::.ctor(string) = (
			01 00 33 4d 69 63 72 6f 73 6f 66 74 2e 56 69 73
			75 61 6c 53 74 75 64 69 6f 2e 49 6d 61 67 69 6e
			67 2e 49 6e 74 65 72 6f 70 2e 49 6d 61 67 65 4d
			6f 6e 69 6b 65 72 00 00
		)
		.get instance valuetype Microsoft.VisualStudio.Imaging.Interop.ImageMoniker Microsoft.VisualStudio.Imaging.Interop.IImageHandle::get_Moniker()
	}

} // end of class Microsoft.VisualStudio.Imaging.Interop.IImageHandle

You are not using the latest version of the tool, please update.
Latest version is '11.2.0.10050' (yours is '9.1.0.7988')
