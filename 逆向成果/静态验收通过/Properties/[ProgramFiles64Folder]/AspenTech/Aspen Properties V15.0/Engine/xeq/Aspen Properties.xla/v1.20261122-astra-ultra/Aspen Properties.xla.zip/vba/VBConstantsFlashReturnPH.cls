Attribute VB_Name = "VBConstantsFlashReturnPH"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnPH
    ph_Temperature = out_Temperature
    ph_VaporFraction = out_VaporFraction
    ph_X = out_X
    ph_Y = out_Y
    ph_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Temperature
    list(2) = VaporFraction
    list(3) = X
    list(4) = Y
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get Temperature() As Long
    Temperature = ph_Temperature
End Property

Public Property Get VaporFraction() As Long
    VaporFraction = ph_VaporFraction
End Property

Public Property Get X() As Long
    X = ph_X
End Property

Public Property Get Y() As Long
    Y = ph_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = ph_SFRAC
End Property


