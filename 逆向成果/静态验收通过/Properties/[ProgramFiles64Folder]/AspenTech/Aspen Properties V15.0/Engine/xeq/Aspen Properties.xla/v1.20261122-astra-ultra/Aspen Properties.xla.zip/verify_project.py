"""Replay static acceptance for Aspen Properties.xla from the extracted source package."""
import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE/'verification'))
from check_cache import inspect as inspect_cache
from check_edit import run as check_edit
from check_static import inspect as inspect_structure
from extract_project import dump
from pack_project import assemble


def read_json(file):
    return json.loads(file.read_text('utf-8'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('original',type=Path)
    parser.add_argument('fresh_directory',type=Path)
    args=parser.parse_args()
    for line in (BASE/'SHA256SUMS').read_text('ascii').splitlines():
        digest,name=line.split('  ',1)
        if hashlib.sha256((BASE/name).read_bytes()).hexdigest()!=digest:
            raise ValueError(f'Packaged member checksum mismatch: {name}')
    root=args.fresh_directory.resolve()
    root.mkdir(parents=True,exist_ok=False)
    source=root/'source'
    source.mkdir()
    for name in ('vba','project'):
        shutil.copytree(BASE/name,source/name)
    for name in ('workbook.json','project.json'):
        shutil.copyfile(BASE/name,source/name)
    evidence=source/'evidence'
    evidence.mkdir()
    inspect_cache(args.original,evidence/'cache.json')
    if read_json(evidence/'cache.json')!=read_json(BASE/'evidence/cache.json'):
        raise ValueError('The original cache evidence changed')
    fixture=root/'roundtrip.xla'
    assemble(source,fixture)
    observed=inspect_structure(args.original,fixture,source)
    dump(evidence/'static.json',observed)
    static=read_json(evidence/'static.json')
    reference=read_json(BASE/'evidence/static.json')
    # CFB storage modification times may change during the new serialization.
    for result in (reference,static):
        result.pop('fixture_sha256')
    if reference!=static:
        raise ValueError('The project or controls differ from the archived verification')
    check_edit(source,root,evidence/'edit-test.json')
    if read_json(evidence/'edit-test.json')!=read_json(BASE/'evidence/edit-test.json'):
        raise ValueError('The edit/readback test changed')
    print('PASS: source, project streams, workbook, forms, code checks and edits')


if __name__=='__main__':
    main()

