Attribute VB_Name = "VBConstantsFlashReturnPS"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnPS
    ps_Temperature = out_Temperature
    ps_VaporFraction = out_VaporFraction
    ps_X = out_X
    ps_Y = out_Y
    ps_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Temperature
    list(2) = VaporFraction
    list(3) = X
    list(4) = Y
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get Temperature() As Long
    Temperature = ps_Temperature
End Property

Public Property Get VaporFraction() As Long
    VaporFraction = ps_VaporFraction
End Property

Public Property Get X() As Long
    X = ps_X
End Property

Public Property Get Y() As Long
    Y = ps_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = ps_SFRAC
End Property


