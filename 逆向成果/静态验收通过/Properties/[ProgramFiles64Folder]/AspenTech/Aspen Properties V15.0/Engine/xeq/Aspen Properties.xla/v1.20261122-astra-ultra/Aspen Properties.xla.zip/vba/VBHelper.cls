Attribute VB_Name = "VBHelper"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Private m_Constants As VBConstants
Private m_IsDefined As Boolean

Public Sub Initialize(constants_ As VBConstants)

    Set m_Constants = constants_
    m_IsDefined = True
    
End Sub

Public Property Get IsDefined() As Boolean

    IsDefined = m_IsDefined
    
End Property

Public Function PropertyName(code As Long) As String

Dim result As String

Select Case code
    Case a_AcentricFactor:                  result = "acentricFactor"
    Case a_ActivityCoefficient:             result = "activityCoefficient"
    Case a_CriticalCompressibilityFactor:   result = "criticalCompressibilityFactor"
    Case a_CriticalPressure:                result = "criticalPressure"
    Case a_CriticalTemperature:             result = "criticalTemperature"
    Case a_Density:                         result = "density"
    Case a_DiffusionCoefficient:            result = "diffusionCoefficient"
    Case a_Enthalpy:                        result = "enthalpy"
    Case a_Entropy:                         result = "entropy"
    Case a_Fugacity:                        result = "fugacity"
    Case a_FugacityCoefficient:             result = "fugacityCoefficient"
    Case a_GibbsFreeEnergy:                 result = "gibbsFreeEnergy"
    Case a_GrossHeatingValue:               result = "grossHeatingValue"
    Case a_HeatCapacity:                    result = "heatCapacity"
    Case a_HeatCapacityCv:                  result = "heatCapacityCv"
    Case a_InternalEnergy:                  result = "internalEnergy"
    Case a_LogFugacityCoefficient:          result = "logFugacityCoefficient"
    Case a_MassDensity:                     result = "massDensity"
    Case a_MolecularWeight:                 result = "molecularWeight"
    Case a_NetHeatingValue:                 result = "netHeatingValue"
    Case a_NormalBoilingPoint:              result = "normalBoilingPoint"
    Case a_NormalFreezingPoint:             result = "normalFreezingPoint"
    Case a_pH:                              result = "pH"
    Case a_SolubilityIndex:                 result = "solubiliityIndex"
    Case a_SurfaceTension:                  result = "surfaceTension"
    Case a_ThermalConductivity:             result = "thermalConductivity"
    Case a_VaporPressure:                   result = "vaporPressure"
    Case a_Viscosity:                       result = "viscosity"
    Case a_Volume:                          result = "volume"
    Case Else:
End Select

PropertyName = result

End Function

Public Function PropertyDescription(code As AspenProperty) As String

Dim result As String

Select Case code
    Case a_AcentricFactor:                  result = "The acentric factor for a component, omega, a measure of the non-sphericity of molecules."
    Case a_ActivityCoefficient:             result = "The activity coefficient of a component in a mixture, gamma, a measure of the deviation from an ideal solution."
    Case a_CriticalCompressibilityFactor:   result = "The critical compressibility factor, Zc, a measure of the deviation from an ideal gas at the critical point."
    Case a_CriticalPressure:                result = "The critical pressure for a componnt, Pc, at the critical point."
    Case a_CriticalTemperature:             result = "The critical temperature for a component, Tc, at the critical point."
    Case a_Density:                         result = "Molar density of a component or a mixture, rho = moles / V."
    Case a_DiffusionCoefficient:            result = "Diffusion coefficient of a component in a mixture. This is computed as the average of binary diffusion coefficients involving the component, using mixing rules."
    Case a_Enthalpy:                        result = "Molar enthalpy of a component or a mixture, h = H / moles."
    Case a_Entropy:                         result = "Molar entropy of a cmponent or a mixture, s = S / moles."
    Case a_Fugacity:                        result = "Fugacity of a component in pure state or in a mixture, f, the effective partial pressure for chemical equilibrium."
    Case a_FugacityCoefficient:             result = "Fugacity coefficient of a component in pure state or in a mixture, phi, the ratio of the fugacity of the component to its partial pressure."
    Case a_GibbsFreeEnergy:                 result = "Molar Gibbs free energy of a component or a mixture, g = h - T * s."
    Case a_GrossHeatingValue:               result = "API high heating value of a mixture, QVALGRS, a measure of the heat of combusion of the substance with oxygen, using liquid water, HCl and HF as combusion products."
    Case a_HeatCapacity:                    result = "Molar heat capacity at constant pressure of a component or a mixture, cp."
    Case a_HeatCapacityCv:                  result = "Molar heat capacity at constant volume of a component or a mixture, cv."
    Case a_InternalEnergy:                  result = "Molar internal energy of a component or a mixture, u = U / moles."
    Case a_LogFugacityCoefficient:          result = "Natural logarithm of fugacity coefficient of a component in pure state or in a mixture."
    Case a_MassDensity:                     result = "Mass density of a component or a mixture, rho = mass / V."
    Case a_MolecularWeight:                 result = "Molecular weight of a component, MW." ', may be calcualted from molecular formula dependong on options in the property package.
    Case a_NetHeatingValue:                 result = "API low heating value of a mixture, QVALNET, a measure of the heat of combustion of the substance with oxygen, using water vapor, Cl2 and F2 as combusion products."
    Case a_NormalBoilingPoint:              result = "Normal boiling point temperature for a component, TB, at 1 atm absolute pressure."
    Case a_NormalFreezingPoint:             result = "Normal freezing point temperature for a component, FREEZEPT, at 1 atm absolute pressure."
    Case a_pH:                              result = "pH for an electrolyte system. It is a standard measure of the strength of aqueous acids and bases."
    Case a_SolubilityIndex:                 result = "Solubility index of a salt in a mixture, SOLINDEX, for ionic salts. It is the ratio of activity in the mixture to activity at saturation."
    Case a_SurfaceTension:                  result = "Surface tension of a component or a mixture, sigma."
    Case a_ThermalConductivity:             result = "Thermal conductivity of a component or a mixture, lambda."
    Case a_VaporPressure:                   result = "Vapor pressure of a component, PL."
    Case a_Viscosity:                       result = "Viscosity of a component or a mixture, eta."
    Case a_Volume:                          result = "Molar volume of a component or a mixture, v = V / moles (the reciprocal of molar density)."
    Case Else:
End Select

PropertyDescription = result

End Function

Public Function ReturnName(code As FlashReturn) As String

Dim result As String

Select Case code
    Case out_Beta:              result = "BETA"
    Case out_Enthalpy:          result = "H"
    Case out_Pressure:          result = "P"
    Case out_SFRAC:             result = "SFRAC"
    Case out_Temperature:       result = "T"
    Case out_VaporFraction:     result = "V"
    Case out_X:                 result = "X"
    Case out_X1:                result = "X:1"
    Case OUT_X2:                result = "X:2"
    Case out_Y:                 result = "Y"
    Case Else:
End Select

ReturnName = result

End Function

Public Function FlashName(code As FlashType) As String

Dim result As String

Select Case code
    Case PV_VLE:    result = "PVFlash"
    Case PH_VLE:    result = "PHFlash"
    Case TP_VLE:    result = "TPFlash"
    Case TV_VLE:    result = "TVFlash"
    Case TH_VLE:    result = "THFlash"
    Case PS_VLE:    result = "PSFlash"
    Case PU_VLE:    result = "PUFlash"
    Case PV_VLLE:   result = "PVFlash3"
    Case PH_VLLE:   result = "PHFlash3"
    Case TP_VLLE:   result = "TPFlash3"
    Case TV_VLLE:   result = "TVFlash3"
    Case TH_VLLE:   result = "THFlash3"
    Case PH_LLE:    result = "PHFlashLL"
    Case TP_LLE:    result = "TPFlashLL"
    Case TH_LLE:    result = "THFlashLL"
    Case Else:
End Select

FlashName = result

End Function

Public Function FlashDescription(code As FlashType) As String

Dim result As String

Select Case code
    Case PV_VLE:    result = "Pressure-vapor fraction VLE flash."
    Case PH_VLE:    result = "Pressure-enthalpy VLE flash."
    Case TP_VLE:    result = "Temperature-pressure VLE flash."
    Case TV_VLE:    result = "Temperature-vapor fraction VLE flash."
    Case TH_VLE:    result = "Temperature-enthalpy VLE flash."
    Case PS_VLE:    result = "Pressure-entropy VLE flash."
    Case PU_VLE:    result = "Pressure-internal energy VLE flash."
    Case PV_VLLE:   result = "Pressure-vapor fraction VLLE flash."
    Case PH_VLLE:   result = "Pressure-enthalpy VLLE flash."
    Case TP_VLLE:   result = "Temperature-pressure VLLE flash."
    Case TV_VLLE:   result = "Temperature-vapor fraction VLLE flash."
    Case TH_VLLE:   result = "Temperature-enthalpy VLLE flash."
    Case PH_LLE:    result = "Pressure-enthalpy LLE flash."
    Case TP_LLE:    result = "Temperature-pressure LLE flash."
    Case TH_LLE:    result = "Temperature-enthalpy LLE flash."
    Case Else:
End Select

FlashDescription = result

End Function
