Attribute VB_Name = "COMAddinHelper"
' The prog id for the current version of the addin
Private Const APAddinProgid = "APXLAddinLoader.Connect.V15.0"
Private app As AspenPropertiesExcelCalculator.PropertiesApp

Public Function APXL_HasValidPackage() As Boolean

If (g_COPackage Is Nothing) Then
    APXL_HasValidPackage = False
Else
    APXL_HasValidPackage = True
End If
End Function

Public Function APXL_GetActiveUnitSet() As String
GetGlobalUnitArray
APXL_GetActiveUnitSet = Module8.aUnitSet(0)
End Function

Public Sub APXL_MethodSet()
SelectPropertyMethodSet
End Sub

Public Function APXL_GetCompIDs() As Variant
APXL_GetCompIDs = Functions.compids
End Function

Public Function APXL_GetCompFormulas() As Variant
APXL_GetCompFormulas = Functions.formulae
End Function

Public Function APXL_GetCompNames() As Variant
APXL_GetCompNames = Functions.strName
End Function

Public Function APXL_GetMethodLabels() As String
    APXL_GetMethodLabels = ""
    If g_pkgName = "" Then
        Exit Function
    End If

    Call DeleteClass1
    
    If (g_COPackage Is Nothing) Then
        Exit Function
    End If
    
    Dim props As Variant
    Dim counter As Integer
    Dim AspenPkg As IAspenPropertyPackage
    Set AspenPkg = g_COPackage
    props = AspenPkg.ListAvailablePropertyMethods
        
    counter = 0
    For counter = LBound(props) To UBound(props)
        APXL_GetMethodLabels = APXL_GetMethodLabels & props(counter) & ";"
    Next

    Set AspenPkg = Nothing
End Function

Public Function APXL_GetPropertyLabels() As String
    APXL_GetPropertyLabels = ""
    If g_pkgName = "" Then
        Exit Function
    End If
       
    Call DeleteClass1
    
    If (g_COPackage Is Nothing) Then
        Exit Function
    End If
    
    Dim props As Variant
    Dim counter As Integer
    Dim co As Long
    Dim i As Long
    Dim j As Long
    Dim temp As Variant
    
    props = g_COPackage.GetPropList
    counter = 0
    For counter = LBound(props) To UBound(props)
        If (0 = InStr(1, props(counter), ".", vbTextCompare) And _
            0 = InStr(1, props(counter), "kvalues", vbTextCompare) And _
            0 = InStr(1, props(counter), "idealGasEnthalpyOfFormationAt25C", vbTextCompare) And _
            0 = InStr(1, props(counter), "energyLennardJones", vbTextCompare) And _
            0 = InStr(1, props(counter), "lengthLennardJones", vbTextCompare)) And _
            props(counter) <> "energy" And props(counter) <> "enthalpyF" And _
            props(counter) <> "enthalpyNF" And props(counter) <> "entropyF" And _
            props(counter) <> "entropyNF" Then
            APXL_GetPropertyLabels = APXL_GetPropertyLabels & props(counter) & ";"
        End If
    Next

    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "internalEnergy;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "massDensity;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "normalBoilingPoint;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "normalFreezingPoint;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "criticalTemperature;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "criticalPressure;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "criticalCompressibilityFactor;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "acentricFactor;"
    'APXL_GetPropertyLabels = APXL_GetPropertyLabels & "gyrationRadius;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "netHeatingValue;"
    APXL_GetPropertyLabels = APXL_GetPropertyLabels & "grossHeatingValue;"
End Function

Public Function APXL_GetCapeOpenPackages() As String
APXL_GetCapeOpenPackages = Selection.GetCAPEPropertyPackages
End Function

Public Sub APXL_SetPackage(fileName As String)
'Clear previous package
CloseExistingPropertyPackage

DeleteClass1

'Set the package name
g_pkgName = fileName
ComparePDFdateWithBKPdateAndDelPDF (g_pkgName)
Call ResolveGlobalPackageAndMaterialObject
Call CheckIfLinksAreConsistent

If (fileName <> "" And g_pkgName = "") Then
    COMAddinHelper.UpdatePackage ("")
End If
End Sub

Public Sub APXL_SetGlobalUnits(unitDef As String)
Module8.SetNewUnitSet (unitDef)
End Sub

Public Sub APXL_LaunchNewCase()
LaunchNewApplication
End Sub

Public Sub APXL_EditExistingCase()
EditExistingPackage (g_pkgName)
End Sub

Public Sub APXL_ReleaseObjects()
ReleasePackage
End Sub

Public Sub APXL_UnitLabels()
SelectUnits
End Sub

Public Sub APXL_UnitSets()
SelectGlobalUnits
End Sub

Public Function Invoke(action As String, Optional args As Variant = "")
On Error GoTo giveup
    If (app Is Nothing) Then
        Call GetCOMApplication(app)
    End If
    If Not app Is Nothing Then
        Invoke = app.Invoke(action, args)
    End If
giveup:
End Function

Private Sub GetCOMApplication(ByRef retval As AspenPropertiesExcelCalculator.PropertiesApp)
    Set retval = Nothing
    
    Dim addin As COMAddin
    For Each addin In Application.COMAddIns
        If addin.progID = APAddinProgid Then
            
            Dim apAddin As IAPComAddin
            Set apAddin = addin.Object
            If Not apAddin Is Nothing Then
                Set retval = apAddin.PropertiesXLApp
            End If
            
            Exit For
        End If
    Next

End Sub

Public Function APXL_COMHandShake() As String
APXL_COMHandShake = "APXL_ReturnHandShake"
End Function

Public Sub UpdateRibbon(Optional enabled As Boolean = True)
Call Invoke("APXL_InvalidateRibbon", enabled)
End Sub

Public Sub ShowHelp(helpId As String)
Call Invoke("APXL_ShowHelp", helpId)
End Sub

Public Sub UpdatePackage(fileName As String)
Call Invoke("APXL_UpdatePackage", fileName)
End Sub

Public Function GetSavedUnitDefs() As String
GetSavedUnitDefs = Invoke("APXL_GetUnitDefinitions")
End Function

Public Sub StoreUnitDefinition(unitKey As String, unitDef As String)
Dim args(0 To 1) As Variant
args(0) = unitKey
args(1) = unitDef
Call Invoke("APXL_StoreUnitDef", args)
End Sub

Public Sub SelectPackage()
Call Invoke("APXL_SelectPackage")
End Sub
