Attribute VB_Name = "VBConstantsFlashReturnTHLL"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnTHLL
    thll_Pressure = out_Pressure
    thll_Beta = out_Beta
    thll_X1 = out_X1
    thll_X2 = OUT_X2
    thll_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Pressure
    list(2) = Beta
    list(3) = X1
    list(4) = X2
    list(6) = SFRAC
    GetValues = list
    
End Function

Public Property Get Pressure() As Long
    Pressure = thll_Pressure
End Property

Public Property Get Beta() As Long
    Beta = thll_Beta
End Property

Public Property Get X1() As Long
    X1 = thll_X1
End Property

Public Property Get X2() As Long
    X2 = thll_X2
End Property

Public Property Get SFRAC() As Long
    SFRAC = thll_SFRAC
End Property



