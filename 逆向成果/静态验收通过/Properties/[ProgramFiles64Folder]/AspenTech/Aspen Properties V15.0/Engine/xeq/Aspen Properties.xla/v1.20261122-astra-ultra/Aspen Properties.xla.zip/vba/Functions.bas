Attribute VB_Name = "Functions"
Option Explicit

Public resultCalc As Variant
Dim intResultCounter As Integer
Public errmsg As String
Public compids As Variant
Public formulae As Variant
Public boiltemps As Variant
Public casno As Variant
Public strName As Variant
Public molwt As Variant
Public bChangeCom As Boolean
Public GetValueIndex As Integer
Public bNoteText As Boolean
Public strUnitsType As String
Public strUnitsLabel As String
Public strRangeUnitsApply As String
Dim strGPropName As String
Dim strPropName As String
Public breCalculation As Boolean

' Function   : MoleFractionToMassFraction(MoleFraction As Variant, ComponentList As Variant)
'              Takes input molefraction from the excel sheet and returns corresponding massfraction
' Returns    : Variant (Array for MassFraction)
' Created    : 03/20/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Function MoleFractionToMassFraction(ComponentList As Variant, moleFraction As Variant) As Variant
Attribute MoleFractionToMassFraction.VB_Description = "Performs mass fraction conversion from mole fraction. Use Shift+Ctrl+Enter for multiple components."
Attribute MoleFractionToMassFraction.VB_HelpID = 3
Attribute MoleFractionToMassFraction.VB_ProcData.VB_Invoke_Func = " \n20"
    If GetNumColumnsInArray(moleFraction) < GetNumColumnsInArray(ComponentList) Then Exit Function
    Dim aTempArray As Variant
    Dim sum
    Dim results As Variant
       
    sum = 0
    '
    Dim i As Integer
    
    Dim bVerticalArray As Boolean
    bVerticalArray = IsVerticalArray()
   '
    Dim components As Variant
    components = GetValuesFromArray(ComponentList) 'components is now an array of one dimension (0 to n-1)
    
    aTempArray = GetValuesFromArray(moleFraction) 'aTempArray is now an array of one dimension (0 to n-1 or 0 to n) and may be different from components
    Dim temp As Variant
    temp = aTempArray 'Save aTempArray
    
    'ReDim aTempArray(UBound(components)) As Variant 'Make aTempArray as an array of one dimension (0 to n-1) from components
    ReDim Preserve aTempArray(LBound(components) To UBound(components)) 'Make aTempArray as an array of one dimension (0 to n-1) from components
       
'    For i = LBound(aTempArray) To UBound(aTempArray)
'      aTempArray(i) = CDbl(temp(i))
'    Next
    '
    Dim aMolecularWeight As Variant
    ' Gets MolecularWeight for the component list
    aMolecularWeight = PureComponentConstant(ComponentList, "molecularWeight")
   ' we do not want results vertically, however if the final function
   ' wants it vertically PureComponentConstant will be fooled into believing
   ' that we wanted molecularWeight vertically, because that itself is a public
   ' function. So we need to revert back to horizontal arrays if PureComponentConstant
   ' returns it vertically
   ' a bit of a waste by double transpose, guess does not hurt much though
   If bVerticalArray = True Then
       aMolecularWeight = Application.WorksheetFunction.Transpose(aMolecularWeight)
       ReDim Preserve aMolecularWeight(LBound(components) To UBound(components)) 'Make aMolecularWeight as an array of one dimension (0 to n-1) from components
   End If
   '
   ' If GetNumColumnsInArray(ComponentList) = GetNumColumnsInArray(MoleFraction) Then
        If CheckFractionSum(aTempArray) = True Then
            results = ConvertFraction(aTempArray, aMolecularWeight, 1)
            If bVerticalArray = True Then
                MoleFractionToMassFraction = Application.WorksheetFunction.Transpose(results)
            Else
                MoleFractionToMassFraction = results
            End If
        End If
   ' End If
   breCalculation = True
End Function
' Function   : MassFlowToMoleFraction(ComponentList As Variant, MassFlow As Variant) As Variant
'              Takes input massFlow from the excel sheet and returns corresponding molefraction
' Returns    : Variant (Array for MassFraction)
' Created    : 03/20/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Function MassFlowToMoleFraction(ComponentList As Variant, MassFlow As Variant) As Variant
Attribute MassFlowToMoleFraction.VB_Description = "Performs mass fraction conversion from MassFlow. Use Shift+Ctrl+Enter for multiple components."
Attribute MassFlowToMoleFraction.VB_HelpID = 5
Attribute MassFlowToMoleFraction.VB_ProcData.VB_Invoke_Func = " \n20"
    If GetNumColumnsInArray(MassFlow) < GetNumColumnsInArray(ComponentList) Then Exit Function
    Dim aMassFraction As Variant
    Dim aTempVariant As Variant
    Dim aCompList As Variant
    Dim sumVal As Double
    sumVal = 0#
    Dim i As Integer
   '
   ' see if this is requesting results vertically
    Dim bVerticalArray As Boolean
    bVerticalArray = IsVerticalArray()
   '
    Dim components As Variant
    components = GetValuesFromArray(ComponentList) 'components is now an array of one dimension (0 to n-1)
    
    aTempVariant = GetValuesFromArray(MassFlow) 'aTempVariant is now an array of one dimension (0 to n-1 or 0 to n) and may be different from components
    Dim temp As Variant
    temp = aTempVariant 'Save aTempVariant
    
    'ReDim aTempVariant(UBound(components)) As Variant 'Make aTempVariant as an array of one dimension (0 to n-1) from components
    ReDim Preserve aTempVariant(LBound(components) To UBound(components)) 'Make aTempVariant as an array of one dimension (0 to n-1) from components
    
    For i = LBound(aTempVariant) To UBound(aTempVariant)
       sumVal = sumVal + CDbl(aTempVariant(i))
       'sumVal = sumVal + CDbl(temp(i))
    Next
    
    For i = LBound(aTempVariant) To UBound(aTempVariant)
      aTempVariant(i) = CDbl(aTempVariant(i)) / sumVal
      'aTempVariant(i) = CDbl(temp(i)) / sumVal
    Next
    
    MassFlowToMoleFraction = MassFractionToMoleFraction(ComponentList, aTempVariant)
    breCalculation = True
End Function
' Function implemented by Nilesh, modifications included by Jwalant
Function PureProperty(ComponentList As Variant, PropertyName As String, Temperature As String, Pressure As String, phase As String, Optional propertyMethod As Variant) As Variant
Attribute PureProperty.VB_Description = "Calculates pure component properties. Input and results are in user specified Global Units Set. Valid Phase = V or L or S. Use Shift+Ctrl+Enter for multiple components."
Attribute PureProperty.VB_HelpID = 284
Attribute PureProperty.VB_ProcData.VB_Invoke_Func = " \n20"
    'Dim mobj As Object
    'Dim mt As Object
    Dim coMatObj As ICOMaterialObject
    Dim components As Variant
    Dim vals As Variant
    'Dim util As Object
    Dim bPhase As Boolean
    Dim bTypeLabel As String
    Dim dblTemperature As Double
    Dim dblPressure As Double
    Dim i As Integer
    Dim j As Integer
    Dim bCompFound As Boolean
    Dim strConst As String
    Dim strTdependent As String
    Dim strPdependent As String
    Dim strPureProperty As String
    Dim strMixtureProperty As String
    Dim sPhase As String
    Dim strPropHasBasis As String
    Dim bChangedPropertyMethod As Boolean
    bChangedPropertyMethod = False
'
' 5/30/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    components = GetValuesFromArray(ComponentList)
    Dim tempComps As Variant
    tempComps = components
    ReDim components(UBound(components)) As String
    For i = LBound(tempComps) To UBound(tempComps)
        components(i) = CStr(tempComps(i))
    Next
    
    Dim bVerticalArray As Boolean
    Dim bRangeCaller As Boolean
    ' Use this flag to transpose the results if they are requested
    ' in a vertical array
    ' Use this right at the end where the function return value is set
    bVerticalArray = IsVerticalArray(bRangeCaller)
    'bRangeCaller = True
    
    'Stop '<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

    On Error GoTo trap
    errmsg = ""
    
    If IsPropertyPackageAvailable() = False Then Exit Function
    
    PropertyName = getCaseSensitivePropertyName(PropertyName)
    
    ' 10/1/2009 by Yuhua Song. CQ00386972
    ' ap\source\atcapeopen\atcomaterial\COMatObject.cpp
    Set coMatObj = g_MaterialObject
    strPureProperty = ""
    ' Code added by Jwalant - For initiating aUnitSet for globalUnitSet's unitConversion Calculations
    Call GetGlobalUnitArray
'    PropertyName = getCaseSensitivePropertyName(PropertyName)
    If IsValidProperty(PropertyName, strConst, strTdependent, strPdependent, strPureProperty, strMixtureProperty, strPropHasBasis) = False _
        Or Trim(PropertyName) = "" Or Trim(strPureProperty) = "0" Then
        'MsgBox "'" & PropertyName & "' is not a pure component property"
        'Exit Function
        GoTo trap
    End If
    
    If IsMissing(propertyMethod) Then
        propertyMethod = ""
    End If
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If Temperature = "" Then
        If g_Tref = "" Then
           Call InitializeGlobalVariables
        End If
        Temperature = g_Tref
    End If
    
    If Pressure = "" Then
        If g_Pref = "" Then
           Call InitializeGlobalVariables
        End If
        Pressure = g_Pref
    End If
    errmsg = "The specified Temperature is not a valid value."
    resultCalc = SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", Temperature, "Set")
    ' Version 11.1 Implementation - dblTemperature = CDbl(Temperature) 'Val(Temperature) 'CDbl
    dblTemperature = CDbl(resultCalc)
    errmsg = "The specified Pressure is not a valid value."
    resultCalc = SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", Pressure, "Set")
    dblPressure = CDbl(resultCalc)
    'Version 11.1 ImplementationdblPressure = CDbl(Pressure) 'Val(Pressure)
    errmsg = ""
    
    If IsNumeric(phase) Then
        errmsg = "The specified Phase is not a valid value."
        GoTo trap
    End If
    
    For i = LBound(components) To UBound(components)
        bCompFound = False
        For j = LBound(compids) To UBound(compids)
            If Trim(components(i)) = Trim(compids(j)) Then
                bCompFound = True
                Exit For
            End If
        Next
    Next
    
    If bCompFound = False Then
        For i = LBound(components) To UBound(components)
            bCompFound = False
            For j = LBound(compids) To UBound(compids)
                If Trim(components(i)) = Trim(compids(j)) Then
                    bCompFound = True
                    Exit For
                End If
            Next
            If bCompFound = False Then
                errmsg = "The specified component '" & components(i) & "' in ComponentList is not valid."
                GoTo trap
            End If
        Next
    End If
    
    phase = UCase(Trim(CStr(phase)))
    If IsValidPhase(PropertyName, phase, sPhase) = False Then
        If StrComp(PropertyName, g_strPropName) <> 0 Then
            g_strPropName = PropertyName
            MsgBox "'" & phase & "' is not valid phase for '" & PropertyName & "' Property"
            Exit Function
        End If
    Else
        phase = sPhase
    End If
    
    ' 10/1/2009 by Yuhua Song. CQ00386972
    ' Call ap\source\atcapeopen\atcomaterial\COMatObject.cpp
    coMatObj.SetComponentIds (components)
  
    Dim values As Variant
    Dim realVal(1) As Double
    values = realVal

    values(0) = dblTemperature
    Call g_MaterialObject.SetProp("temperature", "Overall", components, "Mixture", Empty, values)
    values(0) = dblPressure
    Call g_MaterialObject.SetProp("pressure", "Overall", components, "Mixture", Empty, values)

    Dim propNames As Variant
    Dim phases As Variant
    ReDim propNames(0) As String
    ReDim phases(0) As String
    propNames(0) = PropertyName
    '
    ' if propertymethod is not default then set it
    If propertyMethod <> "" Then
        bChangedPropertyMethod = SetPropertyMethodOrSet(propertyMethod)
    End If
    '
    phases(0) = phase
    
    '1/30/04 Fan: For massDensity caluclation, get mole density first
    Dim MassDen As Boolean
    MassDen = False
    If (propNames(0) = "massDensity") Then
        MassDen = True
        PropertyName = "density"
        propNames(0) = PropertyName
        strPropHasBasis = "1"
    End If
    
    '6/12/2008 Suphat: for surfacetension, phase must be VaporLiquid
    Dim SurfTen As Boolean
    Dim PhaseVL As String
    SurfTen = False

    Dim PhasesToSet As Variant
    ReDim PhasesToSet(1) As String

    If (propNames(0) = "surfaceTension") Then
        SurfTen = True
        phases(0) = "VaporLiquid"
        PhaseVL = "VaporLiquid"
        PhasesToSet(0) = "Vapor"
        PhasesToSet(1) = "Liquid"
        coMatObj.SetPhases (PhasesToSet)
    Else
        'Ping Li : 08/28/2008 -- Before call CalcProp we should set phase first
        '                        because CalcProp will check for exist phase.
        coMatObj.SetPhases (phases)
    End If
    
    ' 10/1/2009 by Yuhua Song. CQ00386972
    ' Call ap\source\atcapeopen\atcoproperties\COPropPack.cpp
    Call g_COPackage.CalcProp(g_MaterialObject, propNames, phases, "Pure")

    If (SurfTen) Then
       If Trim(strPropHasBasis) = "1" Then ' specify mole basis
           vals = g_MaterialObject.GetProp(PropertyName, PhaseVL, components, "Pure", "Mole")
       Else
           vals = g_MaterialObject.GetProp(PropertyName, PhaseVL, components, "Pure", Empty)
       End If
    Else
       If Trim(strPropHasBasis) = "1" Then ' specify mole basis
           vals = g_MaterialObject.GetProp(PropertyName, phase, components, "Pure", "Mole")
       Else
           vals = g_MaterialObject.GetProp(PropertyName, phase, components, "Pure", Empty)
       End If
    End If
    
    '1/30/04 Fan: If MassDen = true
    ' Change the propNames back to massDensity for the unit and value processing
    If (MassDen = True) Then
        PropertyName = "massDensity"
        propNames(0) = PropertyName
        strPropHasBasis = "0"
    End If

    ' Code added by Jwalant (Entire For Loop - Implementation for getting values back in user specified unit from SI)
     For i = LBound(arrPropUnit, 1) To UBound(arrPropUnit, 1)
       If arrPropUnit(i, 0) = PropertyName Then
            strGPropName = arrPropUnit(i, 1)
        If strGPropName <> "Dimensionless" Then
           For intResultCounter = LBound(vals) To UBound(vals)
           vals(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), strGPropName, CStr(vals(intResultCounter)), "Get")
           Next intResultCounter
           
        End If
      Exit For
      End If
     Next i
    bNoteText = True
    bTypeLabel = GetUnitsTypeLabel(PropertyName, strUnitsType, strUnitsLabel)
    If bTypeLabel = True Then
        strRangeUnitsApply = GetCurrentCallerRange
    End If
    ' clean the material object
    coMatObj.Clean
    Set coMatObj = Nothing
    ' reset property method to global method
    If bChangedPropertyMethod = True Then
        Call RestoreOriginalProperty
    End If
'    Dim bVerticalArray As Boolean
'    ' Use this flag to transpose the results if they are requested
'    ' in a vertical array
'    ' Use this right at the end where the function return value is set
'    bVerticalArray = IsVerticalArray()
'    ' For enthalpy, Gibb's energy, entropy, heat capacity, molar volume
'    ' Cape Open values need to be multiplied by 1000
'    ' Abhijit & Suphat Dec 28, 2000
'    ' Same applies to all derivatives of these properties as well.
    Dim baseProp As String
    Dim derProp As String
    baseProp = PropertyName
    Dim pos As Long
    pos = InStr(1, PropertyName, ".", vbTextCompare)
    If (pos <> 0) Then
      If ((pos - 1) > 0) Then
        baseProp = Left(PropertyName, pos - 1)
        derProp = Right(PropertyName, Len(PropertyName) - pos)
      End If
    End If
    
    Dim k As Integer
    Select Case baseProp
        Case "enthalpy", "entropy", "gibbsFreeEnergy", "volume", "heatCapacity", "internalEnergy", "heatCapacityCv"
            k = 0
            For i = LBound(components) To UBound(components)
                If (derProp = "Dmoles") Then
                    vals(k) = vals(k) * 1000# * 1000#
                Else
                    vals(k) = vals(k) * 1000#
                End If
                k = k + 1
            Next
        Case "density"
            k = 0
            For i = LBound(components) To UBound(components)
                If (derProp = "Dmoles") Then
                    vals(k) = vals(k)
                Else
                    vals(k) = vals(k) / 1000#
                End If
                k = k + 1
            Next
        Case "massDensity" '1/30/04 Fan: massDensity =  mole density* MW
            Dim aMolecularWeight As Variant
            Dim strUnitsTypeTemp As String
            Dim strUnitsLabelTemp As String
            Dim strRangeUnitsApplyTemp As String
            
            ' Save these because PureComponentConstant will overwrite them
            strUnitsTypeTemp = strUnitsType
            strUnitsLabelTemp = strUnitsLabel
            strRangeUnitsApplyTemp = strRangeUnitsApply
            
            aMolecularWeight = PureComponentConstant(ComponentList, "molecularWeight")
            
            ' Restore these because PureComponentConstant overwrote
            strUnitsType = strUnitsTypeTemp
            strUnitsLabel = strUnitsLabelTemp
            strRangeUnitsApply = strRangeUnitsApplyTemp
            
            If bVerticalArray = True Then 'aMolecularWeight is an array of two dimenions from (1,1) to (n, 1).
                aMolecularWeight = Application.WorksheetFunction.Transpose(aMolecularWeight) 'aMolecularWeight is one dimention (1 to n).
                ReDim Preserve aMolecularWeight(LBound(vals) To UBound(vals)) 'aMolecularWeight is one dimention (0 to n-1).
            End If
            
            k = 0
            For i = LBound(components) To UBound(components)
                vals(k) = vals(k) * CDbl(aMolecularWeight(k)) / 1000#
                k = k + 1
            Next
            
            ' Other
'            If bVerticalArray = True Then
'              k = 0
'              For i = LBound(components) To UBound(components)
'                vals(k) = vals(k) * CDbl(aMolecularWeight(k + 1, 1)) / 1000#
'                k = k + 1
'              Next
'            Else
'              k = 0
'              For i = LBound(components) To UBound(components)
'                vals(k) = vals(k) * CDbl(aMolecularWeight(k)) / 1000#
'                k = k + 1
'              Next
'            End If
            
     End Select
     If bVerticalArray = True Then
        PureProperty = Application.WorksheetFunction.Transpose(vals)
     Else
        PureProperty = vals
     End If
     
     breCalculation = True
     Exit Function
trap:
'
' 5/30/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    vals = SetErrors(components, "Pure")
    If (bVerticalArray = True) Then
        PureProperty = Application.WorksheetFunction.Transpose(vals)
    Else
        PureProperty = vals
    End If
'
    strUnitsType = ""
    strUnitsLabel = ""
    strRangeUnitsApply = ""
    coMatObj.Clean
    Set coMatObj = Nothing
    ' reset property method to global method
    If bChangedPropertyMethod = True Then
        Call RestoreOriginalProperty
    End If
    
    If bChangeCom = True Then Exit Function
    If errmsg <> "" Then
        errmsg = ""
    End If
End Function

' Function implemented by Nilesh, modifications included by Jwalant
Function PureComponentConstant(ComponentList As Variant, PropertyName As String) As Variant
Attribute PureComponentConstant.VB_Description = "Returns pure component constant such as molecular weight and normal boiling point. Results are in user specified Global Units Set. Use Shift+Ctrl+Enter for multiple components."
Attribute PureComponentConstant.VB_HelpID = 308
Attribute PureComponentConstant.VB_ProcData.VB_Invoke_Func = " \n20"
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    Dim strConst As String
    Dim strTdependent As String
    Dim strPdependent As String
    Dim strPureProperty As String
    Dim strMixtureProperty As String
    Dim strPropHasBasis As String
    
    Dim i As Integer
    Dim components As Variant
    components = GetValuesFromArray(ComponentList)
    
    Dim bVerticalArray As Boolean
    bVerticalArray = IsVerticalArray()
    
    On Error GoTo trap
    
    PropertyName = getCaseSensitivePropertyName(PropertyName)
    If IsValidProperty(PropertyName, strConst, strTdependent, strPdependent, strPureProperty, strMixtureProperty, strPropHasBasis) = False _
        Or Trim(PropertyName) = "" Or Trim(strConst) = "0" Then
        'MsgBox "'" & PropertyName & "' is not a pure component constant"
        'Exit Function
        GoTo trap
    End If
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    If g_Pref = "" Then
       Call InitializeGlobalVariables
    End If
    result = PureProperty(ComponentList, PropertyName, g_Tref, g_Pref, "L")
    
    ' Check and reset MW that is missing
    If (PropertyName = "molecularWeight") Then
      Dim aMolecularWeight As Variant
      aMolecularWeight = result
      Dim bChange As Boolean
      bChange = False
      Dim j As Integer
      
      If bVerticalArray = True Then 'aMolecularWeight is an array of two dimenions from (1,1) to (n, 1).
        aMolecularWeight = Application.WorksheetFunction.Transpose(aMolecularWeight) 'aMolecularWeight is one dimention (1 to n).
        'ReDim Preserve aMolecularWeight(LBound(aMolecularWeight) To UBound(aMolecularWeight)) 'aMolecularWeight is one dimention (0 to n-1).
        'ReDim aMolecularWeight(UBound(aMolecularWeight)) As String
        For j = LBound(aMolecularWeight) To UBound(aMolecularWeight)
          If CDbl(aMolecularWeight(j)) < -1E+30 Or CDbl(aMolecularWeight(j)) > 1E+30 Then
            aMolecularWeight(j) = 1E+35
            bChange = True
          End If
        Next
      Else 'aMolecularWeight is one dimention (0 to n-1).
        'ReDim aMolecularWeight(UBound(aMolecularWeight)) As String
        For j = LBound(aMolecularWeight) To UBound(aMolecularWeight)
          If CDbl(aMolecularWeight(j)) < -1E+30 Or CDbl(aMolecularWeight(j)) > 1E+30 Then
            aMolecularWeight(j) = 1E+35
            bChange = True
          End If
        Next
      End If
      
      If (bChange = True) Then
        'ReDim aMolecularWeight(UBound(aMolecularWeight)) As Variant
        
        If bVerticalArray = True Then
          result = Application.WorksheetFunction.Transpose(aMolecularWeight)
        Else
          result = aMolecularWeight
        End If
      End If

    End If
    
    PureComponentConstant = result
    Exit Function
trap:
'    Dim i As Integer
'    Dim vals As Variant
'    Dim components As Variant
'    components = GetValuesFromArray(ComponentList)
    Dim tempComps As Variant
    tempComps = components
    ReDim components(UBound(components)) As String
    For i = LBound(tempComps) To UBound(tempComps)
        components(i) = CStr(tempComps(i))
    Next
    
'    Dim bVerticalArray As Boolean
'    bVerticalArray = IsVerticalArray()
    Dim vals As Variant
    vals = SetErrors(components, "Pure")
    If bVerticalArray = True Then
        PureComponentConstant = Application.WorksheetFunction.Transpose(vals)
    Else
        PureComponentConstant = vals
    End If

    If bChangeCom = True Then Exit Function
    If errmsg <> "" Then
        errmsg = ""
    End If
    
End Function
' Function implemented by Nilesh, modifications included by Jwalant
Function VaporPressure(ComponentList As Variant, Temperature As String) As Variant
Attribute VaporPressure.VB_Description = "Calculates liquid vapor pressure of pure components. Input and results are in user specified Global Units Set. Use Shift+Ctrl+Enter for multiple components."
Attribute VaporPressure.VB_HelpID = 310
Attribute VaporPressure.VB_ProcData.VB_Invoke_Func = " \n20"
    If IsPropertyPackageAvailable() = False Then Exit Function
   ' SetGetConvertValue(sGlobalSet As String, sPropName As String, dValue As Double, sFlag As String) As Double
    Dim strConst As String
    Dim strTdependent As String
    Dim strPdependent As String
    Dim strPureProperty As String
    Dim strMixtureProperty As String
    Dim strPropHasBasis As String
    
    Call GetGlobalUnitArray
    If IsValidProperty("vaporPressure", strConst, strTdependent, strPdependent, strPureProperty, strMixtureProperty, strPropHasBasis) = False Then
        Exit Function
    End If
    
    resultCalc = Temperature
    '  Version 11.1 Implementation : result = PureProperty(ComponentList, "vaporPressure", Temperature, "0", "L", "SYSOP0")
'
' 5/27/2009 by Yuhua Song. CQ00369766: Pass the pressure as 101325 Pa instead of 0 to void a system error in Aspen Properties
'
    If g_Pref = "" Then
       Call InitializeGlobalVariables
    End If
    resultCalc = PureProperty(ComponentList, "vaporPressure", CStr(resultCalc), g_Pref, "L", "SYSOP0")
    VaporPressure = resultCalc
End Function
Function AverageMolecularWeight(ComponentList As Variant, moleFraction As Variant) As Double
Attribute AverageMolecularWeight.VB_Description = "Calculates Average Molecular Weight at specified mole fraction."
Attribute AverageMolecularWeight.VB_HelpID = 16
Attribute AverageMolecularWeight.VB_ProcData.VB_Invoke_Func = " \n20"
   Dim aMolecularWeight As Variant
   Dim aTempArray As Variant
   Dim i As Integer
   'Dim results As Variant
   Dim results As Double
   
   ' see if this is requesting results vertically
   Dim bVerticalArray As Boolean
   bVerticalArray = IsVerticalArray()
   '
   aTempArray = GetValuesFromArray(moleFraction)
   aMolecularWeight = PureComponentConstant(ComponentList, "molecularWeight")
   ' we do not want results vertically, however if the final function
   ' wants it vertically PureComponentConstant will be fooled into believing
   ' that we wanted molecularWeight vertically, because that itself is a public
   ' function. So we need to revert back to horizontal arrays if PureComponentConstant
   ' returns it vertically
   ' a bit of a waste by double transpose, guess does not hurt much though
   If bVerticalArray = True Then
       aMolecularWeight = Application.WorksheetFunction.Transpose(aMolecularWeight)
       ReDim Preserve aMolecularWeight(LBound(aTempArray) To UBound(aTempArray))
   End If
   '
   On Error GoTo ERR_VBA_CALLER
   results = 0
   If GetNumColumnsInArray(ComponentList) = GetNumColumnsInArray(moleFraction) Then
    If CheckFractionSum(aTempArray) = True Then
        For i = LBound(aTempArray) To UBound(aTempArray)
            results = results + CDbl(aTempArray(i)) * CDbl(aMolecularWeight(i))
        Next
    End If
   End If
   AverageMolecularWeight = results
   Exit Function

ERR_VBA_CALLER:
    For i = LBound(aTempArray) To UBound(aTempArray)
        results = results + CDbl(aTempArray(i)) * CDbl(aMolecularWeight(i))
    Next
    AverageMolecularWeight = results
   
End Function
' Function Implemented By Nilesh Patel
Private Function GetValuesFromArray(arr As Variant) As Variant
    Dim theRange As Variant
    Dim nRows As Integer
    Dim nCols As Integer
    Dim index As Integer
    
    Dim i As Integer
    Dim j As Integer
    Dim theValue As Variant
  
    If TypeName(arr) = "Range" Then
        Set theRange = arr
        nRows = theRange.Rows.count
        nCols = theRange.Columns.count
        index = 0
  '     GetValueIndex = 0
        ReDim theValue(0 To nRows * nCols - 1)
        For i = 1 To nRows
           For j = 1 To nCols
              theValue(index) = theRange.Cells(i, j).value
              ' theValue(GetValueIndex) = theRange.Cells(i, j).Value
              ' GetValueIndex = GetValueIndex + 1
              index = index + 1
          Next j
        Next i
    ElseIf VarType(arr) < 8129 Then
  '     test2 = Array(cverr(xlerrvalue, xlerrvalue))
        Exit Function
    Else
        Dim imax As Integer
        Dim imin As Integer
        imin = LBound(arr, 1)
        imax = UBound(arr, 1)
        ReDim theValue(0 To (imax - imin))

        'For i = imin To imax
        '    theValue(i) = arr(i)
        'Next i
        For i = 0 To UBound(theValue)
            theValue(i) = arr(i + imin)
        Next i
        
'        Dim imax As Integer
'        Dim imin As Integer
'        Dim jmax As Integer
'        Dim jmin As Integer
'        imin = LBound(arr, 1)
'        imax = UBound(arr, 1)
'     '  ReDim theValue(imin To imax)
'       jmin = LBound(arr, 2)
'
'        jmax = UBound(arr, 2)
'       ReDim theValue(0 To (imax - imin) * (jmax - jmin) - 1)
'       index = 0
'        For i = imin To imax
'           For j = jmin To jmax
'              theValue(i) = arr(i)
'            Next j
'        Next i

    End If
    
    GetValuesFromArray = theValue
End Function
' Ping Li : 08/28/2008 Because the ReDim statement cannot change the data type of
'                      an array variable or provide new initialization values
'                      for the array elements we need the following function to return
'                      data type as VT_ARRAY|VT_R8
Private Function GetDoubleValuesFromArray(arr As Variant) As Variant
    Dim theRange As Variant
    Dim nRows As Integer
    Dim nCols As Integer
    Dim index As Integer
    
    Dim i As Integer
    Dim j As Integer
    Dim theValue() As Double
    Dim theValues As Variant
  
    If TypeName(arr) = "Range" Then
        Set theRange = arr
        nRows = theRange.Rows.count
        nCols = theRange.Columns.count
        index = 0
        ReDim theValue(0 To nRows * nCols - 1)
        For i = 1 To nRows
            For j = 1 To nCols
                theValue(index) = theRange.Cells(i, j).value
                index = index + 1
            Next j
        Next i
    ElseIf VarType(arr) < 8129 Then
        Exit Function
    Else
        Dim imax As Integer
        Dim imin As Integer
        imin = LBound(arr, 1)
        imax = UBound(arr, 1)
        ReDim theValue(0 To (imax - imin))

        For i = 0 To UBound(theValue)
            theValue(i) = arr(i + imin)
        Next i
        'Dim imax As Integer
        'Dim imin As Integer
        'imin = LBound(arr, 1)
        'imax = UBound(arr, 1)
        'ReDim theValue(0 To (imax - imin))
        'For i = imin To imax
        '    theValue(i) = arr(i)
        'Next i
    End If
    theValues = theValue
    GetDoubleValuesFromArray = theValues
End Function
' Function Implemented By Nilesh Patel
Private Function GetNumRowsInArray(arr As Variant) As Variant
    Dim theRange As Variant
    Dim nRows As Integer
    Dim nCols As Integer
    Dim index As Integer
   
   
    Dim i As Integer
    Dim j As Integer
    Dim theValue As Variant
  
    If TypeName(arr) = "Range" Then
        Set theRange = arr
        GetNumRowsInArray = theRange.Columns.count
    Else
        GetNumRowsInArray = 0
    End If
End Function
' Function Implemented By Nilesh Patel
Private Function GetNumColumnsInArray(arr As Variant) As Variant
    Dim theRange As Variant
    Dim nRows As Integer
    Dim nCols As Integer
    Dim index As Integer
    Dim i As Integer
    Dim j As Integer
    Dim theValue As Variant
     index = 0
    
      If TypeName(arr) = "Range" Then
       Set theRange = arr
       nRows = theRange.Rows.count
       nCols = theRange.Columns.count
      
       ReDim theValue(0 To nRows * nCols - 1)
         For i = 1 To nRows
          For j = 1 To nCols
         
        
           theValue(index) = theRange.Cells(i, j).value
      
          index = index + 1
        Next j
    Next i
   
    ElseIf VarType(arr) < 8129 Then
  '     test2 = Array(cverr(xlerrvalue, xlerrvalue))
        Exit Function
    Else
        Dim imax As Integer
        Dim imin As Integer
        imin = LBound(arr, 1)
        imax = UBound(arr, 1)
        index = imax - imin + 1
        'BJS, 2022.06.08
        '-- ReDim theValue(0 To (imax - imin))
        '--For i = imin To imax
        '--    heValue(i) = arr(i)
        '--    index = index + 1
        '--Next i
    End If
  
  GetNumColumnsInArray = index
'    If TypeName(arr) = "Range" Then
'        Set theRange = arr
'        GetNumColumnsInArray = theRange.Columns.Count
'    Else
'        GetNumColumnsInArray = 0
'    End If
End Function
Function MixtureProperty(ComponentList As Variant, moleFraction As Variant, PropertyName As String, Temperature As String, Pressure As String, phase As String, Optional propertyMethod As Variant) As Variant
Attribute MixtureProperty.VB_Description = "Calculates mixture property, e.g., enthalpy & fugacityCoefficient. Input & results are in user specified Global Units Set. Valid Phase = V or L or S. Use Shift+Ctrl+Enter for partial property, such as fugacityCoefficient."
Attribute MixtureProperty.VB_HelpID = 285
Attribute MixtureProperty.VB_ProcData.VB_Invoke_Func = " \n20"
    Dim coMatObj As ICOMaterialObject
    Dim components As Variant
    'Dim util As Object
    Dim molefracs As Variant
    Dim bPhase As Boolean
    Dim bTypeLabel As Boolean
    
    Dim temp As Variant
    Dim count As Integer
    Dim sum
    Dim i As Integer
    Dim j As Integer
    Dim bCompFound As Boolean
    
    Dim dblTemperature As Double
    Dim dblPressure As Double
    
    Dim strConst As String
    Dim strTdependent As String
    Dim strPdependent As String
    Dim strPureProperty As String
    Dim strMixtureProperty As String
    Dim sPhase As String
    Dim sGlobalPropertyName As String ' added by jwalant for setting prop. name consistent with units.dat/propunits.dat
    Dim bChangedPropertyMethod As Boolean
    Dim strPropHasBasis As String
    
    'Call CleanComment 'Comment out for now 1/6/2016
    
    bChangedPropertyMethod = False
'
' 5/30/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    components = GetValuesFromArray(ComponentList)
    Dim tempComps As Variant
    tempComps = components
    ReDim components(UBound(components)) As String
    For i = LBound(tempComps) To UBound(tempComps)
        components(i) = CStr(tempComps(i))
    Next
    
    Dim bVerticalArray As Boolean
    ' Use this flag to transpose the results if they are requested
    ' in a vertical array
    ' Use this right at the end where the function return value is set
    bVerticalArray = IsVerticalArray()
    
    On Error GoTo trap
    errmsg = ""
    If IsPropertyPackageAvailable() = False Then Exit Function
    
    PropertyName = getCaseSensitivePropertyName(PropertyName)

    Dim baseProp As String
    Dim derProp As String
    baseProp = PropertyName
    Dim pos As Long
    pos = InStr(1, PropertyName, ".", vbTextCompare)
    If (pos <> 0) Then
      If ((pos - 1) > 0) Then
        baseProp = Left(PropertyName, pos - 1)
        derProp = Right(PropertyName, Len(PropertyName) - pos)
      End If
    End If
    
'    On Error GoTo trap
'
'    errmsg = ""
'    If IsPropertyPackageAvailable() = False Then Exit Function
    
    Set coMatObj = g_MaterialObject
    Call GetGlobalUnitArray
    
'    PropertyName = getCaseSensitivePropertyName(PropertyName)
    If IsValidProperty(PropertyName, strConst, strTdependent, strPdependent, strPureProperty, strMixtureProperty, strPropHasBasis) = False _
        Or Trim(PropertyName) = "" Or Trim(strMixtureProperty) = "0" Then
        'MsgBox "The specified property name " & "'" & PropertyName & "' is not a mixture property."
        'Exit Function
        'errmsg = "The specified property name " & "'" & PropertyName & "' is not a mixture property."  'Comment out for now 1/6/2016
        GoTo trap
    End If

    If IsMissing(propertyMethod) Then
        propertyMethod = ""
    End If
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If Temperature = "" Then
        If g_Tref = "" Then
           Call InitializeGlobalVariables
        End If
        Temperature = g_Tref
    End If
    
    If Pressure = "" Then
        If g_Pref = "" Then
           Call InitializeGlobalVariables
        End If
        Pressure = g_Pref
    End If

'    If Not IsArray(MoleFraction) Then
'        errMsg = "The specified MoleFraction is not a valid value."
'        GoTo trap
'    End If
    
'   temp = GetValuesFromArray(MoleFraction)
    temp = GetDoubleValuesFromArray(moleFraction)
    For i = LBound(temp) To UBound(temp)
       ' If Not IsNumeric(Val(Temp(i))) Then
        If Not IsNumeric(CDbl(temp(i))) Then
            errmsg = "The specified MoleFraction is not a valid value."
            GoTo trap
        End If
    Next i
        
    errmsg = ""
    errmsg = "The specified Temperature is not a valid value."
    '' Following code added by Jwalant Vyas on 04/11/2002
    resultCalc = SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", Temperature, "Set")
    dblTemperature = CDbl(resultCalc)
    'Version 11.1 dblTemperature = CDbl(Temperature) 'Val(Temperature) 'CDbl - Old Code
    errmsg = "The specified Pressure is not a valid value."
    resultCalc = SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", Pressure, "Set")
    dblPressure = CDbl(resultCalc)
    'Version 11.1 dblPressure = CDbl(Pressure) 'Val(Pressure) 'CDbl
    errmsg = ""
    
    If IsNumeric(phase) Then
        errmsg = "The specified Phase is not a valid value."
        GoTo trap
    End If
    
    phase = UCase(Trim(CStr(phase)))
    If IsValidPhase(PropertyName, phase, sPhase) = False Then
        MsgBox "'" & phase & "' is not valid phase for '" & PropertyName & "' Property"
        Exit Function
    Else
        phase = sPhase
    End If
    
    count = 0
    sum = 0
    For i = LBound(temp) To UBound(temp)
'        Values(count) = Temp(i) ' + valIndx
        sum = sum + CDbl(temp(i))    'sum = sum + Val(Temp(i))  Nilesh
        count = count + 1
    Next

    If sum = 0 Then
        For i = LBound(temp) To UBound(temp)
            sum = sum + temp(i)
            count = count + 1
        Next
    End If
    
    If sum = 0 Then
'
' 08/22/2010, Yuhua Song
' CQ00247628: Normalize molefractions instead of complaining sum isn't equal to 1
'
        GoTo trap
        'Exit Function
    End If
'
    If Format(sum, "0.0000000000000#") <> Format(1, "0.0000000000000#") Then
'
' 08/22/2010, Yuhua Song
' CQ00247628: Normalize molefractions instead of complaining sum isn't equal to 1
'
        GoTo trap
        'Exit Function
    End If
    
    For i = LBound(components) To UBound(components)
        bCompFound = False
        For j = LBound(compids) To UBound(compids)
            If Trim(components(i)) = Trim(compids(j)) Then
                bCompFound = True
                Exit For
            End If
        Next
    Next
    
    If bCompFound = False Then
        For i = LBound(components) To UBound(components)
            bCompFound = False
            For j = LBound(compids) To UBound(compids)
                If Trim(components(i)) = Trim(compids(j)) Then
                    bCompFound = True
                    Exit For
                End If
            Next
            If bCompFound = False Then
                errmsg = "The specified component '" & components(i) & "' in ComponentList is not valid."
                GoTo trap
            End If
        Next
    End If
    
    ' pH requires that H+ or H3O+ be specified
    If PropertyName = "pH" Then
        If HasPhComponents() = False Then
            errmsg = "H+ or H3O+ must be specified for pH calculations"
            GoTo trap
        End If
    End If
  
    coMatObj.SetComponentIds (components)
  
    Dim values As Variant
    Dim realVal(1) As Double
    values = realVal
    values(0) = dblTemperature
    Call g_MaterialObject.SetProp("temperature", "Overall", components, "Mixture", Empty, values)
    values(0) = dblPressure
    Call g_MaterialObject.SetProp("pressure", "Overall", components, "Mixture", Empty, values)
  
 '  molefracs = GetValuesFromArray(MoleFraction)
    molefracs = GetDoubleValuesFromArray(moleFraction)
    
    For i = LBound(molefracs) To UBound(molefracs)  'Nilesh
        molefracs(i) = CDbl(molefracs(i))           'Nilesh
    Next i                                          'Nilesh
    
'    If (Phase = "L") Then
 '       strMolFrac(0) = "Liquidcomposition"
 '   Else
 '       strMolFrac(0) = "Vaporcomposition"
 '   End If
 '   Call mobj.SetIndependentVar(strMolFrac, molefracs)
    Call g_MaterialObject.SetProp("fraction", phase, components, "Mixture", "Mole", molefracs)

    Dim propNames As Variant
    Dim phases As Variant
    ReDim propNames(0) As String
    ReDim phases(0) As String
    propNames(0) = PropertyName
    '
    ' if propertymethod is not default then set it
    If propertyMethod <> "" Then
        bChangedPropertyMethod = SetPropertyMethodOrSet(propertyMethod)
    End If
    '
    phases(0) = phase
    
    '8/21/06 Ping Li: For massDensity caluclation, get mole density first
    Dim MassDen As Boolean
    MassDen = False
    If (propNames(0) = "massDensity") Then
        MassDen = True
        PropertyName = "density"
        propNames(0) = PropertyName
        strPropHasBasis = "1"
    End If
    
    '6/12/2008 Suphat: for surfacetension, phase must be VaporLiquid
    Dim SurfTen As Boolean
    Dim PhaseVL As String
    SurfTen = False

    Dim PhasesToSet As Variant
    ReDim PhasesToSet(1) As String

    If (propNames(0) = "surfaceTension") Then
        SurfTen = True
        phases(0) = "VaporLiquid"
        PhaseVL = "VaporLiquid"
        PhasesToSet(0) = "Vapor"
        PhasesToSet(1) = "Liquid"
        coMatObj.SetPhases (PhasesToSet)
    Else
      'Ping Li : 08/28/2008 -- Before call CalcProp we should set phase first
        '                        because CalcProp will checking exist phase.
      coMatObj.SetPhases (phases)
    End If
    
    'Ping Li : 11/08/2008 -- Use name diffusionCoefficient2 instead of diffusionCoefficient
    Dim DiffusionCoefficient As Boolean
    Dim DiffusionCoefficient2 As Variant
    ReDim DiffusionCoefficient2(0) As String
    Dim DiffusionCoeff2 As String
    DiffusionCoefficient = False

    If (propNames(0) = "diffusionCoefficient") Then
        DiffusionCoefficient = True
        DiffusionCoefficient2(0) = "diffusionCoefficient2"
        DiffusionCoeff2 = "diffusionCoefficient2"
        Call g_COPackage.CalcProp(g_MaterialObject, DiffusionCoefficient2, phases, "Mixture")
    Else
        Call g_COPackage.CalcProp(g_MaterialObject, propNames, phases, "Mixture")
    End If

    Dim Value1 As Variant
    '
    If (SurfTen) Then
       If Trim(strPropHasBasis) = "1" Then ' specify mole basis
           Value1 = g_MaterialObject.GetProp(PropertyName, PhaseVL, components, "Mixture", "Mole")
       Else
           Value1 = g_MaterialObject.GetProp(PropertyName, PhaseVL, components, "Mixture", Empty)
       End If
    ElseIf (DiffusionCoefficient) Then
       If Trim(strPropHasBasis) = "1" Then ' specify mole basis
           Value1 = g_MaterialObject.GetProp(DiffusionCoeff2, phase, components, "Mixture", "Mole")
       Else
           Value1 = g_MaterialObject.GetProp(DiffusionCoeff2, phase, components, "Mixture", Empty)
       End If
    Else
       If Trim(strPropHasBasis) = "1" Then ' specify mole basis
           Value1 = g_MaterialObject.GetProp(PropertyName, phase, components, "Mixture", "Mole")
       Else
           Value1 = g_MaterialObject.GetProp(PropertyName, phase, components, "Mixture", Empty)
       End If
    End If
    
    
    '8/21/06 Ping Li: If MassDen = true
    ' Change the propNames back to massDensity for the unit and value processing
    If (MassDen = True) Then
        PropertyName = "massDensity"
        propNames(0) = PropertyName
        strPropHasBasis = "0"
    End If

    ' Code added by Jwalant (Entire for loop implementation is for getting result value back in user specified units
    ' from SI unit system)
     For i = LBound(arrPropUnit, 1) To UBound(arrPropUnit, 1)
       If arrPropUnit(i, 0) = PropertyName Then
            strGPropName = arrPropUnit(i, 1)
        If strGPropName <> "Dimensionless" Then
           For intResultCounter = LBound(Value1) To UBound(Value1)
           Value1(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), strGPropName, CStr(Value1(intResultCounter)), "Get")
           Next intResultCounter
           
        End If
        Exit For
       End If
     Next i
    'sUnitsType = arrPropUnit(i, 1)
    bNoteText = True
    bTypeLabel = GetUnitsTypeLabel(PropertyName, strUnitsType, strUnitsLabel)
    If bTypeLabel = True Then
        strRangeUnitsApply = GetCurrentCallerRange
    End If
    
    coMatObj.Clean
    Set coMatObj = Nothing
    ' reset property method to global method
    If bChangedPropertyMethod = True Then
        Call RestoreOriginalProperty
    End If
    '
'    Dim bVerticalArray As Boolean
'    bVerticalArray = IsVerticalArray()
    If bVerticalArray = True Then
        MixtureProperty = Application.WorksheetFunction.Transpose(Value1)
    Else
        MixtureProperty = Value1
    End If
    ' For enthalpy, Gibb's energy, entropy, heat capacity, molar volume
    ' Cape Open values need to be multiplied by 1000
    ' Abhijit & Suphat Dec 28, 2000
'    Dim baseProp As String
'    Dim derProp As String
'    baseProp = PropertyName
'    Dim pos As Long
'    pos = InStr(1, PropertyName, ".", vbTextCompare)
'    If (pos <> 0) Then
'      If ((pos - 1) > 0) Then
'        baseProp = Left(PropertyName, pos - 1)
'        derProp = Right(PropertyName, Len(PropertyName) - pos)
'      End If
'    End If
    
    ' No need to check for vertical array out here, because all
    ' the following properties are scalars
    
    Select Case baseProp
        Case "enthalpy", "entropy", "gibbsFreeEnergy", "volume", "heatCapacity", "internalEnergy", "netHeatingValue", "grossHeatingValue", "heatCapacityCv"
                If (derProp = "Dmoles") Then
                    MixtureProperty = 1000# * 1000# * Value1(0)
                Else
                    MixtureProperty = 1000# * Value1(0)
                End If
        Case "density"
                If (derProp = "Dmoles") Then
                    MixtureProperty = Value1(0)
                Else
                    MixtureProperty = Value1(0) / 1000#
                End If
        Case "massDensity" '8/21/06 Ping Li: massDensity =  mole density* MW
            Dim averMolecularWeight As Double
            averMolecularWeight = AverageMolecularWeight(ComponentList, moleFraction)
            MixtureProperty = Value1(0) * averMolecularWeight / 1000#
    End Select
 
    Exit Function
trap:
'
' 5/30/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    Dim Value2 As Variant
    If baseProp = "fugacityCoefficient" Or baseProp = "logFugacityCoefficient" Or baseProp = "fugacity" Or baseProp = "activityCoefficient" Then
'
' vector
'
        Value2 = SetErrors(components, "Mixture")
        If bVerticalArray = True Then
            MixtureProperty = Application.WorksheetFunction.Transpose(Value2)
        Else
            MixtureProperty = Value2
        End If
    Else
'
' single
'
        MixtureProperty = SetErrors(components, Empty)
    End If
    
    'Call AddComment  'Comment out for now 1/6/2016
    
    strUnitsType = ""
    strUnitsLabel = ""
    strRangeUnitsApply = ""
    coMatObj.Clean
    Set coMatObj = Nothing
    ' reset property method to global method
    If bChangedPropertyMethod = True Then
        Call RestoreOriginalProperty
    End If
    
    If bChangeCom = True Then Exit Function
    If errmsg <> "" Then
        errmsg = ""
    End If
    breCalculation = True
End Function

'Function ComponentFugacityCoefficients(ComponentList As Variant, MoleFractions As Variant, Temperature As String, Pressure As String, Phase As String, Optional PropertyMethod As Variant) As Variant
'    Dim RESULTS As Variant
'    If IsPropertyPackageAvailable() = False Then Exit Function
'    RESULTS = MixtureProperty(ComponentList, MoleFractions, "fugacityCoefficient", Temperature, Pressure, Phase, PropertyMethod)
'    ComponentFugacityCoefficients = RESULTS
'End Function

'Function ComponentDiffusivity(ComponentList As Variant, MoleFractions As Variant, Temperature As String, Pressure As String, Phase As String, Optional PropertyMethod As Variant) As Variant
'    Dim RESULTS As Variant
'    If IsPropertyPackageAvailable() = False Then Exit Function
'    RESULTS = MixtureProperty(ComponentList, MoleFractions, "diffusivityCoefficient", Temperature, Pressure, Phase, PropertyMethod)
'    ComponentDiffusivity = RESULTS
'End Function

'Function FlashLiquidComposition(ComponentList As Variant, MoleFraction As Variant, _
'                               VaporFraction As Double, Temperature As Double, _
'                              Pressure As Double, FlashType As String) As Variant
'  If IsPropertyPackageAvailable() = False Then Exit Function
'  FlashLiquidComposition = InternalFlash(ComponentList, MoleFraction, VaporFraction, Temperature, _
'                        Pressure, FlashType, "Liquidcomposition")
'End Function
'
'Function FlashVaporComposition(ComponentList As Variant, MoleFraction As Variant, _
'                              VaporFraction As Double, Temperature As Double, _
'                              Pressure As Double, FlashType As String) As Variant
'  If IsPropertyPackageAvailable() = False Then Exit Function
'  FlashVaporComposition = InternalFlash(ComponentList, MoleFraction, VaporFraction, Temperature, _
'                        Pressure, FlashType, "Vaporcomposition")
'End Function
'
'Function FlashVaporFraction(ComponentList As Variant, MoleFraction As Variant, _
'                              VaporFraction As Double, Temperature As Double, _
'                              Pressure As Double, FlashType As String) As Variant
'  If IsPropertyPackageAvailable() = False Then Exit Function
'  FlashVaporFraction = InternalFlash(ComponentList, MoleFraction, VaporFraction, Temperature, _
'                        Pressure, FlashType, "VaporFraction")
'End Function
'
'Function FlashHeatDuty(ComponentList As Variant, MoleFraction As Variant, _
'                              VaporFraction As Double, Temperature As Double, _
'                              Pressure As Double, FlashType As String) As Variant
'  If IsPropertyPackageAvailable() = False Then Exit Function
'  FlashHeatDuty = InternalFlash(ComponentList, MoleFraction, VaporFraction, Temperature, _
'                        Pressure, FlashType, "Heatduty")
'End Function
'
'Function FlashTemperature(ComponentList As Variant, MoleFraction As Variant, _
'                              VaporFraction As Double, Temperature As Double, _
'                              Pressure As Double, FlashType As String) As Variant
'  If IsPropertyPackageAvailable() = False Then Exit Function
'  FlashTemperature = InternalFlash(ComponentList, MoleFraction, VaporFraction, Temperature, _
'                        Pressure, FlashType, "Temperature")
'End Function
'
'Function FlashPressure(ComponentList As Variant, MoleFraction As Variant, _
'                              VaporFraction As Double, Temperature As Double, _
'                              Pressure As Double, FlashType As String) As Variant
'  If IsPropertyPackageAvailable() = False Then Exit Function
'  FlashPressure = InternalFlash(ComponentList, MoleFraction, VaporFraction, Temperature, _
'                        Pressure, FlashType, "Pressure")
'End Function
' Function implemented by Nilesh Patel
'1/30/04 Fan: Add entropy and internal energy to the argument list to support PSflash and PUflash
Private Function InternalFlash(ComponentList As Variant, moleFraction As Variant, VaporFraction As String, _
      Temperature As String, Pressure As String, Enthalpy As String, Entropy As String, internalEnergy As String, _
      FlashType As String, Optional returns As Variant, Optional propertyMethod As Variant) As Variant
    Dim coMatObj As ICOMaterialObject 'ap\source\atcapeopen\atcomaterial\COMatObject.cpp
    'Dim mobj As Object
    Dim compNames As Variant
    'Dim util As Object
    'Dim mt As Object
    Dim nComps As Integer
    Dim sum As Double
    Dim bTypeLabel As Boolean
    Dim dblTemperature As Double
    Dim dblPressure As Double
    Dim dblVaporFraction As Double
    Dim dblEnthalpy As Double
    Dim dblEntropy As Double
    Dim dblInternalEnergy As Double
    Dim i As Integer
    Dim j As Integer
    Dim bCompFound As Boolean
        
    'Dim PropPkg, AspenPkg As Object
    
    Dim molefrac As Variant
    Dim bChangedPropertyMethod As Boolean
    bChangedPropertyMethod = False
'
' 5/30/2009 by Yuhua Song. CQ00126511: Indicate an error if the flash calculation is failed
' isNoError = TRUE: flash calculation is successed
'           FALSE: flash calculation is failed, call SetErrors to set error in the cells
'
    Dim isNoError As Boolean
    isNoError = True

    On Error GoTo trap
    
    errmsg = ""
    If IsMissing(propertyMethod) Then
        propertyMethod = ""
    End If
    
    Set coMatObj = g_MaterialObject
    errmsg = "The specified Temperature is not a valid value."
    Call GetGlobalUnitArray
    dblTemperature = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", Temperature, "Set"))
    ' Version 11.1 - dblTemperature = CDbl(Temperature) 'Val(Temperature) 'CDbl  Nilesh
    errmsg = "The specified Pressure is not a valid value."
    'Code added by Jwalant Vyas
    dblPressure = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", Pressure, "Set"))
    ' Version 11.1 - dblPressure = CDbl(Pressure) 'Val(Pressure) 'CDbl Nilesh
    errmsg = "The specified VaporFraction is not a valid value."
    
    dblVaporFraction = CDbl(VaporFraction) ' Val(VaporFraction) 'CDbl Nilesh
    errmsg = "The specified Enthalpy is not a valid value."
    ' Code added by Jwalant Vyas
    dblEnthalpy = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTHALPY", Enthalpy, "Set"))
    ' Version 11.1- dblEnthalpy = CDbl(Enthalpy) 'Val(Enthalpy) 'CDbl Nilesh
    '1/26/04 Fan: Add checkes for entropy and Internal Energy
    errmsg = "The specified Entropy is not a valid value."
    dblEntropy = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTROPY", Entropy, "Set"))
    errmsg = "The specified Internal Energy is not a valid value."
    dblInternalEnergy = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTHALPY", internalEnergy, "Set"))
'
    errmsg = ""

'    If Not IsArray(MoleFraction) Then
'        errMsg = "The specified MoleFraction is not a valid value."
'        GoTo trap
'    End If
    
    molefrac = GetDoubleValuesFromArray(moleFraction)
'   molefrac = GetValuesFromArray(MoleFraction)
    For i = LBound(molefrac) To UBound(molefrac)
        'If Not IsNumeric(Val(molefrac(i))) Then
        If Not IsNumeric(CDbl(molefrac(i))) Then 'Nilesh
            errmsg = "The specified MoleFraction is not a valid value."
            GoTo trap
        End If
        molefrac(i) = CDbl(molefrac(i))    'Nilesh
    Next i
    
    If dblVaporFraction < 0 Or dblVaporFraction > 1 Then
        errmsg = "VaporFraction must be between 0 and 1, please try again."
        GoTo trap
    End If
    
    compNames = GetValuesFromArray(ComponentList)
    Dim tempComps As Variant
    tempComps = compNames
    ReDim compNames(UBound(compNames)) As String
    For i = LBound(tempComps) To UBound(tempComps)
        compNames(i) = CStr(tempComps(i))
    Next
    
    For i = LBound(compNames) To UBound(compNames)
        bCompFound = False
        For j = LBound(compids) To UBound(compids)
            If Trim(compNames(i)) = Trim(compids(j)) Then
                bCompFound = True
                Exit For
            End If
        Next
    Next
    
    If bCompFound = False Then
        For i = LBound(compNames) To UBound(compNames)
            bCompFound = False
            For j = LBound(compids) To UBound(compids)
                If Trim(compNames(i)) = Trim(compids(j)) Then
                    bCompFound = True
                    Exit For
                End If
            Next
            If bCompFound = False Then
                errmsg = "The specified component '" & compNames(i) & "' in ComponentList is not valid."
                GoTo trap
            End If
        Next
    End If
    
    ' Call ap\source\atcapeopen\atcomaterial\COMatObject.cpp\STDMETHODIMP CCOMaterialObject::SetComponentIds
    coMatObj.SetComponentIds (compNames)
    nComps = UBound(compNames) - LBound(compNames) + 1
  
    Dim value As Variant
    Dim realVal(0) As Double
    value = realVal
  
    FlashType = UCase(FlashType)
    If FlashType = "TV" Then FlashType = "TVF"
    If FlashType = "PV" Then FlashType = "PVF"
    
    If FlashType = "TLF" Or FlashType = "TVF" Or FlashType = "TP" Or FlashType = "TH" Then '"TVF"
        value(0) = dblTemperature
        Call g_MaterialObject.SetProp("temperature", "Overall", compNames, "Mixture", Empty, value)
    End If
    If FlashType = "PLF" Or FlashType = "PVF" Or FlashType = "TP" Or FlashType = "PH" Or FlashType = "PS" Or FlashType = "PU" Then '"PVF"
        value(0) = dblPressure
        Call g_MaterialObject.SetProp("pressure", "Overall", compNames, "Mixture", Empty, value)
    End If
    If FlashType = "PLF" Or FlashType = "PVF" Or FlashType = "TLF" Or FlashType = "TVF" Then '"TVF" "PVF"
        value(0) = dblVaporFraction
        Call g_MaterialObject.SetProp("PhaseFraction", "V", compNames, "Mixture", "Mole", value)
    End If
  
    Dim temp As Variant
    Dim values As Variant
'   temp = GetValuesFromArray(MoleFraction)
    temp = GetDoubleValuesFromArray(moleFraction)
    ReDim values(nComps) As Double
    Dim count As Integer
    count = 0
    sum = 0
    For i = LBound(temp) To UBound(temp)
        values(count) = CDbl(temp(i))   'Temp(i)  Nilesh
        sum = sum + CDbl(temp(i))       ' sum = sum + Val(Temp(i)) Nilesh
        count = count + 1
    Next
    
    If sum = 0 Then
        For i = LBound(temp) To UBound(temp)
            sum = sum + temp(i)
            count = count + 1
        Next
    End If
    
    If sum = 0 Then Exit Function
    If Format(sum, "0.0000000000000#") <> Format(1, "0.0000000000000#") Then
        strUnitsType = ""
        strUnitsLabel = ""
        strRangeUnitsApply = ""
        GoTo trap
        'Exit Function
    End If
    
    Call g_MaterialObject.SetProp("fraction", "L", compNames, "Mixture", "Mole", temp)
    
'   temp = GetValuesFromArray(MoleFraction)
    temp = GetDoubleValuesFromArray(moleFraction)
    count = 0
    sum = 0
    For i = LBound(temp) To UBound(temp)
        values(count) = CDbl(temp(i))   'Temp(i)   Nilesh
        sum = sum + CDbl(temp(i))    'sum = sum + Val(Temp(i)) Nilesh
        count = count + 1
    Next
    
    If sum = 0 Then
        For i = LBound(temp) To UBound(temp)
            sum = sum + temp(i)
            count = count + 1
        Next
    End If
    
    If sum = 0 Then Exit Function
    If Format(sum, "0.0000000000000#") <> Format(1, "0.0000000000000#") Then
        strUnitsType = ""
        strUnitsLabel = ""
        strRangeUnitsApply = ""
        GoTo trap
        'Exit Function
    End If
    Call g_MaterialObject.SetProp("fraction", "V", compNames, "Mixture", "Mole", temp)
 
    Call g_MaterialObject.SetProp("molFraction", "Overall", compNames, "Mixture", "Mole", molefrac)
'   Call mobj.SetProp("molFraction", "Overall", ComponentList, "Mixture", "Mole", MoleFraction)
    ' Set Overall (Feed) Enthalpy
    
    If FlashType = "TH" Or FlashType = "PH" Then
        Dim Enth As Variant
        Dim realEnth(0) As Double
        Enth = realEnth
        ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole  (Excel input is in j/kmole)
        Enth(0) = dblEnthalpy / 1000# 'Enthalpy
        Call g_MaterialObject.SetProp("enthalpy", "Overall", compNames, "Mixture", "Mole", Enth)
    End If
    
    ' 1/26/04 Fan: Add PS and PU flashes
    If FlashType = "PS" Then
        Dim Entro As Variant
        Dim realEntro(0) As Double
        Entro = realEntro
        Entro(0) = dblEntropy / 1000# 'Entropy
        Call g_MaterialObject.SetProp("entropy", "Overall", compNames, "Mixture", "Mole", Entro)
    End If
    
    If FlashType = "PU" Then
        Dim InternalE As Variant
        Dim realInternalE(0) As Double
        InternalE = realInternalE
        InternalE(0) = dblInternalEnergy / 1000# 'Internal energy
        Call g_MaterialObject.SetProp("internalEnergy", "Overall", compNames, "Mixture", "Mole", InternalE)
    End If
    
    ' Suphat/Abhijit Dec 28, 2000 try setProp for vaporFraction
    If FlashType = "PLF" Or FlashType = "PVF" Or FlashType = "TLF" Or FlashType = "TVF" Then '"TVF" "PVF"
        Dim vfrac As Variant
        Dim realVfrac(0) As Double
        vfrac = realVfrac
        ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole  (Excel input is in j/kmole)
        vfrac(0) = dblVaporFraction
        Call g_MaterialObject.SetProp("PhaseFraction", "V", compNames, "Mixture", "Mole", vfrac)
    End If
    '
    ' if propertymethod is not default then set it
    If propertyMethod <> "" Then
        bChangedPropertyMethod = SetPropertyMethodOrSet(propertyMethod)
    End If
    '
    ' Call ap\source\atcapeopen\atcoproperties\COPropPack.cpp\STDMETHODIMP CCOPropertyPackage::CalcEquilibrium
    Call g_COPackage.CalcEquilibrium(g_MaterialObject, FlashType, Empty)
    GoTo display:
''
'' 4/21/2009 by Yuhua Song. CQ00126511: Indicate an error if the flash calculation is failed
'' isNoError = TRUE: flash calculation is successed
''           FALSE: flash calculation is failed, call SetErrors to set error in the cells
''
'    Dim isNoError As Boolean
''    isNoError = True
'    isNoError = g_COPackage.PropCheck(g_MaterialObject, Empty)
''
trap:
    isNoError = False
'
display:
    Dim Values2 As Variant

'   IndVars2(0) = "Temperature"
'   IndVars2(1) = "Pressure"
'   IndVars2(2) = "Liquidcomposition"
'   IndVars2(3) = "Vaporcomposition"
'   IndVars2(4) = "VaporFraction"
    Dim indvar As Variant
    ReDim indvar(0) As String
    
    strUnitsType = ""
    strUnitsLabel = ""
    strRangeUnitsApply = ""
    
    Select Case returns
        Case "Pressure", "P", "p", "pressure"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("pressure", "Overall", compNames, "Mixture", Empty)
              '' Code Added by Jwalant - For getting results back in user specified units system
              For intResultCounter = LBound(Values2) To UBound(Values2)
                  Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", CStr(Values2(intResultCounter)), "Get")
              Next intResultCounter
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
'           Values2 = g_MaterialObject.GetProp("pressure", "Overall", compNames, "Mixture", Empty)
'            '' Code Added by Jwalant - For getting results back in user specified units system
'            For intResultCounter = LBound(Values2) To UBound(Values2)
'                Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", CStr(Values2(intResultCounter)), "Get")
'            Next intResultCounter
            '' Code Added by Jwalant
            
            strUnitsType = "PRESSURE"
            strUnitsLabel = SetGetLabel("PRESSURE")
            strRangeUnitsApply = GetCurrentCallerRange
        Case "Temperature", "T", "temperature", "t"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("temperature", "Overall", compNames, "Mixture", Empty)
              '' Code Added by Jwalant - For getting results back in user specified units system
              For intResultCounter = LBound(Values2) To UBound(Values2)
                  Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", CStr(Values2(intResultCounter)), "Get")
              Next intResultCounter
            Else
              Values2 = SetErrors(compNames, Empty)
'
' for test: 4/21/2009 by Yuhua Song. CQ00126511
'            Dim Values3() As Variant
'            Dim CompList2() As Variant
'            ReDim CompList2(0 To 1) As Variant
'            CompList2(0) = "Water"
'            CompList2(1) = "Ethanol"
'            Values3 = SetErrors3(CompList2, Empty)
            End If
            
'            Values2 = g_MaterialObject.GetProp("temperature", "Overall", compNames, "Mixture", Empty)
'            '' Code Added by Jwalant - For getting results back in user specified units system
'            For intResultCounter = LBound(Values2) To UBound(Values2)
'                Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", CStr(Values2(intResultCounter)), "Get")
'            Next intResultCounter
            '' Code Added by Jwalant
            
            strUnitsType = "TEMPERATURE"
            strUnitsLabel = SetGetLabel("TEMPERATURE")
            strRangeUnitsApply = GetCurrentCallerRange
        Case "x", "X", "LiquidMoleFraction", "Liquidmolefraction", "liquidmolefraction"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("fraction", "Liquid", compNames, "Mixture", "Mole")
            Else
              Values2 = SetErrors(compNames, "Mole")
            End If
            
'            Values2 = g_MaterialObject.GetProp("fraction", "Liquid", compNames, "Mixture", "Mole")

            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "y", "Y", "VaporMoleFraction", "vapormolefraction", "Vapormolefraction"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("fraction", "Vapor", compNames, "Mixture", "Mole")
            Else
              Values2 = SetErrors(compNames, "Mole")
            End If
            
'            Values2 = g_MaterialObject.GetProp("fraction", "Vapor", compNames, "Mixture", "Mole")

            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "h", "H", "Enthalpy", "enthalpy"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("enthalpy", "Overall", compNames, "Mixture", "Mole")
              '' Code Added by Jwalant - For getting results back in user specified units system
              For intResultCounter = LBound(Values2) To UBound(Values2)
                  Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTHALPY", CStr(Values2(intResultCounter)), "Get")
              Next intResultCounter
              ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole  (Excel input is in j/kmole)
              Dim Thousand As Double
              Thousand = 1000#
              Values2(0) = Values2(0) * Thousand
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
'            Values2 = g_MaterialObject.GetProp("enthalpy", "Overall", compNames, "Mixture", "Mole")
'              '' Code Added by Jwalant - For getting results back in user specified units system
'            For intResultCounter = LBound(Values2) To UBound(Values2)
'                Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTHALPY", CStr(Values2(intResultCounter)), "Get")
'            Next intResultCounter
'            ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole  (Excel input is in j/kmole)
'            Dim Thousand As Double
'            Thousand = 1000#
'            Values2(0) = Values2(0) * Thousand

            strUnitsType = "MOLE-ENTHALPY"
            ' Code added by Jwalant
            strUnitsLabel = SetGetLabel("MOLE-ENTHALPY")
            strRangeUnitsApply = GetCurrentCallerRange
        Case "v", "VaporFraction", "V", "Vaporfraction", "vaporfraction"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("PhaseFraction", "V", compNames, "Mixture", "Mole")
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
          ' Abhijit and Suphat Dec 28, 2000. Use getProp
            'Values2 = mobj.GetIndependentVar(indvar)
'            Values2 = g_MaterialObject.GetProp("PhaseFraction", "V", compNames, "Mixture", "Mole")

            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "SFRAC", "SolidFraction", "sfrac", "Solidfraction", "solidfraction"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("PhaseFraction", "Solid", compNames, "Mixture", "Mole")
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
'            Values2 = g_MaterialObject.GetProp("PhaseFraction", "Solid", compNames, "Mixture", "Mole")

            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
    End Select
    '
    coMatObj.Clean
    Set coMatObj = Nothing
    ' reset property method to global method
    If bChangedPropertyMethod = True Then
        Call RestoreOriginalProperty
    End If
    
    bNoteText = True
    Dim bVerticalArray As Boolean
    bVerticalArray = IsVerticalArray()
    If bVerticalArray = True Then
        InternalFlash = Application.WorksheetFunction.Transpose(Values2)
    Else
        InternalFlash = Values2
    End If
'
    If isNoError = True Then
        breCalculation = True
    Else
        If bChangeCom = True Then Exit Function
        If errmsg <> "" Then
            errmsg = ""
        End If
    End If
End Function

Function TVFlash(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                VaporFraction As String, Optional returns As Variant, Optional propertyMethod As Variant) As Variant
Attribute TVFlash.VB_Description = "Calculates phase equilibrium at specified temperature and molar vapor fraction. Returns=P,H,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
Attribute TVFlash.VB_HelpID = 293
Attribute TVFlash.VB_ProcData.VB_Invoke_Func = " \n20"
                
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Pressure"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Pref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash(ComponentList, moleFraction, VaporFraction, Temperature, g_Pref, "0", "0", "0", "TVF", returns, propertyMethod) '"TVF"
    TVFlash = result
End Function

Function PVFlash(ComponentList As Variant, moleFraction As Variant, Pressure As String, _
                VaporFraction As String, Optional returns As Variant, Optional propertyMethod As Variant)
Attribute PVFlash.VB_Description = "Calculates phase equilibrium at specified pressure and molar vapor fraction. Returns=T,H,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
Attribute PVFlash.VB_HelpID = 291
Attribute PVFlash.VB_ProcData.VB_Invoke_Func = " \n20"
    
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Temperature"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash(ComponentList, moleFraction, VaporFraction, g_Tref, Pressure, "0", "0", "0", "PVF", returns, propertyMethod) '"PVF"
    PVFlash = result
'
'    Dim bError As Boolean
'    result = InternalFlash(ComponentList, MoleFraction, VaporFraction, "0", Pressure, "0", "0", "0", "PVF", Returns, PropertyMethod, bError) '"PVF"
'    If bError = True Then
'      PVFlash = result
'    Else
'      PVFlash = "<ERROR>"
'    End If
End Function

Function TPFlash(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                Pressure As String, Optional returns As Variant, Optional propertyMethod As Variant)
Attribute TPFlash.VB_Description = "Calculates phase equilibrium at specified temperature and pressure. Returns=V,H,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
Attribute TPFlash.VB_HelpID = 295
Attribute TPFlash.VB_ProcData.VB_Invoke_Func = " \n20"
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "VaporFraction"
    End If
    
    result = InternalFlash(ComponentList, moleFraction, "0", Temperature, Pressure, "0", "0", "0", "TP", returns, propertyMethod)
    TPFlash = result
End Function

Function THFlash(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                Enthalpy As String, Optional returns As Variant, Optional propertyMethod As Variant)
Attribute THFlash.VB_Description = "Calculates phase equilibrium at specified temperature and molar enthalpy. Returns=P,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
Attribute THFlash.VB_HelpID = 314
Attribute THFlash.VB_ProcData.VB_Invoke_Func = " \n20"
                
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Pressure"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Pref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash(ComponentList, moleFraction, "0", Temperature, g_Pref, Enthalpy, "0", "0", "TH", returns, propertyMethod)
    THFlash = result
End Function

Function PHFlash(ComponentList As Variant, moleFraction As Variant, Pressure As String, _
                Enthalpy As String, Optional returns As Variant, Optional propertyMethod As Variant)
Attribute PHFlash.VB_Description = "Calculates phase equilibrium at specified pressure and molar enthalpy. Returns=T,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
Attribute PHFlash.VB_HelpID = 313
Attribute PHFlash.VB_ProcData.VB_Invoke_Func = " \n20"
                          
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Temperature"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash(ComponentList, moleFraction, "0", g_Tref, Pressure, Enthalpy, "0", "0", "PH", returns, propertyMethod)
    PHFlash = result
End Function
'1/30/04 Fan: added PSflash
Function PSFlash(ComponentList As Variant, moleFraction As Variant, Pressure As String, _
                Entropy As String, Optional returns As Variant, Optional propertyMethod As Variant)
Attribute PSFlash.VB_Description = "Calculates phase equilibrium at specified pressure and molar entropy. Returns=T,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
Attribute PSFlash.VB_HelpID = 12
Attribute PSFlash.VB_ProcData.VB_Invoke_Func = " \n20"
                            
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Temperature"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash(ComponentList, moleFraction, "0", g_Tref, Pressure, "0", Entropy, "0", "PS", returns, propertyMethod)
    PSFlash = result
End Function
'1/30/04 Fan: added PUflash
Function PUFlash(ComponentList As Variant, moleFraction As Variant, Pressure As String, _
                internalEnergy As String, Optional returns As Variant, Optional propertyMethod As Variant)
Attribute PUFlash.VB_Description = "Calculates phase equilibrium at specified pressure and molar internal energy. Returns=T,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
Attribute PUFlash.VB_HelpID = 13
Attribute PUFlash.VB_ProcData.VB_Invoke_Func = " \n20"
                
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Temperature"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash(ComponentList, moleFraction, "0", g_Tref, Pressure, "0", "0", internalEnergy, "PU", returns, propertyMethod)
    PUFlash = result
End Function

Private Function InternalFlash3(ComponentList As Variant, moleFraction As Variant, VaporFraction As String, _
      Temperature As String, Pressure As String, Enthalpy As String, FlashType As String, Optional returns As Variant, _
      Optional keyComponent As String, Optional propertyMethod As Variant) As Variant
      
    Dim coMatObj As ICOMaterialObject
    'Dim mobj As Object
    Dim compNames As Variant
    'Dim util As Object
    'Dim mt As Object
    Dim nComps As Integer
    Dim sum As Double
    Dim bTypeLabel As Boolean
    Dim dblTemperature As Double
    Dim dblPressure As Double
    Dim dblVaporFraction As Double
    Dim dblEnthalpy As Double
    Dim i As Integer
    Dim j As Integer
    Dim bCompFound As Boolean
        
    'Dim PropPkg, AspenPkg As Object
    Dim molefrac As Variant
    Dim bChangedPropertyMethod As Boolean
    bChangedPropertyMethod = False
'
' 5/30/2009 by Yuhua Song. CQ00126511: Indicate an error if the flash calculation is failed
' isNoError = TRUE: flash calculation is successed
'           FALSE: flash calculation is failed, call SetErrors to set error in the cells
'
    Dim isNoError As Boolean
    isNoError = True
    
    On Error GoTo trap
    
    errmsg = ""
    If IsMissing(keyComponent) Then
        keyComponent = ""
    Else
        keyComponent = UCase(Trim(CStr(keyComponent)))
    End If
    
    If IsMissing(propertyMethod) Then
        propertyMethod = ""
    End If
    
    Set coMatObj = g_MaterialObject
    errmsg = "The specified Temperature is not a valid value."
    Call GetGlobalUnitArray
    ' Code added by Jwalant
    dblTemperature = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", Temperature, "Set"))
    'Version: 11.1 dblTemperature = CDbl(Temperature)   'Val(Temperature) 'CDbl Nilesh
    errmsg = "The specified Pressure is not a valid value."
    ' Code added by Jwalant
    dblPressure = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", Pressure, "Set"))
    'Version: 11.1dblPressure = CDbl(Pressure) 'Val(Pressure) 'CDbl Nilesh
    errmsg = "The specified VaporFraction is not a valid value."
    dblVaporFraction = CDbl(VaporFraction)   'Val(VaporFraction) 'CDbl Nilesh
    errmsg = "The specified Enthalpy is not a valid value."
    'Version 11.1 dblEnthalpy = CDbl(Enthalpy)
    dblEnthalpy = CDbl(SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTHALPY", Enthalpy, "Set"))
    ' Old Code dblEnthalpy = CDbl(Enthalpy) 'Val(Enthalpy) 'CDbl Nilesh
    errmsg = ""
    
'    If Not IsArray(MoleFraction) Then
'        errMsg = "The specified MoleFraction is not a valid value."
'        GoTo trap
'    End If
    
'   molefrac = GetValuesFromArray(MoleFraction)
    molefrac = GetDoubleValuesFromArray(moleFraction)
    For i = LBound(molefrac) To UBound(molefrac)
       ' If Not IsNumeric(Val(molefrac(i))) Then
        If Not IsNumeric(CDbl(molefrac(i))) Then   'Nilesh
            errmsg = "The specified MoleFraction is not a valid value."
            GoTo trap
        End If
    Next i
    
    If dblVaporFraction < 0 Or dblVaporFraction > 1 Then
        errmsg = "VaporFraction must be between 0 and 1, please try again."
        GoTo trap
    End If
    
    compNames = GetValuesFromArray(ComponentList)
    Dim tempComps As Variant
    tempComps = compNames
    ReDim compNames(UBound(compNames)) As String
    For i = LBound(tempComps) To UBound(tempComps)
        compNames(i) = CStr(tempComps(i))
    Next

    For i = LBound(compNames) To UBound(compNames)
        bCompFound = False
        For j = LBound(compids) To UBound(compids)
            If Trim(compNames(i)) = Trim(compids(j)) Then
                bCompFound = True
                Exit For
            End If
        Next
    Next
    
    If bCompFound = False Then
        For i = LBound(compNames) To UBound(compNames)
            bCompFound = False
            For j = LBound(compids) To UBound(compids)
                If Trim(compNames(i)) = Trim(compids(j)) Then
                    bCompFound = True
                    Exit For
                End If
            Next
            If bCompFound = False Then
                errmsg = "The specified component '" & compNames(i) & "' in ComponentList is not valid."
                GoTo trap
            End If
        Next
    End If
    
    coMatObj.SetComponentIds (compNames)
    nComps = UBound(compNames) - LBound(compNames) + 1
  
    Dim value As Variant
    Dim realVal(0) As Double
    value = realVal
    
    FlashType = UCase(FlashType)
    If FlashType = "TV3" Then FlashType = "TVF3"
    If FlashType = "PV3" Then FlashType = "PVF3"
    
    If FlashType = "TLF3" Or FlashType = "TVF3" Or FlashType = "TP3" Or FlashType = "TH3" Or _
        FlashType = "TPLL" Or FlashType = "THLL" Then
        value(0) = dblTemperature
        Call g_MaterialObject.SetProp("temperature", "Overall", compNames, "Mixture", Empty, value)
     End If
    If FlashType = "PLF3" Or FlashType = "PVF3" Or FlashType = "TP3" Or FlashType = "PH3" Or _
        FlashType = "TPLL" Or FlashType = "PHLL" Then
        value(0) = dblPressure
        Call g_MaterialObject.SetProp("pressure", "Overall", compNames, "Mixture", Empty, value)
    End If
    If FlashType = "PLF3" Or FlashType = "PVF3" Or FlashType = "TLF3" Or FlashType = "TVF3" Then
        value(0) = dblVaporFraction
        Call g_MaterialObject.SetProp("PhaseFraction", "V", compNames, "Mixture", "Mole", value)
    End If
  
 '   IndVars(indx) = "Liquidcomposition"
 '   indx = indx + 1
    Dim temp As Variant
    Dim values As Variant
'   temp = GetValuesFromArray(MoleFraction)
    temp = GetDoubleValuesFromArray(moleFraction)
'   temp = MoleFraction
    ReDim values(nComps)
    Dim count As Integer
    count = 0
    sum = 0
    For i = LBound(temp) To UBound(temp)
        values(count) = CDbl(temp(i))   'Temp(i) Nilesh
        sum = sum + CDbl(temp(i))  'sum = sum + Val(Temp(i)) Nilesh
        count = count + 1
    Next
    
    If sum = 0 Then
        For i = LBound(temp) To UBound(temp)
            sum = sum + temp(i)
            count = count + 1
        Next
    End If
    
    If sum = 0 Then Exit Function
    If Format(sum, "0.0000000000000#") <> Format(1, "0.0000000000000#") Then
        strUnitsType = ""
        strUnitsLabel = ""
        strRangeUnitsApply = ""
        GoTo trap
        'Exit Function
    End If
    
    Call g_MaterialObject.SetProp("fraction", "L", compNames, "Mixture", "Mole", temp)
    
 '   valIndx = valIndx + Count
 '   IndVars(indx) = "Vaporcomposition"
 '   indx = indx + 1
 '  temp = GetValuesFromArray(MoleFraction)
    temp = GetDoubleValuesFromArray(moleFraction)
 '  temp = MoleFraction
    count = 0
    sum = 0
    For i = LBound(temp) To UBound(temp)
        values(count) = CDbl(temp(i)) 'Temp(i) Nilesh
        sum = sum + CDbl(temp(i))    'sum = sum + Val(Temp(i)) Nilesh
        count = count + 1
    Next
    
    If sum = 0 Then
        For i = LBound(temp) To UBound(temp)
            sum = sum + temp(i)
            count = count + 1
        Next
    End If
    
    If sum = 0 Then Exit Function
    If Format(sum, "0.0000000000000#") <> Format(1, "0.0000000000000#") Then
        strUnitsType = ""
        strUnitsLabel = ""
        strRangeUnitsApply = ""
        GoTo trap
        'Exit Function
    End If
    Call g_MaterialObject.SetProp("fraction", "V", compNames, "Mixture", "Mole", temp)
  '  valIndx = valIndx + Count
  
 '   Dim tmpIndVars As Variant
 '   ReDim tmpIndVars(indx - 1) As String
 '   Dim tmpValues As Variant
 '   ReDim tmpValues(valIndx - 1) As Double
  
 '  For i = 0 To indx - 1
  '      tmpIndVars(i) = IndVars(i)
  '  Next
 '   For i = 0 To valIndx - 1
  '      tmpValues(i) = Values(i)
 '   Next
  
  '  Call mobj.SetIndependentVar(tmpIndVars, tmpValues)
    Call g_MaterialObject.SetProp("molFraction", "Overall", compNames, "Mixture", "Mole", molefrac)
'   Call mobj.SetProp("molFraction", "Overall", ComponentList, "Mixture", "Mole", MoleFraction)
    ' Set Overall (Feed) Enthalpy
    
    If FlashType = "TH3" Or FlashType = "PH3" Or FlashType = "THLL" Or FlashType = "PHLL" Then
        Dim Enth As Variant
        Dim realEnth(0) As Double
        Enth = realEnth
        ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole  (Excel input is in j/kmole)
        Enth(0) = dblEnthalpy / 1000# 'Enthalpy
        Call g_MaterialObject.SetProp("enthalpy", "Overall", compNames, "Mixture", "Mole", Enth)
    End If
    
    ' Suphat/Abhijit Dec 28, 2000 try setProp for vaporFraction
    If FlashType = "PLF3" Or FlashType = "PVF3" Or FlashType = "TLF3" Or FlashType = "TVF3" Then
        Dim vfrac As Variant
        Dim realVfrac(0) As Double
        vfrac = realVfrac
        ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole  (Excel input is in j/kmole)
        vfrac(0) = dblVaporFraction
        Call g_MaterialObject.SetProp("PhaseFraction", "V", compNames, "Mixture", "Mole", vfrac)
    End If
    '
    ' if propertymethod is not default then set it
    If propertyMethod <> "" Then
        bChangedPropertyMethod = SetPropertyMethodOrSet(propertyMethod)
    End If
    '
    ' Call ap\source\atcapeopen\atcoproperties\COPropPack.cpp
    Call g_COPackage.CalcEquilibrium(g_MaterialObject, FlashType, Empty)
    GoTo display:
''
'' 4/21/2009 by Yuhua Song. CQ00126511: Indicate an error if the flash calculation is failed
'' isNoError = TRUE: flash calculation is successed
''           FALSE: flash calculation is failed, call SetErrors to set error in the cells
''
'    Dim isNoError As Boolean
''    isNoError = True
'    isNoError = g_COPackage.PropCheck(g_MaterialObject, Empty)
''
trap:
    isNoError = False
'
display:
    Dim Values2 As Variant

'   IndVars2(0) = "Temperature"
'   IndVars2(1) = "Pressure"
'   IndVars2(2) = "Liquidcomposition"
'   IndVars2(3) = "Vaporcomposition"
'   IndVars2(4) = "VaporFraction"
    Dim indvar As Variant
    ReDim indvar(0) As String
    
    strUnitsType = ""
    strUnitsLabel = ""
    strRangeUnitsApply = ""
'
' 4/24/2009 by Yuhua Song. CQ00126536 & CQ00141921: If a key component is given, check to see if two liquid
' phases should be switched.
'
    Dim Beta As Variant, Beta1 As Double, Low As Double, High As Double, Check As Boolean, bChange As Boolean, _
        X1 As Variant, X2 As Variant
    Low = 0
    High = 1

    Select Case returns
        Case "Pressure", "P", "p", "pressure"
            If isNoError = True Then
'             indvar(0) = "Pressure"
'             Values2 = mobj.GetIndependentVar(indvar)
             ' Add Code here
            ' Values2 = mobj.GetProp("pressure", "Overall", compNames, "Mixture", "Mass") 'Mole
              Values2 = g_MaterialObject.GetProp("pressure", "Overall", compNames, "Mixture", Empty)
            ' Code added by Jwalant
              For intResultCounter = LBound(Values2) To UBound(Values2)
                Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", CStr(Values2(intResultCounter)), "Get")
              Next intResultCounter
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
'
' '           indvar(0) = "Pressure"
''            Values2 = mobj.GetIndependentVar(indvar)
'            ' Add Code here
'           ' Values2 = mobj.GetProp("pressure", "Overall", compNames, "Mixture", "Mass") 'Mole
'            Values2 = g_MaterialObject.GetProp("pressure", "Overall", compNames, "Mixture", Empty)
'            ' Code added by Jwalant
'            For intResultCounter = LBound(Values2) To UBound(Values2)
'                Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "PRESSURE", CStr(Values2(intResultCounter)), "Get")
'            Next intResultCounter
            
            strUnitsType = "PRESSURE"
            ' Code added by Jwalant
            strUnitsLabel = SetGetLabel("PRESSURE")
            strRangeUnitsApply = GetCurrentCallerRange
        Case "Temperature", "T", "temperature", "t"
            If isNoError = True Then
  '           indvar(0) = "Temperature"
  '           Values2 = mobj.GetIndependentVar(indvar)
            
             'Values2 = mobj.GetProp("temperature", "Overall", compNames, "Mixture", "Mass") 'Mole
              Values2 = g_MaterialObject.GetProp("temperature", "Overall", compNames, "Mixture", Empty)
             ' Code added by Jwalant
              For intResultCounter = LBound(Values2) To UBound(Values2)
                 Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", CStr(Values2(intResultCounter)), "Get")
              Next intResultCounter
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
'
'  '          indvar(0) = "Temperature"
'  '          Values2 = mobj.GetIndependentVar(indvar)
'
'            'Values2 = mobj.GetProp("temperature", "Overall", compNames, "Mixture", "Mass") 'Mole
'            Values2 = g_MaterialObject.GetProp("temperature", "Overall", compNames, "Mixture", Empty)
'            ' Code added by Jwalant
'            For intResultCounter = LBound(Values2) To UBound(Values2)
'                Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "TEMPERATURE", CStr(Values2(intResultCounter)), "Get")
'            Next intResultCounter
            
            strUnitsType = "TEMPERATURE"
            ' Code adde by Jwalant
            strUnitsLabel = SetGetLabel("TEMPERATURE")
            strRangeUnitsApply = GetCurrentCallerRange
           
        Case "x:1", "X:1", "Liquid1MoleFraction", "Liquid1molefraction", "liquid1molefraction"
            If isNoError = True Then
   '          indvar(0) = "Liquidcomposition"
   '          Values2 = mobj.GetIndependentVar(indvar)
              Values2 = g_MaterialObject.GetProp("fraction", "Liquid", compNames, "Mixture", "Mole")
'
' 4/24/2009 by Yuhua Song. CQ00126536 & CQ00141921: If a key component is given, check to see if two liquid
' phases should be switched.
'
              If keyComponent <> "" Then
                If IsValidComponent(compNames, keyComponent) = True Then
'
' get BETA
'
                  Beta = g_MaterialObject.GetProp("L2Fraction", "Liquid2", compNames, "Mixture", "Mole")
                  Beta1 = Beta(0)
                  Check = Beta1 > Low And Beta1 < High
                  If Check = True Then
'
' get X:2
'
                    X2 = g_MaterialObject.GetProp("molFraction", "Liquid2", compNames, "Mixture", "Mole")
                    bChange = IsChangeX1(compNames, keyComponent, Values2, X2)
                  End If
                End If
              End If
            Else
              Values2 = SetErrors(compNames, "Mole")
            End If
            
'  '          indvar(0) = "Liquidcomposition"
'   '         Values2 = mobj.GetIndependentVar(indvar)
'            Values2 = g_MaterialObject.GetProp("fraction", "Liquid", compNames, "Mixture", "Mole")
            
            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "x:2", "X:2", "Liquid2MoleFraction", "Liquid2molefraction", "liquid2molefraction"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("molFraction", "Liquid2", compNames, "Mixture", "Mole")
'
' 4/24/2009 by Yuhua Song. CQ00126536 & CQ00141921: If a key component is given, check to see if two liquid
' phases should be switched.
'
              If keyComponent <> "" Then
                If IsValidComponent(compNames, keyComponent) = True Then
'
' get BETA
'
                  Beta = g_MaterialObject.GetProp("L2Fraction", "Liquid2", compNames, "Mixture", "Mole")
                  Beta1 = Beta(0)
                  Check = Beta1 > Low And Beta1 < High
                  If Check = True Then
'
' get X:1
'
                    X1 = g_MaterialObject.GetProp("fraction", "Liquid", compNames, "Mixture", "Mole")
                    bChange = IsChangeX2(compNames, keyComponent, Values2, X1)
                  End If
                End If
              End If
            Else
              Values2 = SetErrors(compNames, "Mole")
            End If
            
'            Values2 = g_MaterialObject.GetProp("molFraction", "Liquid2", compNames, "Mixture", "Mole")
            
            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "y", "Y", "VaporMoleFraction", "vapormolefraction", "Vapormolefraction"
            If isNoError = True Then
     '        indvar(0) = "Vaporcomposition"
     '        Values2 = mobj.GetIndependentVar(indvar)
              Values2 = g_MaterialObject.GetProp("fraction", "Vapor", compNames, "Mixture", "Mole")
            Else
              Values2 = SetErrors(compNames, "Mole")
            End If
            
'     '       indvar(0) = "Vaporcomposition"
'     '       Values2 = mobj.GetIndependentVar(indvar)
'            Values2 = g_MaterialObject.GetProp("fraction", "Vapor", compNames, "Mixture", "Mole")
            
            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "h", "H", "Enthalpy", "enthalpy"
            If isNoError = True Then
           '  Add code here
            ' Values2 = mobj.GetProp("enthalpy", "Overall", compNames, "Mixture", "Mole")
              Values2 = g_MaterialObject.GetProp("enthalpy", "Overall", compNames, "Mixture", "Mole")
            ' Code added by  Jwalant
              For intResultCounter = LBound(Values2) To UBound(Values2)
                 Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTHALPY", CStr(Values2(intResultCounter)), "Get")
              Next intResultCounter
              ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole
              Dim Thousand As Double
              Thousand = 1000#
              Values2(0) = Values2(0) * Thousand
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
'           ' Add code here
'            'Values2 = mobj.GetProp("enthalpy", "Overall", compNames, "Mixture", "Mole")
'            Values2 = g_MaterialObject.GetProp("enthalpy", "Overall", compNames, "Mixture", "Mole")
'            ' Code added by  Jwalant
'            For intResultCounter = LBound(Values2) To UBound(Values2)
'                Values2(intResultCounter) = SetGetConvertValue(CStr(aUnitSet(0)), "MOLE-ENTHALPY", CStr(Values2(intResultCounter)), "Get")
'            Next intResultCounter
'            ' Abhijit and Suphat Dec 28, 2000 CO Enthalpy is in J/mole
'            Dim Thousand As Double
'            Thousand = 1000#
'            Values2(0) = Values2(0) * Thousand
            
            strUnitsType = "MOLE-ENTHALPY"
            'strUnitsLabel = "J/kmol"
            ' Code added by Jwalant
            strUnitsLabel = SetGetLabel("MOLE-ENTHALPY")
            strRangeUnitsApply = GetCurrentCallerRange
        Case "v", "VaporFraction", "V", "Vaporfraction", "vaporfraction"
            If isNoError = True Then
              indvar(0) = "VaporFraction"
            ' Abhijit and Suphat Dec 28, 2000. Use getProp
            'Values2 = mobj.GetIndependentVar(indvar)
              Values2 = g_MaterialObject.GetProp("PhaseFraction", "V", compNames, "Mixture", "Mole")
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
'            indvar(0) = "VaporFraction"
'            ' Abhijit and Suphat Dec 28, 2000. Use getProp
'            'Values2 = mobj.GetIndependentVar(indvar)
'            Values2 = g_MaterialObject.GetProp("PhaseFraction", "V", compNames, "Mixture", "Mole")
            
            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "beta", "Beta", "BETA"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("L2Fraction", "Liquid2", compNames, "Mixture", "Mole")
'
' 4/24/2009 by Yuhua Song. CQ00126536 & CQ00141921: If a key component is given, check to see if two liquid
' phases should be switched.
'
              If keyComponent <> "" Then
                If IsValidComponent(compNames, keyComponent) = True Then
'
' Check Beta > 0 and Beta < 1
'
                  Beta1 = Values2(0)
                  Check = Beta1 > Low And Beta1 < High
                  If Check = True Then
'
' get X:1 and X:2
'
                    X1 = g_MaterialObject.GetProp("fraction", "Liquid", compNames, "Mixture", "Mole")
                    X2 = g_MaterialObject.GetProp("molFraction", "Liquid2", compNames, "Mixture", "Mole")
                    If IsChangeX1(compNames, keyComponent, X1, X2) = True Then
                      Values2(0) = 1 - Beta1
                    End If
                  End If
                End If
              End If
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
'            Values2 = g_MaterialObject.GetProp("L2Fraction", "Liquid2", compNames, "Mixture", "Mole")
            
            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
        Case "SFRAC", "SolidFraction", "sfrac", "Solidfraction", "solidfraction"
            If isNoError = True Then
              Values2 = g_MaterialObject.GetProp("PhaseFraction", "Solid", compNames, "Mixture", "Mole")
            Else
              Values2 = SetErrors(compNames, Empty)
            End If
            
'            Values2 = g_MaterialObject.GetProp("PhaseFraction", "Solid", compNames, "Mixture", "Mole")
            
            strUnitsType = "Dimensionless"
            strUnitsLabel = "Unitless"
            strRangeUnitsApply = GetCurrentCallerRange
    End Select
      
    coMatObj.Clean
    ' reset property method to global method
    If bChangedPropertyMethod = True Then
        Call RestoreOriginalProperty
    End If
    Set coMatObj = Nothing
    
    bNoteText = True
    Dim bVerticalArray As Boolean
    bVerticalArray = IsVerticalArray()
    If bVerticalArray = True Then
        InternalFlash3 = Application.WorksheetFunction.Transpose(Values2)
    Else
        InternalFlash3 = Values2
    End If
'
    If isNoError = True Then
        breCalculation = True
    Else
        If bChangeCom = True Then Exit Function
        If errmsg <> "" Then
            errmsg = ""
        End If
    End If
End Function

Function TVFlash3(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                VaporFraction As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute TVFlash3.VB_Description = "Calculates vapor-liquid-liquid phase equilibrium at specified temperature and molar vapor fraction. Returns=P,H,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
Attribute TVFlash3.VB_HelpID = 318
Attribute TVFlash3.VB_ProcData.VB_Invoke_Func = " \n20"

    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Pressure"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Pref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash3(ComponentList, moleFraction, VaporFraction, Temperature, g_Pref, "0", "TVF3", returns, keyComponent, _
    propertyMethod)
    TVFlash3 = result
End Function

Function PVFlash3(ComponentList As Variant, moleFraction As Variant, Pressure As String, _
                VaporFraction As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute PVFlash3.VB_Description = "Calculates vapor-liquid-liquid phase equilibrium at specified pressure and molar vapor fraction. Returns=T,H,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
Attribute PVFlash3.VB_HelpID = 315
Attribute PVFlash3.VB_ProcData.VB_Invoke_Func = " \n20"
          
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Temperature"
    End If
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash3(ComponentList, moleFraction, VaporFraction, g_Tref, Pressure, "0", "PVF3", returns, keyComponent, _
    propertyMethod)
    PVFlash3 = result
End Function

Function TPFlash3(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                Pressure As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute TPFlash3.VB_Description = "Calculates vapor-liquid-liquid phase equilibrium at specified temperature and pressure. Returns=V,H,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
Attribute TPFlash3.VB_HelpID = 317
Attribute TPFlash3.VB_ProcData.VB_Invoke_Func = " \n20"
        
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "VaporFraction"
    End If

    result = InternalFlash3(ComponentList, moleFraction, "0", Temperature, Pressure, "0", "TP3", returns, keyComponent, _
    propertyMethod)

    TPFlash3 = result
End Function

Function THFlash3(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                Enthalpy As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute THFlash3.VB_Description = "Calculates vapor-liquid-liquid phase equilibrium at specified temperature and molar enthalpy. Returns=P,V,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
Attribute THFlash3.VB_HelpID = 319
Attribute THFlash3.VB_ProcData.VB_Invoke_Func = " \n20"

    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Pressure"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Pref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash3(ComponentList, moleFraction, "0", Temperature, g_Pref, Enthalpy, "TH3", returns, keyComponent, _
    propertyMethod)
    THFlash3 = result
End Function

Function PHFlash3(ComponentList As Variant, moleFraction As Variant, Pressure As String, _
                Enthalpy As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute PHFlash3.VB_Description = "Calculates vapor-liquid-liquid phase equilibrium at specified pressure and molar enthalpy. Returns=T,V,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2, or Y."
Attribute PHFlash3.VB_HelpID = 316
Attribute PHFlash3.VB_ProcData.VB_Invoke_Func = " \n20"
                
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Temperature"
    End If
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash3(ComponentList, moleFraction, "0", g_Tref, Pressure, Enthalpy, "PH3", returns, keyComponent, _
    propertyMethod)
    PHFlash3 = result
    
End Function

Function TPFlashLL(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                Pressure As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute TPFlashLL.VB_Description = "Calculates liquid-liquid phase equilibrium at specified temperature and pressure. Returns=H,SFRAC,X:1,X:2, or BETA. Use Shift+Ctrl+Enter if Returns=X:1 or X:2."
Attribute TPFlashLL.VB_HelpID = 15
Attribute TPFlashLL.VB_ProcData.VB_Invoke_Func = " \n20"
            
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "VaporFraction"
    End If

    result = InternalFlash3(ComponentList, moleFraction, "0", Temperature, Pressure, "0", "TPLL", returns, keyComponent, _
    propertyMethod)

    TPFlashLL = result
End Function

Function THFlashLL(ComponentList As Variant, moleFraction As Variant, Temperature As String, _
                Enthalpy As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute THFlashLL.VB_Description = "Calculates liquid-liquid phase equilibrium at specified temperature and molar enthalpy. Returns=P,SFRAC,X:1,X:2, or BETA. Use Shift+Ctrl+Enter if Returns=X:1 or X:2."
Attribute THFlashLL.VB_HelpID = 14
Attribute THFlashLL.VB_ProcData.VB_Invoke_Func = " \n20"

    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Pressure"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Pref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash3(ComponentList, moleFraction, "0", Temperature, g_Pref, Enthalpy, "THLL", returns, keyComponent, _
    propertyMethod)
    THFlashLL = result
End Function

Function PHFlashLL(ComponentList As Variant, moleFraction As Variant, Pressure As String, _
                Enthalpy As String, Optional returns As Variant, Optional keyComponent As String, _
                Optional propertyMethod As Variant)
Attribute PHFlashLL.VB_Description = "Calculates liquid-liquid phase equilibrium at specified pressure and molar enthalpy. Returns=T,SFRAC,X:1,X:2, or BETA. Use Shift+Ctrl+Enter if Returns=X:1 or X:2."
Attribute PHFlashLL.VB_HelpID = 1
Attribute PHFlashLL.VB_ProcData.VB_Invoke_Func = " \n20"
                
    If IsPropertyPackageAvailable() = False Then Exit Function
    Dim result As Variant
    
    If IsMissing(returns) Then
        returns = "Temperature"
    End If
    
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    If g_Tref = "" Then
       Call InitializeGlobalVariables
    End If
    result = InternalFlash3(ComponentList, moleFraction, "0", g_Tref, Pressure, Enthalpy, "PHLL", returns, keyComponent, _
    propertyMethod)
    PHFlashLL = result
    
End Function

'Function Flash(FlashType As String, ComponentList As Variant, _
'                MoleFraction As Variant, Temperature As String, Pressure As String, _
'                Enthalpy As String, VaporFraction As String, Optional Returns As Variant, Optional PropertyMethod As Variant)
'    If IsPropertyPackageAvailable() = False Then Exit Function
'
'    On Error GoTo trap

'    FlashType = UCase(FlashType)

'    If IsMissing(Returns) Then
'        Returns = ""
'        If Trim(FlashType) = "TLF" Or Trim(FlashType) = "TVF" Or Trim(FlashType) = "TV" Or Trim(FlashType) = "TH" Or Trim(FlashType) = "TQ" Then
'            Returns = "Pressure"
'        ElseIf Trim(FlashType) = "PLF" Or Trim(FlashType) = "PVF" Or Trim(FlashType) = "PV" Or Trim(FlashType) = "PH" Or Trim(FlashType) = "PQ" Then
'            Returns = "Temperature"
'        ElseIf Trim(FlashType) = "PT" Or Trim(FlashType) = "TP" Then  'FlashType = "PLF" Or FlashType = "PVF" Or FlashType = "TLF" Or FlashType = "TVF"
'                Returns = "VaporFraction"
'        Else
'            errMsg = "Wrong FlashType"
'            GoTo trap
'        End If
'    End If
    
'    If Returns = "" Then
'        errMsg = "No default return for the flash type is available, Please enter a value for return"
'    End If
        
'    strUnitsType = ""
'    strUnitsLabel = ""

'    Select Case Returns
'        Case "Temperature", "T", "temperature", "t"
''            strUnitsType = "TEMPERATURE"
''            strUnitsLabel = "K"
'            Returns = "Temperature"
'        Case "Pressure", "P", "p", "pressure"
''            strUnitsType = "PRESSURE"
''            strUnitsLabel = "N/sqm"
'            Returns = "Pressure"
'        Case "VaporFraction", "V", "v", "Vaporfraction", "vaporfraction"
''            strUnitsType = "Dimensionless"
''            strUnitsLabel = "Unitless"
'            Returns = "VaporFraction"
'        Case "X", "x", "LiquidComposition", "Liquidcomposition", "liquidcomposition"
''            strUnitsType = "Dimensionless"
''            strUnitsLabel = "Unitless"
'            Returns = "Liquidcomposition"
'        Case "Y", "y", "VaporComposition", "vaporcomposition", "Vaporcomposition"
''            strUnitsType = "Dimensionless"
''            strUnitsLabel = "Unitless"
'            Returns = "Vaporcomposition"
'        Case "Q", "H", "q", "h", "HeatDuty", "Heatduty", "heatduty"
''            strUnitsType = "MOLE-ENTHALP"
''            strUnitsLabel = "J/kmol"
'            Returns = "Heatduty"
'    End Select
    
'    Select Case FlashType
'        Case "TP", "TVF" '"TVF"
'            If Returns = "Temperature" Then Flash = CVErr(2001)
'        Case "TVF", "PVF" '"TVF" "PVF"
'            If Returns = "Vaporfraction" Then Flash = CVErr(2001)
'        Case "TP", "PVF" '"PVF"
'            If Returns = "Pressure" Then Flash = CVErr(2001)
'    End Select

'    Flash = InternalFlash(ComponentList, MoleFraction, VaporFraction, Temperature, _
'          Pressure, Enthalpy, FlashType, Returns, PropertyMethod)
'    Exit Function
'trap:
'    If errMsg <> "" Then
'        MsgBox errMsg
'        errMsg = ""
'    End If
'End Function

' Function   : MassFractionToMoleFraction(Massfraction As Variant, ComponentList As Variant)
'              Takes input massfraction from the excel sheet and returns corresponding molefraction
' Returns    : Variant (Array for MassFraction)
' Created    : 03/20/2002
' Version    : Aspen Properties 12.1
'Author:       Jwalant Vyas
 Function MassFractionToMoleFraction(ComponentList As Variant, Massfraction As Variant) As Variant
Attribute MassFractionToMoleFraction.VB_Description = "Performs mole fraction conversion from mass fraction. Use Shift+Ctrl+Enter for multiple components."
Attribute MassFractionToMoleFraction.VB_HelpID = 4
Attribute MassFractionToMoleFraction.VB_ProcData.VB_Invoke_Func = " \n20"
   If GetNumColumnsInArray(Massfraction) < GetNumColumnsInArray(ComponentList) Then Exit Function
   Dim aMolecularWeight As Variant
   Dim aTempArray As Variant
   Dim aCompList As Variant
   Dim i As Integer
   Dim results As Variant
   
   ' see if this is requesting results vertically
   Dim bVerticalArray As Boolean
   bVerticalArray = IsVerticalArray()
   '
   Dim components As Variant
   components = GetValuesFromArray(ComponentList) 'components is now an array of one dimension (0 to n-1)
    
   aTempArray = GetValuesFromArray(Massfraction) 'aTempArray is now an array of one dimension (0 to n-1 or 0 to n) and may be different from components
   Dim temp As Variant
   temp = aTempArray 'Save aTempArray
   'ReDim aTempArray(UBound(components)) As Variant 'Make aTempArray as an array of one dimension (0 to n-1) from components
   ReDim Preserve aTempArray(LBound(components) To UBound(components)) 'Make aTempArray as an array of one dimension (0 to n-1) from components
   
'   For i = LBound(aTempArray) To UBound(aTempArray)
'      aTempArray(i) = CDbl(temp(i))
'   Next
   
   aMolecularWeight = PureComponentConstant(ComponentList, "molecularWeight")
   ' we do not want results vertically, however if the final function
   ' wants it vertically PureComponentConstant will be fooled into believing
   ' that we wanted molecularWeight vertically, because that itself is a public
   ' function. So we need to revert back to horizontal arrays if PureComponentConstant
   ' returns it vertically
   ' a bit of a waste by double transpose, guess does not hurt much though
   If bVerticalArray = True Then
       aMolecularWeight = Application.WorksheetFunction.Transpose(aMolecularWeight)
       ReDim Preserve aMolecularWeight(LBound(components) To UBound(components)) 'Make aMolecularWeight as an array of one dimension (0 to n-1) from components
   End If
   '
   'If GetNumColumnsInArray(ComponentList) = GetNumColumnsInArray(Massfraction) Then
    If CheckFractionSum(aTempArray) = True Then
        results = ConvertFraction(aTempArray, aMolecularWeight, 0)
        If bVerticalArray = True Then
            MassFractionToMoleFraction = Application.WorksheetFunction.Transpose(results)
        Else
            MassFractionToMoleFraction = results
        End If
    End If
   'End If
   breCalculation = True
End Function
' Function Implemented by Nilesh
Function UnitsConversion(From_Units As String, To_Units As String, From_Value As Variant) As Variant
Attribute UnitsConversion.VB_Description = "Performs units conversion. Use Shift+Ctrl+Enter for multiple values."
Attribute UnitsConversion.VB_HelpID = 302
Attribute UnitsConversion.VB_ProcData.VB_Invoke_Func = " \n20"

    Dim i As Integer
    Dim fromBlock As String
    Dim fromMult As Double
    Dim fromAdd As Double
    Dim toBlock As String
    Dim toMult As Double
    Dim toAdd As Double

    For i = LBound(arrUnit, 2) To UBound(arrUnit, 2)
        'Debug.Print arrUnit(0, i)
        If Trim(arrUnit(1, i)) = Trim(From_Units) Then
            fromBlock = arrUnit(0, i)
            fromMult = Val(arrUnit(2, i)) ' Here, Val is used because the entries in units.dat etc. use period (.) as
            fromAdd = Val(arrUnit(3, i))  ' decimal separator, regardless of locale settings.
        End If
        
        If Trim(arrUnit(1, i)) = Trim(To_Units) Then
            toBlock = arrUnit(0, i)
            toMult = Val(arrUnit(2, i))
            toAdd = Val(arrUnit(3, i))
        End If
    
        If Trim(fromBlock) = Trim(toBlock) And (fromBlock <> Empty Or toBlock <> Empty) Then
            Exit For
        End If
    Next i
    
    If Trim(fromBlock) <> Trim(toBlock) Then
        UnitsConversion = 0
        MsgBox "Units labels of From_Units and To_Units must be of the same type"
        Exit Function
    End If
    
    If IsArray(From_Value) = False Then
        UnitsConversion = (fromMult * From_Value + fromAdd - toAdd) / toMult
    Else
        UnitsConversion = ConvertVectorValues(From_Value, fromMult, fromAdd, toMult, toAdd)
    End If
End Function
Private Function ConvertVectorValues(From_Value As Variant, fromMult As Double, fromAdd As Double, toMult As Double, toAdd As Double) As Variant
    Dim bVerticalArray As Boolean
    bVerticalArray = IsVerticalArray()
    Dim counter As Integer
    Dim results As Variant
    results = GetValuesFromArray(From_Value)
    For counter = LBound(results) To UBound(results)
        results(counter) = (fromMult * results(counter) + fromAdd - toAdd) / toMult
    Next
    If bVerticalArray = True Then
        results = Application.WorksheetFunction.Transpose(results)
    End If
    ConvertVectorValues = results
End Function

' Function implemented by Nilesh and commented out by Jwalant
'Private Function getUnitsTypeLabel(strPropertyName As String, ByRef sUnitsType As String, ByRef sUnitsLabel As String) As Boolean
'    Dim i As Integer
'    Call CheckUnitArray
''     Call CheckPropUnitArray
'    getUnitsTypeLabel = False
'    For i = LBound(arrPropUnit, 1) To UBound(arrPropUnit, 1)
'        If arrPropUnit(i, 0) = strPropertyName Then
'            sUnitsType = arrPropUnit(i, 1)
'            sUnitsLabel = arrPropUnit(i, 2)
'            getUnitsTypeLabel = True
'        End If
'    Next i
' Function   : SetGetLabel(sPropName As String)
'              Takes input for propertyname and returns label for that for specified global unit
' Returns    : String
' Created    : 04/09/2002
' Version    : Aspen Properties 12.1
'Author:       Jwalant Vyas

' Subroutine : GetUnitsConversion(sPropertyName As String)
'              Takes input for propertyname and sets corresponding an array
'              of all units available in units.dat file for it
' Returns    : None
' Created    : 04/05/2002
' Version    : Aspen Properties 12.1
'Author:       Jwalant Vyas
Sub GetUnitsConversion(sPropertyName As String)
Dim i As Integer
Dim j As Integer
Dim k As Integer
Dim count As Integer
count = 0
Dim unitIndex As Integer
For i = LBound(arrProp, 1) To UBound(arrProp, 1)
    If Trim(arrProp(i, 2)) = sPropertyName Then
        unitIndex = Val(arrProp(i, 5)) - Val(arrProp(i, 1))
        For j = LBound(arrUnit, 2) To UBound(arrUnit, 2)
            If j = unitIndex Then
                count = 0
                ReDim arrPropTemp(Val(arrProp(i, 1)) - 1)
                For k = unitIndex To unitIndex + Val(arrProp(i, 1)) - 1
                    arrPropTemp(count) = (arrUnit(1, k))
                    count = count + 1
                Next k
                Exit For
            End If
        Next j
        Exit For
    End If
Next i
End Sub
' Function implemented by Nilesh - Modified by Jwalant

Private Function GetUnitsTypeLabel(strPropertyName As String, ByRef sUnitsType As String, ByRef sUnitsLabel As String) As Boolean

    Dim i As Integer
    Call CheckUnitArray
    Dim sLab As String
'     Call CheckPropUnitArray
    GetUnitsTypeLabel = False
    For i = LBound(arrPropUnit, 1) To UBound(arrPropUnit, 1)
        If arrPropUnit(i, 0) = strPropertyName Then
            sLab = arrPropUnit(i, 1)
            sUnitsType = arrPropUnit(i, 1)
            ' Adde by Jwalant
            sUnitsLabel = SetGetLabel(sLab)
            'sUnitsLabel = arrPropUnit(i, 2) ' :Version 11.1 Implementation Before 04/09/2002
            GetUnitsTypeLabel = True
        End If
    Next i
End Function

Private Function IsValidProperty(strPropertyName As String, ByRef sConst As String, ByRef sTdependent As String, _
    ByRef sPdependent As String, ByRef sPureProperty As String, ByRef sMixtureProperty As String, _
    ByRef strPropHasBasis As String) As Boolean
    
    Dim i As Integer
    'Call CheckUnitArray
    Call CheckPropUnitArray
    IsValidProperty = False
    For i = LBound(arrPropUnit, 1) To UBound(arrPropUnit, 1)
        If arrPropUnit(i, 0) = strPropertyName Then
            sConst = arrPropUnit(i, 3)
            sTdependent = arrPropUnit(i, 4)
            sPdependent = arrPropUnit(i, 5)
            sPureProperty = arrPropUnit(i, 6)
            sMixtureProperty = arrPropUnit(i, 7)
            strPropHasBasis = arrPropUnit(i, 9)
            IsValidProperty = True
            Exit For
        End If
    Next i
End Function

Private Function IsValidPhase(strPropertyName As String, strPhase As String, ByRef sPhase As String) As Boolean
    Dim iPhase
    Dim i As Integer
    'Call CheckUnitArray
    Call CheckPropUnitArray
'
' 5/26/2009 by Yuhua Song. CQ00096326: Add solid properties calculation.
'
    IsValidPhase = False
    For i = LBound(arrPropUnit, 1) To UBound(arrPropUnit, 1)
        If arrPropUnit(i, 0) = strPropertyName Then
            iPhase = arrPropUnit(i, 8)
            Select Case iPhase
                Case "0"
                    sPhase = "L"
                Case "1"
                    sPhase = "V"
                Case "2"
                    If strPhase = "V" Or strPhase = "L" Then sPhase = strPhase
                Case "4"
                    If strPhase = "V" Or strPhase = "L" Or strPhase = "S" Then sPhase = strPhase
                Case "3"
                    sPhase = "L"
                    IsValidPhase = True
                    Exit Function
            End Select
            If sPhase = "V" Or sPhase = "L" Or sPhase = "S" Then
                If sPhase = strPhase Then
                    IsValidPhase = True
                Else
                    IsValidPhase = False
                End If
                Exit Function
            Else
                IsValidPhase = False
                Exit Function
            End If
        End If
    Next i
End Function

Private Function HasPhComponents()
    Dim j As Integer
    HasPhComponents = False
    For j = LBound(formulae) To UBound(formulae)
        If "H3O+" = Trim(formulae(j)) Or "H+" = Trim(formulae(j)) Then
            HasPhComponents = True
            Exit For
        End If
    Next
End Function


' Function   : checkFractionSum(aFraction As Variant)
'              Takes fractionList as input and validates the fraction sum equlas unity
' Returns    : Boolean
' Created    : 03/20/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Private Function CheckFractionSum(aFraction As Variant) As Boolean
   Dim sum
   sum = 0
   Dim i As Integer
   For i = LBound(aFraction) To UBound(aFraction)
       sum = sum + CDbl(aFraction(i))
   Next
   If sum = 0 Then
      CheckFractionSum = False
      Exit Function
   End If
   If Format(sum, "0.0000000000000#") <> Format(1, "0.0000000000000#") Then
      CheckFractionSum = False
      Exit Function
   Else
      CheckFractionSum = True
   End If
End Function
' Function   : convertFraction(aFractionList As Variant, aMolWeight As Variant, i As Integer)
'              Takes fractionList, molecularweight and i(flag) as input and converts fractions
'              mole<->mass
' Returns    : Variant (Array of Fraction)
' Created    : 03/20/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Private Function ConvertFraction(aFractionList As Variant, aMolWeight As Variant, i As Integer) As Variant
      Dim counter As Integer
      Dim tempSum
      tempSum = 0#
      
      On Error GoTo trap
      For counter = LBound(aFractionList) To UBound(aFractionList)
         If i = 1 Then
             'For mole to mass conversion
             aFractionList(counter) = aFractionList(counter) * CDbl(aMolWeight(counter))
             tempSum = tempSum + aFractionList(counter)
          Else
             'For mass to mole conversion
             aFractionList(counter) = aFractionList(counter) / CDbl(aMolWeight(counter))
             tempSum = tempSum + aFractionList(counter)
          End If
        Next
        For counter = LBound(aFractionList) To UBound(aFractionList)
            aFractionList(counter) = aFractionList(counter) / tempSum
        Next
            ConvertFraction = aFractionList
            
trap:
End Function

' Function   : SetGetConvertValue(sGlobalSet As String, sPropName As String, dValue As String, sFlag As String) As Double
' Returns    : Double
'            : Takes input as property name, global unit set, value entered by the user, and a flag variable
'              for determining either it needs to convert unit to SI or back from SI and returns corresponding unit
' Created    : 04/08/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Private Function SetGetConvertValue(sGlobalSet As String, sPropName As String, dValue As String, sFlag As String) As Double
    Dim sFromUnit As String
    Dim sToUnit As String
    Dim inVal As Double
    inVal = CDbl(dValue) ' can be any locale setting, so use CDbl
    If sPropName = "TEMPERATURE" Or sPropName = "PRESSURE" Or sPropName = "MOLE-VOLUME" Or sPropName = "MOLE-ENTHALPY" Or sPropName = "MOLE-HEAT-CAPACITY" Then
        Select Case sPropName
            Case "TEMPERATURE"
                If IsEmpty(aUnitSet(1)) Then
                    sFromUnit = GetConvertUnit(sGlobalSet, sPropName)
                Else
                    sFromUnit = aUnitSet(1)
                End If
            Case "PRESSURE"
                If IsEmpty(aUnitSet(2)) Then
                    sFromUnit = GetConvertUnit(sGlobalSet, sPropName)
                Else
                    sFromUnit = aUnitSet(2)
                End If
            Case "MOLE-VOLUME"
                If IsEmpty(aUnitSet(3)) Then
                    sFromUnit = GetConvertUnit(sGlobalSet, sPropName)
                Else
                    sFromUnit = aUnitSet(3)
                End If
            Case "MOLE-ENTHALPY"
                If IsEmpty(aUnitSet(4)) Then
                    sFromUnit = GetConvertUnit(sGlobalSet, sPropName)
                Else
                    sFromUnit = aUnitSet(4)
                End If
            Case "MOLE-HEAT-CAPACITY"
                If IsEmpty(aUnitSet(5)) Then
                    sFromUnit = GetConvertUnit(sGlobalSet, sPropName)
                Else
                    sFromUnit = aUnitSet(5)
                End If
        End Select
    Else
        sFromUnit = GetConvertUnit(sGlobalSet, sPropName)
    End If
        sToUnit = GetConvertUnit("SI", sPropName)
    If sFlag = "Set" Then
        SetGetConvertValue = UnitsConversion(sFromUnit, sToUnit, inVal)
    ElseIf sFlag = "Get" Then
        SetGetConvertValue = UnitsConversion(sToUnit, sFromUnit, inVal)
    End If
End Function
' Function   : PopulateUnitArray()
'            : Pouplate English,SI and Metric unit array for corresponding unit system
'              for Temperature, Pressure, Mole-Volume,Mole-Enthalpy,Mole-Heat-Capacity
'            :
' Created    : 04/09/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub PopulateUnitArray()
     English(0) = GetConvertUnit("English", "TEMPERATURE")
     SI(0) = GetConvertUnit("SI", "TEMPERATURE")
     Metrics(0) = GetConvertUnit("Metric", "TEMPERATURE")
     English(1) = GetConvertUnit("English", "PRESSURE")
     SI(1) = GetConvertUnit("SI", "PRESSURE")
     Metrics(1) = GetConvertUnit("Metric", "PRESSURE")
     English(2) = GetConvertUnit("English", "MOLE-VOLUME")
     SI(2) = GetConvertUnit("SI", "MOLE-VOLUME")
     Metrics(2) = GetConvertUnit("Metric", "MOLE-VOLUME")
     English(3) = GetConvertUnit("English", "MOLE-ENTHALPY")
     SI(3) = GetConvertUnit("SI", "MOLE-ENTHALPY")
     Metrics(3) = GetConvertUnit("Metric", "MOLE-ENTHALPY")
     English(4) = GetConvertUnit("English", "MOLE-HEAT-CAPACITY")
     SI(4) = GetConvertUnit("SI", "MOLE-HEAT-CAPACITY")
     Metrics(4) = GetConvertUnit("Metric", "MOLE-HEAT-CAPACITY")
End Sub

' Function   : getGlobalUnitArray()
'            : gets global unit set string defined by user and parse it to initiate and create aUnitSet array
'            :
' Created    : 04/18/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas

Sub GetGlobalUnitArray()
 If IsGlobalUnitSetAvailable = False Then
     gUnitSet = "Global Units Set: SI"
 End If
 Call ParseUnitSet(gUnitSet)
End Sub

Private Function SetPropertyMethodOrSet(vtPropertyMethod As Variant) As Boolean
    Dim AspenPkg As IAspenPropertyPackage
    On Error GoTo exitFunction
    SetPropertyMethodOrSet = False
    Dim strMethText As String
    strMethText = vtPropertyMethod
    strMethText = Trim(strMethText)
    If strMethText = "" Then Exit Function
    strMethText = UCase(strMethText)
    ' same as global, no changes
    If strMethText = UCase(g_InitialGlobalOpsetname) Then Exit Function
    '
    ' see if this is a set
    Dim bIsSet As Boolean
    Call frmPropMethSet.MethodIsSet(strMethText, bIsSet)
    '
    If bIsSet = False Then
        ' Process if this is not a method set
        Dim strBlank As String
        Dim lMinus1 As Long
        lMinus1 = -1 ' < 0 means missing below
        strBlank = ""
        Set AspenPkg = g_COPackage
        Call AspenPkg.SetPropertyMethod(strMethText, strBlank, strBlank, lMinus1, strBlank, lMinus1)
        Set AspenPkg = Nothing
        SetPropertyMethodOrSet = True
    Else
        ' process if this is a method set
        Dim strSetID As String
        Dim strPropMeth As String
        Dim strHenryID As String
        Dim strChemistryID As String
        Dim strFreeWater As String
        Dim lTrueComps As Long
        Dim lSoluWater As Long
        Dim bParseSuccess As Boolean
        bParseSuccess = False
        Call frmPropMethSet.ParseTextForMethodSet(strMethText, strSetID, strPropMeth, _
                                    strHenryID, strChemistryID, lTrueComps, _
                                    strFreeWater, lSoluWater, bParseSuccess)
        If bParseSuccess = True Then
            ' if this is exactly the same as global then exit function
            If g_InitialGlobalOpsetname = strPropMeth And _
                g_InitialGlobalHenry = strHenryID And _
                g_InitialGlobalChemistry = strChemistryID And _
                g_InitialGlobalFreeWater = strFreeWater And _
                g_InitialGlobalTrueComps = lTrueComps And _
                g_InitialGlobalSoluWater = lSoluWater _
                    Then Exit Function
                
            Set AspenPkg = g_COPackage
            Call AspenPkg.SetPropertyMethod(strPropMeth, strHenryID, strChemistryID, lTrueComps, strFreeWater, lSoluWater)
            Set AspenPkg = Nothing
            SetPropertyMethodOrSet = True
        End If
    End If
exitFunction:
    Set AspenPkg = Nothing
End Function

Sub RestoreOriginalProperty()
    Dim AspenPkg As IAspenPropertyPackage
    On Error GoTo errSub
    Set AspenPkg = g_COPackage
    Call AspenPkg.RestoreOriginalGlobalPropertySpecs
'    Call AspenPkg.SetPropertyMethod(g_InitialGlobalOpsetname, _
'                                    g_InitialGlobalHenry, _
'                                    g_InitialGlobalChemistry, _
'                                    g_InitialGlobalTrueComps, _
'                                    g_InitialGlobalFreeWater, _
'                                    g_InitialGlobalSoluWater)
errSub:
    Set AspenPkg = Nothing
End Sub

Private Function IsVerticalArray(Optional ByRef bRangeCaller) As Boolean
    Dim nRows As Integer
    Dim nCols As Integer
    IsVerticalArray = False
    
    On Error GoTo ErrHandler
    bRangeCaller = True
    nRows = Application.Caller.Rows.count
    nCols = Application.Caller.Columns.count
    
    ' if more than 1 column then it is a horizontal selection
    If nCols > 1 Then Exit Function
    
    If nRows > 1 Then
        IsVerticalArray = True
    End If
    Exit Function
    
ErrHandler:
    If (Err.number <> 424) Then ' VBA caller
        Call Err.Raise(Err.number, "IsVerticalArray", Err.Description)
    End If
    bRangeCaller = False
End Function

Private Function GetCurrentCallerRange() As String
    GetCurrentCallerRange = ""
    If TypeName(Application.Caller) = "Range" Then
        GetCurrentCallerRange = Application.Caller.Address
    End If
End Function
'
' 4/21/2009 by Yuhua Song. CQ00126511: Indicate an error if the flash calculation is failed
' isNoError = TRUE: flash calculation is successed
'           FALSE: flash calculation is failed, call SetErrors to set error in the cells
'
Private Function SetErrors(compNames As Variant, props As Variant) As Variant
    If IsEmpty(props) Then
'
' set single <ERROR> to SetErors
'
        SetErrors = "<ERROR>"
    Else
        Dim theValue As Variant
        Dim imax As Integer
        Dim imin As Integer
        imin = LBound(compNames, 1)
        imax = UBound(compNames, 1)
        ReDim theValue(0 To (imax - imin))
        Dim i As Integer
        For i = imin To imax
            theValue(i) = "<ERROR>"
        Next i
        
        SetErrors = theValue
    End If
End Function

Private Function SetErrors3(ComponentList() As Variant, props As Variant) As Variant()
    Dim iCompListSize As Integer
    iCompListSize = UBound(ComponentList, 1)
        
    Dim myErrInfo As Variant
    ReDim myErrInfo(0 To iCompListSize) As String
    Dim i As Integer
    i = 0
    For i = LBound(ComponentList, 1) To UBound(ComponentList, 1)
        myErrInfo(i) = "<ERROR>"
    Next
        
    SetErrors3 = myErrInfo
End Function


Private Function IsValidComponent(compNames As Variant, keyComponent As String) As Boolean
    IsValidComponent = False
    Dim imax As Integer
    Dim imin As Integer
    imin = LBound(compNames, 1)
    imax = UBound(compNames, 1)
    Dim i As Integer, j As Integer
    Dim comp As String
    For i = imin To imax
        comp = compNames(i)
        j = StrComp(comp, keyComponent)
        If j = 0 Then
            IsValidComponent = True
            Exit Function
        End If
    Next i
End Function
'
' 4/24/2009 by Yuhua Song. CQ00126536 & CQ00141921: If a key component is given, check to see if two liquid
' phases should be switched.
'
Private Function IsChangeX1(compNames As Variant, keyComponent As String, ByRef X1 As Variant, X2 As Variant) As Boolean
    
    IsChangeX1 = False
    
    Dim imax As Integer
    Dim imin As Integer
    imin = LBound(compNames, 1)
    imax = UBound(compNames, 1)
    Dim i As Integer
    For i = imin To imax
      If StrComp(compNames(i), keyComponent) = 0 Then
        If X1(i) > X2(i) Then
'
' switch
'
           X1 = X2
           IsChangeX1 = True
           Exit Function
        End If
      End If
    Next i
End Function

Private Function IsChangeX2(compNames As Variant, keyComponent As String, ByRef X2 As Variant, X1 As Variant) As Boolean
    
    IsChangeX2 = False
    
    Dim imax As Integer
    Dim imin As Integer
    imin = LBound(compNames, 1)
    imax = UBound(compNames, 1)
    Dim i As Integer
    For i = imin To imax
      If StrComp(compNames(i), keyComponent) = 0 Then
        If X1(i) > X2(i) Then
'
' switch
'
           X2 = X1
           IsChangeX2 = True
           Exit Function
        End If
      End If
    Next i
End Function

Sub AddComment()
    Dim callingRange As Range
    Set callingRange = Application.Caller
    callingRange.AddComment errmsg
    errmsg = ""
End Sub

Sub CleanComment()
    Dim callingRange As Range
    Set callingRange = Application.Caller
    callingRange.ClearComments
End Sub

' Function   : MoleFlowToMoleFraction(ComponentList As Variant, MoleFlow As Variant) As Variant
'              Takes input MoleFlow from the excel sheet and returns corresponding molefraction
' Returns    : Variant (Array for MoleFraction)
' Created    : 06/30/2017
' Version    : Aspen Properties V11
' Author     : Yuhua Song
Function MoleFlowToMoleFraction(ComponentList As Variant, MoleFlow As Variant) As Variant
Attribute MoleFlowToMoleFraction.VB_Description = "Performs mole fraction conversion from MoleFlow. Use Shift+Ctrl+Enter for multiple components."
Attribute MoleFlowToMoleFraction.VB_HelpID = 320
Attribute MoleFlowToMoleFraction.VB_ProcData.VB_Invoke_Func = " \n20"
    On Error GoTo ERR_VBA_CALLER
    If GetNumColumnsInArray(MoleFlow) < GetNumColumnsInArray(ComponentList) Then Exit Function
    On Error GoTo 0
    Dim results As Variant
    Dim sumVal As Double
    sumVal = 0#
    Dim i As Integer
   '
   ' see if this is requesting results vertically
    Dim bVerticalArray As Boolean
    bVerticalArray = IsVerticalArray()
   '
    Dim components As Variant
    components = GetValuesFromArray(ComponentList) 'components is now an array of one dimension (0 to n-1)
    
    results = GetValuesFromArray(MoleFlow) 'results is now an array of one dimension (0 to n-1 or 0 to n) and may be different from components
    
    Dim temp As Variant
    temp = results 'Save results
    
    'ReDim results(UBound(components)) As Variant 'Make results as an array of one dimension (0 to n-1) from components
    ReDim Preserve results(LBound(components) To UBound(components)) 'Make results as an array of one dimension (0 to n-1) from components
    
    For i = LBound(results) To UBound(results)
       sumVal = sumVal + CDbl(results(i))
       'sumVal = sumVal + CDbl(temp(i))
    Next
    
    For i = LBound(results) To UBound(results)
      'results(i) = CDbl(temp(i)) / sumVal
      results(i) = CDbl(results(i)) / sumVal
    Next
    '
    If bVerticalArray = True Then
        MoleFlowToMoleFraction = Application.WorksheetFunction.Transpose(results)
    Else
        MoleFlowToMoleFraction = results
    End If
    breCalculation = True
    Exit Function
    
ERR_VBA_CALLER:
    If (LBound(ComponentList) = LBound(MoleFlow)) And (UBound(ComponentList) = UBound(MoleFlow)) Then
        On Error Resume Next
        Resume
    End If
End Function
