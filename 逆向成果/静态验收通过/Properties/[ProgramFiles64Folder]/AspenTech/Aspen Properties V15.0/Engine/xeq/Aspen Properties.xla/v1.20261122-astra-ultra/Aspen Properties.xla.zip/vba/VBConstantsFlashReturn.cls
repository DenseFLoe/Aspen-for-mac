Attribute VB_Name = "VBConstantsFlashReturn"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public PV As New VBConstantsFlashReturnPV
Public PH As New VBConstantsFlashReturnPH
Public TP As New VBConstantsFlashReturnTP
Public TV As New VBConstantsFlashReturnTV
Public TH As New VBConstantsFlashReturnTH
Public PS As New VBConstantsFlashReturnPS
Public PU As New VBConstantsFlashReturnPU
Public PV3 As New VBConstantsFlashReturnPV3
Public PH3 As New VBConstantsFlashReturnPH3
Public TP3 As New VBConstantsFlashReturnTP3
Public TV3 As New VBConstantsFlashReturnTV3
Public TH3 As New VBConstantsFlashReturnTH3
Public PHLL As New VBConstantsFlashReturnPHLL
Public TPLL As New VBConstantsFlashReturnTPLL
Public THLL As New VBConstantsFlashReturnTHLL

Public Enum FlashReturn
    out_Beta = 1
    out_Enthalpy = 2
    out_Pressure = 3
    out_SFRAC = 4
    out_Temperature = 5
    out_VaporFraction = 6
    out_X = 7
    out_Y = 8
    out_X1 = 9
    OUT_X2 = 10
End Enum

Public Function GetValues(flashCode As Long) As Long()

    Dim list() As Long
    
    Select Case flashCode
        Case FlashType.PH_LLE:      list = Me.PHLL.GetValues()
        Case FlashType.PH_VLE:      list = Me.PH.GetValues()
        Case FlashType.PH_VLLE:     list = Me.PH3.GetValues()
        Case FlashType.PS_VLE:      list = Me.PS.GetValues()
        Case FlashType.PU_VLE:      list = Me.PU.GetValues()
        Case FlashType.PV_VLE:      list = Me.PV.GetValues()
        Case FlashType.PV_VLLE:     list = Me.PV3.GetValues()
        Case FlashType.TH_LLE:      list = Me.THLL.GetValues()
        Case FlashType.TH_VLE:      list = Me.TH.GetValues()
        Case FlashType.TH_VLLE:     list = Me.TH3.GetValues()
        Case FlashType.TP_LLE:      list = Me.TPLL.GetValues()
        Case FlashType.TP_VLE:      list = Me.TP.GetValues()
        Case FlashType.TP_VLLE:     list = Me.TP3.GetValues()
        Case FlashType.TV_VLE:      list = Me.TV.GetValues()
        Case FlashType.TV_VLLE:     list = Me.TV3.GetValues()
        Case Else:
            MsgBox "Unknown return type defined.", vbOKOnly + vbExclamation, "VBConstantsFlashReturn"
            list = Empty
    End Select
    
    GetValues = list
    
End Function
