Attribute VB_Name = "VBConstantsFlashReturnPHLL"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnPHLL
    phll_Temperature = out_Temperature
    phll_Beta = out_Beta
    phll_X1 = out_X1
    phll_X2 = OUT_X2
    phll_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Temperature
    list(2) = Beta
    list(3) = X1
    list(4) = X2
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get Temperature() As Long
    Temperature = phll_Temperature
End Property

Public Property Get Beta() As Long
    Beta = phll_Beta
End Property

Public Property Get X1() As Long
    X1 = phll_X1
End Property

Public Property Get X2() As Long
    X2 = phll_X2
End Property

Public Property Get SFRAC() As Long
    SFRAC = phll_SFRAC
End Property




