Attribute VB_Name = "Main"
Dim eventClass As New claAppEvents
Public g_pkgName As String
Public g_InitialGlobalOpsetname As String
Public g_InitialGlobalHenry As String
Public g_InitialGlobalChemistry As String
Public g_InitialGlobalFreeWater As String
Public g_InitialGlobalTrueComps As Long
Public g_InitialGlobalSoluWater As Long
Public g_NeedToUpdatePackageName As Boolean
Public g_PropSys As ICapeThermoSystem
Public g_COPackage As ICapeThermoPropertyPackage
Public g_MaterialObject As ICapeThermoMaterialObject
Public g_MMVersion As String
Public g_MMGUI As String
Public g_MMCurVer As String
Public g_CapeOpenVersion As String
Public g_DeferredResolve As Boolean
Public g_strPropName As String
Public g_Tref As String
Public g_Pref As String
Public g_Quit As Boolean
Public g_AspenPropertiesKey As String
Public g_AspenPropertiesMMTOP As String
Public g_AspenPropertiesStartupdir As String
Public g_x64Excel As Boolean
Public g_APLicense As Boolean
Public g_FullPath As String
Public g_APropBit As Long
Public g_BaseUnitSet As String

Sub Auto_Add()

End Sub

Sub Auto_Remove()
    Dim count As Integer
    Dim i As Integer
    Dim mu As MenuItem

    On Error Resume Next
    count = Application.ShortcutMenus(xlWorksheetCell).MenuItems.count
    For i = count To 1 Step -1
        Set mu = Application.ShortcutMenus(xlWorksheetCell).MenuItems.Item(i)
        If mu.Caption = "&Aspen Properties" Then
            Application.ShortcutMenus(xlWorksheetCell).MenuItems.Item(i).Delete
            Exit Sub
        End If
    Next i
End Sub

Sub Auto_Open()
'
'    Initialize global variables
'
' 6/2/2009 by Yuhua Song. CQ00133247: Meaningful error messages from Properties Excel Calculator
'
    Call InitializeGlobalVariables
    Set eventClass.xlApp = Application
    
    With Application
    
'        .OnSheetActivate = "AddFunctionDetail"
     
        
        '.OnCalculate = "fnUnitText"
        '.OnEntry = "fnUnitText"
        
        
        .OnSheetActivate = "getUnits"
    End With
    'Setting flag to false as for each work book fist entry will not be recalculation - Jwalant
    breCalculation = False
    Call populateShortCutMenu
End Sub

Sub Auto_Close()
    Dim X As Integer
    X = 0
'    Set g_mtmpl = Nothing
'    Set g_AspenApp = Nothing
'If eventClass Is Nothing Then
'Else
'    Set eventClass = Nothing
'End If

    If mobjClass1 Is Nothing Then
    
    Else
        mobjClass1.bCloseApp = True
    End If
    If (g_APLicense = True) Then
    Call DeleteClass1
    End If
    
End Sub


