Attribute VB_Name = "VBConstantsPureProperty"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum AspenPureProperty
' pure      -   single
    pure_Enthalpy = AspenProperty.a_Enthalpy
    pure_Entropy = AspenProperty.a_Entropy
    pure_Fugacity = AspenProperty.a_Fugacity
    pure_FugacityCoefficient = AspenProperty.a_FugacityCoefficient
    pure_GibbsFreeEnergy = AspenProperty.a_GibbsFreeEnergy
    pure_GrossHeatingValue = AspenProperty.a_GrossHeatingValue
    pure_HeatCapacity = AspenProperty.a_HeatCapacity
    pure_HeatCapacityCv = AspenProperty.a_HeatCapacityCv
    pure_InternalEnergy = AspenProperty.a_InternalEnergy
    pure_LogFugacityCoefficient = AspenProperty.a_LogFugacityCoefficient
    pure_MassDensity = AspenProperty.a_MassDensity
    pure_SurfaceTension = AspenProperty.a_SurfaceTension
    pure_ThermalConductivity = AspenProperty.a_ThermalConductivity
    pure_Viscosity = AspenProperty.a_Viscosity
    pure_Volume = AspenProperty.a_Volume
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(15)
    list(1) = Enthalpy
    list(2) = Entropy
    list(3) = Fugacity
    list(4) = FugacityCoefficient
    list(5) = GibbsFreeEnergy
    list(6) = GrossHeatingValue
    list(7) = HeatCapacity
    list(8) = HeatCapacityCv
    list(9) = internalEnergy
    list(10) = LogFugacityCoefficient
    list(11) = MassDensity
    list(12) = SurfaceTension
    list(13) = ThermalConductivity
    list(14) = Viscosity
    list(15) = Volume
    GetValues = list
    
End Function

Public Property Get Enthalpy() As Long
    Enthalpy = AspenPureProperty.pure_Enthalpy
End Property

Public Property Get Entropy() As Long
    Entropy = AspenPureProperty.pure_Entropy
End Property

Public Property Get Fugacity() As Long
    Fugacity = AspenPureProperty.pure_Fugacity
End Property

Public Property Get FugacityCoefficient()
    FugacityCoefficient = AspenPureProperty.pure_FugacityCoefficient
End Property

Public Property Get GibbsFreeEnergy()
    GibbsFreeEnergy = AspenPureProperty.pure_GibbsFreeEnergy
End Property

Public Property Get GrossHeatingValue()
    GrossHeatingValue = AspenPureProperty.pure_GrossHeatingValue
End Property

Public Property Get HeatCapacity()
    HeatCapacity = AspenPureProperty.pure_HeatCapacity
End Property

Public Property Get HeatCapacityCv()
    HeatCapacityCv = AspenPureProperty.pure_HeatCapacityCv
End Property

Public Property Get internalEnergy()
    internalEnergy = AspenPureProperty.pure_InternalEnergy
End Property

Public Property Get LogFugacityCoefficient()
    LogFugacityCoefficient = AspenPureProperty.pure_LogFugacityCoefficient
End Property

Public Property Get MassDensity()
    MassDensity = AspenPureProperty.pure_MassDensity
End Property

Public Property Get SurfaceTension()
    SurfaceTension = AspenPureProperty.pure_SurfaceTension
End Property

Public Property Get ThermalConductivity()
    ThermalConductivity = AspenPureProperty.pure_ThermalConductivity
End Property

Public Property Get Viscosity()
    Viscosity = AspenPureProperty.pure_Viscosity
End Property

Public Property Get Volume()
    Volume = AspenPureProperty.pure_Volume
End Property

