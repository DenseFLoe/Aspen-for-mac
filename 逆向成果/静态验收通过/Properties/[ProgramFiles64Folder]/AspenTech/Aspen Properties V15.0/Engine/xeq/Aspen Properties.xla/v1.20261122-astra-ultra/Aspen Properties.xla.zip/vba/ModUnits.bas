Attribute VB_Name = "ModUnits"
Public arrPropTemp() As Variant
Public arrProp() As Variant
Public arrUnit() As Variant
Public arrPropUnit() As Variant


Sub fnUnitText()
    'NoteText for all selected cells for function wizard
    'Call populateShortCutMenu
    If Trim(strRangeUnitsApply) = "" Or Trim(strUnitsType) = "" Or Trim(strUnitsLabel) = "" Or strUnitsType = Empty Or strUnitsLabel = Empty Or bNoteText = False Then
        strRangeUnitsApply = ""
        Exit Sub
    End If
    Dim tempaddress As String
    tempaddress = Application.ActiveWindow.Selection.Address
    If strRangeUnitsApply = tempaddress Then
        Call fnSetUnitText(strUnitsType, strUnitsLabel)
    End If
    
    strUnitsType = ""
    strUnitsLabel = ""
    strRangeUnitsApply = ""
End Sub

Sub getUnits()
    Dim arrSize As Integer
    Dim strLine As String
    Dim blkNum As Integer
    Dim strRecord As String
    Dim arrSizeFound As Boolean
    Dim strNew As String
    Dim totalLen As Integer
    Dim startPos As Integer
    Dim endPos As Integer
    Dim i As Integer
    Dim strElement As String
    Dim strOld As String
    Dim arrPos As Integer
    Dim CountUnit As Integer
    ReDim arrProp(1, 1) As Variant
    Dim CountProp As Integer
    Dim oldTotal As String
    Dim fullPath As String
    
    fullPath = ThisWorkbook.Path
    On Error GoTo err_getunits
    Close #1
    Open fullPath & "\units.dat" For Input As #1
    
    arrSizeFound = False
    CountUnit = 0
    oldTotal = 0
    Do While Not EOF(1)
        Line Input #1, strLine
        strRecord = Trim(strLine)
        If Not (InStr(strRecord, "C$") <> 0) And strRecord <> Empty And InStr(strRecord, " ") <> 0 Then
            If IsNumeric(Mid(strRecord, 1, InStr(strRecord, " ") - 1)) Then
                If arrSizeFound = False Then
                    arrSize = Mid(strRecord, 1, InStr(strRecord, " ") - 1)
                    arrSizeFound = True
                    ReDim arrProp(arrSize, 5) As Variant
                    'Debug.Print strRecord
                Else
                    strNew = strRecord
                    totalLen = Len(strRecord)
                    startPos = 1
                    endPos = InStr(strNew, " ")
                    
                    i = 0
                    Do
                        If endPos = 0 Then
                            strElement = Mid(strNew, 1)
                            'ReDim Preserve arrProp(arrSize, i) As Variant
                            arrProp(CountProp, i) = strElement
                            Exit Do
                        Else
                            strElement = Trim(Mid(strNew, 1, endPos))
                        End If
                        strOld = strNew
                        strNew = Mid(strOld, endPos + 1)
                        endPos = InStr(strNew, " ")
                        If Trim(strElement) <> "" Then
                            'ReDim Preserve arrProp(arrSize, i) As Variant
                            If i = 0 Then
                             '  If CountProp = 101 Then
                                 'MsgBox CoutnProp
                                 'End If
                                arrProp(CountProp, 5) = CountUnit
                                arrProp(CountProp, i) = CountProp
                                blkNum = CountProp 'Val(strElement)
                                CountProp = CountProp + 1
'                            ElseIf i = 1 Then
'                                oldTotal = Val(strElement)
'                                arrProp(CountProp, i) = strElement
                               'arrProp(CountProp, 5) = oldTotal - CountUnit
                            Else
                                 If CountProp = 102 Then
                                   arrProp(CountProp, 5) = 671
                                   arrProp(CountProp, i) = strElement
                                 Else
                                arrProp(CountProp, i) = strElement
                                End If
                            End If
                            i = i + 1
'                            If i = 1 Then
'                                'arrPos = Val(strElement)
'                                blkNum = CountProp 'Val(strElement)
'                            End If
                            If i = 2 Then noTotalUnit = Val(noTotalUnit) + Val(strElement)
                        End If
                    Loop While strNew <> Empty
                End If
            Else
                If Mid(strRecord, 1, 2) <> "C$" And Mid(strRecord, 1, 5) <> "UNITS" Then
                    strNew = strRecord
                    totalLen = Len(strRecord)
                    startPos = 1
                    endPos = InStr(strNew, " ")
                    
                    i = 0
                    Do
                        If endPos = 0 Then
                            strElement = Mid(strNew, 1)
                            ReDim Preserve arrUnit(4, noTotalUnit) As Variant
                            If i = 0 Then
                                arrUnit(0, CountUnit) = blkNum
                                arrUnit(1, CountUnit) = strElement
                                i = 2
                            Else
                                arrUnit(i, CountUnit) = strElement
                            End If
                            Exit Do
                        Else
                            strElement = Trim(Mid(strNew, 1, endPos))
                        End If
                        strOld = strNew
                        strNew = Mid(strOld, endPos + 1)
                        endPos = InStr(strNew, " ")
                        If Trim(strElement) <> "" Then
                            ReDim Preserve arrUnit(4, noTotalUnit) As Variant
                            If i = 0 Then
                                arrUnit(0, CountUnit) = blkNum
                                arrUnit(1, CountUnit) = strElement
                                i = 1
                            Else
                                arrUnit(i, CountUnit) = strElement
                            End If
                            i = i + 1
                        End If
                    Loop While strNew <> Empty
                    oldTotal = noTotalUnit
                    CountUnit = CountUnit + 1
                End If
            End If
        End If
    Loop
    Close #1
    Call getPropUnits
    
    If Mid(Application.Version, 1, 1) <> "7" Then
        Call AddFunctionDetail
    End If
    
    ' Setting gUnitSet = nothing for each newly open work book
    gUnitSet = GetUnitSet()
    If gUnitSet = "" Then
       bInitUnitSet = False
    Else
       bInitUnitSet = True
    End If

    Exit Sub
err_getunits:
    If Trim(fullPath) <> "" Then
    'MsgBox "Error in getting units from Units.dat file in \Engine\xeq." & Chr(13) & "Please check if the file is missing or corrupted"
    MsgBox "Error in getting units from Units.dat file in " & fullPath & Chr(13) & "Please check if the file is missing or corrupted"
    End If
End Sub

Sub getPropUnits()
    Dim arrSize As Integer
    Dim strLine As String
    Dim blkNum As Integer
    Dim strRecord As String
    Dim arrSizeFound As Boolean
    Dim strNew As String
    Dim totalLen As Integer
    Dim startPos As Integer
    Dim endPos As Integer
    Dim i As Integer
    Dim strElement As String
    Dim strOld As String
    Dim arrPos As Integer
    Dim CountUnit As Integer
    Dim fullPath As String
    
    fullPath = ThisWorkbook.Path
    On Error GoTo err_getpropunits
    Close #2
    'Open ThisWorkbook.Path & "\propunits.dat" For Input As #2
    Open fullPath & "\propunits.dat" For Input As #2
    arrSizeFound = False
    CountUnit = 0
    Do While Not EOF(2)
        Line Input #2, strLine
        strRecord = Trim(strLine)
        If Not (InStr(strRecord, "C$") <> 0) And strRecord <> Empty And InStr(strRecord, " ") <> 0 Then
            If IsNumeric(Mid(strRecord, 1, InStr(strRecord, " ") - 1)) Then
                If arrSizeFound = False Then
                    arrSize = Mid(strRecord, 1, InStr(strRecord, " ") - 1)
                    arrSizeFound = True
                    ReDim Preserve arrPropUnit(arrSize, 9) As Variant
                    'Debug.Print strRecord
                End If
            Else
                strNew = strRecord
                totalLen = Len(strRecord)
                startPos = 1
                endPos = InStr(strNew, " ")
                    
                i = 0
                Do
                    If endPos = 0 Then
                        strElement = Mid(strNew, 1)
                        'ReDim Preserve arrProp(arrSize, i) As Variant
                        arrPropUnit(CountUnit, i) = strElement
                        Exit Do
                    Else
                        strElement = Trim(Mid(strNew, 1, endPos))
                    End If
                    strOld = strNew
                    strNew = Mid(strOld, endPos + 1)
                    endPos = InStr(strNew, " ")
                    If Trim(strElement) <> "" Then
                        'ReDim Preserve arrProp(arrSize, i) As Variant
                        arrPropUnit(CountUnit, i) = strElement
                        i = i + 1
                    End If
                Loop While strNew <> Empty
                CountUnit = CountUnit + 1
            End If
        End If
    Loop
    Close #2
    Exit Sub
err_getpropunits:
    If Trim(fullPath) <> "" Then
      'MsgBox "Error in getting property and units from propunits.dat file in \Engine\xeq." & Chr(13) & "Please check if the file is missing or corrupted"
      MsgBox "Error in getting property and units from propunits.dat file in " & fullPath & Chr(13) & "Please check if the file is missing or corrupted"
    End If
End Sub

