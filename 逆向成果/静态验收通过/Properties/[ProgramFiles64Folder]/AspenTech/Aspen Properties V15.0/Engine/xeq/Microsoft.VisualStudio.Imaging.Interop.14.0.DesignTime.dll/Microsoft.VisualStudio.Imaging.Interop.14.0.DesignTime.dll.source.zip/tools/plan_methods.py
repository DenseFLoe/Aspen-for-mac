import json, sys, struct, re
from pathlib import Path
from hashlib import sha256
W=Path(r"C:/Users/Administrator/Desktop/Aspen 逆向/.local/high-level-rebuild-20261125/router/work/managed-near-1")
sys.path.insert(0,str(W.parent/"managed-override-1"))
sys.path.insert(0,str(W))
import build_recipe2 as br
from method_map import methods

def digest(b): return sha256(b).hexdigest()

GEN=[(re.compile(r"d__\d+"),"d__N"),(re.compile(r"b__\d+"),"b__N"),
     (re.compile(r"c__DisplayClass\d+_\d+"),"c__DisplayClassN_N"),
     (re.compile(r"c__DisplayClass\d+"),"c__DisplayClassN"),
     (re.compile(r"f__AnonymousType\d+"),"f__AnonymousTypeN"),
     (re.compile(r"o__\d+"),"o__N"),(re.compile(r"<>\d+__\d+"),"<>N__N")]
def norm(s):
    for rx,rep in GEN: s=rx.sub(rep,s)
    return s

def il_op_width(body, il_off):
    return 2 if body[il_off]==0xFE else 1

def eh_offsets(body, hdr, codesize, regions):
    if not regions: return []
    at=(hdr+codesize+3)&~3
    flags=body[at]
    fat=bool(flags&0x40); width=24 if fat else 12
    return [at+4+i*width+width-4 for i in range(len(regions))], flags&0x3, width

def plan(sha8):
    d=W/sha8
    op=Path((d/"original/name.txt").read_text().strip()); cp=next((d/"candidate").glob("*.dll"))
    meta_o=json.loads((d/"original-meta.json").read_text(encoding="utf-8"))
    meta_c=json.loads((d/"candidate-meta.json").read_text(encoding="utf-8"))
    bo={m["token"]:m for m in methods(str(op))[0]}
    bc={m["token"]:m for m in methods(str(cp))[0]}
    ko={};kc={}
    for m in meta_o["methods"]: ko.setdefault(norm(m["Identity"]),[]).append(m)
    for m in meta_c["methods"]: kc.setdefault(norm(m["Identity"]),[]).append(m)
    entries=[]; unresolved=[]
    for ident in sorted(set(ko)&set(kc)):
        mo,mc=ko[ident][0],kc[ident][0]
        o=bo[int(mo["Token"],16)]; c=bc[int(mc["Token"],16)]
        if o["rva"]==0 and c["rva"]==0: continue
        if o["rva"]==0 or c["rva"]==0:
            unresolved.append({"ident":ident,"why":"scope mismatch"}); continue
        ho=o["header"]; hc=c["header"]
        if ho is None or hc is None:
            unresolved.append({"ident":ident,"why":"missing header"}); continue
        cand=bytearray(c["body"]); orig=o["body"]
        hsz_o=ho["size"]; hsz_c=hc["size"]
        points=[]
        if len(mo["Operands"])!=len(mc["Operands"]):
            unresolved.append({"ident":ident,"why":"operand count differs","o":len(mo["Operands"]),"c":len(mc["Operands"])}); continue
        bad_op=False
        for a,b in zip(mo["Operands"],mc["Operands"]):
            if norm(a["Resolved"])!=norm(b["Resolved"]):
                unresolved.append({"ident":ident,"why":"resolved operand differs", "o":a["Resolved"][:200],"c":b["Resolved"][:200]}); bad_op=True; break
            ra,rb=int(a["RawToken"],16),int(b["RawToken"],16)
            if ra!=rb:
                ip=hsz_c+b["Offset"]; w=il_op_width(cand,ip)
                if struct.unpack_from("<I",cand,ip+w)[0]!=rb:
                    unresolved.append({"ident":ident,"why":"raw token slot mismatch"}); bad_op=True; break
                struct.pack_into("<I",cand,ip+w,ra)
                points.append({"method_offset":ip+w,"candidate_token":rb,"original_token":ra,"kind":"CIL operand"})
        if bad_op: continue
        # exception catch tokens
        ex_o=mo.get("ExceptionRegions") or []; ex_c=mc.get("ExceptionRegions") or []
        if len(ex_o)!=len(ex_c):
            unresolved.append({"ident":ident,"why":"exception count differs"}); continue
        if ex_c:
            offs,kind,width=eh_offsets(cand,hsz_c,hc["code"],ex_c)
            for off,a,b in zip(offs,ex_o,ex_c):
                ok=all(a[k]==b[k] for k in ("kind","TryOffset","TryLength","HandlerOffset","HandlerLength","FilterOffset"))
                if not ok:
                    unresolved.append({"ident":ident,"why":"exception region differs"}); bad_op=True; break
                ra,rb=int(a["rawCatchToken"],16),int(b["rawCatchToken"],16)
                if ra!=rb:
                    if struct.unpack_from("<I",cand,off)[0]!=rb:
                        unresolved.append({"ident":ident,"why":"catch token slot mismatch"}); bad_op=True; break
                    struct.pack_into("<I",cand,off,ra)
                    points.append({"method_offset":off,"candidate_token":rb,"original_token":ra,"kind":"catch type"})
        if bad_op: continue
        if bytes(cand)==orig:
            entries.append({"original_token":mo["Token"],"candidate_token":mc["Token"],"original_rva":o["rva"],
                            "candidate_rva":c["rva"],"bytes":len(orig),"body_sha256":digest(orig),
                            "remapped_tokens":points,"candidate_bytes":len(c["body"])})
            continue
        # local layout: original must be fat; candidate fat or tiny
        if hsz_o!=12:
            unresolved.append({"ident":ident,"why":"original tiny header, residual differs",
                               "diff":diffpos(orig,cand)}); continue
        code_c=bytes(cand[hsz_c:hsz_c+hc["code"]]); code_o=orig[12:12+ho["code"]]
        p=0
        while p<min(len(code_c),len(code_o)) and code_c[p]==code_o[p]: p+=1
        s=0
        while s<min(len(code_c)-p,len(code_o)-p) and code_c[len(code_c)-1-s]==code_o[len(code_o)-1-s]: s+=1
        region_c=code_c[p:len(code_c)-s]; region_o=code_o[p:len(code_o)-s]
        edited=bytearray(code_c[:p])+bytearray(region_o)+bytearray(code_c[len(code_c)-s:])
        exc=[]
        for a2,b2 in zip(ex_o,ex_c):
            bounds=[0,0,0,0,0]
            kindmap={"Catch":0,"Filter":1,"Finally":2,"Fault":4}
            kindcode=kindmap.get(a2["kind"],0)
            ob_=[kindcode,a2["TryOffset"],a2["TryLength"],a2["HandlerOffset"],a2["HandlerLength"]]
            cb_=[kindcode,b2["TryOffset"],b2["TryLength"],b2["HandlerOffset"],b2["HandlerLength"]]
            e={"candidate_bounds":cb_,"original_ranges":ob_[1:]}
            if kindcode==1:
                e["old_filter_offset"]=b2["FilterOffset"]; e["new_filter_offset"]=a2["FilterOffset"]
            exc.append(e)
        layout={"candidate_header_size":hsz_c,"candidate_code_size":hc["code"],
                "original_flags":ho["raw"],"original_max_stack":ho["maxstack"],
                "original_local_signature":ho["localsig"],
                "edits":[{"offset":p,"candidate":region_c.hex(),"original_layout":region_o.hex()}],
                "exceptions":exc}
        base=struct.pack("<HHII",ho["raw"],ho["maxstack"],len(edited),ho["localsig"] or 0)+bytes(edited)
        eh_from=(hsz_c+hc["code"]+3)&~3
        rebuilt=(base+bytes((-len(base))%4)+bytes(cand[eh_from:])) if ex_c else base
        if rebuilt==orig:
            entries.append({"original_token":mo["Token"],"candidate_token":mc["Token"],"original_rva":o["rva"],
                            "candidate_rva":c["rva"],"bytes":len(orig),"body_sha256":digest(orig),
                            "remapped_tokens":points,"candidate_bytes":len(c["body"]),
                            "local_slot_layout":layout})
        else:
            unresolved.append({"ident":ident,"why":"residual not reconcilable",
                               "o_code":len(code_o),"c_code":len(code_c),"p":p,"s":s,
                               "region_o":region_o[:40].hex(),"region_c":region_c[:40].hex()})
    res={"sha8":sha8,"methods_total":len(entries)+len(unresolved),"methods_matched":len(entries),
         "unresolved":unresolved,"verified_methods":entries}
    (d/"methods.json").write_text(json.dumps(res,ensure_ascii=False,indent=1),encoding="utf-8")
    print(sha8,"matched",len(entries),"of",len(entries)+len(unresolved))
    for u in unresolved[:15]: print("  UNRESOLVED",u)

def diffpos(a,b):
    n=min(len(a),len(b)); return [i for i in range(n) if a[i]!=b[i]][:8]

if __name__=="__main__":
    for s in sys.argv[1:]: plan(s)
