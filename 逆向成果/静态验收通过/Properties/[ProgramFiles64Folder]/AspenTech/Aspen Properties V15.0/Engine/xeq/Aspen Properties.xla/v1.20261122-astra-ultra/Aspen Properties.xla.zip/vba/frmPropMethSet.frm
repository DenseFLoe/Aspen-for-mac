VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmPropMethSet 
   Caption         =   "Select Property Method Set"
   ClientHeight    =   6315
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6360
   OleObjectBlob   =   "frmPropMethSet.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmPropMethSet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Option Explicit
'
Private Const CONST_SETID As String = "SetId"
Private Const CONST_PROPMETH As String = "PropertyMethod"
Private Const CONST_CHEMID As String = "ChemistryID"
Private Const CONST_HENRYID As String = "HenryId"
Private Const CONST_FREEWATER As String = "FreeWaterMethod"
Private Const CONST_SOLUWATER As String = "SoluWaterOption"
Private Const CONST_APPROACH As String = "TrueComponents"
'
' Options for True-Comps
Private Const CONST_APPROACH_OPT1 As String = "True species"
Private Const CONST_APPROACH_OPT0 As String = "Apparent components"
'
' Options for Solu-Water
Private Const CONST_SOLUWATER_OPT0  As String = "0 - Solubility data and ideal vapor"
Private Const CONST_SOLUWATER_OPT1  As String = "1 - Solubility data"
Private Const CONST_SOLUWATER_OPT2  As String = "2 - Solubility data and correction"
Private Const CONST_SOLUWATER_OPT3  As String = "3 - Global method"
Private Const CONST_SOLUWATER_OPT4  As String = "4 - High water solubility for VLE"
'
Private Function SoluWaterGetStringFromLong(longValue As Long) As String
    SoluWaterGetStringFromLong = ""
    Select Case longValue
        Case 0
            SoluWaterGetStringFromLong = CONST_SOLUWATER_OPT0
            Exit Function
        Case 1
            SoluWaterGetStringFromLong = CONST_SOLUWATER_OPT1
            Exit Function
        Case 2
            SoluWaterGetStringFromLong = CONST_SOLUWATER_OPT2
            Exit Function
        Case 3
            SoluWaterGetStringFromLong = CONST_SOLUWATER_OPT3
            Exit Function
        Case 4
            SoluWaterGetStringFromLong = CONST_SOLUWATER_OPT4
            Exit Function
    End Select
End Function
'
Private Function SoluWaterGetLongFromString(strValue As String) As Long
    ' -1 means error
    SoluWaterGetLongFromString = -1
    On Error GoTo errExit
    Dim leftChar As String
    Dim longVal As Long
    leftChar = strValue
    leftChar = Trim(leftChar)
    ' check for blank string
    If leftChar = "" Then Exit Function
    leftChar = Left(leftChar, 1)
    ' convert to long
    longVal = CLng(leftChar)
    If longVal > -1 And longVal < 5 Then
        SoluWaterGetLongFromString = longVal
    End If
errExit:
'
End Function
'
Private Function ApproachGetStringFromLong(longValue As Long) As String
    ApproachGetStringFromLong = ""
    Select Case longValue
        Case 0
            ApproachGetStringFromLong = CONST_APPROACH_OPT0 ' apparent
            Exit Function
        Case 1
            ApproachGetStringFromLong = CONST_APPROACH_OPT1 ' true
            Exit Function
    End Select
End Function
'
Private Function ApproachGetLongFromString(strValue As String) As Long
    ' -1 means error
    ApproachGetLongFromString = -1
    On Error GoTo errExit
    Dim strTemp As String
    strTemp = strValue
    strTemp = Trim(strTemp)
    ' check for blank string
    If strTemp = "" Then Exit Function
    If UCase(strTemp) = UCase(CONST_APPROACH_OPT0) Then
        ApproachGetLongFromString = 0
    End If
    If UCase(strTemp) = UCase(CONST_APPROACH_OPT1) Then
        ApproachGetLongFromString = 1
    End If
errExit:
'
End Function

Private Sub cboApproach_Enter()
    lblComment.Caption = "Calculation approach for electrolytes. True species will use molecular solutes, ions and salts, apparent components will not."
End Sub

Private Sub cboApproach_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    lblComment.Caption = ""
End Sub

Private Sub cboChemistry_Enter()
    lblComment.Caption = "Chemistry ID selected from the list of chemistry specifications in the property package."
End Sub

Private Sub cboChemistry_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    lblComment.Caption = ""
End Sub

Private Sub cboFreeWater_Enter()
    lblComment.Caption = "Select property method for free water phase calculations."
End Sub

Private Sub cboFreeWater_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    lblComment.Caption = ""
End Sub

Private Sub cboHenryComp_Enter()
    lblComment.Caption = "Henry component list ID selected from the list of Henry component specifications in the property package."
End Sub

Private Sub cboHenryComp_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    lblComment.Caption = ""
End Sub

Private Sub cboPropertyMethod_Enter()
    lblComment.Caption = "Property method to be used in the calculations."
End Sub

Private Sub cboPropertyMethod_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    lblComment.Caption = ""
End Sub

Private Sub cboSoluWater_Enter()
    lblComment.Caption = "Method for calculating water solubility in free water"
End Sub

Private Sub cboSoluWater_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    lblComment.Caption = ""
End Sub

Private Sub txtMethSetID_Enter()
    lblComment.Caption = "Identifier for the method set. Provide an ID that allows easy identification of the method set."
End Sub

Private Sub txtMethSetID_Exit(ByVal Cancel As MSForms.ReturnBoolean)
    lblComment.Caption = ""
End Sub

Private Sub cmdCancel_Click()
   Me.Hide
   Unload frmPropMethSet
End Sub

Private Sub cmdHelp_Click()
    Call COMAddinHelper.ShowHelp("40009")
End Sub

Private Sub cmdOK_Click()
    Dim strSetID As String
    Dim strPropMeth As String
    Dim strHenryID As String
    Dim strChemistryID As String
    Dim strSoluWater As String
    Dim strFreeWater As String
    Dim strApproach As String
    '
    strSetID = txtMethSetID.value
    strSetID = Trim(strSetID)
    If Len(strSetID) = 0 Then
        MsgBox "Method set ID must be specified"
        Exit Sub
    End If
    '
    If InStr(strSetID, " ") <> 0 Or _
        InStr(strSetID, "=") <> 0 Or _
        InStr(strSetID, ",") <> 0 Then
        MsgBox "Commas, equals and spaces are not allowed in the method set ID"
        Exit Sub
    End If
    '
    strPropMeth = cboPropertyMethod.value
    strPropMeth = Trim(strPropMeth)
    If Len(strPropMeth) = 0 Then
        MsgBox "Property method must be specified"
        Exit Sub
    End If
    '
    strHenryID = cboHenryComp.value
    strHenryID = Trim(strHenryID)
    '
    strChemistryID = cboChemistry.value
    strChemistryID = Trim(strChemistryID)
    '
    strSoluWater = cboSoluWater.value
    strSoluWater = Trim(strSoluWater)
    If Len(strSoluWater) = 0 Then
        MsgBox "Water solubility method must be specified"
        Exit Sub
    End If
    Dim lSoluWater As Long
    lSoluWater = SoluWaterGetLongFromString(strSoluWater)
    If lSoluWater = -1 Then ' error
        MsgBox strSoluWater & " is an invalid water solubility method"
        Exit Sub
    End If
    '
    strFreeWater = cboFreeWater.value
    strFreeWater = Trim(strFreeWater)
    If Len(strFreeWater) = 0 Then
        MsgBox "Free water property method must be specified"
        Exit Sub
    End If
    '
    strApproach = cboApproach.value
    strApproach = Trim(strApproach)
    If Len(strApproach) = 0 Then
        MsgBox "Electrolyte calculation approach must be specified"
        Exit Sub
    End If
    Dim lTrueComps As Long
    lTrueComps = ApproachGetLongFromString(strApproach)
    If lTrueComps = -1 Then ' error
        MsgBox strApproach & " is an invalid electrolyte calculation approach"
        Exit Sub
    End If
    ' Chemistry must be specified for apparent components
    If Len(strChemistryID) = 0 And lTrueComps = 0 Then
        MsgBox "Chemistry must be specified for apparent-components approach"
        Exit Sub
    End If
    '
    ' write the specifications
    Call WriteMethSetToSelectedCell(strSetID, _
                                strPropMeth, _
                                strHenryID, _
                                strChemistryID, _
                                CStr(lSoluWater), _
                                strFreeWater, _
                                CStr(lTrueComps))
    ' close the form
    Me.Hide
    Unload frmPropMethSet
End Sub

Private Sub UserForm_Initialize()
    Dim i As Integer
    i = 0
    Dim lstFromAspenPkg As Variant
    Dim AspenPkg As IAspenPropertyPackage
    Set AspenPkg = g_COPackage
    On Error GoTo releaseAspenPkg
    '
    ' Populate property methods
    Call cboPropertyMethod.Clear
    lstFromAspenPkg = AspenPkg.ListAvailablePropertyMethods
    '
    If IsEmpty(lstFromAspenPkg) = False Then
        i = 0
        For i = LBound(lstFromAspenPkg) To UBound(lstFromAspenPkg)
            cboPropertyMethod.AddItem (lstFromAspenPkg(i))
        Next
        cboPropertyMethod.enabled = True
    Else
        cboPropertyMethod.enabled = False
    End If
    '
    ' Populate henry comps
    Call cboHenryComp.Clear
    lstFromAspenPkg = AspenPkg.ListAvailableHenryComps
    '
    If IsEmpty(lstFromAspenPkg) = False Then
        i = 0
        For i = LBound(lstFromAspenPkg) To UBound(lstFromAspenPkg)
            cboHenryComp.AddItem (lstFromAspenPkg(i))
        Next
        cboHenryComp.AddItem ("") ' allows blank
        cboHenryComp.enabled = True
    Else
        cboHenryComp.enabled = False
    End If
    '
    ' Populate chemistry
    Call cboChemistry.Clear
    lstFromAspenPkg = AspenPkg.ListAvailableChemistry
    '
    If IsEmpty(lstFromAspenPkg) = False Then
        i = 0
        For i = LBound(lstFromAspenPkg) To UBound(lstFromAspenPkg)
            cboChemistry.AddItem (lstFromAspenPkg(i))
        Next
        cboChemistry.AddItem ("") ' allows blank
        cboChemistry.enabled = True
    Else
        cboChemistry.enabled = False
    End If
    '
    ' Populate free water
    Call cboFreeWater.Clear
    lstFromAspenPkg = AspenPkg.ListAvailableFreeWaterOpsets
    '
    If IsEmpty(lstFromAspenPkg) = False Then
        i = 0
        For i = LBound(lstFromAspenPkg) To UBound(lstFromAspenPkg)
            cboFreeWater.AddItem (lstFromAspenPkg(i))
        Next
        cboFreeWater.enabled = True
    Else
        cboFreeWater.enabled = False
    End If
    '
    ' Populate true components
    Call cboApproach.Clear
    cboApproach.AddItem (CONST_APPROACH_OPT1) ' put true comps first
    cboApproach.AddItem (CONST_APPROACH_OPT0)
    '
    ' Populate solu water
    Call cboSoluWater.Clear
    cboSoluWater.AddItem (CONST_SOLUWATER_OPT0)
    cboSoluWater.AddItem (CONST_SOLUWATER_OPT1)
    cboSoluWater.AddItem (CONST_SOLUWATER_OPT2)
    cboSoluWater.AddItem (CONST_SOLUWATER_OPT3)
    cboSoluWater.AddItem (CONST_SOLUWATER_OPT4)
    '
    ' Check if the cell selected has a method set defined
    ' if so, use that method set as default
    Dim strDefSetID As String
    Dim strPropMeth As String
    Dim strHenryID As String
    Dim strChemistryID As String
    Dim strSoluWater As String
    Dim strFreeWater As String
    Dim strApproach As String
    Dim lTrueCompsApproach As Long
    Dim lSoluWater As Long
    '
    If GetSelectedCellMethodSet(strDefSetID, strPropMeth, strHenryID, _
                                strChemistryID, lSoluWater, strFreeWater, _
                                lTrueCompsApproach) = False Then
        ' get the default from the property package
        strDefSetID = ""
        Call AspenPkg.GetPropertyMethod(strPropMeth, strHenryID, strChemistryID, _
                                        lTrueCompsApproach, strFreeWater, lSoluWater)
    End If
    '
    ' fill the correct starting entries
    txtMethSetID.value = strDefSetID
    '
    Call ValidateAndSetComboEntry(strPropMeth, cboPropertyMethod, "Property Method")
    Call ValidateAndSetComboEntry(strHenryID, cboHenryComp, "Henry Component ID")
    Call ValidateAndSetComboEntry(strChemistryID, cboChemistry, "Chemistry ID")
    Call ValidateAndSetComboEntry(strFreeWater, cboFreeWater, "Free Water Property")
    strSoluWater = SoluWaterGetStringFromLong(lSoluWater)
    Call ValidateAndSetComboEntry(strSoluWater, cboSoluWater, "Water Solubility Method")
    strApproach = ApproachGetStringFromLong(lTrueCompsApproach)
    Call ValidateAndSetComboEntry(strApproach, cboApproach, "Electrolyte Calculation Approach")
releaseAspenPkg:
    ' release AspenPkg
    Set AspenPkg = Nothing
End Sub

Private Function GetSelectedCellMethodSet(ByRef strDefSetID As String, _
                                          ByRef strPropMeth As String, _
                                          ByRef strHenryID As String, _
                                          ByRef strChemistryID As String, _
                                          ByRef lSoluWater As Long, _
                                          ByRef strFreeWater As String, _
                                          ByRef lApproach As Long) _
                                          As Boolean
    GetSelectedCellMethodSet = False
    Dim txtSelectedCell As String
    Dim r As Range
    On Error GoTo errInFunction
    Set r = Application.Selection.Cells(1, 1)
    txtSelectedCell = r.value
    If txtSelectedCell = "" Or InStr(UCase(txtSelectedCell), UCase(CONST_SETID)) = 0 Then
        ' blank cell or this does not cureently contain a set ID
        Exit Function
    End If
    ' Now parse the text in the selected cell
    Dim bParseSuccess As Boolean
    Call ParseTextForMethodSet(txtSelectedCell, strDefSetID, strPropMeth, strHenryID, _
                                strChemistryID, lApproach, strFreeWater, _
                                 lSoluWater, bParseSuccess)
    If bParseSuccess = True Then
        GetSelectedCellMethodSet = True
        ' Need to change the ID to whatever case it was. Don't need
        ' to be as rigorous as the GetValueFromMethSet method. Look for
        ' the first = sign and then get the value following that
        Dim intPos As Integer
        Dim strTemp As String
        ' look for =
        intPos = InStr(txtSelectedCell, "=")
        ' look for the value beginning at the = sign
        intPos = InStr(intPos, UCase(txtSelectedCell), UCase(strDefSetID))
        ' Now get the correct string
        strTemp = Right(txtSelectedCell, Len(txtSelectedCell) - intPos + 1)
        strTemp = Left(strTemp, Len(strDefSetID))
        If UCase(strTemp) = UCase(strDefSetID) Then strDefSetID = strTemp
    End If
    
errInFunction:
End Function

Private Sub WriteMethSetToSelectedCell(strSetID As String, _
                                strPropMeth As String, _
                                strHenryID As String, _
                                strChemistryID As String, _
                                strSoluWater As String, _
                                strFreeWater As String, _
                                strApproach As String)
    Dim textToWrite As String
    Dim commentToWrite As String
    ' Set ID and Property ID has to be there, checked by caller
    textToWrite = CONST_SETID & "=" & strSetID & ", " & _
                    CONST_PROPMETH & "=" & strPropMeth
    commentToWrite = CONST_SETID & "=" & strSetID & vbLf & _
                    CONST_PROPMETH & "=" & strPropMeth
    '
    If Len(strHenryID) <> 0 Then
        textToWrite = textToWrite & ", " & CONST_HENRYID & "=" & strHenryID
        commentToWrite = commentToWrite & vbLf & CONST_HENRYID & "=" & strHenryID
    End If
    '
    If Len(strChemistryID) <> 0 Then
        textToWrite = textToWrite & ", " & CONST_CHEMID & "=" & strChemistryID
        commentToWrite = commentToWrite & vbLf & CONST_CHEMID & "=" & strChemistryID
    End If
    '
    If Len(strApproach) <> 0 Then
        textToWrite = textToWrite & ", " & CONST_APPROACH & "=" & strApproach
        commentToWrite = commentToWrite & vbLf & CONST_APPROACH & "=" & strApproach
    End If
    '
    If Len(strFreeWater) <> 0 Then
        textToWrite = textToWrite & ", " & CONST_FREEWATER & "=" & strFreeWater
        commentToWrite = commentToWrite & vbLf & CONST_FREEWATER & "=" & strFreeWater
    End If
    '
    If Len(strSoluWater) <> 0 Then
        textToWrite = textToWrite & ", " & CONST_SOLUWATER & "=" & strSoluWater
        commentToWrite = commentToWrite & vbLf & CONST_SOLUWATER & "=" & strSoluWater
    End If
    '
    Dim r As Range
    On Error GoTo errInFunction
    Set r = Application.Selection.Cells(1, 1)
    r.value = textToWrite
    r.Interior.ColorIndex = 39
    r.Font.Bold = True
    r.ClearComments
    r.AddComment (commentToWrite)
    r.Comment.Shape.TextFrame.AutoSize = True
errInFunction:
End Sub

Sub ParseTextForMethodSet(strText As String, _
                           ByRef strDefSetID As String, _
                           ByRef strPropMeth As String, _
                           ByRef strHenryID As String, _
                           ByRef strChemistryID As String, _
                           ByRef lApproach As Long, _
                           ByRef strFreeWater As String, _
                           ByRef lSoluWater As Long, _
                           ByRef bParseSuccess As Boolean)
    bParseSuccess = False
    If strText = "" Then Exit Sub
    On Error GoTo exitsub
    '
    Dim strTextUCase As String
    strTextUCase = UCase(strText)
    strTextUCase = Trim(strTextUCase)
    ' make sure setid and property method are present, otherwise this is meaningless
    If InStr(strTextUCase, UCase(CONST_SETID)) = 0 Or _
       InStr(strTextUCase, UCase(CONST_PROPMETH)) = 0 Then Exit Sub
    '
    ' Now get each value
    strDefSetID = GetValueFromMethSet(strTextUCase, CONST_SETID)
    If strDefSetID = "" Then Exit Sub
    '
    strPropMeth = GetValueFromMethSet(strTextUCase, CONST_PROPMETH)
    If strPropMeth = "" Then Exit Sub
    '
    ' Henry and Chemistry can be missing
    strHenryID = GetValueFromMethSet(strTextUCase, CONST_HENRYID)
    strChemistryID = GetValueFromMethSet(strTextUCase, CONST_CHEMID)
    '
    ' this should be there unless someone tampered with it
    ' but we will let it go even if missing
    lSoluWater = CLng(GetValueFromMethSet(strTextUCase, CONST_SOLUWATER))
    '
    ' this should be there unless someone tampered with it
    ' but we will let it go even if missing
    strFreeWater = GetValueFromMethSet(strTextUCase, CONST_FREEWATER)
    '
    ' this should be there unless someone tampered with it
    ' but we will let it go even if missing
    lApproach = CLng(GetValueFromMethSet(strTextUCase, CONST_APPROACH))
    '
    ' declare success
    bParseSuccess = True
exitsub:
End Sub

Private Function GetValueFromMethSet(strToParseUCase As String, strVariable As String) As String
    GetValueFromMethSet = ""
    On Error GoTo endFunction
    If strToParseUCase = "" Or strVariable = "" Then Exit Function
    '
    ' Make all comparisons upper case so that there is no confusion
    Dim strVariableUCase As String
    strVariableUCase = UCase(strVariable)
    '
    Dim varPosition As Integer
    varPosition = InStr(strToParseUCase, strVariableUCase)
    If varPosition = 0 Then Exit Function
    ' Now try to get value from Variable = Value . Value may be followed by space, end of string or comma
    Dim strTemp As String
    strTemp = Right(strToParseUCase, Len(strToParseUCase) - varPosition + 1)
    ' strTemp is now e.g. SETID = MYIDX, PROPERTYMETHOD = ...
    ' Now remove the variable name e.g. = MYIDX, PROPERTYMETHOD = ...
    strTemp = Right(strTemp, Len(strTemp) - Len(strVariableUCase))
    '
    Dim bEndLoop As Boolean
    Dim bFound As Boolean
    Dim strLeftChar As String
    bFound = False
    bEndLoop = False
    '
    ' Now look for = sign
    Do
        ' check if we are at the end of the string
        If Len(strTemp) = 0 Then Exit Function
        strLeftChar = Left(strTemp, 1)
        ' Move to next character
        strTemp = Right(strTemp, Len(strTemp) - 1)
        If strLeftChar = "=" Then
            bFound = True
            bEndLoop = True
        ElseIf strLeftChar <> " " Then
            ' This is invalid if the variable name is not followed by = or space
            Exit Function
        End If
    Loop While bEndLoop = False
    '
    ' Remove blank spaces on the left
    strTemp = LTrim(strTemp)
    '
    ' Now find the end of the variable name
    '
    ' check for empty string
    Dim lenStrTemp As Integer
    lenStrTemp = Len(strTemp)
    If lenStrTemp = 0 Then Exit Function
    '
    ' check for a , right after the =, which is invalid
    '
    strLeftChar = Left(strTemp, 1)
    If strLeftChar = "," Then Exit Function
    '
    ' Now find the position of the next comma or space or end of string
    Dim commaPos As Integer
    Dim spacePos As Integer
    commaPos = InStr(strTemp, ",")
    spacePos = InStr(strTemp, " ")
    '
    ' if commaPos is 0, there is no comma, then this can only be the last entry
    ' if there are intermediate spaces then this is wrong
    If commaPos = 0 And spacePos <> 0 Then Exit Function
    '
    ' if no comma or space then return the entire string
    If commaPos = 0 And spacePos = 0 Then
        GetValueFromMethSet = strTemp ' must be the entire string because this is the last entry
        Exit Function
    End If
    '
    ' This is the case where a comma and a space was found
    ' keep it simple, find the comma and then trim the string
    strTemp = Left(strTemp, commaPos - 1)
    strTemp = Trim(strTemp)
    GetValueFromMethSet = strTemp
endFunction:
'
End Function

Private Sub ValidateAndSetComboEntry(strValue As String, ByRef cboComboBox As ComboBox, strMsgVariable As String)
    Dim i As Integer
    Dim bFound As Boolean
    '
    ' fill out value
    If strValue <> "" Then
        bFound = False
        For i = 0 To (cboComboBox.ListCount - 1)
            If UCase(strValue) = UCase(cboComboBox.list(i)) Then
                bFound = True
                Exit For
            End If
        Next i
        If bFound = True Then
            cboComboBox.Text = cboComboBox.list(i)
        Else
            MsgBox "Specified " & LCase(strMsgVariable) & " " & strValue & _
                    " was not found in the current property package", _
                    vbOKOnly, "Invalid " & strMsgVariable & " in Set"
        End If
    End If
End Sub

Sub MethodIsSet(strMethodUCase As String, ByRef bIsSet As Boolean)
    If InStr(strMethodUCase, UCase(CONST_SETID)) = 0 Then
        bIsSet = False
    Else
        bIsSet = True
    End If
End Sub
