Attribute VB_Name = "VBConstantsFlashReturnTV"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnTV
    tv_Pressure = out_Pressure
    tv_Enthalpy = out_Enthalpy
    tv_X = out_X
    tv_Y = out_Y
    tv_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Pressure
    list(2) = Enthalpy
    list(3) = X
    list(4) = Y
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get Pressure() As Long
    Pressure = tv_Pressure
End Property

Public Property Get Enthalpy() As Long
    Enthalpy = tv_Enthalpy
End Property

Public Property Get X() As Long
    X = tv_X
End Property

Public Property Get Y() As Long
    Y = tv_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = tv_SFRAC
End Property



