Attribute VB_Name = "VBConstantsFlashReturnTH"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnTH
    th_Pressure = out_Pressure
    th_VaporFraction = out_VaporFraction
    th_X = out_X
    th_Y = out_Y
    th_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Pressure
    list(2) = VaporFraction
    list(3) = X
    list(4) = Y
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get Pressure() As Long
    Pressure = th_Pressure
End Property

Public Property Get VaporFraction() As Long
    VaporFraction = th_VaporFraction
End Property

Public Property Get X() As Long
    X = th_X
End Property

Public Property Get Y() As Long
    Y = th_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = th_SFRAC
End Property

