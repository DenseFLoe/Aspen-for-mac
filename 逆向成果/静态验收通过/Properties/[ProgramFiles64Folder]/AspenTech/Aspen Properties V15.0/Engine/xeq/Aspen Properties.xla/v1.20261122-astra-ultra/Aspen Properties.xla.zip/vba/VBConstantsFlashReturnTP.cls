Attribute VB_Name = "VBConstantsFlashReturnTP"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnTP
    tp_VaporFraction = out_VaporFraction
    tp_Enthalpy = out_Enthalpy
    tp_X = out_X
    tp_Y = out_Y
    tp_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = VaporFraction
    list(2) = Enthalpy
    list(3) = X
    list(4) = Y
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get VaporFraction() As Long
    VaporFraction = tp_VaporFraction
End Property

Public Property Get Enthalpy() As Long
    Enthalpy = tp_Enthalpy
End Property

Public Property Get X() As Long
    X = tp_X
End Property

Public Property Get Y() As Long
    Y = tp_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = tp_SFRAC
End Property
