Attribute VB_Name = "BrowseFolder"
Option Private Module
'this will allow you to browse for folder starting at your desktop.

Const MAX_PATH As Long = 260
Const dhcErrorExtendedError = 1208&
Const dhcNoError = 0&

'specify root dir for browse for folder by constants
'you can also specify values by constants for searhcable folders and options.
Const dhcCSIdlDesktop = &H0
Const dhcCSIdlPrograms = &H2
Const dhcCSIdlControlPanel = &H3
Const dhcCSIdlInstalledPrinters = &H4
Const dhcCSIdlPersonal = &H5
Const dhcCSIdlFavorites = &H6
Const dhcCSIdlStartupPmGroup = &H7
Const dhcCSIdlRecentDocDir = &H8
Const dhcCSIdlSendToItemsDir = &H9
Const dhcCSIdlRecycleBin = &HA
Const dhcCSIdlStartMenu = &HB
Const dhcCSIdlDesktopDirectory = &H10
Const dhcCSIdlMyComputer = &H11
Const dhcCSIdlNetworkNeighborhood = &H12
Const dhcCSIdlNetHoodFileSystemDir = &H13
Const dhcCSIdlFonts = &H14
Const dhcCSIdlTemplates = &H15


'constants for limiting choices for BrowseForFolder Dialog

Const dhcBifReturnAll = &H0
Const dhcBifReturnOnlyFileSystemDirs = &H1
Const dhcBifDontGoBelowDomain = &H2
Const dhcBifIncludeStatusText = &H4
Const dhcBifSystemAncestors = &H8
Const dhcBifBrowseForComputer = &H1000
Const dhcBifBrowseForPrinter = &H2000


'... you can get a lot more of these values from your integrated API viewer for constant specifcation or go to AllPai.net and see their samples.

#If VBA7 Then
    Public Type BROWSEINFO
      hWndOwner As LongPtr
      pidlRoot As Long
      pszDisplayName As String
      pszTitle As String
      ulFlags As Long
      lpfn As LongPtr
      lParam As LongPtr
      iImage As Long
    End Type
#Else
    Public Type BROWSEINFO
       hWndOwner As Long
       pidlRoot As Long
       pszDisplayName As String
       pszTitle As String
       ulFlags As Long
       lpfn As Long
       lParam As Long
       iImage As Long
    End Type
#End If

Public Function BrowseForFolder(ByVal lngCSIDL As Long, _
   ByVal lngBiFlags As Long, _
   strFolder As String, _
   Optional ByVal hWnd As Variant = 0, _
   Optional pszTitle As String = "Select Folder") As Long

    Dim usrBrws As BROWSEINFO
    Dim lngReturn As Long
    Dim lngIDL As Long
'
' No longer user.
'
BrowseForFolder = lngReturn

End Function


Function GetFolderBrowse() As String
    Dim strPath As String
    Dim result As Long
'
' No longer user.
'
    GetFolderBrowse = strPath
End Function


