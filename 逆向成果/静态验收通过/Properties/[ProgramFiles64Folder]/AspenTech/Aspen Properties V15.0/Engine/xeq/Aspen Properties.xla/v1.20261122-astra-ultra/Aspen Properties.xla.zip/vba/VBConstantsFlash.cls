Attribute VB_Name = "VBConstantsFlash"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashType
    PV_VLE      ' pressure-vapor fraction VLE flash
    PH_VLE      ' pressure-enthalpy VLE flash
    TP_VLE      ' temperature-pressure VLE flash
    TV_VLE      ' temperature-vapor fraction VLE flash
    TH_VLE      ' tempeature-enthalpy VLE flash
    PS_VLE      ' pressure-entropy VLE flash
    PU_VLE      ' pressure-internal energy VLE flash
    PV_VLLE     ' pressure-vapor fraction VLLE flash
    PH_VLLE     ' pressure-enthalpy VLLE flash
    TP_VLLE     ' temperature-pressure VLLE flash
    TV_VLLE     ' temperature-vapor fraction VLLE flash
    TH_VLLE     ' temperature-enthalpy VLLE flash
    PH_LLE      ' pressure-enthalpy LLE flash
    TP_LLE      ' temperature-pressure LLE flash
    TH_LLE      ' temperature-enthalpy LLE flash
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(15)
    list(1) = PVFlash
    list(2) = PHFlash
    list(3) = TPFlash
    list(4) = TVFlash
    list(5) = THFlash
    list(6) = PSFlash
    list(7) = PUFlash
    list(8) = PVFlash3
    list(9) = PHFlash3
    list(10) = TPFlash3
    list(11) = TVFlash3
    list(12) = THFlash3
    list(13) = PHFlashLL
    list(14) = TPFlashLL
    list(15) = THFlashLL
    
    GetValues = list
    
End Function

Public Property Get PVFlash() As Long
    PVFlash = PV_VLE
End Property

Public Property Get PHFlash() As Long
    PHFlash = PH_VLE
End Property

Public Property Get TPFlash() As Long
    TPFlash = TP_VLE
End Property

Public Property Get TVFlash() As Long
    TVFlash = TV_VLE
End Property

Public Property Get THFlash() As Long
    THFlash = TH_VLE
End Property

Public Property Get PSFlash() As Long
    PSFlash = PS_VLE
End Property

Public Property Get PUFlash() As Long
    PUFlash = PU_VLE
End Property

Public Property Get PVFlash3() As Long
    PVFlash3 = PV_VLLE
End Property

Public Property Get PHFlash3() As Long
    PHFlash3 = PH_VLLE
End Property

Public Property Get TPFlash3() As Long
    TPFlash3 = TP_VLLE
End Property

Public Property Get TVFlash3() As Long
    TVFlash3 = TV_VLLE
End Property

Public Property Get THFlash3() As Long
    THFlash3 = TH_VLLE
End Property

Public Property Get PHFlashLL() As Long
    PHFlashLL = PH_VLLE
End Property

Public Property Get TPFlashLL() As Long
    TPFlashLL = TP_VLLE
End Property

Public Property Get THFlashLL() As Long
    THFlashLL = TH_VLLE
End Property






