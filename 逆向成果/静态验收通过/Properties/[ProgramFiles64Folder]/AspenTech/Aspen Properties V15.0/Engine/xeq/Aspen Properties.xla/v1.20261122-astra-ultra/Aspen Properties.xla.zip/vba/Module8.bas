Attribute VB_Name = "Module8"
Public firstRow As Integer
Public firstCol As Integer
Public sG_UnitSet As String
Public English(0 To 4)  ' As Variant
Public SI(0 To 4)    'As Variant
Public Metrics(0 To 4) '  As Variant
Public aUnitSet(0 To 6) As Variant
Public itemCount As Integer
Dim sGlobalUnit As String
Public gUnitSet As String
Public bInitUnitSet As Boolean
Public strNew As String
Public strWord As String
Public strUnitVal As String
Dim slblName As String
Dim lcharCount As Long
Dim usrResponse As Integer


Private Sub ClearPreviousPropertyPackage()
    Set g_COPackage = Nothing
    Set g_MaterialObject = Nothing
End Sub

'Sub     : ClearPreviousGlobalUnitSet()
'        : Clears the defined global unit set on the excel spread sheet
'Created : 04/17/2002
'Author  : Jwalant Vyas
 Sub ClearPreviousGlobalUnitSet()
    Dim count As Integer
    Dim i As Integer
    count = Application.Worksheets.count
    On Error Resume Next
    For i = 1 To count
        Application.Worksheets(i).Range("UnitSet").Clear
    Next i
End Sub

'Sub     : SetNewUnitSetRange()
'        : Sets user defined global unit set on the excel spread sheet
'Created : 04/17/2002
'Author  : Jwalant Vyas
 
Private Sub SetNewUnitSetRange()
    Dim r As Range
    Set r = Application.Selection.Cells(1, 1)
    r.value = gUnitSet
    names.Add "UnitSet", "=" & r.Address
End Sub



Private Function GetBkpFromFullPath(strFullPath As String) As String
    Dim fullPath As String
    Dim slashPos As Integer
    GetBkpFromFullPath = ""
    fullPath = strFullPath
    If strFullPath = "" Then Exit Function
    slashPos = InStrRev(fullPath, "\")
    If slashPos = 0 Then
        GetBkpFromFullPath = fullPath
        Exit Function
    End If
    GetBkpFromFullPath = Right(fullPath, Len(fullPath) - slashPos)
End Function

' This is called for a deferred checkout of a license. When the user chooses
' Select Property Package/New, it launches the Aspen Properties application
' That application consumes a license. When this function is called we do
' not want to check out another license by calling ResolvePropertyPackage
' Instead we defer the call to till after the application is closed
' Here we make sure we save the information necessary in order to
' resolve the property package at a later time
Public Sub SelectPropertyPackageDeferred()
    ' this is called from the event of the new application only after
    ' everything has been saved and the aprpdf file size confirmed
    ' So we need not be that cautious. We can assume that the
    ' aprpdf file will work and the package is legitimate
    Call ClearPreviousPropertyPackage
    g_pkgName = mobjClass1.strPath
    COMAddinHelper.UpdatePackage (g_pkgName)
    g_NeedToUpdatePackageName = True
End Sub

' Completes the actions deferred by calling SelectPropertyPackageDeferred
' this is called right after the class that created the Aspen Properties
' application and captured its events is deleted. That way the license
' would be returned by the other application
Public Sub CompleteTheDeferredResolvePackage()
    If g_NeedToUpdatePackageName = True Then
        On Error GoTo resetUpdateFlag
        COMAddinHelper.UpdatePackage (g_pkgName)
        'Call ResolveGlobalPackageAndMaterialObject
resetUpdateFlag:
        g_NeedToUpdatePackageName = False
    End If
End Sub

' deletes a pdf file if it is older than the bkp file - CapeOpen will resolve
' take care of generation of a new pdf file
Sub ComparePDFdateWithBKPdateAndDelPDF(strBKPName As String)
    Dim sFileName As String
    Dim sAPROPName As String
    Dim sPDFName As String
    ' make sure that the pdf is more recent than the aprbkp file
    If strBKPName = "" Then Exit Sub
    If DirCatch(strBKPName) = "" Then Exit Sub
    If FileLen(strBKPName) = 0 Then Exit Sub

    If InStr(strBKPName, ".aprbkp") = 0 Then Exit Sub
    
    sFileName = Left(strBKPName, InStr(strBKPName, ".aprbkp"))
    
    sPDFName = sFileName + "aprpdf"
    sAPROPName = sFileName + "aprop"
    
    If CheckPDF(sPDFName, strBKPName) < 0 Then
        KillExists (sPDFName)
    End If

End Sub

Private Function CheckPDF(sPDFFileName As String, sBKPFileName As String) As Integer
    Dim dateDiff As Date
    Dim datePDF As Date
    Dim dateBKP As Date
    
    If DirCatch(sPDFFileName) = "" Then
        CheckPDF = -1
        Exit Function
    End If
    If FileLen(sPDFFileName) = 0 Then
        CheckPDF = -1
        Exit Function
    End If
    datePDF = FileDateTime(sPDFFileName)
    dateBKP = FileDateTime(sBKPFileName)
    If datePDF > dateBKP Then
        CheckPDF = 0
    Else
        CheckPDF = -1
    End If
End Function


' Subroutine : SelectUnit_Click(sFormName As String)
'            : Takes input from frmGlobalUnitSet and displays it on the excel interface
'
' Created    : 04/05/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub SelectUnit_Click(sFormName As String)
 
With frmGlobalUnitSet
    sGlobalUnit = .cmbGlobalUnitSetList.Text
    sG_UnitSet = "Global Units Set: " + sGlobalUnit
    Select Case sGlobalUnit
        Case "English"
            CheckUnitArray (English())
        Case "SI"
            CheckUnitArray (SI())
        Case "Metric", "Metrics"
            CheckUnitArray (Metrics())
        Case Else
            sG_UnitSet = sG_UnitSet + "  Temperature: " + .cmbTemperatureList.Text
            sG_UnitSet = sG_UnitSet + "  Pressure: " + .cmbPressureList.Text
            sG_UnitSet = sG_UnitSet + "  Molar Heat Capacity: " + .cmbMolarCP.Text
            sG_UnitSet = sG_UnitSet + "  Molar Enthalpy: " + .cmbMolarEnthalpy.Text
            sG_UnitSet = sG_UnitSet + "  Molar Volume: " + .cmbMolarVol.Text
            'sG_UnitSet = sG_UnitSet + "  BaseUnitSet: " + .BaseUnitSet
            sG_UnitSet = sG_UnitSet + "  BaseUnitSet: " + g_BaseUnitSet
            Call COMAddinHelper.StoreUnitDefinition(sGlobalUnit, sG_UnitSet)
    End Select
    .Hide
End With

SetNewUnitSet (sG_UnitSet)
End Sub


Public Sub SetNewUnitSet(unitDef As String)

Dim r As Range
Dim c As Range
Dim rowNo As Long
Dim columnNo As Long
Dim rowId As Long
Dim columnId As Long
Dim uLable As String

With Application.ActiveWindow.ActiveCell
    rowNo = .Row
    columnNo = .Column
End With

If IsGlobalUnitSetAvailable = True Then
    Call ClearPreviousGlobalUnitSet
End If

With Application.Cells
        On Error Resume Next
        Set r = .SpecialCells(xlCellTypeFormulas)
        If r Is Nothing Then
            breCalculation = False
        Else
            breCalculation = True
        End If
    End With

If (unitDef <> gUnitSet And bInitUnitSet = True) Or (unitDef <> gUnitSet And breCalculation = True) Then
    
        ' bInitUnit = False
        usrResponse = MsgBox("You are changing global units set, property calculations will be updated using the new units set. Do you want to continue ?", vbYesNo)
        If usrResponse = vbNo Then
            With Application.Cells(rowNo, columnNo)
                .Select
                .value = gUnitSet
                Application.ActiveWindow.Selection.Font.Bold = True
                Application.ActiveWindow.Selection.Interior.ColorIndex = 34
            End With
            Exit Sub
        Else
            gUnitSet = unitDef
            SetNewUnitSetRange
        
            ' Checking flag to ensure that atleast one calculation is present on the excel sheet
            If breCalculation = True Then
                frmUpdation.Show
                frmUpdation.Repaint
                'Following code implements auto calculation and auto label setting whenever user
                ' makes changes with global unit set - Added by Jwalant Vyas
                Application.CalculateFull
                With Application.Cells
                    Set r = .SpecialCells(xlCellTypeFormulas)
                    For Each c In r
                    On Error Resume Next
                            slblName = c.Item(1).Comment.Shape.AlternativeText
                            lcharCount = InStr(slblName, ":")
                            slblName = Mid(slblName, InStr(slblName, ":") + 1)
                            slblName = LTrim(slblName)
                            slblName = Left(slblName, InStr(slblName, ":"))
                            slblName = Mid(slblName, 1, (Len(slblName) - 1))
                            slblName = Mid(slblName, 2, Len(slblName))
                            uLable = SetGetLabel(slblName)
                            Application.Cells(c.Row, c.Column).Comment.Text "{" + slblName + ":" + uLable + "}"
                    Next c
                End With
                With Application.Cells(rowNo, columnNo).Select
                End With
                Unload frmUpdation
            End If
        End If
    Else
        gUnitSet = unitDef
        bInitUnitSet = True
        SetNewUnitSetRange
    End If
    
    Application.ActiveWindow.Selection.Font.Bold = True
    Application.ActiveWindow.Selection.Interior.ColorIndex = 34
    
ParseUnitSet (gUnitSet)
COMAddinHelper.UpdateRibbon
End Sub

' Subroutine : CheckUnitArray(sarrayName As Variant)
'            : Checks the input array for verifying the user input (unit type) for a particular
'              property vs. unit type for the same property based on global unit type
' Created    : 04/05/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Private Sub CheckUnitArray(sarrayName As Variant)
Dim arrayCounter As Integer
Dim blblFlag As Boolean
With frmGlobalUnitSet
    If .cmbTemperatureList.Text <> sarrayName(0) Then
        sG_UnitSet = sG_UnitSet + "  Temperature: " + .cmbTemperatureList.Text
    End If
    If .cmbPressureList.Text <> sarrayName(1) Then
       sG_UnitSet = sG_UnitSet + "  Pressure: " + .cmbPressureList.Text
    End If
    If .cmbMolarCP.Text <> sarrayName(4) Then
       sG_UnitSet = sG_UnitSet + "  Molar Heat Capacity: " + .cmbMolarCP.Text
    End If
    If .cmbMolarEnthalpy.Text <> sarrayName(3) Then
        sG_UnitSet = sG_UnitSet + "  Molar Enthalpy: " + .cmbMolarEnthalpy.Text
    End If
    If .cmbMolarVol.Text <> sarrayName(2) Then
        sG_UnitSet = sG_UnitSet + "  Molar Volume: " + .cmbMolarVol.Text
    End If
 End With
End Sub

' Function   : ParseUnitSet(sUnitString As String)
'            : Parse global unit set string and sets it in aUnitSet() array
'            :
' Created    : 04/17/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub ParseUnitSet(sUnitString As String)
Dim bTemperature As Boolean
Dim bPressure As Boolean
Dim bMolarHeatCapacity As Boolean
Dim bMolarVolume As Boolean
Dim bMolarEnthalpy As Boolean
Dim bBaseUnitSet As Boolean
Dim countIndex As Integer
bTemperature = False
bPressure = False
bMolarHeatCapacity = False
bMolarVolume = False
bMolarEnthalpy = False
'ReDim aUnitSet(0)

strNew = Trim(sUnitString)
countIndex = 0
Do
    strWord = Mid(strNew, 1, InStr(strNew, ":"))
    strNew = Mid(strNew, InStr(strNew, ":") + 1)
    strNew = Mid(strNew, 2)
    If InStr(strNew, " ") = 0 Then
      strUnitVal = Left(strNew, Len(strNew))
      strNew = Empty
    Else
        strUnitVal = Mid(strNew, 1, InStr(strNew, " ") - 1)
        strNew = Mid(strNew, (Len(strUnitVal) + 1))
        strNew = Mid(strNew, InStr(strNew, " ") + 1)
    End If
    Select Case strWord
        Case "Global Units Set:"
              aUnitSet(0) = strUnitVal
        Case " Temperature:"
             ' ReDim Preserve aUnitSet(1)
              aUnitSet(1) = strUnitVal
              bTemperature = True
              
        Case " Pressure:"
             'ReDim Preserve aUnitSet(2)
              aUnitSet(2) = strUnitVal
               bPressure = True
        Case " Molar Volume:"
              'ReDim Preserve aUnitSet(3)
              aUnitSet(3) = strUnitVal
               bMolarVolume = True
        Case " Molar Enthalpy:"
              'ReDim Preserve aUnitSet(4)
              aUnitSet(4) = strUnitVal
               bMolarEnthalpy = True
        Case " Molar Heat Capacity:"
              'ReDim Preserve aUnitSet(5)
              aUnitSet(5) = strUnitVal
               bMolarHeatCapacity = True
        Case " BaseUnitSet:"
              aUnitSet(6) = strUnitVal
              bBaseUnitSet = True
    End Select
  'countIndex = countIndex + 1
 Loop While (Len(strNew) <> 0)
 'If countIndex < 5 Then
    If bTemperature = False Then
       aUnitSet(1) = Empty
       
    End If
    If bPressure = False Then
       aUnitSet(2) = Empty
    End If
    If bMolarHeatCapacity = False Then
       aUnitSet(5) = Empty
    End If
    If bMolarVolume = False Then
       aUnitSet(3) = Empty
    End If
    If bMolarEnthalpy = False Then
       aUnitSet(4) = Empty
    End If
    If (bBaseUnitSet = False) Then
        aUnitSet(6) = aUnitSet(0)
    End If
    
          
 'End If
 
End Sub

Sub ResolveGlobalPackageAndMaterialObject()
    Dim bHasBkpAtSpecifiedLocation As Boolean
    ' Clear the previous property package
    Set g_COPackage = Nothing
    Set g_MaterialObject = Nothing
    g_InitialGlobalOpsetname = ""
    g_InitialGlobalHenry = ""
    g_InitialGlobalChemistry = ""
    g_InitialGlobalFreeWater = ""
    g_InitialGlobalTrueComps = -1
    g_InitialGlobalSoluWater = -1
    '
    ' Resolve the new property package
    If g_pkgName = "" Then
        Exit Sub
    End If
'
' 10/09/2009, Yuhua Song
' CQ00133247: Licensing error message for Properties Excel Calculator:
'
    ' fetch the property package
    On Error GoTo propPkg

    If g_PropSys Is Nothing Then
        If g_CapeOpenVersion = "" Then
           Call InitializeGlobalVariables
        End If
        Set g_PropSys = CreateObject("ATCOProperties.COPropertySystem." + g_CapeOpenVersion)
        Dim AspenPropSys As IAspenCapeThermoSystem
        Set AspenPropSys = g_PropSys
        Call AspenPropSys.SetPropertiesExclusiveLicense
'
' 10/09/2009, Yuhua Song
' CQ00133247: Licensing error message for Properties Excel Calculator:
'
' \\ap\source\atcapeopen\atcoproperties\COPropSys.cpp
'
        Call AspenPropSys.SetPropertiesExcelAddin
        Set AspenPropSys = Nothing
    End If
'
' If no Aspen Properties license is available of an error happenes,
' an message will pop up as "Aspen Properties Excel Calculator encounters a fatal licensing error and needs to close."
' The message is from "ap\source\atcapeopen\atcohelper\APRSystem.cpp\ABORT_HANDLER ()".
'
' YS: 1/31/2018. For .cota package, default, hcgas, and simple, they may need to be upgraded. Otherwise, this call may fail.
' ap\source\atcapeopen\atcoproperties\COPropSys.cpp
    Set g_COPackage = g_PropSys.ResolvePropertyPackage(g_pkgName)
    
    If g_COPackage Is Nothing Then
        MsgBox "Failed to resolve Property Package " & g_pkgName
        Exit Sub
    End If
    
    Call g_COPackage.getComponentList(compids, formulae, strName, boiltemps, molwt, casno)

    ' Force the type to VT_BSTR|VT_ARRAY - CapeOpen checks for this
    ReDim compids(UBound(compids)) As String
    Call g_COPackage.getComponentList(compids, formulae, strName, boiltemps, molwt, casno)
    
    ' This material object is just a container
    ' and does not need to know about the package, so just create it
    Set g_MaterialObject = CreateObject("ATCOMaterial.COMaterialObject." + g_CapeOpenVersion)
    '
    ' fetch the global property method
    On Error GoTo trapPkg
    Dim AspenPkg As IAspenPropertyPackage
    Set AspenPkg = g_COPackage
    '
    Call AspenPkg.GetPropertyMethod(g_InitialGlobalOpsetname, _
                                    g_InitialGlobalHenry, _
                                    g_InitialGlobalChemistry, _
                                    g_InitialGlobalTrueComps, _
                                    g_InitialGlobalFreeWater, _
                                    g_InitialGlobalSoluWater)
trapPkg:
    Set AspenPkg = Nothing
    Exit Sub
propPkg:
'
' 10/09/2009, Yuhua Song
' CQ00133247: Licensing error message for Properties Excel Calculator:
'
' This message will pop up in \\ap\source\atcapeopen\atcohelper\APRSystem.cpp\ABORT_HANDLER ()
'
'    MsgBox "FATAL LICENSING ERROR FOR ASPEN PROPERTIES AND EXCEL HAS TO CLOSE"
    If g_COPackage Is Nothing Then
        MsgBox "Failed to resolve Property Package " & g_pkgName & "."
        g_pkgName = ""
    End If
End Sub
'
Sub InitializeGlobalVariables()
'
' Yuhua Song, 10/22/2009
' CQ00389139: Un-initialization of global variables.
'
' Check Excel bit: x86 or x64 and Aspen Properties: x86 or x64
'
    Call CheckExcel
    If (g_AspenPropertiesKey = "") Then
      Exit Sub
    End If
'
    g_APLicense = True
    g_Tref = 0.00001
    g_Pref = 0.00001
    g_MMVersion = "41.0"
    g_MMGUI = "V15.0"
    g_CapeOpenVersion = "41.0"
    g_DeferredResolve = False
    g_Quit = False
    g_NeedToUpdatePackageName = False
    g_FullPath = ""
    g_BaseUnitSet = "SI"

'#If Win64 Then '64-bit Excel with 32-bit Aspen Properties
'  g_AspenPropertiesKey = "SOFTWARE\Wow6432Node\AspenTech\Aspen Properties\"
'#Else '32-bit Excel
'  g_AspenPropertiesKey = "SOFTWARE\AspenTech\Aspen Properties\"
'#End If
    
    Call CheckMatch
    
End Sub

Sub CheckExcel()
    Dim ver2 As String
    Dim v64PathKey As String
    Dim v64 As String

' Check Excel: 32-bit or 64-bit
    ' Call COM
    v64 = Invoke("APXL_GetExcelBitness")
    '
    If v64 = "x64" Then
          g_x64Excel = True
    Else
          g_x64Excel = False
    End If
'
' Set g_AspenPropertiesKey and get g_MMCurVer
'[HKEY_LOCAL_MACHINE\SOFTWARE\AspenTech\Aspen Properties\CurVer]
'@= "41.0"
'
    g_AspenPropertiesKey = "SOFTWARE\AspenTech\Aspen Properties\"
    '
    ' Call COM
    g_MMCurVer = Invoke("APXL_GetCurrentVersion")
    '
    If g_MMCurVer = "" Then
        g_AspenPropertiesKey = "" ' No AProp installed.
        MsgBox "Aspen Properties is not installed. Please check your installation." & vbCr, _
          vbOKOnly, "Warning: Aspen Properties Excel Calculator"
        Exit Sub
    End If
End Sub


Sub CheckMatch()
    Dim Version1 As String
    Select Case g_MMVersion
       Case "22.0"
       Version1 = "V7.0"
       Case "23.0"
       Version1 = "V7.1"
       Case "24.0"
       Version1 = "V7.2"
       Case "25.0"
       Version1 = "V7.3"
       Case "26.0"
       Version1 = "V7.3.2"
       Case "27.0"
       Version1 = "V8.0"
       Case "28.0"
       Version1 = "V8.2"
       Case "30.0"
       Version1 = "V8.4"
       Case "32.0"
       Version1 = "V8.6"
       Case "34.0"
       Version1 = "V8.8"
       Case "35.0"
       Version1 = "V9"
       Case "36.0"
       Version1 = "V10"
       Case "37.0"
       Version1 = "V11"
       Case "38.0"
       Version1 = "V12"
       Case "39.0"
       Version1 = "V12.1"
       Case "40.0"
       Version1 = "V14.0"
       Case "41.0"
       Version1 = "V15.0"
       Case Else
       Version1 = "Unknown version"
    End Select
    '
    ' Call COM
    g_MMCurVer = Invoke("APXL_GetCurrentVersion")
    '
    If g_MMCurVer <> g_MMVersion Then
        Dim Version2 As String
        Select Case g_MMCurVer
           Case "22.0"
           Version2 = "V7.0."
           Case "23.0"
           Version2 = "V7.1."
           Case "24.0"
           Version2 = "V7.2."
           Case "25.0"
           Version2 = "V7.3."
           Case "26.0"
           Version2 = "V7.3.2."
           Case "27.0"
           Version2 = "V8.0."
           Case "28.0"
           Version2 = "V8.2."
           Case "30.0"
           Version2 = "V8.4."
           Case "32.0"
           Version2 = "V8.6."
           Case "34.0"
           Version2 = "V8.8."
           Case "35.0"
           Version2 = "V9."
           Case "36.0"
           Version2 = "V10."
           Case "37.0"
           Version2 = "V11."
           Case "38.0"
           Version2 = "V12."
           Case "39.0"
           Version2 = "V12.1."
           Case "40.0"
           Version2 = "V14.0."
           Case "41.0"
           Version2 = "V15.0."
           Case Else
           Version2 = "Unknown version"
        End Select

        MsgBox "Warning: you are running Aspen Properties Excel Add-in " + Version1 + " with Aspen Properties " + Version2 & _
              " The mismatch may result in wrong results from property or flash calculations. You can run 'Set Version' to fix the Aspen Properties version or select the same version of Excel Add-in from Aspen Excel Add-in Manager." & vbCr, _
        vbOKOnly, "Excel Add-in should run with the same version of Aspen Properties"
        'Application.ActiveWorkbook.Close
        'Application.Quit
        Exit Sub
    End If
End Sub
' make sure that the correct Aspen Properties.xla is referenced
Sub CheckIfLinksAreConsistent()
    Dim strLinkName As String
    Dim aLinks As Variant
    Dim strCorrectXlaPath As String
    
    On Error GoTo exitError
    If g_MMVersion = "" Then
       Call InitializeGlobalVariables
    End If
    '
    ' Call COM
    strCorrectXlaPath = Invoke("APXL_GetCorrectXlaPath") '"c:\\Program Files\\AspenTech\\Aspen Properties VXX.0\\Engine\\xeq\\Aspen Properties.xla"
    '
    'MsgBox strCorrectXlaPath
    If strCorrectXlaPath = "" Then
        MsgBox "Error: Could not locate the installation location of Aspen Properties " + g_MMVersion + " in the registry"
        Exit Sub
    End If

    ' make sure the xla file is present
    If DirCatch(strCorrectXlaPath) = "" Then
        MsgBox ("Error: Aspen Properties.xla was not found in the installed location" & strCorrectXlaPath)
        Exit Sub
    End If
    aLinks = ActiveWorkbook.LinkSources(xlExcelLinks)
    If Not IsEmpty(aLinks) Then
        For i = 1 To UBound(aLinks)
            strLinkName = aLinks(i)
            If InStr(LCase(strLinkName), "aspen properties.xla") Then
                If LCase(strLinkName) <> LCase(strCorrectXlaPath) Then
                    ActiveWorkbook.ChangeLink strLinkName, strCorrectXlaPath, xlExcelLinks
                End If
            End If
        Next i
    End If
exitError:
End Sub

Public Sub CloseExistingPropertyPackage()
    On Error GoTo cleanupPkg
    Dim AspenPkg As IAspenPropertyPackage
    Set AspenPkg = g_COPackage
    If g_COPackage Is Nothing Then
    Else
        Set AspenPkg = g_COPackage
        Call AspenPkg.CloseAspenPropertyPackage
    End If
cleanupPkg:
    Set AspenPkg = Nothing
    Set g_COPackage = Nothing
    Set g_MaterialObject = Nothing
    g_pkgName = ""
End Sub

Public Sub ReleasePackage()
    On Error GoTo cleanupPkg
    Dim AspenPkg As IAspenPropertyPackage
    Set AspenPkg = g_COPackage
    If g_COPackage Is Nothing Then
    Else
        Set AspenPkg = g_COPackage
        Call AspenPkg.CloseAspenPropertyPackage
    End If
cleanupPkg:
    Set AspenPkg = Nothing
    Set g_COPackage = Nothing
    Set g_MaterialObject = Nothing
    Set g_PropSys = Nothing
End Sub

