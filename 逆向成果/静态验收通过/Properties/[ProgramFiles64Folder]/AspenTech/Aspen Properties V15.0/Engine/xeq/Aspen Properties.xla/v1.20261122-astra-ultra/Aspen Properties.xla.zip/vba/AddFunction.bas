Attribute VB_Name = "AddFunction"
Option Explicit
Option Private Module

Sub RemoveFunctionDetail()
'    On Error Resume Next
'   Dim DLLPath As String: DLLPath = ThisWorkbook.Path
'   If Dir(DLLPath) = "" Then Exit Sub
'   Dim Table As Range, Funcs As Range
'   Set Table = shFunctions.Range("A2").CurrentRegion
'   Set Funcs = shFunctions.Range(Table.Cells(2, 1), Table.Cells(Table.Rows.count, Table.Columns.count))
'   If Run([FuncDelete], Funcs) = -1 Then ExecuteExcel4Macro "UNREGISTER(""" & DLLPath & """)"
End Sub

Sub AddFunctionDetail()
   'Dim DLLPath As String
   'DLLPath = ThisWorkbook.Path
   
   'If Dir(DLLPath) = "" Then Exit Sub
   'Dim Table As Range, Funcs As Range
   'Set Table = shFunctions.Range("A2").CurrentRegion
   'Set Funcs = shFunctions.Range(Table.Cells(2, 1), Table.Cells(Table.Rows.count, Table.Columns.count))
   
   'Application.RegisterXLL DLLPath
   'Run [FunCustomize], ThisWorkbook.Name, Funcs
   'Application.SendKeys "%^{F9}"
    
    ' to add more worksheet functions, you need to change NbFuncs
    ' and add more entries to funNameDes
  
    ' description, helpContextID, and helpFile are temporary
    ' the helpfile needs to be in the same directory as this xla file
    Const CatName = "Aspen Properties"
    Const NbFuncs = 25
    Dim i As Integer
    Dim j As Integer
    Dim Cat As String
    Dim LCat As Integer
    Dim FctName, FctDesc
    Dim funNameDes(NbFuncs, 3) As Variant
'
' 5/26/2009 by Yuhua Song. CQ00096326: Add solid properties calculation.
'
    On Error Resume Next
    funNameDes(0, 0) = "MixtureProperty"
    funNameDes(0, 1) = "Calculates mixture property, e.g., enthalpy & fugacityCoefficient. Input & results are in user specified Global Units Set. Valid Phase = V or L or S. Use Shift+Ctrl+Enter for partial property, such as fugacityCoefficient."
    funNameDes(0, 2) = 285
    funNameDes(1, 0) = "PureComponentConstant"
    funNameDes(1, 1) = "Returns pure component constant such as molecular weight and normal boiling point. Results are in user specified Global Units Set. Use Shift+Ctrl+Enter for multiple components."
    funNameDes(1, 2) = 308
    funNameDes(2, 0) = "PureProperty"
    funNameDes(2, 1) = "Calculates pure component properties. Input and results are in user specified Global Units Set. Valid Phase = V or L or S. Use Shift+Ctrl+Enter for multiple components."
    funNameDes(2, 2) = 284
    funNameDes(3, 0) = "VaporPressure"
    funNameDes(3, 1) = "Calculates liquid vapor pressure of pure components. Input and results are in user specified Global Units Set. Use Shift+Ctrl+Enter for multiple components."
    funNameDes(3, 2) = 310
    funNameDes(4, 0) = "PHFlash"
    funNameDes(4, 1) = "Calculates phase equilibrium at specified pressure and molar enthalpy. Returns=T,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
    funNameDes(4, 2) = 313
    funNameDes(5, 0) = "PVFlash"
    funNameDes(5, 1) = "Calculates phase equilibrium at specified pressure and molar vapor fraction. Returns=T,H,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
    funNameDes(5, 2) = 291
    funNameDes(6, 0) = "THFlash"
    funNameDes(6, 1) = "Calculates phase equilibrium at specified temperature and molar enthalpy. Returns=P,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
    funNameDes(6, 2) = 314
    funNameDes(7, 0) = "TPFlash"
    funNameDes(7, 1) = "Calculates phase equilibrium at specified temperature and pressure. Returns=V,H,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
    funNameDes(7, 2) = 295
    funNameDes(8, 0) = "TVFlash"
    funNameDes(8, 1) = "Calculates phase equilibrium at specified temperature and molar vapor fraction. Returns=P,H,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
    funNameDes(8, 2) = 293
    funNameDes(9, 0) = "PHFlash3"
    funNameDes(9, 1) = "Calculates vapor-liquid-liquid phase equilibrium at specified pressure and molar enthalpy. Returns=T,V,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2, or Y."
    funNameDes(9, 2) = 316
    funNameDes(10, 0) = "PVFlash3"
    funNameDes(10, 1) = "Calculates vapor-liquid-liquid phase equilibrium at specified pressure and molar vapor fraction. Returns=T,H,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
    funNameDes(10, 2) = 315
    funNameDes(11, 0) = "THFlash3"
    funNameDes(11, 1) = "Calculates vapor-liquid-liquid phase equilibrium at specified temperature and molar enthalpy. Returns=P,V,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
    funNameDes(11, 2) = 319
    funNameDes(12, 0) = "TPFlash3"
    funNameDes(12, 1) = "Calculates vapor-liquid-liquid phase equilibrium at specified temperature and pressure. Returns=V,H,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
    funNameDes(12, 2) = 317
    funNameDes(13, 0) = "TVFlash3"
    funNameDes(13, 1) = "Calculates vapor-liquid-liquid phase equilibrium at specified temperature and molar vapor fraction. Returns=P,H,SFRAC,X:1,X:2,BETA, or Y. Use Shift+Ctrl+Enter if Returns=X:1,X:2 or Y."
    funNameDes(13, 2) = 318
    funNameDes(14, 0) = "UnitsConversion"
    funNameDes(14, 1) = "Performs units conversion. Use Shift+Ctrl+Enter for multiple values."
    funNameDes(14, 2) = 302
    ' function 15,16,17
    ' Created    : 03/20/2002
    ' Version    : Aspen Properties 12.1
    ' Author     : Jwalant Vyas
    funNameDes(15, 0) = "MoleFractionToMassFraction"
    funNameDes(15, 1) = "Performs mass fraction conversion from mole fraction. Use Shift+Ctrl+Enter for multiple components."
    funNameDes(15, 2) = 3
    funNameDes(16, 0) = "MassFractionToMoleFraction"
    funNameDes(16, 1) = "Performs mole fraction conversion from mass fraction. Use Shift+Ctrl+Enter for multiple components."
    funNameDes(16, 2) = 4
    funNameDes(17, 0) = "MassFlowToMoleFraction"
    funNameDes(17, 1) = "Performs mass fraction conversion from MassFlow. Use Shift+Ctrl+Enter for multiple components."
    funNameDes(17, 2) = 5
    funNameDes(18, 0) = "PSFlash"
    funNameDes(18, 1) = "Calculates phase equilibrium at specified pressure and molar entropy. Returns=T,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
    funNameDes(18, 2) = 12
    funNameDes(19, 0) = "PUFlash"
    funNameDes(19, 1) = "Calculates phase equilibrium at specified pressure and molar internal energy. Returns=T,V,SFRAC,X or Y. Use Shift+Ctrl+Enter if Returns=X or Y."
    funNameDes(19, 2) = 13
    funNameDes(20, 0) = "AverageMolecularWeight"
    funNameDes(20, 1) = "Calculates Average Molecular Weight at specified mole fraction."
    funNameDes(20, 2) = 16
    funNameDes(21, 0) = "PHFlashLL"
    funNameDes(21, 1) = "Calculates liquid-liquid phase equilibrium at specified pressure and molar enthalpy. Returns=T,SFRAC,X:1,X:2, or BETA. Use Shift+Ctrl+Enter if Returns=X:1 or X:2."
    funNameDes(21, 2) = 1
    funNameDes(22, 0) = "THFlashLL"
    funNameDes(22, 1) = "Calculates liquid-liquid phase equilibrium at specified temperature and molar enthalpy. Returns=P,SFRAC,X:1,X:2, or BETA. Use Shift+Ctrl+Enter if Returns=X:1 or X:2."
    funNameDes(22, 2) = 14
    funNameDes(23, 0) = "TPFlashLL"
    funNameDes(23, 1) = "Calculates liquid-liquid phase equilibrium at specified temperature and pressure. Returns=H,SFRAC,X:1,X:2, or BETA. Use Shift+Ctrl+Enter if Returns=X:1 or X:2."
    funNameDes(23, 2) = 15
    funNameDes(24, 0) = "MoleFlowToMoleFraction"
    funNameDes(24, 1) = "Performs mole fraction conversion from MoleFlow. Use Shift+Ctrl+Enter for multiple components."
    funNameDes(24, 2) = 320
    'Application.ScreenUpdating = False
    LCat = 16 ' not used any more - no need to hardwire, use CatName instead'
'    Do
'        LCat = LCat + 1
'        Application.ExecuteExcel4Macro _
'        "DEFINE.NAME(""Djzh" & LCat & """,0,2,,," & LCat & ")"
'        Cat = CatName 'Names("Djzh" & LCat).Category
'    Loop While Cat <> "User Defined" And Cat <> CatName

'    If Cat = "User Defined" Then
'        Application.ExecuteExcel4Macro _
'        "DEFINE.NAME(""Djzh" & LCat & """,0,2,,,""" & CatName & """)"
'    End If
'    MsgBox "Help file for Insert Function: " & ThisWorkbook.Path & "\apropexceladdin.chm"
    For i = 0 To NbFuncs - 1
        Application.MacroOptions Macro:=funNameDes(i, 0), _
        Description:=funNameDes(i, 1), Category:=CatName, HelpContextID:=funNameDes(i, 2), HelpFile:=ThisWorkbook.Path & "\apropexceladdin.chm"
    Next i
'    For i = 0 To NbFuncs - 1
'        Application.MacroOptions Macro:=funNameDes(i, 0), _
'        Description:=funNameDes(i, 1), Category:=CatName, HelpContextID:=funNameDes(i, 2), HelpFile:=AddIns("Aspen Properties").Path & "\apr-ug3.chm"
'    Next i
'    For i = 15 To LCat
'        Application.ExecuteExcel4Macro "DELETE.NAME(""Djzh" & i & """)"
'    Next i

'  ThisWorkbook.IsAddin = True
'  ThisWorkbook.Saved = True
End Sub

Function IsPropertyPackageAvailable() As Boolean
    If g_pkgName = "" Then
        IsPropertyPackageAvailable = False
    Else
        IsPropertyPackageAvailable = True
    End If
End Function
'Function   : IsGlobalUnitSetAvailable()
'           : Checks whether the user has defined global unit set or not
'Returns    : Boolean
'Created    : 04/15/2002
'Version    : Aspen Properties 12.1
'Author     : Jwalant Vyas
Function IsGlobalUnitSetAvailable() As Boolean
    If gUnitSet = "" Then
        gUnitSet = GetUnitSet()
        If gUnitSet = "" Then
            IsGlobalUnitSetAvailable = False
            Exit Function
        End If
    End If
    IsGlobalUnitSetAvailable = True
End Function
'Function   : GetUnitSet()
'           : Returns name of the global unit set defined by the user
'Returns    : String
'Created    : 04/15/2002
'Version    : Aspen Properties 12.1
'Author     : Jwalant Vyas
Function GetUnitSet() As String
    Dim strName As String
    Dim count As Integer
    Dim i As Integer
    strName = ""
    On Error Resume Next
    strName = ActiveSheet.Range("UnitSet")
    If strName = "" Then
        count = Application.Worksheets.count
        For i = 1 To count
            strName = Application.Worksheets(i).Range("UnitSet")
            If strName <> "" Then Exit For
        Next i
    End If
    GetUnitSet = strName
End Function


Function getCaseSensitivePropertyName(strPropertyName As String) As String
    Dim i As Integer
    Dim lcaseStrPropertyName As String
    Dim lcaseArrPropUnit  As String
    
    getCaseSensitivePropertyName = strPropertyName ' Set to the original name.
    
    Call CheckPropUnitArray
    lcaseStrPropertyName = LCase(strPropertyName)
    For i = LBound(arrPropUnit, 1) To UBound(arrPropUnit, 1)
        lcaseArrPropUnit = LCase(arrPropUnit(i, 0))
        If lcaseArrPropUnit = lcaseStrPropertyName Then
            getCaseSensitivePropertyName = arrPropUnit(i, 0)
        End If
    Next i
End Function

