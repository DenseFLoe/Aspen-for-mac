Attribute VB_Name = "VBConnection"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit

Private m_IsDefined As Boolean
Private m_Package As String

Public Functions As New VBFunctionsWrapper
Public Helper As New VBHelper
Public Constants As New VBConstants
Public Package As New VBPackage

Public Function Initialize(packageName As String) As Boolean 'TODO: CHANGE UNITS

    Call Package.Initialize(packageName)
    On Error GoTo ErrHandler
    Call Helper.Initialize(Constants)
    Call Functions.Initialize(Package, Constants, Helper)
    m_IsDefined = True
    
ErrHandler:
    Initialize = m_IsDefined
End Function

Public Property Get IsDefined() As Boolean

    IsDefined = m_IsDefined
    
End Property

