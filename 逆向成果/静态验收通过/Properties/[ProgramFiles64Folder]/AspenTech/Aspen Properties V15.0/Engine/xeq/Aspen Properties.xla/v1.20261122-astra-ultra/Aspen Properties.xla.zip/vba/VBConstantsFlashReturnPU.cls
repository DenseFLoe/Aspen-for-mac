Attribute VB_Name = "VBConstantsFlashReturnPU"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnPU
    pu_Temperature = out_Temperature
    pu_VaporFraction = out_VaporFraction
    pu_X = out_X
    pu_Y = out_Y
    pu_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Temperature
    list(2) = VaporFraction
    list(3) = X
    list(4) = Y
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get Temperature() As Long
    Temperature = pu_Temperature
End Property

Public Property Get VaporFraction() As Long
    VaporFraction = pu_VaporFraction
End Property

Public Property Get X() As Long
    X = pu_X
End Property

Public Property Get Y() As Long
    Y = pu_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = pu_SFRAC
End Property



