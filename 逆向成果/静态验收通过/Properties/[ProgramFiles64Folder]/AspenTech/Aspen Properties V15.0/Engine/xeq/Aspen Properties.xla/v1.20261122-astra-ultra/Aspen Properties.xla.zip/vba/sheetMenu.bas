Attribute VB_Name = "sheetMenu"
Global bSpecifyUnit As Boolean
Global bConvertUnit As Boolean
Dim ToProp As String, toUnit As String, ToDesc As String

Sub populateShortCutMenu()
    Dim iBlkNum As Integer
    Dim bFound As Boolean
    Dim arrMenu() As Variant
    Dim mb, mnuAUSep1, mnuAUTemp, mi, mnuAUPres, mnuAUSep2, mnuACUTemp, mnuACUPres, mnuAUSepe1, mnuASU, mnuACU
    
    Dim topLevelMenuItem
    
    Call getUnits

    For Each mb In Application.ShortcutMenus(xlWorksheetCell).MenuItems
        If mb.Caption = "Aspen Properties" Then Exit Sub
    Next
    
    Set mnuAUSep1 = Application.ShortcutMenus(xlWorksheetCell).MenuItems.Add(Caption:="-")
    Set topLevelMenuItem = Application.ShortcutMenus(xlWorksheetCell).MenuItems.AddMenu(Caption:="Aspen Properties")
    With topLevelMenuItem
        Set mnuAUTemp = .MenuItems.AddMenu(Caption:="Specify Temperature Units")
        With mnuAUTemp
            Set mi = .MenuItems.Add("K")
            mi.OnAction = "UnitK"
            Set mi = .MenuItems.Add("F")
            mi.OnAction = "UnitF"
            Set mi = .MenuItems.Add("C")
            mi.OnAction = "UnitC"
            Set mi = .MenuItems.Add("R")
            mi.OnAction = "UnitR"
        End With
        
        Set mnuAUPres = .MenuItems.AddMenu(Caption:="Specify Pressure Units")
        With mnuAUPres
            Set mi = .MenuItems.Add("N/sqm")
            mi.OnAction = "UnitNsqm"
            Set mi = .MenuItems.Add("psi")
            mi.OnAction = "Unitpsi"
            Set mi = .MenuItems.Add("atm")
            mi.OnAction = "Unitatm"
            Set mi = .MenuItems.Add("lbf/sqft")
            mi.OnAction = "Unitlbfsqft"
            Set mi = .MenuItems.Add("bar")
            mi.OnAction = "Unitbar"
            Set mi = .MenuItems.Add("torr")
            mi.OnAction = "Unittorr"
            Set mi = .MenuItems.Add("in-water")
            mi.OnAction = "Unitinwater"
            Set mi = .MenuItems.Add("kg/sqcm")
            mi.OnAction = "Unitkgsqcm"
            Set mi = .MenuItems.Add("mmHg")
            mi.OnAction = "UnitmmHg"
            Set mi = .MenuItems.Add("kPa")
            mi.OnAction = "UnitkPa"
            Set mi = .MenuItems.Add("mm-water")
            mi.OnAction = "Unitmmwater"
            Set mi = .MenuItems.Add("mbar")
            mi.OnAction = "Unitmbar"
            Set mi = .MenuItems.Add("psig")
            mi.OnAction = "Unitpsig"
            Set mi = .MenuItems.Add("atmg")
            mi.OnAction = "Unitatmg"
            Set mi = .MenuItems.Add("barg")
            mi.OnAction = "Unitbarg"
            Set mi = .MenuItems.Add("kg/sqcmg")
            mi.OnAction = "Unitkgsqcmg"
            Set mi = .MenuItems.Add("lb/ft-sqsec")
            mi.OnAction = "Unitlbftsqsec"
            Set mi = .MenuItems.Add("lb/m-sqsec")
            mi.OnAction = "Unitlbmsqsec"
        End With
        
        Set mnuAUSep2 = .MenuItems.Add(Caption:="-")
        Set mnuACUTemp = .MenuItems.AddMenu(Caption:="Convert Temperature Units")
        With mnuACUTemp
            Set mi = .MenuItems.Add("K")
            mi.OnAction = "ConvertUnitK"
            Set mi = .MenuItems.Add("F")
            mi.OnAction = "ConvertUnitF"
            Set mi = .MenuItems.Add("C")
            mi.OnAction = "ConvertUnitC"
            Set mi = .MenuItems.Add("R")
            mi.OnAction = "ConvertUnitR"
        End With
        
        Set mnuACUPres = .MenuItems.AddMenu(Caption:="Convert Pressure Units")
        With mnuACUPres
            Set mi = .MenuItems.Add("N/sqm")
            mi.OnAction = "ConvertUnitNsqm"
            Set mi = .MenuItems.Add("psi")
            mi.OnAction = "ConvertUnitpsi"
            Set mi = .MenuItems.Add("atm")
            mi.OnAction = "ConvertUnitatm"
            Set mi = .MenuItems.Add("lbf/sqft")
            mi.OnAction = "ConvertUnitlbfsqft"
            Set mi = .MenuItems.Add("bar")
            mi.OnAction = "ConvertUnitbar"
            Set mi = .MenuItems.Add("torr")
            mi.OnAction = "ConvertUnittorr"
            Set mi = .MenuItems.Add("in-water")
            mi.OnAction = "ConvertUnitinwater"
            Set mi = .MenuItems.Add("kg/sqcm")
            mi.OnAction = "ConvertUnitkgsqcm"
            Set mi = .MenuItems.Add("mmHg")
            mi.OnAction = "ConvertUnitmmHg"
            Set mi = .MenuItems.Add("kPa")
            mi.OnAction = "ConvertUnitkPa"
            Set mi = .MenuItems.Add("mm-water")
            mi.OnAction = "ConvertUnitmmwater"
            Set mi = .MenuItems.Add("mbar")
            mi.OnAction = "ConvertUnitmbar"
            Set mi = .MenuItems.Add("psig")
            mi.OnAction = "ConvertUnitpsig"
            Set mi = .MenuItems.Add("atmg")
            mi.OnAction = "ConvertUnitatmg"
            Set mi = .MenuItems.Add("barg")
            mi.OnAction = "ConvertUnitbarg"
            Set mi = .MenuItems.Add("kg/sqcmg")
            mi.OnAction = "ConvertUnitkgsqcmg"
            Set mi = .MenuItems.Add("lb/ft-sqsec")
            mi.OnAction = "ConvertUnitlbftsqsec"
            Set mi = .MenuItems.Add("lb/m-sqsec")
            mi.OnAction = "ConvertUnitlbmsqsec"
        End With
    


        Set mnuAUSepe1 = .MenuItems.Add(Caption:="-")
    
        Set mnuASU = .MenuItems.Add(Caption:="Specify Units")
        mnuASU.OnAction = "wndSpecifyUnit"
    
        Set mnuACU = .MenuItems.Add(Caption:="Convert Units")
        mnuACU.OnAction = "wndConvertUnit"
    End With
    
End Sub

Sub UnitK()
    ToProp = "Temperature"
    toUnit = "K"
    ToDesc = "Kelvin"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub UnitF()
    ToProp = "Temperature"
    toUnit = "F"
    ToDesc = "Fahrenheit"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub UnitC()
    ToProp = "Temperature"
    toUnit = "C"
    ToDesc = "Celsius"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub UnitR()
    ToProp = "Temperature"
    toUnit = "R"
    ToDesc = "Rankin"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub UnitNsqm()
    ToProp = "Pressure"
    toUnit = "N/sqm"
    ToDesc = "N/sqm"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitpsi()
    ToProp = "Pressure"
    toUnit = "psi"
    ToDesc = "psi"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitlbfsqft()
    ToProp = "Pressure"
    toUnit = "lbf/sqft"
    ToDesc = "atm"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitatm()
    ToProp = "Pressure"
    toUnit = "atm"
    ToDesc = "atm"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitbar()
    ToProp = "Pressure"
    toUnit = "bar"
    ToDesc = "bar"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unittorr()
    ToProp = "Pressure"
    toUnit = "torr"
    ToDesc = "torr"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitinwater()
    ToProp = "Pressure"
    toUnit = "in-water"
    ToDesc = "in-water"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitkgsqcm()
    ToProp = "Pressure"
    toUnit = "kg/sqcm"
    ToDesc = "kg/sqcm"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub UnitmmHg()
    ToProp = "Pressure"
    toUnit = "mmHg"
    ToDesc = "mmHg"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub UnitkPa()
    ToProp = "Pressure"
    toUnit = "kPa"
    ToDesc = "kPa"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitmmwater()
    ToProp = "Pressure"
    toUnit = "mm-water"
    ToDesc = "mm-water"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitmbar()
    ToProp = "Pressure"
    toUnit = "mbar"
    ToDesc = "mbar"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitpsig()
    ToProp = "Pressure"
    toUnit = "psig"
    ToDesc = "psig"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitatmg()
    ToProp = "Pressure"
    toUnit = "atmg"
    ToDesc = "atmg"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitbarg()
    ToProp = "Pressure"
    toUnit = "barg"
    ToDesc = "barg"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitkgsqcmg()
    ToProp = "Pressure"
    toUnit = "kg/sqcmg"
    ToDesc = "kg/sqcmg"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitlbftsqsec()
    ToProp = "Pressure"
    toUnit = "lb/ft-sqsec"
    ToDesc = "lb/ft-sqsec"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub Unitlbmsqsec()
    ToProp = "Pressure"
    toUnit = "lb/m-sqsec"
    ToDesc = "lb/m-sqsec"
    Call SetUnitText(ToProp, toUnit)
End Sub

Sub ConvertUnitK()
    ToProp = "Temperature"
    toUnit = "K"
    ToDesc = "Kelvin"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitF()
    ToProp = "Temperature"
    toUnit = "F"
    ToDesc = "Fahrenheit"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitC()
    ToProp = "Temperature"
    toUnit = "C"
    ToDesc = "Celsius"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitR()
    ToProp = "Temperature"
    toUnit = "R"
    ToDesc = "Rankin"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitNsqm()
    ToProp = "Pressure"
    toUnit = "N/sqm"
    ToDesc = "N/sqm"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitpsi()
    ToProp = "Pressure"
    toUnit = "psi"
    ToDesc = "psi"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitatm()
    ToProp = "Pressure"
    toUnit = "atm"
    ToDesc = "atm"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitlbfsqft()
    ToProp = "Pressure"
    toUnit = "lbf/sqft"
    ToDesc = "atm"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitbar()
    ToProp = "Pressure"
    toUnit = "bar"
    ToDesc = "bar"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnittorr()
    ToProp = "Pressure"
    toUnit = "torr"
    ToDesc = "torr"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitinwater()
    ToProp = "Pressure"
    toUnit = "in-water"
    ToDesc = "in-water"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitkgsqcm()
    ToProp = "Pressure"
    toUnit = "kg/sqcm"
    ToDesc = "kg/sqcm"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitmmHg()
    ToProp = "Pressure"
    toUnit = "mmHg"
    ToDesc = "mmHg"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitkPa()
    ToProp = "Pressure"
    toUnit = "kPa"
    ToDesc = "kPa"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitmmwater()
    ToProp = "Pressure"
    toUnit = "mm-water"
    ToDesc = "mm-water"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitmbar()
    ToProp = "Pressure"
    toUnit = "mbar"
    ToDesc = "mbar"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitpsig()
    ToProp = "Pressure"
    toUnit = "psig"
    ToDesc = "psig"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitatmg()
    ToProp = "Pressure"
    toUnit = "atmg"
    ToDesc = "atmg"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitbarg()
    ToProp = "Pressure"
    toUnit = "barg"
    ToDesc = "barg"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitkgsqcmg()
    ToProp = "Pressure"
    toUnit = "kg/sqcmg"
    ToDesc = "kg/sqcmg"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitlbftsqsec()
    ToProp = "Pressure"
    toUnit = "lb/ft-sqsec"
    ToDesc = "lb/ft-sqsec"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub ConvertUnitlbmsqsec()
    ToProp = "Pressure"
    toUnit = "lb/m-sqsec"
    ToDesc = "lb/m-sqsec"
    Call subConvertUnit(ToProp, toUnit)
End Sub

Sub SetUnitText(toProperty As String, toUnit As String)
    Dim OldNoteText
    Dim L, pos
    OldNoteText = ""

    With Application.ActiveWindow.ActiveCell
    
   
    On Error Resume Next
 
     L = Len(.Comment.Text)
'        If InStr(.NoteText, toProperty) Then
        pos = InStr(.Comment.Text, "}")
        If L > pos Then
            OldNoteText = Right(.Comment.Text, L - pos)
        End If
        If InStr(.Comment.Text, "{") And InStr(.Comment.Text, "}") Then
            .AddComment.Text ""
'        Else
'            OldNoteText = .NoteText
        End If
        .ClearComments
        
        .AddComment.Text "{" & toProperty & ":" & toUnit & "}" & OldNoteText
        'Preserve the old message
    End With
End Sub


Sub subConvertUnit(toProperty As String, toUnit As String)
    Dim OldNoteText
    Dim L, pos
    Dim fromUnit As String
    OldNoteText = ""

    With Application.ActiveWindow.ActiveCell
        If .Formula <> CStr(.value) Then
            MsgBox "You cannot convert property function results using the right-mouse Convert Units menu." & Chr(13) & _
            "Please use the UnitsConversion function from the Function Wizard."
            Exit Sub
        End If
        
       On Error Resume Next

        L = Len(.Comment.Text)
'        If InStr(.NoteText, toProperty) Then
            If toProperty = Mid(.Comment.Text, 2, Len(toProperty)) Then
                fromUnit = Mid(.Comment.Text, InStr(.NoteText, ":") + 1, InStr(.NoteText, "}") - InStr(.NoteText, ":") - 1)
                .value = UnitsConversion(fromUnit, toUnit, .value)
            End If
            pos = InStr(.Comment.Text, "}")
           If L > pos Then
                OldNoteText = Right(.Comment.Text, L - pos)
           End If
            If InStr(.Comment.Text, "{") And InStr(.Comment.Text, "}") Then
                 .AddComment.Text ""
'        Else
'            OldNoteText = .NoteText
        End If
        .ClearComments
        
        .AddComment.Text "{" & toProperty & ":" & toUnit & "}" & OldNoteText
        'Preserve the old message
    End With
End Sub

Sub wndSpecifyUnit()
    bSpecifyUnit = True
    Dim propListIndex As Integer
    Dim unitListIndex As Integer
    Dim oldProperty As String

    Call CheckUnitArray
    propListIndex = 0
    unitListIndex = 0
    oldProperty = ""
        
    With Application.ActiveWindow.ActiveCell
    On Error Resume Next
        If .Comment.Text <> "" And InStr(.Comment.Text, "{") And InStr(.Comment.Text, ":") And InStr(.Comment.Text, "}") Then
            oldProperty = Mid(InStr(.Comment.Text, "{") + 1, InStr(.Comment.Text, ":") - 1)
            oldUnit = Mid(InStr(.Comment.Text, ":") + 1, InStr(.Comment.Text, "}") - 1)
        End If
    End With
            
    With frmSelectUnits
        .lstProperty.Clear
        .lstUnit.Clear
        For i = LBound(arrProp, 1) + 1 To UBound(arrProp, 1)
            .lstProperty.AddItem arrProp(i, 2)
            If oldProperty = arrProp(i, 2) Then
                propListIndex = i
            End If
        Next i
        .lstProperty.ListIndex = propListIndex
        .Show
    End With
    bSpecifyUnit = False
End Sub

Sub wndConvertUnit()
    Call CheckUnitArray
    bConvertUnit = True
    With frmSelectUnits
        .lstProperty.Clear
        .lstUnit.Clear
        For i = LBound(arrProp, 1) + 1 To UBound(arrProp, 1)
            .lstProperty.AddItem arrProp(i, 2)
        Next i
        .Show
    End With
    bConvertUnit = False
End Sub
Sub SelectGlobalUnits()
Call DeleteClass1
If IsPropertyPackageAvailable() = False Then Exit Sub
Load frmGlobalUnitSet
frmGlobalUnitSet.Show
End Sub
Sub SelectUnits()
   Call DeleteClass1
    Call CheckUnitArray
    With frmSelectUnits
        .Caption = "Select Units"
        .lstProperty.Clear
        .lstUnit.Clear
        For i = LBound(arrProp, 1) + 1 To UBound(arrProp, 1)
            .lstProperty.AddItem arrProp(i, 2)
        Next i
        .Show
    End With
End Sub

Sub CheckUnitArray()
    Dim retval As Integer
    On Error GoTo err_CheckUnits
    If IsArray(arrProp) = False Then
        Call getUnits
    End If
    retval = LBound(arrProp, 1)
    Exit Sub
err_CheckUnits:
    Call getUnits
End Sub

Sub CheckPropUnitArray()
    Dim retval As Integer
    On Error GoTo err_CheckPropUnits
    If IsArray(arrPropUnit) = False Then
        Call getPropUnits
    End If
    retval = LBound(arrPropUnit, 1)
    Exit Sub
err_CheckPropUnits:
    Call getPropUnits
End Sub

Sub fnSetUnitText(toProperty As String, toUnit As String)
    Dim OldNoteText
    Dim L, pos
    Dim i
    OldNoteText = ""

    If bNoteText = False Then Exit Sub
    If toProperty = "Dimensionless" Or toUnit = "Unitless" Or Trim(strUnitsType) = "" Or Trim(strUnitsLabel) = "" Then
        If toProperty = "Dimensionless" Or toUnit = "Unitless" Then
            For i = 1 To Application.ActiveWindow.Selection.Cells.count
                With Application.ActiveWindow.Selection.Cells(i)
                    If .Formula <> CStr(.value) Then
                        On Error Resume Next
                        .ClearNotes
                    End If
                End With
            Next i
            Application.ActiveWindow.Selection.Interior.ColorIndex = xlColorIndexNone
            bNoteText = False
            Exit Sub
        End If
    End If
    
    For i = 1 To Application.ActiveWindow.Selection.Cells.count
        With Application.ActiveWindow.Selection.Cells(i)
            If .Formula <> CStr(.value) Then
                On Error Resume Next
                L = Len(.Comment.Text)
                pos = InStr(.Comment.Text, "}")
                If L > pos Then
                    OldNoteText = Right(.Comment.Text, L - pos)
                End If
                If InStr(.Comment.Text, "{") And InStr(.Comment.Text, "}") Then
                  .AddComment.Text ""
                End If
                .ClearComments
        
                 .AddComment.Text "{" & toProperty & ":" & toUnit & "}" & OldNoteText
                .Font.Bold = True
                .Interior.ColorIndex = 19
            End If
        End With
    Next i
'    Application.ActiveWindow.Selection.Font.Bold = True
'    Application.ActiveWindow.Selection.Interior.ColorIndex = 19
    bNoteText = False
    strUnitsType = ""
    strUnitsLabel = ""
    strRangeUnitsApply = ""
End Sub

' Subroutine : modifyMenuState()
'              Implementaion for modifying the status of Menu Items under the "Aspen Properties"
'              Menu during use of New and Configure Aspen Properties Option under main menu
' Created    : 03/13/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas

Public Sub modifyMenuState(sStatus As String)
    If (sStatus = "Enable") Then
        COMAddinHelper.UpdateRibbon (True)
    Else
        COMAddinHelper.UpdateRibbon (False)
    End If
End Sub

