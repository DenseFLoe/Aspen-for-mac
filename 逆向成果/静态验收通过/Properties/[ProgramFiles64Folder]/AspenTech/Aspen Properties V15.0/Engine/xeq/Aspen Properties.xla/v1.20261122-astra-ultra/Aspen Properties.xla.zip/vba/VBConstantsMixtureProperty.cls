Attribute VB_Name = "VBConstantsMixtureProperty"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum AspenMixtureProperty
' mixture   -   single
    mix_ActivityCoefficient = AspenProperty.a_ActivityCoefficient
    mix_Density = AspenProperty.a_Density
    mix_DiffusionCoefficient = AspenProperty.a_DiffusionCoefficient
    
    mix_Enthalpy = AspenProperty.a_Enthalpy
    mix_Entropy = AspenProperty.a_Entropy
    
    mix_Fugacity = AspenProperty.a_Fugacity
    mix_FugacityCoeffient = AspenProperty.a_FugacityCoefficient
    
    mix_GibbsFreeEnergy = AspenProperty.a_GibbsFreeEnergy
    mix_GrossHeatingValue = AspenProperty.a_GrossHeatingValue
    mix_HeatCapacity = AspenProperty.a_HeatCapacity
    mix_HeatCapacityCv = AspenProperty.a_HeatCapacityCv
    mix_InternalEnergy = AspenProperty.a_InternalEnergy
    
    mix_LogFugacityCoefficient = AspenProperty.a_LogFugacityCoefficient
    
    mix_MassDensity = AspenProperty.a_MassDensity
    mix_NetHeatingValue = AspenProperty.a_NetHeatingValue
    mix_pH = AspenProperty.a_pH
    
    mix_SolubilityIndex = AspenProperty.a_SolubilityIndex
    
    mix_SurfaceTension = AspenProperty.a_SurfaceTension
    mix_ThermalConductivity = AspenProperty.a_ThermalConductivity
    mix_Viscosity = AspenProperty.a_Viscosity
    mix_Volume = AspenProperty.a_Volume
End Enum

Public Enum MixtureValues
    All = 1
    MixtureOnly = 2
    ComponentOnly = 3
End Enum

Public Function GetValues(Optional returnValues As MixtureValues = MixtureValues.All) As Long()

    Dim list() As Long
    
    If returnValues = All Then
        ReDim list(15)
        list(1) = ActivityCoefficient
        list(2) = Enthalpy
        list(3) = Entropy
        list(4) = GibbsFreeEnergy
        list(5) = GrossHeatingValue
        list(6) = HeatCapacity
        list(7) = HeatCapacityCv
        list(8) = internalEnergy
        list(9) = MassDensity
        list(10) = NetHeatingValue
        list(11) = PH
        list(12) = SurfaceTension
        list(13) = ThermalConductivity
        list(14) = Viscosity
        list(15) = Volume
    ElseIf returnValues = MixtureOnly Then
    
    Else ' component in mixture
    
    End If
    GetValues = list
    
End Function

Public Property Get ActivityCoefficient() As Long
    ActivityCoefficient = mix_ActivityCoefficient
End Property

Public Property Get Enthalpy() As Long
    Enthalpy = mix_Enthalpy
End Property

Public Property Get Entropy() As Long
    Entropy = mix_Entropy
End Property

Public Property Get GibbsFreeEnergy() As Long
    GibbsFreeEnergy = mix_GibbsFreeEnergy
End Property

Public Property Get GrossHeatingValue() As Long
    GrossHeatingValue = mix_GrossHeatingValue
End Property

Public Property Get HeatCapacity() As Long
    HeatCapacity = mix_HeatCapacity
End Property

Public Property Get HeatCapacityCv() As Long
    HeatCapacityCv = mix_HeatCapacityCv
End Property

Public Property Get internalEnergy() As Long
    internalEnergy = mix_InternalEnergy
End Property

Public Property Get MassDensity() As Long
    MassDensity = mix_MassDensity
End Property

Public Property Get NetHeatingValue() As Long
    NetHeatingValue = mix_NetHeatingValue
End Property

Public Property Get PH() As Long
    PH = mix_pH
End Property

Public Property Get SurfaceTension() As Long
    SurfaceTension = mix_SurfaceTension
End Property

Public Property Get ThermalConductivity() As Long
    ThermalConductivity = mix_ThermalConductivity
End Property

Public Property Get Viscosity() As Long
    Viscosity = mix_Viscosity
End Property

Public Property Get Volume() As Long
    Volume = mix_Volume
End Property
