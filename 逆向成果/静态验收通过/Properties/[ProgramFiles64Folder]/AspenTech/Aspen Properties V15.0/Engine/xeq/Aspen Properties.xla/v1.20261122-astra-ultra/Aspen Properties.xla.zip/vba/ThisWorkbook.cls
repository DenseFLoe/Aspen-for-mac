Attribute VB_Name = "ThisWorkbook"
Attribute VB_Base = "0{00020819-0000-0000-C000-000000000046}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = True
Dim WithEvents oApp As Excel.Application
Attribute oApp.VB_VarHelpID = -1

Private Sub oApp_NewWorkbook(ByVal Wb As Workbook)
    If g_MMVersion = "" Then
       Call InitializeGlobalVariables
    End If
End Sub


Private Sub oApp_WorkbookBeforeClose(ByVal Wb As Workbook, Cancel As Boolean)
    If mobjClass1 Is Nothing Then
        Exit Sub
    Else
        mobjClass1.bCloseApp = True
    End If
    
    If (g_APLicense = True) Then
    Call DeleteClass1
    End If

    ' Release object PropertySystem
    Set g_PropSys = Nothing
    Set g_COPackage = Nothing
    Set g_MaterialObject = Nothing
    g_InitialGlobalOpsetname = ""
    g_InitialGlobalHenry = ""
    g_InitialGlobalChemistry = ""
    g_InitialGlobalFreeWater = ""
    g_InitialGlobalTrueComps = -1
    g_InitialGlobalSoluWater = -1
    g_pkgName = ""
    g_FullPath = ""
End Sub

Private Sub Workbook_AddinUninstall()
    RemoveFunctionDetail
End Sub

Private Sub Workbook_Open()
    Set oApp = Application
End Sub

Private Sub oApp_SheetChange(ByVal Sh As Object, ByVal Target As Range)
    fnUnitText
End Sub

Private Sub Workbook_SheetCalculate(ByVal Sh As Object)
    g_strPropName = ""
End Sub

Private Sub Workbook_SheetChange(ByVal Sh As Object, ByVal Target As Range)
    g_strPropName = ""
End Sub
