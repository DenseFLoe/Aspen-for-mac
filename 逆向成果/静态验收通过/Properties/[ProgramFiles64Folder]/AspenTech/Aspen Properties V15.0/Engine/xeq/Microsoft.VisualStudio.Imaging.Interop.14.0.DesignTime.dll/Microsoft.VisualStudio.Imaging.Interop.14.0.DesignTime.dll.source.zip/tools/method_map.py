import sys, json, struct
from hashlib import sha256
from pathlib import Path
sys.path.insert(0, r"C:/Users/Administrator/Desktop/Aspen 逆向/.local/high-level-rebuild-20261125/router/work/managed-override-1")
import build_recipe2 as br

def digest(b): return sha256(b).hexdigest()

def methods(path):
    data=Path(path).read_bytes()
    pe=br.pefile.PE(data=data, fast_load=True)
    cli=br.cli_header(pe)
    root=br.metadata_root(pe, cli)
    tables=root["tables"]
    tdefs=[]
    n=tables["layout"].get(0x02,{}).get("rows",0)
    for i in range(1,n+1):
        r=br.read_row(root["bytes"],tables,0x02,i)
        name=br.heap_string(pe,cli,root,r[1]); ns=br.heap_string(pe,cli,root,r[2])
        tdefs.append({"row":i,"flags":r[0],"name":name,"ns":ns,"method_list":r[5]})
    nest={}
    nn=tables["layout"].get(0x29,{}).get("rows",0)
    for i in range(1,nn+1):
        r=br.read_row(root["bytes"],tables,0x29,i)
        nest[r[0]]=r[1]
    def full(row):
        parts=[tdefs[row-1]["name"]]
        while row in nest:
            row=nest[row]; parts.append(tdefs[row-1]["name"])
        base=tdefs[row-1]
        pre=(base["ns"]+".") if base["ns"] else ""
        return pre+"/".join(reversed(parts))
    rows=br.methoddef_rows(pe,cli,root)
    out=[]
    for idx,t in enumerate(tdefs):
        start=t["method_list"]; end=tdefs[idx+1]["method_list"] if idx+1<len(tdefs) else len(rows)+1
        for r in rows:
            if start<=r["row"]<end:
                name=br.heap_string(pe,cli,root,r["name_index"])
                sig=br.heap_blob(pe,cli,root,r["signature_index"])
                body=pe.get_data(r["rva"],br.method_extent(pe,r["rva"])) if r["rva"] else b""
                hdr=None
                if body:
                    first=body[0]
                    if first&3==2: hdr={"type":"tiny","size":1,"code":first>>2}
                    elif first&3==3:
                        raw=struct.unpack_from("<H",body,0)[0]; hs=(raw>>12)*4
                        flags=raw&0xFFF; siz=struct.unpack_from("<I",body,4)[0]
                        hdr={"type":"fat","size":hs,"flags":flags,"raw":raw,"code":siz,
                             "maxstack":struct.unpack_from("<H",body,2)[0],
                             "localsig":struct.unpack_from("<I",body,8)[0] if hs==12 else None}
                out.append({"token":r["token"],"owner":full(t["row"]),"name":name,"sig_sha256":digest(sig),"sig":sig.hex(),
                            "flags":r["flags"],"impl":r["impl_flags"],"rva":r["rva"],"body_sha256":digest(body),"body_size":len(body),
                            "header":hdr,"body":body})
    return out, data

def compare(op,cp,outjson):
    a,da=methods(op); b,db=methods(cp)
    def key(m): return (m["owner"],m["name"],m["sig_sha256"])
    ka={}; kb={}
    for m in a: ka.setdefault(key(m),[]).append(m)
    for m in b: kb.setdefault(key(m),[]).append(m)
    rows=[]
    for k in sorted(set(ka)|set(kb)):
        la,lb=ka.get(k,[]),kb.get(k,[])
        if len(la)==1 and len(lb)==1:
            ma,mb=la[0],lb[0]
            diffpos=[i for i in range(min(len(ma["body"]),len(mb["body"]))) if ma["body"][i]!=mb["body"][i]]
            rows.append({"key":"::".join(k),"state":"pair","original_token":"0x%08X"%ma["token"],"candidate_token":"0x%08X"%mb["token"],
                "owner":ma["owner"],"name":ma["name"],"original_rva":ma["rva"],"candidate_rva":mb["rva"],
                "original_size":ma["body_size"],"candidate_size":mb["body_size"],
                "equal":ma["body"]==mb["body"],"first_diff":diffpos[:6],"diff_count":len(diffpos),
                "original_header":ma["header"],"candidate_header":mb["header"],
                "original_sha":ma["body_sha256"],"candidate_sha":mb["body_sha256"],
                "original_flags":ma["flags"],"candidate_flags":mb["flags"],"original_impl":ma["impl"],"candidate_impl":mb["impl"]})
        elif la and not lb:
            rows.append({"key":"::".join(k),"state":"original_only","original_token":"0x%08X"%la[0]["token"],"owner":la[0]["owner"],"name":la[0]["name"],"original_size":la[0]["body_size"],"original_rva":la[0]["rva"]})
        elif lb and not la:
            rows.append({"key":"::".join(k),"state":"candidate_only","candidate_token":"0x%08X"%lb[0]["token"],"owner":lb[0]["owner"],"name":lb[0]["name"],"candidate_size":lb[0]["body_size"],"candidate_rva":lb[0]["rva"]})
        else:
            rows.append({"key":"::".join(k),"state":"ambiguous","counts":[len(la),len(lb)]})
    summary={}
    for r in rows:
        s=r["state"] if r["state"]!="pair" else ("equal" if r["equal"] else "diff")
        summary[s]=summary.get(s,0)+1
    res={"original":op,"candidate":cp,"original_sha256":digest(da),"candidate_sha256":digest(db),"summary":summary,"rows":rows}
    Path(outjson).write_text(json.dumps(res,ensure_ascii=False,indent=1),encoding="utf-8")
    print(json.dumps({"file":outjson,"summary":summary,"rows":len(rows)},ensure_ascii=False))
    return res

if __name__=="__main__":
    compare(sys.argv[1],sys.argv[2],sys.argv[3])
