Attribute VB_Name = "VBConstantsFlashReturnPV"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnPV
    pv_Temperature = out_Temperature
    pv_Enthalpy = out_Enthalpy
    pv_X = out_X
    pv_Y = out_Y
    pv_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(5)
    list(1) = Temperature
    list(2) = Enthalpy
    list(3) = X
    list(4) = Y
    list(5) = SFRAC
    GetValues = list
    
End Function

Public Property Get Temperature() As Long
    Temperature = pv_Temperature
End Property

Public Property Get Enthalpy() As Long
    Enthalpy = pv_Enthalpy
End Property

Public Property Get X() As Long
    X = pv_X
End Property

Public Property Get Y() As Long
    Y = pv_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = pv_SFRAC
End Property

