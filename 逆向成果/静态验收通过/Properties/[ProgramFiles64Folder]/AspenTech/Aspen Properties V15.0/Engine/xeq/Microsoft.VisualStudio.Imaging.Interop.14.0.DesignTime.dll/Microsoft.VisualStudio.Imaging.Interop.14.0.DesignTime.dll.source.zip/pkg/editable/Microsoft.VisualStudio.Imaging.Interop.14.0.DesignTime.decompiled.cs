using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: ImportedFromTypeLib("ImageParameters140")]
[assembly: TypeLibVersion(14, 0)]
[assembly: Guid("EC05985A-3DBD-49E4-B02A-8C111AD14285")]
[assembly: AssemblyVersion("14.0.0.0")]
namespace Microsoft.VisualStudio.Imaging.Interop;

[Flags]
public enum _ImageAttributesFlags
{
	IAF_Size = 1,
	IAF_Type = 2,
	IAF_Format = 4,
	IAF_Dpi = 8,
	IAF_Background = int.MinValue,
	IAF_Grayscale = 0x40000000,
	IAF_GrayscaleBiasColor = 0x20000000,
	IAF_HighContrast = 0x10000000,
	IAF_RequiredFlags = 0xF,
	IAF_OptionalFlags = -268435456
}
public enum _UIDataFormat
{
	DF_Win32 = 1,
	DF_WinForms,
	DF_WPF
}
public enum _UIImageType
{
	IT_Bitmap = 1,
	IT_Icon,
	IT_ImageList
}
public enum _ImageMonikerType
{
	IMT_Unknown,
	IMT_LoadedFromManifest,
	IMT_Custom,
	IMT_System
}
public enum _UIImageHorizontalAlignment
{
	IHA_Left = 1,
	IHA_Center,
	IHA_Right
}
public enum _UIImageVerticalAlignment
{
	IVA_Top = 1,
	IVA_Center,
	IVA_Bottom
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct ImageAttributes
{
	public int StructSize;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.ImageAttributesFlags")]
	public uint Flags;

	public int LogicalWidth;

	public int LogicalHeight;

	public int Dpi;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.UIDataFormat")]
	public uint Format;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.UIImageType")]
	public uint ImageType;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.RGBA")]
	public uint Background;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.RGBA")]
	public uint GrayscaleBiasColor;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.BOOL")]
	public int HighContrast;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct ImageMoniker
{
	public Guid Guid;

	public int Id;
}
[StructLayout(LayoutKind.Sequential, Pack = 8)]
public struct ImageCompositionLayer
{
	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.ImageMoniker")]
	public ImageMoniker ImageMoniker;

	public int VirtualWidth;

	public int VirtualHeight;

	public int VirtualXOffset;

	public int VirtualYOffset;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.UIImageHorizontalAlignment")]
	public uint HorizontalAlignment;

	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.UIImageVerticalAlignment")]
	public uint VerticalAlignment;
}
[ComImport]
[Guid("B4D44E85-FCF6-481E-BFBF-CDF3A573E298")]
[InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IImageHandle
{
	[DispId(1610678272)]
	[ComAliasName("Microsoft.VisualStudio.Imaging.Interop.ImageMoniker")]
	ImageMoniker Moniker
	{
		[MethodImpl(MethodImplOptions.InternalCall, MethodCodeType = MethodCodeType.Runtime)]
		[return: ComAliasName("Microsoft.VisualStudio.Imaging.Interop.ImageMoniker")]
		get;
	}
}
