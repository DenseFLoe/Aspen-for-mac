Attribute VB_Name = "VBConstants"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public PureProperty As New VBConstantsPureProperty
Public MixtureProperty As New VBConstantsMixtureProperty
Public Parameter As New VBConstantsPureConstant
Public Flash As New VBConstantsFlash
Public ReturnWhat As New VBConstantsFlashReturn

Public Enum AspenProperty
' parameter -   scalar
' component -   array
' mixture   -   single
' pure      -   single
    a_AcentricFactor = 1                ' parameter
    a_ActivityCoefficient = 2           ' component property in a mixture
    a_CriticalCompressibilityFactor = 3 ' parameter
    a_CriticalPressure = 4              ' parameter
    a_CriticalTemperature = 5           ' parameter
    a_Density = 6                       ' parameter
    a_DiffusionCoefficient = 7          ' component property in a mixture
    a_Enthalpy = 8                      ' pure or mixture property
    a_Entropy = 9                       ' pure or mixture property
    a_Fugacity = 10                     ' pure property or component property in a mixture
    a_FugacityCoefficient = 11          ' pure property or component property in a mixture
    a_GibbsFreeEnergy = 12              ' pure or mixture property
    a_GrossHeatingValue = 13            ' pure or mixture property
    a_HeatCapacity = 14                 ' pure or mixture property
    a_HeatCapacityCv = 15               ' pure or mixture property
    a_InternalEnergy = 16               ' pure or mixture property
    a_LogFugacityCoefficient = 17       ' pure property or component property in a mixture
    a_MassDensity = 18                  ' pure or mixture property
    a_MolecularWeight = 19              ' parameter
    a_NetHeatingValue = 20              ' mixture property
    a_NormalBoilingPoint = 21           ' parameter
    a_NormalFreezingPoint = 22          ' parameter
    a_pH = 23                           ' mixture property
    a_SolubilityIndex = 24              ' component property in a mixture
    a_SurfaceTension = 25               ' pure or mixture property
    a_ThermalConductivity = 26          ' pure or mixture property
    a_VaporPressure = 27                ' pure property
    a_Viscosity = 28                    ' pure or mixture property
    a_Volume = 29                       ' pure or mixture property
End Enum

Public Property Get VaporPressure() As Long
    VaporPressure = AspenProperty.a_VaporPressure
End Property



