"""Independently read both CFB files. Compare every interoperable stream and native form."""
import collections
import io
import json
import re
import struct
import sys
import uuid
from pathlib import Path
from unittest.mock import patch

import olefile
from oletools import oleform
from oletools.olevba import decompress_stream
from extract_project import ROOT, SHA, dump, load_project, sha
from pack_project import FORM_GUID

TYPES={14:'Frame',17:'CommandButton',21:'Label',23:'TextBox',24:'ListBox',25:'ComboBox'}
def integer(data, pos):
    return struct.unpack_from('<I',data,pos)[0]


def sites(o, container, module):
    f=o.openstream(container+['f']).read()
    obj=o.openstream(container+['o']).read()
    sites=[]
    real=oleform.consume_OleSiteConcreteControl
    def record(stream):
        at=stream._pos
        result=real(stream)
        b=f[at:stream._pos]
        assert len(b)==4+struct.unpack_from('<H',b,2)[0]
        mask=integer(b,4)
        pos=8
        values={}
        for bit,field,size in [(0,'name',4),(1,'tag',4),(2,'id',4),(3,'help',4),(4,'flags',4),
                (5,'obj_size',4),(6,'tab',2),(7,'cls',2),(9,'group',2),(11,'tip',4),(12,'lic',4),
                (13,'control_source',4),(14,'row_source',4)]:
            if mask&(1<<bit):
                pos=(pos+size-1)//size*size
                values[field]=int.from_bytes(b[pos:pos+size],'little')
                pos+=size
        pos=(pos+3)&~3
        for key in ('name','tag','position','tip','lic','control_source','row_source'):
            if key=='position':
                if mask&256:
                    values['position']=struct.unpack_from('<ii',b,pos)
                    values['position_bytes_at']=at+pos
                    pos+=8
                continue
            if key in values:
                field=values[key]
                length=field&0x7fffffff
                values[key]=b[pos:pos+length].decode('latin1' if field>>31 else 'utf-16le')
                pos+=(length+3)&~3
        assert pos==len(b),(container,at,values,pos,len(b))
        assert result['name'].decode('cp1252')==values['name']
        assert result['id']==values['id'] and result['ClsidCacheIndex']==values['cls']
        sites.append(dict(**values,kind=TYPES[values['cls']],f_offset=at,bytes=len(b),site_sha256=sha(b)))
        return result
    s=oleform.ExtendedStream(io.BytesIO(f),'/'.join(container))
    with patch.object(oleform,'consume_OleSiteConcreteControl',record):
        list(oleform.consume_FormControl(s))
    design_ex=f[s._pos:]
    assert design_ex[:2]==b'\x00\x02' and len(design_ex)==4+U16(design_ex,2)
    cursor=0
    children=[]
    for site in sites:
        size=site.get('obj_size',0)
        content=obj[cursor:cursor+size]
        assert len(content)==size
        site.update(o_offset=cursor,object_sha256=sha(content))
        if size:
            site['object_property_mask']=content[4:12 if site['cls'] in (23,24,25) else 8].hex()
            cursor+=size
        elif site['cls']==14:
            child=next(p for p in o.listdir(streams=False,storages=True)
                       if p[:-1]==container and p[-1].startswith('i') and int(p[-1][1:])==site['id'])
            site['child_storage']=child[-1]
            children.append(child)
        site['events']=[p['name'] for p in module['procedures']
                        if p['name'].lower().startswith(site['name'].lower()+'_')]
    assert cursor==len(obj)
    assert sorted(children)==sorted(p for p in o.listdir(streams=False,storages=True) if p[:-1]==container)
    return dict(storage='/'.join(container),f_sha256=sha(f),o_sha256=sha(obj),sites=sites,
                design_ex_offset=s._pos,design_ex_bytes=design_ex.hex())


def inspect(original, rebuilt, source):
    assert sha(original.read_bytes())==SHA
    manifest=json.loads((source/'project.json').read_text('utf-8'))
    cache=json.loads((source/'evidence/cache.json').read_text('utf-8'))
    archive={}
    with olefile.OleFileIO(original,raise_defects=olefile.DEFECT_INCORRECT) as a, \
         olefile.OleFileIO(rebuilt,raise_defects=olefile.DEFECT_INCORRECT) as b:
        left=load_project(a)
        right=load_project(b)
        assert [m.name for m in left.modules]==[m.name for m in right.modules]==[m['name'] for m in manifest['modules']]
        assert left.codepage==right.codepage==1252
        assert a.root.clsid==b.root.clsid
        original_paths={tuple(p) for p in a.listdir()}
        rebuilt_paths={tuple(p) for p in b.listdir()}
        caches={p for p in original_paths if p[:-1]==(ROOT,'VBA') and p[-1].startswith('__SRP_')}
        assert original_paths-caches==rebuilt_paths
        trees=a.listdir(streams=False,storages=True)
        assert trees==b.listdir(streams=False,storages=True)
        assert all(a.direntries[a._find(p)].clsid==b.direntries[b._find(p)].clsid for p in trees)
        assert all(e.dwUserFlags==0 for db in (a,b) for e in db.direntries if e)
        sources={tuple(m.code_path.split('/')):(m,n) for m,n in zip(left.modules,right.modules)}
        directory=bytearray(decompress_stream(a.openstream([ROOT,'VBA','dir']).read()))
        for m in manifest['modules']:
            field=m['dir_offset_field']
            assert directory[field-6:field]==bytes.fromhex('310004000000')
            assert integer(directory,field)==m['original_text_offset']
            directory[field:field+4]=bytes(4)
        original_dir=decompress_stream(a.openstream([ROOT,'VBA','dir']).read())
        new_dir=decompress_stream(b.openstream([ROOT,'VBA','dir']).read())
        assert bytes(directory)==new_dir
        mapping=[]
        for p in sorted(original_paths):
            raw=a.openstream(p).read()
            row=dict(path='/'.join(p),original_bytes=len(raw),original_sha256=sha(raw))
            if p in caches:
                row['check']='implementation-specific SRP cache omitted on serialization'
            else:
                new=b.openstream(p).read()
                row.update(returned_bytes=len(new),returned_sha256=sha(new))
                if p in sources:
                    l,r=sources[p]
                    assert r.textoffset==0 and l.code_raw==r.code_raw
                    assert l.filename==r.filename and l.type==r.type
                    row.update(check='decompressed VBA bytes equal',source_bytes=len(l.code_raw),
                               source_sha256=sha(l.code_raw),procedures=len(cache[l.name]['procedures']))
                elif p==(ROOT,'VBA','dir'):
                    row.update(check='decompressed bytes equal except 43 MODULEOFFSET values',
                               original_plain_sha256=sha(original_dir),returned_plain_sha256=sha(new_dir))
                elif p==(ROOT,'VBA','_VBA_PROJECT'):
                    assert new==bytes.fromhex('cc61ffff000000') and raw[:4]==bytes.fromhex('cc61b500')
                    row['check']='interoperable version 0xffff without performance cache'
                else:
                    assert raw==new,p
                    row['check']='byte-identical'
            mapping.append(row)
        forms=[p for p in trees if p[-1].startswith('frm') or p[-1]=='i29']
        form_rows=[]
        pairs=[]
        for p in forms:
            original_layout=sites(a,p,cache[p[1]])
            returned_layout=sites(b,p,cache[p[1]])
            assert original_layout==returned_layout
            form_rows.append(original_layout)
        for m in manifest['modules']:
            if 'form' not in m:continue
            name=m['name']
            full=(source/m['form']['file']).read_bytes()
            sig,cb,z1,z2,cx,cy=struct.unpack_from('<6I',full)
            assert sig==0x8424c and cb==len(full)-24 and z1==z2==0
            frame=a.openstream([ROOT,name,'\x03VBFrame']).read()
            dims={k.decode():int(v) for k,v in re.findall(rb'Client(\w+)\s*=\s*(\d+)',frame)}
            assert (cx,cy)==(dims['Width']+2*dims['Left'],dims['Height']+dims['Top']+dims['Left'])
            with olefile.OleFileIO(io.BytesIO(full[24:]),raise_defects=olefile.DEFECT_INCORRECT) as frx:
                assert frx.root.clsid==FORM_GUID
                members={tuple(p) for p in frx.listdir()}
                native={tuple(p[2:]) for p in a.listdir() if p[:2]==[ROOT,name]}
                assert members==native-{('\x03VBFrame',)}
                for p in members-{('\x01CompObj',)}:
                    assert frx.openstream(p).read()==a.openstream([ROOT,name,*p]).read()
                comp=frx.openstream(['\x01CompObj']).read()
                assert comp[12:28]==uuid.UUID(FORM_GUID).bytes_le and b'Forms.Form.1\0' in comp
                assert all(frx.direntries[frx._find(p)].clsid==a.direntries[a._find([ROOT,name,*p])].clsid
                           for p in frx.listdir(storages=True,streams=False))
            pairs.append(dict(form=name,frm=m['file'],frx=m['form']['file'],extent=[cx,cy],
                              storage_class=FORM_GUID,embedded_stream_count=len(members)))
        controls=[s for c in form_rows for s in c['sites']]
        events=[n for s in controls for n in s['events']]
        host={}
        for m in left.modules:
            declarations=re.findall(r'(?im)^\s*(?:Public|Private|Dim|Friend)\s+WithEvents\s+(\w+)\s+As\s+([\w.]+)',m.code)
            owners=[(name,typ) for name,typ in declarations]
            role=next(r['role'] for r in manifest['modules'] if r['name']==m.name)
            if role=='BaseClass':
                owners.append(('UserForm','MSForms.UserForm'))
                ctl={e for s in controls for e in s['events']}
                all_events=[e['name'] for e in cache[m.name]['procedures'] if '_' in e['name']]
                assert all(e in ctl or e.startswith('UserForm_') for e in all_events)
            if role=='Document':
                owners.append(('Workbook' if m.name=='ThisWorkbook' else 'Worksheet',m.name))
            if role=='Class':
                owners.append(('Class',m.name))
            for owner,typ in owners:
                procs=[p['name'] for p in cache[m.name]['procedures'] if p['name'].lower().startswith(owner.lower()+'_')]
                if procs or (owner,typ) in declarations:
                    host.setdefault(m.name,[]).append(dict(receiver=owner,type=typ,procedures=procs))
        metadata=[]
        for pid,v in a.getproperties('\x05DocumentSummaryInformation').items():
            if pid in (24,25,30):
                assert v==b.getproperties('\x05DocumentSummaryInformation')[pid]
                metadata.append(dict(property_id=pid,bytes=len(v),sha256=sha(v)))
        wb=a.openstream('Workbook').read()
        pos=0;hist=collections.Counter();names=collections.Counter();codes=[];bofs=[];indexes=[]
        while pos<len(wb):
            rid,length=struct.unpack_from('<HH',wb,pos)
            body=wb[pos+4:pos+4+length]
            hist[f'{rid:04x}']+=1
            if rid==0x18:
                n=body[3]*(1+body[14]);names[body[15+n:].hex()]+=1
            if rid==0x809:bofs.append(dict(offset=pos,biff=U16(body,0),type=U16(body,2)))
            if rid==0x85:
                bounds=integer(body,0);assert U16(wb,bounds)==0x809
            if rid==0x20b:
                xf=integer(body,12);assert U16(wb,xf)==0x55 and len(body)==16
                indexes.append(dict(offset=pos,defcolwidth=xf))
            if rid==0x1ba:
                codes.append(body[3:].decode('utf-16le' if body[2]&1 else 'latin1'))
            pos+=length+4
        assert pos==len(wb) and bounds==bofs[1]['offset'] and codes==['ThisWorkbook','Sheet1']
        assert not a.parsing_issues and not b.parsing_issues
        assert len(controls)==42 and len(forms)==5
        archive=dict(original_sha256=SHA,fixture_sha256=sha(rebuilt.read_bytes()),storages=manifest['storages'],
            original_streams=len(original_paths),fixture_streams=len(rebuilt_paths),
            stream_checks=mapping,forms=form_rows,form_pairs=pairs,control_count=len(controls),control_event_count=len(events),
            host_events=host,signature_property_values=metadata,
            signature_scope='Comparison of preserved bytes only. Signer trust and host enforcement were not tested.',
            workbook=dict(bytes=len(wb),sha256=sha(wb),record_count=hist.total(),record_histogram=hist,
                defined_name_tokens=names,codenames=codes,bofs=bofs,boundsheet_target=bounds,indexes=indexes))
    return archive


U16=lambda b,i: struct.unpack_from('<H',b,i)[0]
if __name__=='__main__':
    result=inspect(*(Path(s) for s in sys.argv[1:4]))
    dump(Path(sys.argv[4]),result)
    print('streams, exported, controls, control event bindings, record count',
        result['original_streams'],result['fixture_streams'],result['control_count'],
        result['control_event_count'],result['workbook']['record_count'])

