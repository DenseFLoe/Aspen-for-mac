VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmGlobalUnitSet 
   Caption         =   "Manage Unit Sets"
   ClientHeight    =   4695
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5745
   OleObjectBlob   =   "frmGlobalUnitSet.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmGlobalUnitSet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Dim strGlobalUnit As String
Private savedCustomSets As String
Private CUSTOM_Name As String
Private CUSTOM_Temp As String
Private CUSTOM_Pres As String
Private CUSTOM_MolarCP As String
Private CUSTOM_MolarEnthalpy As String
Private CUSTOM_MolarVol As String
Public BaseUnitSet As String

Private Sub cmbGlobalUnitSetList_Change()
 With cmbGlobalUnitSetList
 strGlobalUnit = CStr(.Text)
    Select Case strGlobalUnit
           Case "English"
                 cmbTemperatureList.Text = cmbTemperatureList.list(1)
                 cmbPressureList.Text = cmbPressureList.list(1)
                 cmbMolarCP.Text = cmbMolarCP.list(1)
                 cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(1)
                 cmbMolarVol.Text = cmbMolarVol.list(1)
                 BaseUnitSet = "English"
                 g_BaseUnitSet = "English"
            Case "Metric", "Metrics"
                cmbTemperatureList.Text = cmbTemperatureList.list(2)
                cmbPressureList.Text = cmbPressureList.list(2)
                cmbMolarCP.Text = cmbMolarCP.list(2)
                cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(2)
                cmbMolarVol.Text = cmbMolarVol.list(2)
                BaseUnitSet = "Metric"
                g_BaseUnitSet = "Metric"
           Case "SI"
                cmbTemperatureList.Text = cmbTemperatureList.list(0)
                cmbPressureList.Text = cmbPressureList.list(0)
                cmbMolarCP.Text = cmbMolarCP.list(0)
                cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(0)
                cmbMolarVol.Text = cmbMolarVol.list(0)
                BaseUnitSet = "SI"
                g_BaseUnitSet = "SI"
            Case Else
                GetCustomUnitArrayFromName (strGlobalUnit)
    End Select
  End With
End Sub

Private Sub GetCustomUnitArrayFromName(unitSetID As String)
If (savedCustomSets <> "") Then
    Dim unitSets As Variant
    unitSets = Split(savedCustomSets, ";")
    Dim n As Integer
    For n = 0 To UBound(unitSets)
        Dim UnitSet As String
        UnitSet = unitSets(n)
            If (UnitSet = "") Then
                Exit For
            End If
            
        PopulateCustomSetValues (UnitSet)
        If (CUSTOM_Name = unitSetID) Then
            ' Find unit specified for Temperature
            If CUSTOM_Temp <> Empty Then
                For i = 0 To cmbTemperatureList.ListCount - 1
                    If CUSTOM_Temp = cmbTemperatureList.list(i) Then
                        Exit For
                    End If
                Next i
                cmbTemperatureList.Text = cmbTemperatureList.list(i)
            Else
                 cmbTemperatureList.Text = cmbTemperatureList.list(0)
            End If
            
            ' Find unit specified for pressure
            If CUSTOM_Pres <> Empty Then
                For i = 0 To cmbPressureList.ListCount - 1
                   If CUSTOM_Pres = cmbPressureList.list(i) Then
                        Exit For
                    End If
                Next i
            cmbPressureList.Text = cmbPressureList.list(i)
            Else
                cmbPressureList.Text = cmbPressureList.list(0)
            End If
            
            ' Find unit specified for molar volume
            If CUSTOM_MolarVol <> Empty Then
            For i = 0 To cmbMolarVol.ListCount - 1
                    If CUSTOM_MolarVol = cmbMolarVol.list(i) Then
                        Exit For
                    End If
                Next i
                cmbMolarVol.Text = cmbMolarVol.list(i)
            Else
                cmbMolarVol.Text = cmbMolarVol.list(0)
            End If
            
            ' Find unit specified for molar enthalpy
            If CUSTOM_MolarEnthalpy <> Empty Then
                For i = 0 To cmbMolarEnthalpy.ListCount - 1
                    If CUSTOM_MolarEnthalpy = cmbMolarEnthalpy.list(i) Then
                        Exit For
                    End If
                Next i
                cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(i)
            Else
                cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(0)
            End If
            
            ' Find unit specified for molar heat capacity
            If CUSTOM_MolarCP <> Empty Then
                For i = 0 To cmbMolarCP.ListCount - 1
                    If CUSTOM_MolarCP = cmbMolarCP.list(i) Then
                        Exit For
                    End If
                Next i
                cmbMolarCP.Text = cmbMolarCP.list(i)
            Else
                cmbMolarCP.Text = cmbMolarCP.list(0)
            End If
            Exit Sub
        End If
    Next n
End If

End Sub

Private Sub cmdCancel_Click()
   Me.Hide
   Unload frmGlobalUnitSet
End Sub

Private Sub cmdHelp_Click()
    Call COMAddinHelper.ShowHelp("40006")
End Sub

Private Sub cmdOK_Click()
    With cmbGlobalUnitSetList
        If .Text = Empty Then
           MsgBox "Please Select Global Units Set First"
           Exit Sub
        End If
       ' With frmUpdate
     
      ' frmGlobalUnitSet.Hide
       
        'Remove all whitespace from text
        .Text = Replace(.Text, " ", "")
       
        Call SelectUnit_Click("frmGlobalUnitSet")
      
        'Unload frmUpdate
        'End With
        
     End With
     
     Unload frmGlobalUnitSet
End Sub



Private Sub PopulateCustomSetValues(UnitSet As String)
Dim UnitSetTrim As String
Dim section As String
Dim value As String
UnitSetTrim = Trim(UnitSet)

Dim bTemp As Boolean
Dim bPres As Boolean
Dim bMolarCP As Boolean
Dim bMolarEnthalpy As Boolean
Dim bMolarVol As Boolean
Dim bBaseUnitSet As Boolean

bTemp = False
bPres = False
bMolarCP = False
bMolarEnthalpy = False
bMolarVol = False

GetUnitsSetName = ""
Do
    section = Mid(UnitSetTrim, 1, InStr(UnitSetTrim, ":"))
    UnitSetTrim = Mid(UnitSetTrim, InStr(UnitSetTrim, ":") + 1)
    UnitSetTrim = Mid(UnitSetTrim, 2)
    If InStr(UnitSetTrim, " ") = 0 Then
      value = Left(UnitSetTrim, Len(UnitSetTrim))
      strNew = Empty
    Else
        value = Mid(UnitSetTrim, 1, InStr(UnitSetTrim, " ") - 1)
        UnitSetTrim = Mid(UnitSetTrim, (Len(value) + 1))
        UnitSetTrim = Mid(UnitSetTrim, InStr(UnitSetTrim, " ") + 1)
    End If
    Select Case section
        Case "Global Units Set:"
            CUSTOM_Name = value
        Case " Temperature:"
            CUSTOM_Temp = value
            bTemp = True
        Case " Pressure:"
            CUSTOM_Pres = value
            bPres = True
        Case " Molar Volume:"
            CUSTOM_MolarVol = value
            bMolarVol = True
        Case " Molar Enthalpy:"
            CUSTOM_MolarEnthalpy = value
            bMolarEnthalpy = True
        Case " Molar Heat Capacity:"
            CUSTOM_MolarCP = value
            bMolarCP = True
        Case " BaseUnitSet:"
            BaseUnitSet = value
            bBaseUnitSet = True
    End Select
 Loop While (Len(UnitSetTrim) <> 0 And GetUnitSetName = "")
 
 If (bTemp = False) Then
    CUSTOM_Temp = Empty
 End If
 
 If (bPres = False) Then
    CUSTOM_Pres = Empty
 End If
 
 If (bMolarVol = False) Then
    CUSTOM_MolarVol = Empty
 End If
 
 If (bMolarEnthalpy = False) Then
    CUSTOM_MolarEnthalpy = Empty
 End If
 
 If (bMolarCP = False) Then
    CUSTOM_MolarCP = Empty
 End If
 
 If (bBaseUnistSet = False) Then
    BaseUnitSet = "SI"
 End If

End Sub

Private Sub UserForm_Initialize()
     Dim i As Integer
     i = 0
     
     
     With cmbGlobalUnitSetList
       .AddItem "SI"
       .AddItem "English"
       .AddItem "Metric"
       
        savedCustomSets = COMAddinHelper.GetSavedUnitDefs
        If (savedCustomSets <> "") Then
            Dim unitSets As Variant
            unitSets = Split(savedCustomSets, ";")
            Dim n As Integer
            For n = 0 To UBound(unitSets)
                Dim setName As String
                Dim UnitSet As String
                UnitSet = unitSets(n)
                If (UnitSet = "") Then
                    Exit For
                End If
                PopulateCustomSetValues (UnitSet)
                setName = CUSTOM_Name
                .AddItem setName
            Next n
        End If
     End With
     Call PopulateUnitArray
     With cmbTemperatureList
        Call GetUnitsConversion("TEMPERATURE")
        For i = LBound(arrPropTemp) To UBound(arrPropTemp)
            .AddItem arrPropTemp(i)
        Next i
     End With
     With cmbPressureList
        Call GetUnitsConversion("PRESSURE")
          For i = LBound(arrPropTemp) To UBound(arrPropTemp)
            .AddItem arrPropTemp(i)
          Next i
     End With
     With cmbMolarCP
        Call GetUnitsConversion("MOLE-HEAT-CAPACITY")
         For i = LBound(arrPropTemp) To UBound(arrPropTemp)
            .AddItem arrPropTemp(i)
          Next i
      End With
      
     With cmbMolarEnthalpy
        Call GetUnitsConversion("MOLE-ENTHALPY")
          For i = LBound(arrPropTemp) To UBound(arrPropTemp)
            .AddItem arrPropTemp(i)
          Next i
     End With
     With cmbMolarVol
        Call GetUnitsConversion("MOLE-VOLUME")
           For i = LBound(arrPropTemp) To UBound(arrPropTemp)
            .AddItem arrPropTemp(i)
          Next i
    End With
   Call setGlobalUnitForm
End Sub
'Private Function getIndexes(strListName As Object, strUnit As String) As Integer
'Dim iListCount As Integer
'Dim i As Integer
'iListCount = strListName.ListCount
'For i = 0 To iListCount
'If strUnit = strListName.List(i) Then
'getIndexes = i
'Exit Function
'End If
'Next i
'
'End Function
' S

' Subroutine : setGlobalUnitForm()
'            : sets global unit set with User Input Form (Global Unit Set)
'            :
' Created    : 05/06/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub setGlobalUnitForm()
Dim i As Integer
Call GetGlobalUnitArray   ' Gets previously defined global unit set if any
    ' Find global unit system first
    If aUnitSet(0) <> Empty Then
        Dim foundName As Boolean
        For i = 0 To cmbGlobalUnitSetList.ListCount - 1
            If CStr(aUnitSet(0)) = cmbGlobalUnitSetList.list(i) Then
                foundName = True
                Exit For
            End If
        Next i
        If (foundName = True) Then
            cmbGlobalUnitSetList.Text = cmbGlobalUnitSetList.list(i)
        Else
            cmbGlobalUnitSetList.Text = cmbGlobalUnitSetList.list(0)
        End If
    End If
    ' Find unit specified for Temperature, if any or use defalut temperature unit for specified global unit
    If aUnitSet(1) <> Empty Then
        For i = 0 To cmbTemperatureList.ListCount - 1
            If CStr(aUnitSet(1)) = cmbTemperatureList.list(i) Then
                Exit For
            End If
        Next i
        cmbTemperatureList.Text = cmbTemperatureList.list(i)
    Else
     Select Case CStr(aUnitSet(0))
        Case "SI"
            cmbTemperatureList.Text = cmbTemperatureList.list(0)
        Case "English"
            cmbTemperatureList.Text = cmbTemperatureList.list(1)
         Case "Metric", "Metrics"
            cmbTemperatureList.Text = cmbTemperatureList.list(2)
     End Select
    End If
    ' Find unit specified for pressure, if any or use defalut pressure unit for specified global unit
    If aUnitSet(2) <> Empty Then
       For i = 0 To cmbPressureList.ListCount - 1
            If CStr(aUnitSet(2)) = cmbPressureList.list(i) Then
                Exit For
            End If
        Next i
       cmbPressureList.Text = cmbPressureList.list(i)
    Else
     Select Case CStr(aUnitSet(0))
        Case "SI"
            cmbPressureList.Text = cmbPressureList.list(0)
        Case "English"
            cmbPressureList.Text = cmbPressureList.list(1)
         Case "Metric", "Metrics"
            cmbPressureList.Text = cmbPressureList.list(2)
     End Select
    End If
    ' Find unit specified for molar volume, if any or use defalut molar volume unit for specified global unit
    If aUnitSet(3) <> Empty Then
       For i = 0 To cmbMolarVol.ListCount - 1
            If CStr(aUnitSet(3)) = cmbMolarVol.list(i) Then
                Exit For
            End If
        Next i
        cmbMolarVol.Text = cmbMolarVol.list(i)
    Else
     Select Case CStr(aUnitSet(0))
        Case "SI"
            cmbMolarVol.Text = cmbMolarVol.list(0)
        Case "English"
            cmbMolarVol.Text = cmbMolarVol.list(1)
         Case "Metric", "Metrics"
            cmbMolarVol.Text = cmbMolarVol.list(2)
     End Select
    End If
    ' Find unit specified for molar enthalpy, if any or use defalut molar enthalpy unit for specified global unit
    If aUnitSet(4) <> Empty Then
        For i = 0 To cmbMolarEnthalpy.ListCount - 1
            If CStr(aUnitSet(4)) = cmbMolarEnthalpy.list(i) Then
                Exit For
            End If
        Next i
        cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(i)
    Else
     Select Case CStr(aUnitSet(0))
        Case "SI"
            cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(0)
        Case "English"
            cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(1)
         Case "Metric", "Metrics"
            cmbMolarEnthalpy.Text = cmbMolarEnthalpy.list(2)
     End Select
    End If
    ' Find unit specified for molar heat capacity, if any or use defalut molar heat capacity unit for specified global unit
    If aUnitSet(5) <> Empty Then
        For i = 0 To cmbMolarCP.ListCount - 1
            If CStr(aUnitSet(5)) = cmbMolarCP.list(i) Then
                Exit For
            End If
        Next i
        cmbMolarCP.Text = cmbMolarCP.list(i)
    Else
     Select Case CStr(aUnitSet(0))
        Case "SI"
            cmbMolarCP.Text = cmbMolarCP.list(0)
        Case "English"
            cmbMolarCP.Text = cmbMolarCP.list(1)
         Case "Metric", "Metrics"
            cmbMolarCP.Text = cmbMolarCP.list(2)
     End Select
    End If


End Sub
