Attribute VB_Name = "VBConstantsFlashReturnPV3"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnPV3
    pv3_Temperature = out_Temperature
    pv3_Enthalpy = out_Enthalpy
    pv3_Beta = out_Beta
    pv3_X1 = out_X1
    pv3_X2 = OUT_X2
    pv3_Y = out_Y
    pv3_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(7)
    list(1) = Temperature
    list(2) = Enthalpy
    list(3) = Beta
    list(4) = X1
    list(5) = X2
    list(6) = Y
    list(7) = SFRAC
    GetValues = list
    
End Function

Public Property Get Temperature() As Long
    Temperature = pv3_Temperature
End Property

Public Property Get Enthalpy() As Long
    Enthalpy = pv3_Enthalpy
End Property

Public Property Get Beta() As Long
    Beta = pv3_Beta
End Property

Public Property Get X1() As Long
    X1 = pv3_X1
End Property

Public Property Get X2() As Long
    X2 = pv3_X2
End Property

Public Property Get Y() As Long
    Y = pv3_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = pv3_SFRAC
End Property


