Attribute VB_Name = "VBPackage"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Private m_IsDefined As Boolean
Private m_Name As String

Public Sub Initialize(packageName As String)

    If (VBA.UCase(packageName) = "DEFAULT" Or FileExists(packageName)) Then
        m_Name = packageName
        Call HeartBeat
        m_IsDefined = True
    Else
        Debug.Print ""
        Debug.Print String(110, "*")
        Debug.Print "*** Package source does not exist " & packageName
        Debug.Print String(110, "*")
        Debug.Print ""
        Err.Raise vbObjectError + 9000, "VBPackage.Initialize", _
        "Package source does not exist:" & VBA.vbCrLf & VBA.vbCrLf & packageName
    End If
    
End Sub

Public Property Get UnitSet() As String

    If m_IsDefined Then
        UnitSet = "SI"
    End If
    
End Property

Property Get Name() As String

    Name = m_Name
    
End Property

Public Sub HeartBeat()

    Call APXL_SetPackage(m_Name)
    Call CheckUnitArray
    
End Sub

Public Function GetComponents()

    Dim bExit As Boolean
    Dim comps As Variant
    
TRY_AND_RECOVER:
    comps = COMAddinHelper.APXL_GetCompIDs
    If (Not bExit And IsEmpty(comps)) Then
        Call HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    
    GetComponents = MakeBase1(comps)

End Function

Public Function GetMethods()

    Dim bExit As Boolean
    Dim result As String
    Dim names As Variant
    
TRY_AND_RECOVER:
    result = COMAddinHelper.APXL_GetMethodLabels
    result = Trim(result)
    If (Mid(result, Len(result), 1) = ";") Then
        result = Mid(result, 1, Len(result) - 1)
    End If
    names = Split(result, ";")
    If (Not bExit And IsEmpty(names)) Then
        Call HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    
    GetMethods = MakeBase1(names)
    
End Function

Private Function MakeBase1(arr As Variant) As Variant

    Dim i As Integer
    Dim imax As Integer
    Dim result As Variant
    
    If LBound(arr) = 1 Then
        MakeBase1 = arr
        Exit Function
    End If
    
    imax = UBound(arr) + 1
    ReDim result(imax)
    For i = 1 To imax
        result(i) = arr(i - 1)
    Next i
    MakeBase1 = result
    
End Function

Private Function FileExists(fullPath As String) As Boolean
    
    On Error Resume Next
    
    If Not (Dir(fullPath, vbDirectory) = vbNullString) And (fullPath <> vbNullString) Then
        FileExists = True
    End If
    
End Function
