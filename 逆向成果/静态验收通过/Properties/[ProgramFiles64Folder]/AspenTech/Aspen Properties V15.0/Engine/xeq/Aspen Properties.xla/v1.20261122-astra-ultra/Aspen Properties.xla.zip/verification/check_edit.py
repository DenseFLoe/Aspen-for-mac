"""Change scratch copies of one component, one form/control and one defined name. Static readback only."""
import io
import json
import re
import shutil
import struct
import sys
import tempfile
from pathlib import Path

import olefile
from check_static import sites, U16
from extract_project import ROOT, dump, load_project
from pack_project import assemble

def run(source, work, output):
    work=work.resolve()
    changed=work/'edited-readback.xla'
    with tempfile.TemporaryDirectory(dir=work) as tmp:
        base=Path(tmp).resolve()
        assert base.parent==work
        for name in ('vba','project'):
            shutil.copytree(source/name,base/name)
        for name in ('project.json','workbook.json'):
            shutil.copyfile(source/name,base/name)
        vb=base/'vba/VBACaller.bas'
        tag=b"' Static source readback probe"
        vb.write_bytes(vb.read_bytes().replace(b'Option Explicit',tag+b'\r\nOption Explicit'))
        frm=base/'vba/frmGlobalUnitSet.frm'
        assert frm.read_bytes().count(b'"Manage Unit Sets"')==1
        frm.write_bytes(frm.read_bytes().replace(b'"Manage Unit Sets"',b'"Unit sets readback"'))
        static=json.loads((source/'evidence/static.json').read_text('utf-8'))
        form=next(x for x in static['forms'] if x['storage']==ROOT+'/frmGlobalUnitSet')
        site=form['sites'][0]
        target=site['position'][0]+100
        frx=base/'vba/frmGlobalUnitSet.frx'
        raw=frx.read_bytes()
        memory=io.BytesIO(raw[24:])
        with olefile.OleFileIO(memory,write_mode=True) as obj:
            f=bytearray(obj.openstream('f').read())
            struct.pack_into('<i',f,site['position_bytes_at'],target)
            obj.write_stream('f',bytes(f))
        frx.write_bytes(raw[:24]+memory.getvalue())
        record_file=base/'workbook.json'
        records=json.loads(record_file.read_text('utf-8'))
        selected=next(r['defined_name'] for r in records if 'defined_name' in r and
                      r['defined_name']['formula_tokens']=='1e0000' and re.fullmatch('[A-Za-z][A-Za-z0-9_]*',r['defined_name']['text']))
        old_name=selected['text'];new_name=old_name+'_Readback'
        selected['text']=new_name
        dump(record_file,records)
        assemble(base,changed)
        with olefile.OleFileIO(changed,raise_defects=olefile.DEFECT_INCORRECT) as db:
            modules=load_project(db).modules
            assert next(m for m in modules if m.name=='VBACaller').code_raw==vb.read_bytes()
            frame=db.openstream([ROOT,'frmGlobalUnitSet','\x03VBFrame']).read()
            assert b'"Unit sets readback"' in frame and b'"Manage Unit Sets"' not in frame
            fresh=sites(db,[ROOT,'frmGlobalUnitSet'],dict(procedures=[]))
            readback=next(s for s in fresh['sites'] if s['name']==site['name'])
            assert list(readback['position'])==[target,site['position'][1]]
            wb=db.openstream('Workbook').read()
            p=0;seen=[];bound=ix=None
            while p<len(wb):
                rid,size=struct.unpack_from('<HH',wb,p)
                body=wb[p+4:p+4+size];p+=4+size
                if rid==0x18:
                    seen.append(body[15:15+body[3]*(body[14]+1)].decode('utf-16le' if body[14] else 'latin1'))
                if rid==0x85:bound=struct.unpack_from('<I',body)[0]
                if rid==0x20b:ix=struct.unpack_from('<I',body,12)[0]
            assert seen.count(new_name)==1 and U16(wb,bound)==0x809 and U16(wb,ix)==0x55
            assert bound==static['workbook']['boundsheet_target']+len(wb)-static['workbook']['bytes']
            assert ix==static['workbook']['indexes'][0]['defcolwidth']+len(wb)-static['workbook']['bytes']
        dump(output,dict(module='VBACaller',source_edit_read_back=True,form='frmGlobalUnitSet',
             caption_read_back='Unit sets readback',control=site['name'],original_position=site['position'],
             edited_position=readback['position'],defined_name_before=old_name,defined_name_after=new_name,
             boundsheet_target=bound,index_defcolwidth_target=ix,excel_or_macros_executed=False))


if __name__=='__main__':
    run(*(Path(a) for a in sys.argv[1:]))

