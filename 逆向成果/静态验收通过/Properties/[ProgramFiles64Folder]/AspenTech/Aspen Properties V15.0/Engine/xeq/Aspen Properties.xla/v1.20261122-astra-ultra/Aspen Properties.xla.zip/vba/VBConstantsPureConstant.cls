Attribute VB_Name = "VBConstantsPureConstant"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum AspenParameter
' parameter -   scalar
    par_AcentricFactor = AspenProperty.a_AcentricFactor
    par_CriticalCompressibilityFactor = AspenProperty.a_CriticalCompressibilityFactor
    par_CriticalPressure = AspenProperty.a_CriticalPressure
    par_CriticalTemperature = AspenProperty.a_CriticalTemperature
    par_MolecularWeight = AspenProperty.a_MolecularWeight
    par_NormalBoilingPoint = AspenProperty.a_NormalBoilingPoint
    par_NormalFreezingPoint = AspenProperty.a_NormalFreezingPoint
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(7)
    list(1) = AcentricFactor
    list(2) = CriticalCompressibilityFactor
    list(3) = CriticalPressure
    list(4) = CriticalTemperature
    list(5) = MolecularWeight
    list(6) = NormalBoilingPoint
    list(7) = NormalFreezingPoint
    GetValues = list
    
End Function

Public Property Get AcentricFactor() As Long
    AcentricFactor = par_AcentricFactor
End Property

Public Property Get CriticalCompressibilityFactor() As Long
    CriticalCompressibilityFactor = par_CriticalCompressibilityFactor
End Property

Public Property Get CriticalPressure() As Long
    CriticalPressure = par_CriticalPressure
End Property

Public Property Get CriticalTemperature() As Long
    CriticalTemperature = par_CriticalTemperature
End Property

Public Property Get MolecularWeight() As Long
    MolecularWeight = par_MolecularWeight
End Property

Public Property Get NormalBoilingPoint() As Long
    NormalBoilingPoint = par_NormalBoilingPoint
End Property

Public Property Get NormalFreezingPoint() As Long
    NormalFreezingPoint = par_NormalFreezingPoint
End Property
