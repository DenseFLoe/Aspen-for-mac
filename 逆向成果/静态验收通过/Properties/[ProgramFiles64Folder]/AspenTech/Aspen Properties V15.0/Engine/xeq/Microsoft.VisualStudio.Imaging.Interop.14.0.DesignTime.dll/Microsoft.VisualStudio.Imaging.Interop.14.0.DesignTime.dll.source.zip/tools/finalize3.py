import sys, zipfile
from hashlib import sha256
from pathlib import Path

def main(src, out, ovr):
    src, out, ovr = Path(src), Path(out), Path(ovr)
    with zipfile.ZipFile(src) as z:
        members = {n: z.read(n) for n in z.namelist()}
    for name in ("token_replay3.py", "pe_layout2.py", "replay2.py", "build_recipe2.py"):
        base = ovr if (ovr / name).is_file() else Path(__file__).resolve().parent
        members["tools/" + name] = (base / name).read_bytes()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for n in sorted(members):
            z.writestr(n, members[n])
    print(sha256(out.read_bytes()).hexdigest(), out)

if __name__ == "__main__":
    main(*sys.argv[1:4])
