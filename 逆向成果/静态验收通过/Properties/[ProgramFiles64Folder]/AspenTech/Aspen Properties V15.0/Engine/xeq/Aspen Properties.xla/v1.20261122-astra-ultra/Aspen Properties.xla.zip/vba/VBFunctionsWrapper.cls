Attribute VB_Name = "VBFunctionsWrapper"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Private m_Package       As VBPackage
Private m_Constants     As VBConstants
Private m_Helper        As VBHelper
Private m_IsDefined     As Boolean
'

Public Function Initialize(package_ As VBPackage, constants_ As VBConstants, helper_ As VBHelper) As Boolean

    Set m_Package = package_
    Set m_Constants = constants_
    Set m_Helper = helper_
    m_IsDefined = True
    Initialize = True
    
End Function

Private Sub NormalizeFractions(ByRef fracs As Variant)

    Dim sum As Double
    Dim i As Integer
    
    For i = LBound(fracs) To UBound(fracs)
        sum = sum + fracs(i)
    Next i
    If (sum <> 1) Then
        For i = LBound(fracs) To UBound(fracs)
            fracs(i) = fracs(i) / sum
        Next i
    End If
    
End Sub

Private Function Modify(arr As Variant) As Variant

    Const IBASE As Integer = 1
    Dim imax As Integer
    Dim i As Integer
    Dim result As Variant
    
    If IsEmpty(arr) Then
        Modify = Empty
        Exit Function
    ElseIf (Not IsArray(arr) And (VarType(arr) = vbString Or IsNumeric(arr))) Then ' singular input
        ReDim result(IBASE To IBASE)
        result(IBASE) = arr
        Modify = result
        Exit Function
    End If
    
    If (Not IsArray(arr) And VarType(arr) = vbString) Then ' singular input
        ReDim result(IBASE To IBASE)
        result(IBASE) = arr
        Modify = result
        Exit Function
    ElseIf (IBASE = 1) Then ' change base, because Aspen Calculator returns base 0
        imax = UBound(arr) + 1
        ReDim result(imax)
        For i = IBASE To imax
            result(i) = arr(i - IBASE)
        Next i
        Modify = result
        Exit Function
    ElseIf (IBASE < 0 Or IBASE > 1) Then
        Call MsgBox("Invalid base input. Base can only be 0 or 1.", vbOKOnly + vbExclamation, "Modify")
        Modify = Empty
        Exit Function
    End If
    Modify = arr

End Function

Private Function MakeBase1(arr As Variant) As Variant

    Dim i As Integer
    Dim imax As Integer
    Dim result As Variant
    
    If LBound(arr) = 1 Then
        MakeBase1 = arr
        Exit Function
    End If
    
    imax = UBound(arr) + 1
    ReDim result(imax)
    For i = 1 To imax
        result(i) = arr(i - 1)
    Next i
    MakeBase1 = result
    
End Function

Private Function Size(arr As Variant) As Integer

    If (Not IsArray(arr)) Then
        Size = 0
    End If
    If (LBound(arr) = UBound(arr)) Then
        Size = 1
    Else
        Size = UBound(arr) - LBound(arr) + 1
    End If

End Function

'==============================================================================================================
' Average Molecular Weight
'==============================================================================================================
Public Function AverageMolecularWeight(ByVal components As Variant, ByVal moleFractions As Variant) As Variant

    Dim bExit As Boolean
    Dim result As Variant
    Dim vComponents As Variant
    Dim vMoleFractions As Variant
    Dim v As Variant
    
    If IsArray(components) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    If IsArray(moleFractions) Then
        vMoleFractions = moleFractions
    Else
        vMoleFractions = Modify(moleFractions)
    End If
    If Size(vComponents) <> Size(vMoleFractions) Then
        AverageMolecularWeight = "<ERROR> 'components' and 'moleFractions' must be the same size."
        Exit Function
    End If
    
TRY_AND_RECOVER:
    result = Functions.AverageMolecularWeight(components, vMoleFractions)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    AverageMolecularWeight = result

End Function


'==============================================================================================================
' Mole Fraction to Mass Fraction
'==============================================================================================================
Public Function MoleFractionToMassFraction(ByVal components As Variant, ByVal moleFractions As Variant) As Variant

    Dim bExit As Boolean
    Dim result As Variant
    Dim vComponents As Variant
    Dim vMoleFractions As Variant
    Dim v As Variant
    
    If IsArray(components) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    If IsArray(moleFractions) Then
        vMoleFractions = moleFractions
    Else
        vMoleFractions = Modify(moleFractions)
    End If
    If Size(vComponents) <> Size(vMoleFractions) Then
        MoleFractionToMassFraction = "<ERROR> 'components' and 'moleFractions' must be the same size."
        Exit Function
    End If
    
TRY_AND_RECOVER:
    result = Functions.MoleFractionToMassFraction(vComponents, vMoleFractions)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    MoleFractionToMassFraction = Modify(result)

End Function

'==============================================================================================================
' Mole Flow to Mole Fraction
'==============================================================================================================
Public Function MoleFlowToMoleFraction(ByVal components As Variant, ByVal moleFlows As Variant) As Variant

    Dim bExit As Boolean
    Dim result As Variant
    Dim vComponents As Variant
    Dim vMoleFlows As Variant
    
    If IsArray(components) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    If IsArray(moleFlows) Then
        vMoleFlows = moleFlows
    Else
        vMoleFlows = Modify(moleFlows)
    End If
    If Size(vComponents) <> Size(vMoleFlows) Then
        MoleFlowToMoleFraction = "<ERROR> 'components' and 'moleFlows' must be the same size."
        Exit Function
    End If
    
TRY_AND_RECOVER:
    result = Functions.MoleFlowToMoleFraction(vComponents, vMoleFlows)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    MoleFlowToMoleFraction = Modify(result)

End Function

'==============================================================================================================
' Mass Fraction to Mole Fraction
'==============================================================================================================
Public Function MassFractionToMoleFraction(ByVal components As Variant, ByVal massFractions As Variant) As Variant

    Dim bExit As Boolean
    Dim result As Variant
    Dim vComponents As Variant
    Dim vMassFractions As Variant
    Dim v As Variant
    
    If IsArray(components) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    If IsArray(massFractions) Then
        vMassFractions = massFractions
    Else
        vMassFractions = Modify(massFractions)
    End If
    If Size(vComponents) <> Size(vMassFractions) Then
        MassFractionToMoleFraction = "<ERROR> 'components' and 'massFractions' must be the same size."
        Exit Function
    End If
    
TRY_AND_RECOVER:
    result = Functions.MassFractionToMoleFraction(vComponents, vMassFractions)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    MassFractionToMoleFraction = Modify(result)

End Function

'==============================================================================================================
' Mass Flow to Mole Fraction
'==============================================================================================================
Public Function MassFlowToMoleFraction(ByVal components As Variant, ByVal massFlows As Variant) As Variant

    Dim bExit As Boolean
    Dim result As Variant
    Dim vComponents As Variant
    Dim vMassFlows As Variant
    
    If IsArray(components) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    If IsArray(massFlows) Then
        vMassFlows = massFlows
    Else
        vMassFlows = Modify(massFlows)
    End If
    If Size(vComponents) <> Size(vMassFlows) Then
        MassFlowToMoleFraction = "<ERROR> 'components' and 'massFlows' must be the same size."
        Exit Function
    End If
    
TRY_AND_RECOVER:
    result = Functions.MassFlowToMoleFraction(vComponents, vMassFlows)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    MassFlowToMoleFraction = Modify(result)

End Function

'==============================================================================================================
' Unit Conversion
'==============================================================================================================
Public Function UnitsConversion(fromUnit As String, toUnit As String, values As Variant) As Variant

    Dim bExit As Boolean
    Dim result As Variant
    
TRY_AND_RECOVER:
    result = Functions.UnitsConversion(fromUnit, toUnit, values)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    If IsArray(result) Then
        If (Size(values) = Size(result)) Then
            UnitsConversion = Modify(result)
        Else
            UnitsConversion = result(LBound(result))
        End If
    Else
        UnitsConversion = result
    End If

End Function

'==============================================================================================================
' Vapor Pressure
'==============================================================================================================
Public Function VaporPressure(ByVal components As Variant, ByVal tt As Double) As Variant

    Dim bExit As Boolean
    Dim vComponents As Variant
    Dim propName As String
    Dim result As Variant

    propName = m_Helper.PropertyName(AspenProperty.a_VaporPressure)
    
    If (VarType(components) <> vbString) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    
TRY_AND_RECOVER:
    result = Functions.VaporPressure(vComponents, CStr(tt))
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    VaporPressure = Modify(result)
    
End Function

'==============================================================================================================
' PURE PROPERTY
'==============================================================================================================
'    pure_Enthalpy
'    pure_Entropy
'    pure_Fugacity
'    pure_FugacityCoefficient
'    pure_GibbsFreeEnergy
'    pure_GrossHeatingValue
'    pure_HeatCapacity
'    pure_HeatCapacityCv
'    pure_InternalEnergy
'    pure_LogFugacityCoefficient
'    pure_MassDensity
'    pure_SurfaceTension
'    pure_ThermalConductivity
'    pure_VaporPressure
'    pure_Viscosity
'    pure_Volume

Public Function PureProperty(ByVal components As Variant, ByVal propertyCode As AspenPureProperty, ByVal tt As Double, ByVal pp As Double, _
                             ByVal phase As String, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim vComponents As Variant
    Dim propName As String
    Dim result As Variant
    
    phase = UCase(phase)
    If (phase = "VAPOR" Or phase = "VAPOUR") Then
        phase = "V"
    ElseIf (phase = "LIQUID") Then
        phase = "L"
    ElseIf (phase = "SOLID") Then
        phase = "S"
    End If

    If (phase <> "V" And phase <> "L" And phase <> "S") Then
        PureProperty = "<ERROR> '" & phase & "' is not a valid phase."
        Exit Function
    End If
    
    propName = m_Helper.PropertyName(propertyCode)
    
    If (phase = "V") Then
        If (propertyCode = pure_SurfaceTension) Then
            PureProperty = "<ERROR> 'V' is not a valid phase for '" & propName & "'."
            Exit Function
        End If
    ElseIf (phase = "S") Then
        If (propertyCode = pure_SurfaceTension Or propertyCode = pure_Viscosity) Then
            PureProperty = "<ERROR> 'S' is not a valid phase for '" & propName & "'."
            Exit Function
        End If
    End If
    
    If (VarType(components) <> vbString) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    
TRY_AND_RECOVER:
    result = Functions.PureProperty(vComponents, propName, CStr(tt), CStr(pp), phase, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PureProperty = Modify(result)

End Function

'==============================================================================================================
' MIXTURE PROPERTY
'==============================================================================================================
'    mix_Enthalpy
'    mix_Entropy
'    mix_GibbsFreeEnergy
'    mix_GrossHeatingValue
'    mix_HeatCapacity
'    mix_HeatCapacityCv
'    mix_InternalEnergy
'    mix_MassDensity
'    mix_NetHeatingValue
'    mix_pH
'    mix_SurfaceTension
'    mix_ThermalConductivity
'    mix_Viscosity
'    mix_Volume
    
Public Function MixtureProperty(ByVal components As Variant, moleFractions As Variant, propertyCode As AspenMixtureProperty, ByVal tt As Double, ByVal pp As Double, _
                                ByVal phase As String, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant
    Dim vComponents As Variant
    Dim vMoleFractions As Variant
    Dim propName As String
    
    phase = UCase(phase)
    If (phase = "VAPOR" Or phase = "VAPOUR") Then
        phase = "V"
    ElseIf (phase = "LIQUID") Then
        phase = "L"
    ElseIf (phase = "SOLID") Then
        phase = "S"
    End If

    If (phase <> "V" And phase <> "L" And phase <> "S") Then
        MixtureProperty = "<ERROR> '" & phase & "' is not a valid phase."
        Exit Function
    End If
    
    propName = m_Helper.PropertyName(propertyCode)
    
    If (phase = "V") Then
        If (propertyCode = pure_SurfaceTension Or propertyCode = mix_pH Or propertyCode = mix_ActivityCoefficient) Then
            MixtureProperty = "<ERROR> 'V' is not a valid phase for '" & propName & "'."
            Exit Function
        End If
    ElseIf (phase = "S") Then
        If (propertyCode = mix_GrossHeatingValue Or propertyCode = mix_NetHeatingValue Or propertyCode = mix_pH Or propertyCode = mix_SurfaceTension Or propertyCode = mix_Viscosity Or propertyCode = mix_ActivityCoefficient) Then
            MixtureProperty = "<ERROR> 'S' is not a valid phase for '" & propName & "'."
            Exit Function
        End If
    End If
    
    If IsArray(components) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    If IsArray(moleFractions) Then
        vMoleFractions = moleFractions
    Else
        vMoleFractions = Modify(moleFractions)
    End If
    If Size(vComponents) <> Size(vMoleFractions) Then
        MixtureProperty = "<ERROR> 'components' and 'moleFractions' must be the same size."
        Exit Function
    End If
    
    Call NormalizeFractions(vMoleFractions)
    
TRY_AND_RECOVER:
    result = Functions.MixtureProperty(vComponents, vMoleFractions, propName, CStr(tt), CStr(pp), phase, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    If IsArray(result) Then
        If (Size(vComponents) = Size(result)) Then
            MixtureProperty = Modify(result)
        Else
            MixtureProperty = result(LBound(result))
        End If
    Else
        MixtureProperty = result
    End If
    
End Function

'==============================================================================================================
' COMPONENT PARAMETER
'==============================================================================================================
'    par_AcentricFactor
'    par_CriticalCompressibilityFactor
'    par_CriticalPressure
'    par_CriticalTemperature
'    par_MolecularWeight
'    par_NormalBoilingPoint
'    par_NormalFreezingPoint
Public Function PureComponentConstant(ByVal components As Variant, propertyCode As AspenParameter) As Variant

    Dim bExit As Boolean
    Dim result As Variant
    Dim vComponents As Variant
    Dim propName As String
    
    propName = m_Helper.PropertyName(propertyCode)
    
    If (VarType(components) <> vbString) Then
        vComponents = components
    Else
        vComponents = Modify(components)
    End If
    
TRY_AND_RECOVER:
    result = Functions.PureComponentConstant(vComponents, propName)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    '--If Not IsArray(result) Then
    '--    PureComponentConstant = result
    '--Else 'e.g., surface tension result
    '--    PureComponentConstant = Modify(result)
    '--End If
    If IsArray(components) Then
        PureComponentConstant = Modify(result)
    Else
        PureComponentConstant = result(0)
    End If
    
End Function

'==============================================================================================================
' VAPOR-LIQUID EQUILIBRIUM (VLE) FLASH
'==============================================================================================================
'    PV_VLE      ' pressure-vapor fraction VLE flash
'    PH_VLE      ' pressure-enthalpy VLE flash
'    TP_VLE      ' temperature-pressure VLE flash
'    TV_VLE      ' temperature-vapor fraction VLE flash
'    TH_VLE      ' tempeature-enthalpy VLE flash
'    PS_VLE      ' pressure-entropy VLE flash
'    PU_VLE      ' pressure-internal energy VLE flash
    
Public Function PVFlash(ByVal components As Variant, ByRef moleFractions As Variant, ByVal pp As Double, ByVal vfrac As Double, _
                        ByVal ReturnWhat As FlashReturnPV, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.PVFlash(components, moleFractions, CStr(pp), CStr(vfrac), m_Helper.ReturnName(ReturnWhat), propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PVFlash = Modify(result)
    
End Function

Public Function PHFlash(ByVal components As Variant, ByRef moleFractions As Variant, ByVal pp As Double, ByVal hh As Double, _
                        ByVal ReturnWhat As FlashReturnPH, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.PHFlash(components, moleFractions, CStr(pp), CStr(hh), m_Helper.ReturnName(ReturnWhat), propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PHFlash = Modify(result)
    
End Function


Public Function TPFlash(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal pp As Double, _
                        ByVal ReturnWhat As FlashReturnTP, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.TPFlash(components, moleFractions, CStr(tt), CStr(pp), m_Helper.ReturnName(ReturnWhat), propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    TPFlash = Modify(result)
    
End Function

Public Function TVFlash(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal vfrac As Double, _
                        ByVal ReturnWhat As FlashReturnTV, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.TVFlash(components, moleFractions, CStr(tt), CStr(vfrac), m_Helper.ReturnName(ReturnWhat), propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    TVFlash = Modify(result)
    
End Function

Public Function THFlash(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal hh As Double, _
                        ByVal ReturnWhat As FlashReturnTH, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.THFlash(components, moleFractions, CStr(tt), CStr(hh), m_Helper.ReturnName(ReturnWhat), propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    THFlash = Modify(result)
    
End Function

Public Function PSFlash(ByVal components As Variant, ByRef moleFractions As Variant, ByVal pp As Double, ByVal ss As Double, _
                        ByVal ReturnWhat As FlashReturnPS, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.PSFlash(components, moleFractions, CStr(pp), CStr(ss), m_Helper.ReturnName(ReturnWhat), propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PSFlash = Modify(result)
    
End Function

Public Function PUFlash(ByVal components As Variant, ByRef moleFractions As Variant, ByVal pp As Double, ByVal uu As Double, _
                        ByVal ReturnWhat As FlashReturnPU, Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)

TRY_AND_RECOVER:
    result = Functions.PUFlash(components, moleFractions, CStr(pp), CStr(uu), m_Helper.ReturnName(ReturnWhat), propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PUFlash = Modify(result)
    
End Function

'==============================================================================================================
' VAPOR-LIQUID-LIQUID EQUILIBRIUM (VLLE) FLASH
'==============================================================================================================
'    PV_VLLE     ' pressure-vapor fraction VLLE flash
'    PH_VLLE     ' pressure-enthalpy VLLE flash
'    TP_VLLE     ' temperature-pressure VLLE flash
'    TV_VLLE     ' temperature-vapor fraction VLLE flash
'    TH_VLLE     ' temperature-enthalpy VLLE flash
    
Public Function PVFlash3(ByVal components As Variant, ByRef moleFractions As Variant, ByVal pp As Double, ByVal vfrac As Double, _
                         ByVal ReturnWhat As FlashReturnPV3, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.PVFlash3(components, moleFractions, CStr(pp), CStr(vfrac), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PVFlash3 = Modify(result)
    
End Function

Public Function PHFlash3(ByVal components As Variant, ByRef moleFractions As Variant, ByVal pp As Double, ByVal hh As Double, _
                         ByVal ReturnWhat As FlashReturnPH3, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.PHFlash3(components, moleFractions, CStr(pp), CStr(hh), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PHFlash3 = Modify(result)
    
End Function

Public Function TPFlash3(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal pp As Double, _
                         ByVal ReturnWhat As FlashReturnTP3, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.TPFlash3(components, moleFractions, CStr(tt), CStr(pp), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    TPFlash3 = Modify(result)
    
End Function

Public Function TVFlash3(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal vfrac As Double, _
                         ByVal ReturnWhat As FlashReturnTV3, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.TVFlash3(components, moleFractions, CStr(tt), CStr(vfrac), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    TVFlash3 = Modify(result)
    
End Function

Public Function THFlash3(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal hh As Double, _
                         ByVal ReturnWhat As FlashReturnTH3, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.THFlash3(components, moleFractions, CStr(tt), CStr(hh), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    THFlash3 = Modify(result)
    
End Function

'==============================================================================================================
' LIQUID-LIQUID EQUILIBRIUM (LLE) FLASH
'==============================================================================================================
'    PH_LLE      ' pressure-enthalpy LLE flash
'    TP_LLE      ' temperature-pressure LLE flash
'    TH_LLE      ' temperature-enthalpy LLE flash

Public Function PHFlashLL(ByVal components As Variant, ByRef moleFractions As Variant, ByVal pp As Double, ByVal hh As Double, _
                          ByVal ReturnWhat As FlashReturnPHLL, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.PHFlashLL(components, moleFractions, CStr(pp), CStr(hh), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    PHFlashLL = Modify(result)
    
End Function

Public Function TPFlashLL(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal pp As Double, _
                          ByVal ReturnWhat As FlashReturnTPLL, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.TPFlashLL(components, moleFractions, CStr(tt), CStr(pp), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    TPFlashLL = Modify(result)
    
End Function

Public Function THFlashLL(ByVal components As Variant, ByRef moleFractions As Variant, ByVal tt As Double, ByVal hh As Double, _
                          ByVal ReturnWhat As FlashReturnTHLL, Optional keyComponent As String = "", Optional ByVal propertyMethod = "") As Variant

    Dim bExit As Boolean
    Dim result As Variant

    Call NormalizeFractions(moleFractions)
    
TRY_AND_RECOVER:
    result = Functions.THFlashLL(components, moleFractions, CStr(tt), CStr(hh), m_Helper.ReturnName(ReturnWhat), keyComponent, propertyMethod)
    If (Not bExit And IsEmpty(result)) Then
        Call m_Package.HeartBeat
        bExit = True
        GoTo TRY_AND_RECOVER
    End If
    THFlashLL = Modify(result)
    
End Function





