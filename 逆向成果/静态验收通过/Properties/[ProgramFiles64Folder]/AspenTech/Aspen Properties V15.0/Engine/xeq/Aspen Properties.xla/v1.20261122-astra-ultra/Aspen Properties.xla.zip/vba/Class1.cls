Attribute VB_Name = "Class1"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Public bCloseApp As Boolean
Private pathString As String
Public strFilename As String
Public bNewAppFlag As Boolean
Public strPath As String
Private strTemp As String
Private file_size As Long
Private bInitNewFlag As Boolean
Private bConstFlag As Boolean
Private bformFlag As Boolean
Dim fileName As Object
Dim intRetValue As Integer
Dim intCount As Integer
Dim strFilePath As String
Dim WithEvents mobjHappHappIp As Happ.HappLS
Attribute mobjHappHappIp.VB_VarHelpID = -1
Dim WithEvents mobjtemp As Happ.HappLS
Attribute mobjtemp.VB_VarHelpID = -1
Private strTempPath As String

' Subroutine : Class_Initialize()
'              Instantiate the mobjHappHapIp with AspenProperties.Document
'              Checks out whether to open the New Aspen Properties or to open from
'              any earlier creeated .aprbkp file
' Created    : 03/06/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas

Public Sub CloseApp()
If mobjHappHappIp Is Nothing Then
  Exit Sub
End If

mobjHappHappIp.Visible = False
mobjHappHappIp.SuppressDialogs = True
Set mobjHappHappIp = Nothing
    
End Sub

Public Sub CloseTempApp()
If mobjtemp Is Nothing Then
  Exit Sub
End If

Set mobjtemp = Nothing
    
End Sub

Private Sub Class_Initialize()
'
' 4/10/2009 by Yuhua Song. CQ00252621: modifyMenuState is called to disable or enable
' Aspen Properties menu items
'
    'Set mobjHappHappIp = CreateObject("AspenProperties.Document." + g_MMVersion)
    'If g_MMVersion = "" Then
    '   Call InitializeGlobalVariables
    'End If
    'If bInitNewFlag <> True Then
    '    bInitNewFlag = True
    '    Set mobjHappHappIp = CreateObject("AspenProperties.Document." + g_MMVersion)
    '   'Call mobjHappHappIp.InitFromFile2("D:\Program Files\AspenTech\Aspen Properties " + g_MMVersion + "\GUI\xmp\drex1.aprop")
    '    Call mobjHappHappIp.InitNew2
    '    Call modifyMenuState("Disable")
    'Else
    '    Set mobjtemp = mobjHappHappIp
    '    Set mobjHappHappIp = CreateObject("AspenProperties.Document." + g_MMVersion)
    '    Call mobjHappHappIp.InitFromTemplate2(strFilePath)
    '    Call modifyMenuState("Disable")
    'End If
    'mobjHappHappIp.Visible = True
    'mobjHappHappIp.SuppressDialogs = True
End Sub

Public Sub OpenCase(Optional filePath As String = "")
strFilename = filePath
On Error GoTo ErrorOpening
If g_MMVersion = "" Then
       Call InitializeGlobalVariables
    End If
    If filePath = "" Then
        bInitNewFlag = True
        Set mobjHappHappIp = CreateObject("AspenProperties.Document." + g_MMVersion)
       'Call mobjHappHappIp.InitFromFile2("D:\Program Files\AspenTech\Aspen Properties " + g_MMVersion + "\GUI\xmp\drex1.aprop")
        Call mobjHappHappIp.InitNew2
        Call modifyMenuState("Disable")
    Else
        Set mobjtemp = mobjHappHappIp
        Set mobjHappHappIp = CreateObject("AspenProperties.Document." + g_MMVersion)
        Call mobjHappHappIp.InitFromTemplate2(filePath)
        Call modifyMenuState("Disable")
    End If
    mobjHappHappIp.Visible = True
    Exit Sub
ErrorOpening:
'
' If no Aspen Properties license is available of an error happenes,
' an message will pop up as "Aspen Properties Excel Calculator encounters a fatal licensing error and needs to close."
' The message is from "ap\source\atcapeopen\atcohelper\APRSystem.cpp\ABORT_HANDLER ()".
'
    g_FullPath = ThisWorkbook.Path
    If Trim(g_FullPath) <> "" Then
        MsgBox "Aspen Properties Excel Calculator encounters a" & _
                        " fatal license error and needs to close.", _
                        vbOKOnly, "Aspen Properties Denial"
        'MsgBox "No Aspen Properties license is available and Excel has to close."
        g_APLicense = False
        Application.ActiveWorkbook.Close
        Application.Quit
    End If
End Sub

' Subroutine : mobjHappHappIp_OnGUIClosing()
'              Implementaion for OnGUIClosing() event of HappLS interface of Aspen Properties
' Created    : 03/06/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas

Private Sub mobjHappHappIp_OnGUIClosing()
    mobjHappHappIp.Visible = False
    mobjHappHappIp.SuppressDialogs = True
    ' Check Point for user response to  the option for saving already configured property package
    If bNewAppFlag = False Then
       Application.Visible = True
       intRetValue = MsgBox(" Save the Property Package ?", _
                             vbYesNo + vbMsgBoxSetForeground, " Save Property Package ")
       Select Case intRetValue
            Case vbNo
               bCloseApp = True
               Call modifyMenuState("Enable")
               Exit Sub
            Case vbYes
               bCloseApp = True
               Call SaveApplication
               Call modifyMenuState("Enable")
               If strFilename = "False" And strPath = "False" Then
                   Exit Sub
               End If
        End Select
    Else
          Application.Visible = True
          intRetValue = MsgBox(" Save the Property Package ?", _
                             vbYesNo + vbMsgBoxSetForeground, " Save Property Package ")
       Select Case intRetValue
            Case vbNo
                bCloseApp = True
                Call modifyMenuState("Enable")
                Exit Sub
            Case vbYes
                bCloseApp = True
                Call SaveApplication
                bNewAppFlag = False
                Call modifyMenuState("Enable")
                If strFilename = "False" And strPath = "False" Then
                    Exit Sub
                End If
        End Select
    End If
'
' 780322: Create a new property package, close and save with error and crash in Germany OS.
'
    If strFilePath = "" Then
        bCloseApp = True
        Exit Sub
    End If
'
    If strFilename <> "" Then
        If FunSavePDF = True Then
            '
            ' Check Point for the user responsed to an option of using the configured property
            ' package in the same applicationroperties Excel Calculator problem? ", _
                             vbYesNo, " Property Package Configured ")
            '
            Application.Visible = True
            Call SelectPropertyPackageDeferred
            '
'            intRetValue = MsgBox(" Use the configured Property Package in the current Aspen Properties Excel Calculator problem ? ", _
'                             vbYesNo, " Property Package Configured ")
'            Select Case intRetValue
'                   Case vbNo
'                       Call KillSaveAsFiles
'                       bCloseApp = True
'                       Exit Sub
'                   Case vbYes
'                   Call SelectPropertyPackageDeferred
'            End Select
        Else
            Call MsgBox("The Property Package is not complete and cannot be used in Excel Calculator. ", vbOKOnly + vbInformation, " Property Configuration Failure")
            mobjHappHappIp.SaveAs (strPath)
            Call KillSaveAsFiles
            bCloseApp = True
        End If
    End If
End Sub
' Subroutine : mobjHappHappIp_OnInClosing(ByVal Clear As Long, ByVal msg As String)
'              Implementaion with the option of initiaing the application again or deleting
'              mobjHappHappIp object depening on the value of the flag
' Created    : 03/06/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Private Sub mobjHappHappIp_OnInClosing(ByVal Clear As Long, ByVal msg As String)
        If bConstFlag <> False Then
           bConstFlag = False
            ' To intiate the object and open already created .aprbkp file with improper
            ' configuration
            'Call DeleteClass1
            Call Class_Initialize
        Else
'
' 4/10/2009 by Yuhua Song. CQ00252621: Enable Aspen Properties items after .aprbkp is closed
'
           Call modifyMenuState("Enable")
           bCloseApp = True
           Exit Sub
        End If
End Sub
'Function :funSavePDF()
'          Implementation for running the temp aprpdf file using RUN2 mehthod of HappLS interface
'          Saves it as .aprop and .aprpdf format, and checks the size of the .aprpdf file to validate
'          the proper configuration of property package
'          mobjHappHappIp object depening on the value of the flag
'Returns  :Boolean
'Created  :03/06/2002
'Version  :Aspen Properties 12.1
'Author   :Jwalant Vyas
Private Function FunSavePDF() As Boolean
          If g_MMVersion = "" Then
             Call InitializeGlobalVariables
          End If
          Call GetWorkingFolder '(HKEY_CURRENT_USER, "Software\AspenTech\Aspen Properties\" + g_MMVersion + "\mmgini")
          
          ' Set the flag so that the aprbkp file is saved at the same time
          Dim alwayssavebkpnode As Object
          Set alwayssavebkpnode = mobjHappHappIp.Tree.FindNode("Settings\alwayssavebkp")
          If alwayssavebkpnode.value = 0 Then
                alwayssavebkpnode.value = 1
          End If
          
          mobjHappHappIp.Run2
          Call mobjHappHappIp.SaveAs(strFilePath + "aprop", True)
          ' need to make sure aprbkp is saved
          Call mobjHappHappIp.SaveAs(strFilePath + "aprbkp", True)
          If DirCatch(strFilePath + "aprpdf") <> "" Then
              file_size = FileLen(strFilePath + "aprpdf")
          Else
              file_size = 0
          End If

          If file_size <> 0 Then
             FunSavePDF = True
          Else
             FunSavePDF = False
          End If
End Function
    
' Subroutine : SaveApplication()
'              Implementaion for Save As Dialoge Box to take input from the user, providing
'              the information to the user about configured property package and extracting
'              the file name from the entire path return from the save as dialoge box
'              mobjHappHappIp object depening on the value of the flag
' Created    : 03/06/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub SaveApplication()
    If (strFilename = "") Then
        Application.Visible = True
        strFilename = Application.GetSaveAsFilename(, fileFilter:="Aspen Properties Backup Files (*.aprbkp),*.aprbkp")
    End If
    strPath = strFilename
    If strFilename = "False" Then
        'strPath = strFilename
        bCloseApp = True
        Exit Sub
    'Else
      'strPath = strFilename
    End If
    
    intCount = 1
    strTemp = Left(strFilename, InStr(strFilename, ".aprbkp"))
    strFilePath = strTemp
'
' 780322: Create a new property package, close and save with error and crash in Germany OS.
'
    If strFilePath = "" Then
        bCloseApp = True
        Exit Sub
    End If
'
    Do
      intCount = InStr(intCount, strTemp, "\", 1)
      strTemp = Right(strTemp, Len(strTemp) - intCount)
      If intCount <> 0 And intCount > 1 Then
         intCount = 1
      Else
         intCount = 0
      End If
    Loop While intCount <> 0
     'intCount = InStr(1, strTemp, ".", 1)
    strTemp = Left(strTemp, Len(strTemp) - 1)
    strFilename = strTemp
    'Call MsgBox("You have configured the Property Package: " + strFilename, vbOKOnly + vbInformation, " Property Package Created")
End Sub
' Subroutine : KillSaveAsFiles()
'              Implementaion for destryoing the files which has been created during the last
'              unsuccessful run and to save only .aprbkpfile
'              It will destroy the files from the user specified directory while saving the file
' Created    : 03/13/2002
' Version    : Aspen Properties 12.1
' Author     : Jwalant Vyas
Sub KillSaveAsFiles()
On Error GoTo err_Select
    KillExists (strFilePath + "aprpdf")
    KillExists (strFilePath + "aprhis")
    KillExists (strFilePath + "def")
err_Select:
  Exit Sub
End Sub

