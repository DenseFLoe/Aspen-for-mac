"""Probe the original's 0x00b5 64-bit VBA performance cache and correlate with source."""
import collections
import contextlib
import hashlib
import io
import json
import re
import struct
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

from oletools.olevba import VBA_Parser
from pcodedmp import pcodedmp as pc
from extract_project import ROOT, SHA, load_project, dump

U16 = lambda b,i: struct.unpack_from('<H',b,i)[0]
U32 = lambda b,i: struct.unpack_from('<I',b,i)[0]
PROC = re.compile(r'^\s*(?:(?:Public|Private|Friend|Static)\s+)*(Sub|Function|Property\s+(?:Get|Set|Let))\s+(\w+)\s*\((.*)\)(.*)$',re.I)
builtin = pc.getID
ANCHORS = {
    ('ThisWorkbook','Workbook_Open'): ['oApp','Application'],
    ('ThisWorkbook','Workbook_AddinUninstall'): ['RemoveFunctionDetail'],
    ('Main','Auto_Open'): ['InitializeGlobalVariables','populateShortCutMenu'],
    ('Main','Auto_Close'): ['DeleteClass1'],
    ('Class1','OpenCase'): ['ErrorOpening','InitNew2','InitFromTemplate2','modifyMenuState','Close','Quit'],
    ('Functions','MixtureProperty'): ['trap','SetComponentIds','SetProp','SetPhases'],
    ('Functions','InternalFlash'): ['trap','SetComponentIds','SetProp','CalcEquilibrium'],
    ('Functions','TPFlash'): ['InternalFlash'],
    ('VBFunctionsWrapper','TPFlash'): ['NormalizeFractions','ReturnName','TPFlash','HeartBeat','TRY_AND_RECOVER'],
    ('frmPropMethSet','cmdOK_Click'): ['WriteMethSetToSelectedCell'],
}


def resolve(code, ids, version, wide):
    idx=(code>>1)-0x107
    if wide and version==7 and 0<=idx<len(ids):
        return ids[idx]
    return builtin(code,ids,version,wide)


def source_procs(m):
    lines=m.code.splitlines()
    entries=[]
    i=0
    while i<len(lines):
        start=i+1
        line=lines[i].strip()
        i+=1
        while line.endswith(' _') and i<len(lines):
            line=line[:-2]+' '+lines[i].strip()
            i+=1
        mt=PROC.match(line)
        if not mt:
            continue
        # Stop at the matching ')' of the parameter list, including array parameters.
        opening=line.index('(',mt.start(2)+len(mt[2]))
        depth=1
        pos=opening+1
        quoted=False
        while depth:
            c=line[pos]
            if c=='"':
                quoted=not quoted
            if not quoted:
                depth+=(c=='(')-(c==')')
            pos+=1
        args=line[opening+1:pos-1]
        plist=[]
        for arg in re.split(r',(?=(?:[^"]*"[^"]*")*[^"]*$)',args):
            if arg.strip():
                name=re.match(r'\s*(?:(?:ByVal|ByRef|Optional|ParamArray)\s+)*(\w+)',arg,re.I)[1]
                plist.append(name)
        entries.append(dict(kind=' '.join(mt[1].lower().split()),name=mt[2],line=start,
                            parameters=plist,return_declaration=line[pos:].strip(),declaration=line))
    return entries


def type_key(table,raw):
    if raw>>16 == 0xffff:
        return dict(base=raw&0xff,indirect=False)
    word=U16(table,raw)
    key=dict(base=word&0xff,indirect=True)
    if key['base']==27:
        key['element']=U16(table,raw+6)&0xff
    if key['base']==29:
        key['object_ref']=U16(table,raw+2)
    return key


def inspect(original, destination):
    assert hashlib.sha256(original.read_bytes()).hexdigest()==SHA
    evidence={}
    with contextlib.closing(VBA_Parser(str(original),relaxed=False)) as parser:
        o=parser.ole_file
        pr=load_project(o)
        header=o.openstream(ROOT+'/VBA/_VBA_PROJECT').read()
        ids=pc.getTheIdentifiers(header)
        args=SimpleNamespace(disasmOnly=True,verbose=False)
        dir_data, module_names, wide=pc.processDir(parser, ROOT+'/VBA/dir',args,output_file=io.StringIO())
        assert wide and header[:4].hex()=='cc61b500'
        for m in pr.modules:
            raw=o.openstream(m.code_path).read()[:m.textoffset]
            rows=source_procs(m)
            cache=[]
            context={}
            def trace_line(*a,**kw):
                context.update(pc_line=a[11],line_offset=a[1],line_length=a[2],obj=a[7])
                return original_line(*a,**kw)
            def trace_function(table,declarations,identifiers,offset,optype,endian,version,wide):
                row=rows[len(cache)]
                name_id=U16(table,offset+2)
                assert resolve(name_id,ids,version,wide).lower()==row['name'].lower()
                name=pc.disasmFunc_orig(table,declarations,identifiers,offset,optype,endian,version,wide)
                assert re.search(r'\b'+row['kind'].replace(' ',r'\s+')+r'\s+'+row['name']+r'\(',name,re.I)
                ret=U32(table,offset+60)
                off=U32(table,offset+56)
                arg_names=[]
                slots=[]
                visited=set()
                while off!=0xffffffff:
                    assert off not in visited and off+32<=len(table)
                    visited.add(off)
                    ident=U16(table,off+2)
                    t=U32(table,off+16)
                    flags=U16(table,off+28)
                    if ident==0xfffe:
                        assert flags&0x20 and U32(table,off+24)==0xffffffff
                        rk=type_key(table,ret)
                        ak=type_key(table,t)
                        slots.append(dict(param_offset=off,param_type=f'{t:08x}',return_type=f'{ret:08x}',
                            param_flags=f'{flags:04x}',argument_shape=ak,return_shape=rk,shapes_equal=ak==rk))
                    else:
                        arg_names.append(resolve(ident,ids,version,wide))
                    off=U32(table,off+24)
                if [x.lower() for x in arg_names]!=[x.lower() for x in row['parameters']]:
                    raise ValueError((m.name,row,arg_names))
                entry=dict(**row,cache_line=context['pc_line'],module_byte_offset=context['line_offset'],
                           descriptor_offset=offset,parameters_cache=arg_names,return_slots=slots,
                           stock_fffe='id_FFFE' in name)
                if m.name=='VBACaller' and row['name']=='GetConnection':
                    k=type_key(table,ret)
                    assert k==dict(base=29,indirect=True,object_ref=0)
                    pos=(k['object_ref']>>2)*10
                    cls_code=U16(context['obj'],pos+6)
                    cls=resolve(cls_code,ids,version,wide)
                    assert cls=='VBConnection' and re.fullmatch('As '+cls,row['return_declaration'],re.I)
                    entry['typed_return']=dict(type_descriptor=ret,encoded=table[ret:ret+4].hex(),
                        object_entry=pos,object_bytes=context['obj'][pos:pos+10].hex(),identifier_code=cls_code,
                        identifier_index=(cls_code>>1)-0x107,identifier=cls)
                cache.append(entry)
                return name
            buf=io.StringIO()
            original_line=pc.dumpLine
            with patch.object(pc,'getID',resolve), patch.object(pc,'disasmFunc_orig',pc.disasmFunc,create=True), \
                 patch.object(pc,'disasmFunc',trace_function),patch.object(pc,'dumpLine',trace_line):
                errors=io.StringIO()
                with contextlib.redirect_stderr(errors):
                    pc.pcodeDump(raw,header,dir_data,ids,wide,args,output_file=buf)
            if errors.getvalue().strip():
                raise AssertionError((m.name,errors.getvalue()))
            listing=buf.getvalue()
            assert 'Unrecognized opcode' not in listing and len(rows)==len(cache)==listing.count('FuncDefn')
            instructions=re.split(r'^Line #\d+:\n',listing,flags=re.M)[1:]
            # Operands are checked against explicit Me expressions in the same procedure and logical line.
            found=[]
            src=m.code.splitlines()
            for j,e in enumerate(cache):
                start=e['cache_line'];stop=cache[j+1]['cache_line'] if j+1<len(cache) else len(instructions)
                endline=cache[j+1]['line']-1 if j+1<len(cache) else len(src)
                body=[(i+1,src[i].split("'")[0]) for i in range(e['line'],endline)]
                ops=[(i,op.strip()) for i in range(start+1,stop) for op in instructions[i].splitlines()
                     if op.strip() and not op.strip().startswith(('QuoteRem','Rem ','LitStr','FuncDefn'))]
                anchors=ANCHORS.get((m.name,e['name']),[])
                if anchors:
                    proof=[]
                    for anchor in anchors:
                        token=re.compile(r'\b'+anchor+r'\b',re.I)
                        source_hits=[dict(line=n,source=s.strip()) for n,s in body if token.search(s)]
                        cache_hits=[dict(line=n,op=s) for n,s in ops if token.search(s)]
                        assert source_hits and cache_hits,(m.name,e['name'],anchor)
                        proof.append(dict(anchor=anchor,source_hits=source_hits,cache_hits=cache_hits))
                    e['logic_checks']=proof
                targets=[]
                for n,s in ops:
                    mt=re.fullmatch(r'(GoTo|GoSub|OnError|Label)\s+([a-z_]\w*)',s,re.I)
                    if mt:
                        named=re.compile(r'\b'+mt[2]+r'\b',re.I)
                        hits=[i for i,line in body if named.search(line)]
                        assert hits,(m.name,e['name'],n,s)
                        targets.append(dict(cache_line=n,op=mt[1],target=mt[2],source_lines=hits))
                if targets:e['branch_targets']=targets
                expected=[]
                for i in range(e['line']-1,endline):
                    line=src[i].split("'")[0]
                    expr=[x.lower() for x in re.findall(r'\bMe\.(\w+)',line,re.I)]
                    if expr: expected.append((i+1,expr))
                actual=[]
                for i in range(start,stop):
                    ins=instructions[i]
                    if '\tLd id_FFFF' not in ins:continue
                    fields=re.findall(r'\tLd id_FFFF\s*\n\t(?:MemLd|ArgsMemCall|ArgsMemLd|MemSt)\s+(\w+)',ins)
                    assert len(fields)==ins.count('Ld id_FFFF')
                    actual.append((i,[x.lower() for x in fields]))
                # Call operands are pushed before receivers. Order within each expression can change.
                assert len(actual)==len(expected),(m.name,e['name'],actual,expected)
                for (line,members),(lineno,declared) in zip(actual,expected):
                    assert sorted(members)==sorted(declared),(m.name,line,members,declared)
                    found.append(dict(procedure=e['name'],source_line=lineno,cache_line=line,
                                      source=src[lineno-1].strip(),source_members=declared,stack_members=members))
            assert sum(len(r['stack_members']) for r in found)==listing.count('Ld id_FFFF')
            if m.name=='VBACaller':
                assert '\tNew VBConnection' in listing and '\tSet GetConnection' in listing
            evidence[m.name]=dict(procedures=cache,me_loads=found,cache_lines=len(instructions),
                                  pcode_text_sha256=hashlib.sha256(listing.encode()).hexdigest())
    dump(destination,evidence)
    rows=[p for m in evidence.values() for p in m['procedures']]
    slots=[v for p in rows for v in p['return_slots']]
    assert len(rows)==444 and len(slots)==208 and all(s['shapes_equal'] for s in slots)
    assert sum(p['stock_fffe'] for p in rows)==163
    assert sum(len(r['stack_members']) for m in evidence.values() for r in m['me_loads'])==30
    print('modules/procedures/explicit arguments/stock FFFE/return slots/matching shape/Me loads',
          len(evidence),len(rows),sum(len(p['parameters']) for p in rows),sum(p['stock_fffe'] for p in rows),
          len(slots),sum(s['shapes_equal'] for s in slots),sum(len(r['stack_members']) for m in evidence.values() for r in m['me_loads']))
    print('difference shapes',collections.Counter(str((s['argument_shape'],s['return_shape'])) for s in slots if not s['shapes_equal']))


if __name__=='__main__':
    inspect(Path(sys.argv[1]),Path(sys.argv[2]))

