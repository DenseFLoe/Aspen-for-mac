# Aspen Properties.xla 可编辑工程

本包对应 Aspen Properties V15.0 的 Excel 加载项。原件 SHA-256 为 `d124683bb13ceb5c6a39f661661fc727e67289fdb6257f8bd25b82246dd18919`。

| 文件 | 用途 |
| --- | --- |
| `vba/` | 43 个 CP1252 模块。标准、类及工作簿文档模块保留原始文本与属性。四个窗体各有一对 `.frm`、`.frx`，两者须放在同一目录。 |
| `workbook.json` | 按原顺序保存全部 BIFF8 记录。每个定义名称的文本、标志、作用域和公式令牌可独立修改。其他记录保留原荷载。 |
| `project.json`、`project/` | 工程角色、模块和宿主映射、类型库引用、存储类、工程文本、保护字段、设计器原生属性、文档属性和必要的二进制资源。 `dir.records` 为展开后的 OVBA 目录，43 个模块源偏移已设为零。 |
| `pack_project.py` | 将以上材料写入一份新的 XLA。用 Windows 的结构化存储 API 写文件，用 olefile 读取窗体资源。 |
| `evidence/` | `cache.json` 逐过程列出源码与原件缓存的对照。 `static.json` 逐流核对工程、工作簿与控件。 `edit-test.json` 记录编辑后从新文件读回的值。 |
| `verification/`、`verify_project.py` | 从原件和本包重做静态验收。 `SHA256SUMS` 覆盖包内其余成员。 |

从解压目录执行以下命令。序列化需要 Windows、Python 3.12 和 olefile 0.47。完整复验另用 oletools 0.60.2、pcodedmp 1.2.6。复验会先校验包内指纹，须使用未改动的交付副本。输出文件和复验目录均须采用新路径。

```powershell
python -B pack_project.py "C:/work/new-addin.xla"
python -B verify_project.py "C:/work/original/Aspen Properties.xla" "C:/work/fresh-verification"
```

`ThisWorkbook` 与 `Sheet1` 通过工作簿 CodeName 和 PROJECT 的 Document 声明绑定。保留这两项的宿主角色。窗体文本提供设计器头与代码，FRX 保留控件对象流和嵌套存储。重组时从配对文件读入设计，恢复工程专用的 VBFrame 和原有模块属性。项目使用的 COM 接口及类型库声明随包保留。宿主和外部计算引擎在 Windows 对照阶段提供。

验证用重新序列化文件使用 MS-OVBA 的可移植工程标记。原件实现专用的 30 个 SRP 缓存流及模块编译前缀在原件上核验，生成文件从可编辑源码读取。文档属性中的签名相关原值随包保留，验证记录覆盖字节保全；证书信任、Excel 导入加载及外部计算行为留到 Windows 阶段。[MS-OVBA 版本机制](https://learn.microsoft.com/en-us/openspecs/office_file_formats/ms-ovba/4d20e95c-0c17-47d6-84b9-8da95d8ea129)

