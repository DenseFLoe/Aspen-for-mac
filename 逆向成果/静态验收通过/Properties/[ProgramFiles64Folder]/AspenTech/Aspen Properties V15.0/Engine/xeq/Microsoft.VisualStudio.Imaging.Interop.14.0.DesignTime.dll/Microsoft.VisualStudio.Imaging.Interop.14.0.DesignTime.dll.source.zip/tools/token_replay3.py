"""Replay CLR metadata/layout + source-recompiled CIL method bodies onto Roslyn output.

Combines token_replay2's .NET-1.1-style prefix/CLR-header/strong-name handling with
token_replay.py's token-remapped method-body placement.
"""
import argparse
import json
import struct
import zipfile
from hashlib import sha256
from pathlib import Path

import sys
HERE = Path(__file__).resolve().parent
OVR = HERE.parent / "managed-override-1"
sys.path.insert(0, str(OVR))
from pe_layout2 import bootstrap, finish_image, identified_image, names   # noqa: E402
from replay2 import build                                               # noqa: E402
import build_recipe2 as br                                              # noqa: E402


def reproduce(compiled, recipe, metadata, debug, certificate, strong_name, clr_header):
    if (sha256(compiled).hexdigest() != recipe["compiler_output_sha256"]
            or sha256(metadata).hexdigest() != recipe["original_metadata_sha256"]
            or sha256(debug).hexdigest() != recipe["debug_sha256"]):
        raise ValueError("C#, metadata layout or debug record differs from pinned inputs")
    pe, emitted = identified_image(compiled)
    text = names(pe)[".text"]
    text_start = text.PointerToRawData
    md_start = pe.get_offset_from_rva(emitted["rva"])
    if emitted["rva"] != recipe.get("emitted_metadata_rva", recipe["metadata_rva"]) or not text_start < md_start:
        raise ValueError("Compiler-generated code is outside the verified metadata boundary")
    compiler_region = compiled[text_start:md_start]
    prefix_size = recipe["metadata_rva"] - text.VirtualAddress
    body_region = bytearray(compiler_region[:prefix_size].ljust(prefix_size, b"\0"))
    outputs = []
    used = set()
    for method in recipe["verified_methods"]:
        at = pe.get_offset_from_rva(method["candidate_rva"]) - text_start
        width = method.get("candidate_bytes", method["bytes"])
        if not 0 <= at <= len(compiler_region) - width:
            raise ValueError("A managed method extends outside the compiler code region")
        code = br.reemit_method(compiler_region[at:at + width], method)
        if at < len(body_region):
            clear = min(len(body_region) - at, width)
            body_region[at:at + clear] = bytes(clear)
        destination = method["original_rva"] - text.VirtualAddress
        outputs.append((destination, code))
    for destination, code in outputs:
        width = len(code)
        region = set(range(destination, destination + width))
        if not 0 <= destination <= len(body_region) - width:
            raise ValueError("Original managed method extent is outside the emitted region")
        if not region.isdisjoint(used):
            if body_region[destination:destination + width] != code or not region <= used:
                raise ValueError("Original metadata aliases different compiler method bodies")
            continue
        used.update(region)
        body_region[destination:destination + width] = code
    before, after = bootstrap(pe), recipe["x86_bootstrap"]
    if after:
        iat = pe.get_offset_from_rva(before["iat"]) - text_start
        struct.pack_into("<I", body_region, iat, after["hint"])
    cli = pe.get_offset_from_rva(pe.OPTIONAL_HEADER.DATA_DIRECTORY[14].VirtualAddress) - text_start
    if len(clr_header) != 72:
        raise ValueError("Archived CLR header record is not 72 bytes")
    body_region[cli:cli + 72] = clr_header
    if sha256(body_region).hexdigest() != recipe["original_pre_metadata_blank_strong_sha256"]:
        raise ValueError("Compiler-derived CLR prefix differs from the original (strong slot blanked)")
    body_region += metadata
    resources = recipe["managed_resources"]
    if resources["bytes"]:
        previous_resource_rva, previous_resource_size = struct.unpack_from("<II", body_region, cli + 24)
        resource_data = pe.get_data(previous_resource_rva, previous_resource_size) if previous_resource_size else b""
        if len(resource_data) != resources["bytes"] or sha256(resource_data).hexdigest() != resources["sha256"]:
            raise ValueError("Compiler-emitted managed resources differ from the recorded original")
        body_region = body_region.ljust(resources["rva"] - text.VirtualAddress, b"\0") + resource_data
    debug_relative = recipe.get("trailing_text_rva", recipe["debug_rva"]) - text.VirtualAddress
    if "trailing_text_rva" in recipe and (debug or recipe["debug_rva"] or recipe["debug_directory_bytes"]):
        raise ValueError("A debug-free PE layout includes an unexpected build record")
    if len(body_region) > debug_relative:
        raise ValueError("Original metadata and resources overlap the debug directory")
    body_region = body_region.ljust(debug_relative, b"\0") + debug
    if after:
        body_region += rebuild_import_tail(pe, before, after, recipe)
    return finish_image(compiled, pe, recipe, body_region, certificate, strong_name)


def rebuild_import_tail(pe, before, after, recipe):
    if before["iat"] != after["iat"] or before["reloc_rva"] != after["reloc_rva"]:
        raise ValueError("CLR import/IAT structure changed")
    start = pe.get_offset_from_rva(before["start"])
    cand = pe.get_data(before["start"], before["data_length"])
    hint_off = before["hint"] - before["start"]
    name_off = before["module_name"] - before["start"]
    hint_bytes = cand[hint_off:name_off]
    name_bytes = cand[name_off:before["data_length"]]
    payload = bytearray(after["data_length"])
    payload[0:20] = cand[0:20]
    struct.pack_into("<I", payload, 0, after["thunk"])
    struct.pack_into("<I", payload, 12, after["module_name"])
    thunk_rel = after["thunk"] - after["start"]
    struct.pack_into("<II", payload, thunk_rel, after["hint"], 0)
    payload[after["hint"] - after["start"]:
            after["hint"] - after["start"] + len(hint_bytes)] = hint_bytes
    payload[after["module_name"] - after["start"]:
            after["module_name"] - after["start"] + len(name_bytes)] = name_bytes
    stub = pe.get_data(before["entry"], 6)
    tail = bytes(payload).ljust(after["entry"] - after["start"], bytes(1)) + stub
    if sha256(tail).hexdigest() != recipe.get("import_tail_sha256"):
        raise ValueError("Rebuilt import directory differs from the original")
    return tail


def rebuild_tokens(package_path, work):
    compiled = build(package_path, work)
    with zipfile.ZipFile(package_path) as package:
        recipe = json.loads(package.read("layout-recipe.json"))
        data = reproduce(compiled.read_bytes(), recipe,
                         package.read("original-build/clr-metadata.bin"),
                         package.read("original-build/debug-record.bin"),
                         package.read("original-build/certificate-table.bin"),
                         package.read("original-build/strong-name.bin") if recipe["strong_name"] else b"",
                         package.read("original-build/clr-header.bin"))
    dest = work / "exact"
    dest.mkdir()
    artifact = dest / compiled.name
    artifact.write_bytes(data)
    return artifact


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("archive", type=Path)
    cli.add_argument("new_output_directory", type=Path)
    args = cli.parse_args()
    print(rebuild_tokens(args.archive, args.new_output_directory))
