"""Serialize this add-in's editable source package to a new compound file on Windows.

Uses the Windows structured-storage API. No Excel, VBIDE or macro is invoked.
"""
import argparse
import ctypes as ct
import json
import re
import struct
import uuid
from contextlib import contextmanager
from pathlib import Path

P = ct.c_void_p
U = ct.c_ulong
W = ct.c_wchar_p
EXCLUSIVE_WRITE = 0x12
FORM_GUID = "C62A69F0-16DC-11CE-9E98-00AA00574A4F"


def check(result):
    if result < 0:
        raise OSError(f"OLE structured storage HRESULT 0x{result & 0xffffffff:08x}")


def call(obj, slot, argtypes, *args):
    table = ct.cast(obj, ct.POINTER(ct.POINTER(P))).contents
    method = ct.WINFUNCTYPE(ct.c_long, P, *argtypes)(table[slot])
    return method(obj, *args)


@contextmanager
def releasing(obj):
    try:
        yield obj
    finally:
        call(obj, 2, [])


def write_cfb(destination, streams, classes):
    destination = Path(destination).resolve()
    root = P()
    ole = ct.OleDLL("ole32")
    ole.StgCreateDocfile.argtypes = [W, U, U, ct.POINTER(P)]
    # STGM_FAILIFTHERE is zero. Existing user files are never overwritten.
    check(ole.StgCreateDocfile(str(destination), EXCLUSIVE_WRITE, 0, ct.byref(root)))

    def populate(parent, prefix):
        clsid = classes.get(prefix)
        if clsid:
            guid = (ct.c_ubyte * 16).from_buffer_copy(uuid.UUID(clsid).bytes_le)
            check(call(parent, 15, [P], ct.byref(guid)))
        for name in sorted(p for p in streams if p[:-1] == prefix):
            stream = P()
            check(call(parent, 3, [W, U, U, U, ct.POINTER(P)],
                       name[-1], EXCLUSIVE_WRITE, 0, 0, ct.byref(stream)))
            with releasing(stream):
                data = streams[name]
                written = U()
                check(call(stream, 4, [P, U, ct.POINTER(U)], data, len(data), ct.byref(written)))
                if written.value != len(data):
                    raise OSError(f"short write for {name}")
        for name in sorted(p for p in classes if len(p) == len(prefix) + 1 and p[:-1] == prefix):
            child = P()
            check(call(parent, 5, [W, U, U, U, ct.POINTER(P)],
                       name[-1], EXCLUSIVE_WRITE, 0, 0, ct.byref(child)))
            with releasing(child):
                populate(child, name)
        check(call(parent, 9, [U], 0))

    with releasing(root):
        populate(root, ())


def compressed_vba(source):
    """MS-OVBA 2.4.1. Full blocks may be raw; a final short block uses tokens."""
    encoded = bytearray(b'\x01')
    for start in range(0, len(source), 4096):
        chunk = source[start:start + 4096]
        if len(chunk) == 4096:
            encoded += b'\xff\x3f' + chunk
            continue
        pos = 0
        body = bytearray()
        while pos < len(chunk):
            flag_position = len(body)
            body.append(0)
            for bit in range(8):
                if pos == len(chunk):
                    break
                width = max(4, (pos - 1).bit_length())
                limit = min(len(chunk) - pos, (1 << (16 - width)) + 2)
                origin = chunk.rfind(chunk[pos:pos + 3], 0, pos)
                if origin < 0 or limit < 3:
                    body.append(chunk[pos])
                    pos += 1
                    continue
                count = 3
                while count < limit and chunk[origin + count] == chunk[pos + count]:
                    count += 1
                token = ((pos - origin - 1) << (16 - width)) | (count - 3)
                body[flag_position] |= 1 << bit
                body.extend(struct.pack('<H', token))
                pos += count
        if len(body) > 4096:
            raise ValueError("Final VBA chunk exceeds the token container capacity")
        encoded += struct.pack('<H', 0xb000 + len(body) - 1) + body
    return bytes(encoded)


def workbook_bytes(records):
    parts, boundaries, sheets = [], [], []
    index_rows, default_widths = [], []
    pos = 0
    for row in records:
        rid = int(row['id'], 16)
        if 'defined_name' in row:
            n = row['defined_name']
            name = n['text'].encode('utf-16le' if n['wide'] else 'latin-1')
            tokens = bytes.fromhex(n['formula_tokens'])
            payload = struct.pack('<HBBHHH', n['flags'], n['key'], len(name) // (2 if n['wide'] else 1),
                                  len(tokens), n['ixals'], n['scope'])
            payload += bytes.fromhex(n['reserved']) + bytes([n['wide']]) + name + tokens
        else:
            payload = bytes.fromhex(row['data'])
        if rid == 0x85:
            boundaries.append(len(parts))
        if rid == 0x809 and payload[2:4] == b'\x10\x00':
            sheets.append(pos)
        if rid == 0x20b:
            if len(payload) != 16:
                raise ValueError("Expected an empty-sheet Index for this add-in")
            index_rows.append(len(parts))
        if rid == 0x55:
            default_widths.append(pos)
        parts.append(struct.pack('<HH', rid, len(payload)) + payload)
        pos += len(parts[-1])
    for index, offset in zip(boundaries, sheets, strict=True):
        parts[index] = parts[index][:4] + struct.pack('<I', offset) + parts[index][8:]
    for index, offset in zip(index_rows, default_widths, strict=True):
        parts[index] = parts[index][:16] + struct.pack('<I', offset)
    return b''.join(parts)


def split_form(source, name, type_info):
    marker = b'End\r\n'
    header, tail, code = source.partition(marker)
    if not tail or not code.startswith(b'Attribute VB_Name'):
        raise ValueError(f"form header or code missing for {name}")
    pattern = rb'(?m)^   OleObjectBlob\s*=\s*"' + re.escape(name.encode()) + rb'\.frx":0000\r\n'
    header, count = re.subn(pattern, b'', header)
    if count != 1:
        raise ValueError(f"FRX link missing for {name}")
    return header + type_info.encode('ascii') + b'\r\n' + marker, code


def assemble(base, destination):
    import io
    import olefile  # read-only parser, olefile 0.47
    manifest = json.loads((base / 'project.json').read_text('utf-8'))
    classes = {tuple(row['path']): row['clsid'] for row in manifest['storages']}
    streams = {tuple(row['path']): (base / row['file']).read_bytes() for row in manifest['resources']}
    streams[('Workbook',)] = workbook_bytes(json.loads((base / 'workbook.json').read_text('utf-8')))
    vba = ('_VBA_PROJECT_CUR', 'VBA')
    directory = (base / 'project/dir.records').read_bytes()
    streams[vba + ('dir',)] = compressed_vba(directory)
    streams[vba + ('_VBA_PROJECT',)] = bytes.fromhex('cc61ffff000000')
    for m in manifest['modules']:
        code = (base / m['file']).read_bytes()
        if 'form' in m:
            spec = m['form']
            parent = ('_VBA_PROJECT_CUR', m['name'])
            frame, code = split_form(code, m['name'], spec['type_info_line'])
            lines = code.split(b'\r\n')
            for attr in spec['native_attributes']:
                lines.insert(attr['index'], attr['line'].encode('cp1252'))
            code = b'\r\n'.join(lines)
            streams[parent + ('\x03VBFrame',)] = frame
            frx = (base / spec['file']).read_bytes()
            tag, length, zero1, zero2, cx, cy = struct.unpack_from('<6I', frx)
            if tag != 0x8424c or length != len(frx) - 24 or zero1 or zero2:
                raise ValueError(f"Invalid FRX object header for {m['name']}")
            with olefile.OleFileIO(io.BytesIO(frx[24:]), raise_defects=olefile.DEFECT_INCORRECT) as form:
                for p in form.listdir():
                    if p != ['\x01CompObj']:
                        streams[parent + tuple(p)] = form.openstream(p).read()
                for p in form.listdir(streams=False, storages=True):
                    if form.direntries[form._find(p)].clsid != classes[parent + tuple(p)]:
                        raise ValueError(f"Form storage class mismatch: {p}")
        streams[tuple(m['stream'])] = compressed_vba(code)
    write_cfb(destination, streams, classes)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    assemble(Path(__file__).resolve().parent, args.output)

