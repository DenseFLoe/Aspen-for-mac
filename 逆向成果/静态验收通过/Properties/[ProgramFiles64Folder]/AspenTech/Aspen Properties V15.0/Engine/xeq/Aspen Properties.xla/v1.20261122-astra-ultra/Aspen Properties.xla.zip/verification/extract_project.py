import hashlib
import io
import json
import logging
import re
import shutil
import struct
import sys
import tempfile
import uuid
from pathlib import Path

import olefile
from oletools.olevba import VBA_Project, decompress_stream

from pack_project import FORM_GUID, write_cfb, workbook_bytes
import pack_project

ROOT = '_VBA_PROJECT_CUR'
SHA = 'd124683bb13ceb5c6a39f661661fc727e67289fdb6257f8bd25b82246dd18919'
sha = lambda data: hashlib.sha256(data).hexdigest()


def dump(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=True, indent=2) + '\n', encoding='utf-8')


def load_project(ole):
    pr = VBA_Project(ole, ROOT + '/', ROOT + '/PROJECT', ROOT + '/VBA/dir', False)
    pr.parse_project_stream()
    list(pr.parse_modules())
    return pr


def workbook(data):
    rows = []
    pos = 0
    while pos < len(data):
        rid, size = struct.unpack_from('<HH', data, pos)
        body = data[pos+4:pos+4+size]
        assert len(body) == size
        pos += 4 + size
        row = dict(id=f'{rid:04x}')
        if rid == 0x18:
            flags, key, n, num_tokens, ixals, scope = struct.unpack_from('<HBBHHH', body)
            wide = body[14]
            assert wide in (0, 1)
            end = 15 + n * (wide + 1)
            assert len(body) == end + num_tokens
            row['defined_name'] = dict(text=body[15:end].decode('utf-16le' if wide else 'latin-1'),
                flags=flags, key=key, ixals=ixals, scope=scope, reserved=body[10:14].hex(),
                wide=wide, formula_tokens=body[end:].hex())
        else:
            row['data'] = body.hex()
        rows.append(row)
    assert workbook_bytes(rows) == data
    return rows


def export_frx(ole, m, scratch):
    prefix = [ROOT, m.name]
    frame = ole.openstream(prefix + ['\x03VBFrame']).read()
    removed = re.search(rb'(?m)^   TypeInfoVer[^\r\n]+', frame)
    assert removed and frame.endswith(removed[0]+b'\r\nEnd\r\n')
    header = frame.replace(removed[0]+b'\r\n', b'')
    blob = f'   OleObjectBlob   =   "{m.name}.frx":0000\r\n'.encode('ascii')
    header = header.replace(b'   StartUpPosition', blob + b'   StartUpPosition')
    dims = {k.decode(): int(v) for k,v in re.findall(rb'Client(\w+)\s*=\s*(\d+)', frame)}
    cx = dims['Width'] + 2*dims['Left']
    cy = dims['Height'] + dims['Top'] + dims['Left']
    streams = {tuple(p[2:]): ole.openstream(p).read() for p in ole.listdir()
               if p[:2] == prefix and p[2:] != ['\x03VBFrame']}
    comp = streams[('\x01CompObj',)]
    assert comp[12:28] == bytes(16) and comp.count(b'Embedded Object\x00') == 1
    cut = comp.index(b'Embedded Object\x00') + len(b'Embedded Object\x00')
    assert comp[cut:cut+4] == bytes(4)
    progid = b'Forms.Form.1\x00'
    streams[('\x01CompObj',)] = (comp[:12] + uuid.UUID(FORM_GUID).bytes_le + comp[28:cut] +
                                   struct.pack('<I', len(progid)) + progid + comp[cut+4:])
    classes = {(): FORM_GUID}
    for p in ole.listdir(streams=False, storages=True):
        if p[:2] == prefix and len(p)>2:
            classes[tuple(p[2:])] = ole.direntries[ole._find(p)].clsid
    with tempfile.TemporaryDirectory(dir=scratch) as tmp:
        path = Path(tmp)/'form.ole'
        write_cfb(path, streams, classes)
        data = path.read_bytes()
    return (header + m.code_raw, struct.pack('<6I',0x8424c,len(data),0,0,cx,cy)+data,
            removed[0].decode('ascii'))


def export(src, stage, scratch):
    assert sha(src.read_bytes()) == SHA
    stage.mkdir(exist_ok=True)
    (stage/'vba').mkdir(exist_ok=True)
    (stage/'project').mkdir(exist_ok=True)
    manifest = dict(original_sha256=SHA,storages=[],resources=[],modules=[])
    def put(rel, data):
        dest=stage/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
    with olefile.OleFileIO(src,raise_defects=olefile.DEFECT_INCORRECT) as ole:
        manifest['storages'] = [dict(path=[],clsid=ole.root.clsid)]
        for p in ole.listdir(streams=False,storages=True):
            manifest['storages'].append(dict(path=p,clsid=ole.direntries[ole._find(p)].clsid))
        references=[]
        class References(logging.Handler):
            def emit(self, record):
                message=record.getMessage()
                if message.startswith('REFERENCE ') and (' name:' in message or ' lib id:' in message):
                    references.append(message)
        log=logging.getLogger('olevba')
        saved_level=log.level
        handler=References()
        log.addHandler(handler)
        try:
            log.setLevel(logging.DEBUG)
            project = load_project(ole)
        finally:
            log.removeHandler(handler)
            log.setLevel(saved_level)
        manifest['reference_records']=references
        assert project.codepage==1252 and project.modules_count==len(project.modules)==43
        project_text = ole.openstream([ROOT,'PROJECT']).read().decode('cp1252')
        roles = dict((b,a) for a,b in re.findall(r'(?m)^(Document|Module|Class|BaseClass)=(\w+)',project_text))
        assert set(roles)=={m.name for m in project.modules}
        records = bytearray(decompress_stream(ole.openstream([ROOT,'VBA','dir']).read()))
        position = 0
        for m in project.modules:
            name = m.name.encode('cp1252')
            name_rec = struct.pack('<HI',0x19,len(name))+name
            start = records.index(name_rec,position)
            off_rec = struct.pack('<HII',0x31,4,m.textoffset)
            end = records.index(struct.pack('<HI',0x2b,0),start+len(name_rec))
            assert records[start:end].count(off_rec)==1
            place = records.index(off_rec,start,end)+6
            records[place:place+4] = bytes(4)
            position=end+6
            row=dict(name=m.name,role=roles[m.name],stream=m.code_path.split('/'),
                     file='vba/'+m.filename,original_text_offset=m.textoffset,dir_offset_field=place)
            assert decompress_stream(ole.openstream(m.code_path).read()[m.textoffset:])==m.code_raw
            if roles[m.name]=='BaseClass':
                frm,frx,info = export_frx(ole,m,scratch)
                row['form']=dict(file='vba/'+m.name+'.frx',type_info_line=info)
                hidden=[]
                for i,line in enumerate(m.code_raw.split(b'\r\n')):
                    if re.match(rb'^Attribute VB_(?:Base|TemplateDerived|Customizable) =',line):
                        hidden.append(dict(index=i,line=line.decode('cp1252')))
                        assert frm.count(line+b'\r\n')==1
                        frm=frm.replace(line+b'\r\n',b'')
                row['form']['native_attributes']=hidden
                put(row['file'],frm)
                put(row['form']['file'],frx)
            else:
                put(row['file'],m.code_raw)
            manifest['modules'].append(row)
        put('project/dir.records', bytes(records))
        rows=workbook(ole.openstream('Workbook').read())
        dump(stage/'workbook.json',rows)
        for p in ole.listdir():
            if p==['Workbook'] or p[:2]==[ROOT,'VBA']:
                continue
            if len(p)>2 and p[1] in roles and roles[p[1]]=='BaseClass' and p[2:]!=['\x01CompObj']:
                continue
            name=p[-1]
            if ord(name[0])<32:
                name=f'{ord(name[0]):02x}_'+name[1:]
            path='/'.join(['project',*p[:-1],name])
            if name=='PROJECT':
                path+='.txt'
            put(path,ole.openstream(p).read())
            manifest['resources'].append(dict(path=p,file=path))
        assert not ole.parsing_issues
    dump(stage/'project.json',manifest)
    shutil.copyfile(Path(pack_project.__file__),stage/'pack_project.py')


if __name__=='__main__':
    export(*(Path(s) for s in sys.argv[1:]))

