VERSION 5.00
Begin {C62A69F0-16DC-11CE-9E98-00AA00574A4F} frmSelectUnits 
   Caption         =   "Select Units"
   ClientHeight    =   6960
   ClientLeft      =   45
   ClientTop       =   375
   ClientWidth     =   6945
   OleObjectBlob   =   "frmSelectUnits.frx":0000
   StartUpPosition =   1  'CenterOwner
End
Attribute VB_Name = "frmSelectUnits"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub btnCancel_Click()
Me.Hide
End Sub

Private Sub btnHelp_Click()
Call COMAddinHelper.ShowHelp("40300")
End Sub

Private Sub btnOK_Click()
    Dim r As Range
    Dim toProperty As String
    Dim toUnit As String
    
    If Me.lstUnit.ListIndex < 0 Then Exit Sub
    If bSpecifyUnit = True Then
        toProperty = Me.lstProperty.list(Me.lstProperty.ListIndex)
        toUnit = Me.lstUnit.list(Me.lstUnit.ListIndex)
        Call SetUnitText(toProperty, toUnit)
        Hide
        Exit Sub
    End If
        
    If bConvertUnit = True Then
        toProperty = Me.lstProperty.list(Me.lstProperty.ListIndex)
        toUnit = Me.lstUnit.list(Me.lstUnit.ListIndex)
        Call subConvertUnit(toProperty, toUnit)
        Hide
        Exit Sub
    End If
        
    Set r = Application.Selection.Cells(1, 1)
    r.value = Me.lstUnit.list(Me.lstUnit.ListIndex)
    
    Hide
End Sub

Private Sub lstProperty_Change()
    If (lstProperty.ListIndex = -1) Then
        Exit Sub
    End If
    
    Dim iBlkNum As Integer
    Dim bFound As Boolean
    
    Call CheckUnitArray

    iBlkNum = arrProp(lstProperty.ListIndex, 0)
    lstUnit.Clear
    For i = LBound(arrUnit, 2) To UBound(arrUnit, 2)
        If iBlkNum = arrUnit(0, i) Then
            bFound = False
            For j = 0 To lstUnit.ListCount - 1
                If lstUnit.list(lstUnit.ListIndex + 1) = arrUnit(1, i) Then bFound = True
            Next j
            If Not bFound Then lstUnit.AddItem arrUnit(1, i)
        End If
    Next i
End Sub
