Attribute VB_Name = "VBConstantsFlashReturnTP3"
Attribute VB_Base = "0{FCFB3D2A-A0FA-1068-A738-08002B3371B5}"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = True
Attribute VB_TemplateDerived = False
Attribute VB_Customizable = False
Option Explicit
Option Base 1

Public Enum FlashReturnTP3
    tp3_VaporFraction = out_VaporFraction
    tp3_Enthalpy = out_Enthalpy
    tp3_Beta = out_Beta
    tp3_X1 = out_X1
    tp3_X2 = OUT_X2
    tp3_Y = out_Y
    tp3_SFRAC = out_SFRAC
End Enum

Public Function GetValues() As Long()

    Dim list() As Long
    
    ReDim list(7)
    list(1) = VaporFraction
    list(2) = Enthalpy
    list(3) = Beta
    list(4) = X1
    list(5) = X2
    list(6) = Y
    list(7) = SFRAC
    GetValues = list
    
End Function

Public Property Get VaporFraction() As Long
    VaporFraction = tp3_VaporFraction
End Property

Public Property Get Enthalpy() As Long
    Enthalpy = tp3_Enthalpy
End Property

Public Property Get Beta() As Long
    Beta = tp3_Beta
End Property

Public Property Get X1() As Long
    X1 = tp3_X1
End Property

Public Property Get X2() As Long
    X2 = tp3_X2
End Property

Public Property Get Y() As Long
    Y = tp3_Y
End Property

Public Property Get SFRAC() As Long
    SFRAC = tp3_SFRAC
End Property

